# pre - Social Connection App PRD

## Original Problem Statement
Building a clean, production-ready iOS-first social app called "pre" with:
- Dorsia-style design guide (premium monochrome aesthetic)
- Supabase backend (Auth + Postgres + Storage)
- Real working flows (no dead buttons, no placeholder profiles)
- Structure ready for iOS via Capacitor

## User Personas
1. **Young Adults (18-25)**: University students looking for genuine friendships
2. **Community Builders**: People who want to create and manage social circles
3. **Event Enthusiasts**: Users seeking local meetups and group activities

## Core Requirements (Static)
- Next.js framework with App Router
- Supabase integration (Auth + Postgres + Storage)
- Light/Dark/AMOLED theme modes
- Monochrome-first Malibu aesthetic with Pacifico brand font
- 9-step onboarding flow
- Early Supporter badge system (first 250 users)
- Points & badges gamification

## What's Been Implemented (Phase 0)

### Date: Feb 4, 2026

**Completed:**
- [x] Next.js 14 project scaffold with TypeScript
- [x] Design system tokens (light/dark/AMOLED modes)
- [x] Supabase client setup (ready for credentials)
- [x] Auth context + session management
- [x] Theme context with persistence
- [x] Auth pages (Sign In / Sign Up)
- [x] 9-step Onboarding flow:
  1. Intro/Value prop
  2. Full name
  3. Username (optional, with availability check)
  4. User intent (multi-select)
  5. Interests (multi-select, min 3)
  6. Date of birth (18+ check)
  7. Location (manual + GPS)
  8. Theme selection
  9. Profile photo + bio
- [x] Home Hub with segmented tabs (Circles/People/Events)
- [x] Profile screen with stats
- [x] Settings with theme switcher + AMOLED toggle
- [x] Badges screen with progress
- [x] Safety & Verification screen
- [x] Notifications screen
- [x] Profile edit page
- [x] SQL migrations for all database tables
- [x] Comprehensive README with runbook

**Design Updates:**
- Updated to Pacifico cursive font for "pre" wordmark
- Malibu aesthetic color tokens
- 1px hairline borders (10% opacity)

## Prioritized Backlog

### P0 - Critical (Phase 1)
- [ ] Connect actual Supabase credentials
- [ ] Implement auth with email confirmation
- [ ] Profile data persistence
- [ ] Early supporter number assignment (concurrency-safe)
- [ ] Avatar upload to Supabase Storage

### P1 - High Priority (Phase 2)
- [ ] Circles CRUD operations
- [ ] Events CRUD operations
- [ ] Join/Leave circles
- [ ] RSVP to events
- [ ] Circle chat messaging

### P2 - Medium Priority (Phase 3)
- [ ] Points ledger implementation
- [ ] Badge progression system
- [ ] Real-time notifications
- [ ] Report/Block functionality
- [ ] Referral system with codes

### P3 - Future (Phase 4)
- [ ] Capacitor iOS packaging
- [ ] Push notifications
- [ ] App Store submission
- [ ] Video calls within circles
- [ ] Map view for events

## Technical Architecture

```
/app/pre/
├── src/
│   ├── app/                 # Next.js App Router
│   │   ├── auth/           # Authentication pages
│   │   ├── onboarding/     # 9-step flow
│   │   ├── home/           # Main hub
│   │   ├── profile/        # User profile + edit
│   │   ├── settings/       # App settings
│   │   ├── badges/         # Achievements
│   │   ├── safety/         # Verification
│   │   └── notifications/  # Feed
│   ├── components/
│   │   ├── ui/             # Base components
│   │   ├── providers/      # Context providers
│   │   ├── home/           # Home components
│   │   └── onboarding/     # Onboarding steps
│   ├── lib/
│   │   ├── supabase/       # Client configs
│   │   └── utils.ts        # Helpers
│   └── types/              # TypeScript types
├── supabase/
│   └── migrations/         # SQL schema
└── README.md               # Runbook
```

## Database Schema
- profiles (with early_supporter_number)
- circles
- circle_members
- events
- event_attendees
- messages
- badges
- user_badges
- notifications
- reports
- blocks
- referrals
- points_ledger

## Next Tasks
1. User provides Supabase credentials
2. Run migrations in Supabase SQL Editor
3. Connect real auth
4. Test full sign-up → onboarding → home flow
5. Implement avatar upload
