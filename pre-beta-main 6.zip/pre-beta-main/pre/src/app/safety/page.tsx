'use client'

import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { ArrowLeft, Shield, AlertTriangle, UserX, Phone, CheckCircle } from 'lucide-react'
import Link from 'next/link'

export default function SafetyPage() {
  const { user, profile, loading, initialized } = useAuth()
  const router = useRouter()

  if (!initialized || loading) {
    return <LoadingScreen />
  }

  if (!user) {
    router.replace('/auth')
    return <LoadingScreen />
  }

  return (
    <div className="min-h-screen bg-surface-primary safe-top safe-bottom">
      {/* Header */}
      <header className="px-4 py-4 flex items-center justify-between border-b border-border-secondary">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">Safety</h1>
        <div className="w-9" />
      </header>

      <main className="px-4 py-6">
        <div className="max-w-md mx-auto space-y-6">
          {/* Verification Status */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                  profile?.is_verified ? 'bg-success/10' : 'bg-surface-tertiary'
                }`}>
                  {profile?.is_verified ? (
                    <CheckCircle className="h-5 w-5 text-success" />
                  ) : (
                    <Shield className="h-5 w-5 text-content-tertiary" />
                  )}
                </div>
                <div>
                  <CardTitle>
                    {profile?.is_verified ? 'Verified' : 'Not Verified'}
                  </CardTitle>
                  <CardDescription>
                    {profile?.is_verified
                      ? `Verified via ${profile.verification_type}`
                      : 'Verify your identity for a trusted profile'}
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            {!profile?.is_verified && (
              <CardContent>
                <Button variant="secondary" className="w-full" disabled>
                  Verify Identity (Coming soon)
                </Button>
              </CardContent>
            )}
          </Card>

          {/* Report & Block */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-warning" />
                Report or Block
              </CardTitle>
              <CardDescription>
                Having issues with someone? We're here to help.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button variant="secondary" className="w-full" disabled>
                <AlertTriangle className="h-4 w-4" />
                Report a User (Coming soon)
              </Button>
              <Button variant="secondary" className="w-full" disabled>
                <UserX className="h-4 w-4" />
                Blocked Users (Coming soon)
              </Button>
            </CardContent>
          </Card>

          {/* Emergency Contacts */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Phone className="h-5 w-5 text-content-primary" />
                Emergency Contacts
              </CardTitle>
              <CardDescription>
                Set up trusted contacts who can be notified in emergencies.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="secondary" className="w-full" disabled>
                Add Emergency Contact (Coming soon)
              </Button>
            </CardContent>
          </Card>

          {/* Safety Tips */}
          <div className="p-4 rounded-card bg-surface-secondary border border-border-secondary">
            <h3 className="text-headline text-content-primary mb-3">Safety Tips</h3>
            <ul className="space-y-2 text-callout text-content-secondary">
              <li>• Always meet in public places for first meetups</li>
              <li>• Tell a friend where you're going</li>
              <li>• Trust your instincts - if something feels off, leave</li>
              <li>• Keep personal info private until you trust someone</li>
            </ul>
          </div>
        </div>
      </main>
    </div>
  )
}