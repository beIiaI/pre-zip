'use client'

import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { ArrowLeft, Award, Lock } from 'lucide-react'

// Badge definitions
const BADGES = [
  {
    id: 'early_supporter',
    name: 'Early Supporter',
    description: 'One of the first 250 members to join pre',
    icon: '⭐',
    category: 'special',
    earnable: false,
  },
  {
    id: 'initiator',
    name: 'Initiator',
    description: 'Hosted your first public event',
    icon: '🎯',
    category: 'events',
    earnable: true,
  },
  {
    id: 'social_butterfly',
    name: 'Social Butterfly',
    description: 'Attended 5 events in one month',
    icon: '🦋',
    category: 'events',
    earnable: true,
  },
  {
    id: 'community_pillar',
    name: 'Community Pillar',
    description: 'Hosted 10+ successful events with high attendance',
    icon: '🏛️',
    category: 'events',
    earnable: true,
  },
  {
    id: 'ambassador',
    name: 'Ambassador',
    description: 'Referred 5 friends who completed onboarding',
    icon: '🌟',
    category: 'referrals',
    earnable: true,
  },
  {
    id: 'connector',
    name: 'Connector',
    description: 'Referred 10 friends who completed onboarding',
    icon: '🔗',
    category: 'referrals',
    earnable: true,
  },
  {
    id: 'founders_pre',
    name: "Founders' pre",
    description: 'Exclusive badge for early ambassadors',
    icon: '👑',
    category: 'special',
    earnable: false,
  },
]

export default function BadgesPage() {
  const { user, profile, loading, initialized } = useAuth()
  const router = useRouter()

  if (!initialized || loading) {
    return <LoadingScreen />
  }

  if (!user) {
    router.replace('/auth')
    return <LoadingScreen />
  }

  // TODO: Fetch actual earned badges from Supabase
  const earnedBadges: string[] = profile?.early_supporter_number ? ['early_supporter'] : []

  return (
    <div className="min-h-screen bg-surface-primary safe-top safe-bottom">
      {/* Header */}
      <header className="px-4 py-4 flex items-center justify-between border-b border-border-secondary">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">Badges</h1>
        <div className="w-9" />
      </header>

      <main className="px-4 py-6">
        <div className="max-w-md mx-auto space-y-6">
          {/* Points Summary */}
          <Card>
            <CardContent className="pt-4 flex items-center justify-center gap-4">
              <Award className="h-8 w-8 text-content-primary" />
              <div>
                <p className="text-display text-content-primary">{profile?.total_points || 0}</p>
                <p className="text-callout text-content-secondary">Total Points</p>
              </div>
            </CardContent>
          </Card>

          {/* Earned Badges */}
          {earnedBadges.length > 0 && (
            <section className="space-y-4">
              <h2 className="text-headline text-content-primary">Earned</h2>
              <div className="grid gap-4">
                {BADGES.filter(b => earnedBadges.includes(b.id)).map((badge) => (
                  <Card key={badge.id} className="bg-surface-secondary">
                    <CardHeader>
                      <div className="flex items-center gap-4">
                        <div className="h-12 w-12 rounded-full bg-surface-primary flex items-center justify-center text-2xl border border-border-secondary">
                          {badge.icon}
                        </div>
                        <div>
                          <CardTitle>{badge.name}</CardTitle>
                          <CardDescription>{badge.description}</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                  </Card>
                ))}
              </div>
            </section>
          )}

          {/* Available Badges */}
          <section className="space-y-4">
            <h2 className="text-headline text-content-primary">Available</h2>
            <div className="grid gap-4">
              {BADGES.filter(b => !earnedBadges.includes(b.id) && b.earnable).map((badge) => (
                <Card key={badge.id} className="opacity-60">
                  <CardHeader>
                    <div className="flex items-center gap-4">
                      <div className="h-12 w-12 rounded-full bg-surface-tertiary flex items-center justify-center text-2xl border border-border-secondary">
                        {badge.icon}
                      </div>
                      <div className="flex-1">
                        <CardTitle>{badge.name}</CardTitle>
                        <CardDescription>{badge.description}</CardDescription>
                      </div>
                      <Lock className="h-5 w-5 text-content-tertiary" />
                    </div>
                  </CardHeader>
                </Card>
              ))}
            </div>
          </section>

          {/* Special Badges */}
          <section className="space-y-4">
            <h2 className="text-headline text-content-primary">Special</h2>
            <div className="grid gap-4">
              {BADGES.filter(b => !earnedBadges.includes(b.id) && !b.earnable).map((badge) => (
                <Card key={badge.id} className="opacity-40">
                  <CardHeader>
                    <div className="flex items-center gap-4">
                      <div className="h-12 w-12 rounded-full bg-surface-tertiary flex items-center justify-center text-2xl border border-border-secondary">
                        {badge.icon}
                      </div>
                      <div className="flex-1">
                        <CardTitle>{badge.name}</CardTitle>
                        <CardDescription>{badge.description}</CardDescription>
                      </div>
                      <Lock className="h-5 w-5 text-content-tertiary" />
                    </div>
                  </CardHeader>
                </Card>
              ))}
            </div>
          </section>
        </div>
      </main>
    </div>
  )
}