'use client'

import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { ArrowLeft, Bell } from 'lucide-react'

export default function NotificationsPage() {
  const { user, loading, initialized } = useAuth()
  const router = useRouter()

  if (!initialized || loading) {
    return <LoadingScreen />
  }

  if (!user) {
    router.replace('/auth')
    return <LoadingScreen />
  }

  // TODO: Fetch notifications from Supabase
  const notifications: any[] = []

  return (
    <div className="min-h-screen bg-surface-primary safe-top safe-bottom">
      {/* Header */}
      <header className="px-4 py-4 flex items-center justify-between border-b border-border-secondary">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">Notifications</h1>
        <div className="w-9" />
      </header>

      <main className="px-4 py-6">
        {notifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="h-16 w-16 rounded-full bg-surface-secondary flex items-center justify-center mb-4">
              <Bell className="h-8 w-8 text-content-tertiary" />
            </div>
            <h3 className="text-headline text-content-primary mb-2">No notifications</h3>
            <p className="text-body text-content-secondary max-w-xs">
              You're all caught up! Check back later for updates.
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {notifications.map((notification) => (
              <div
                key={notification.id}
                className="p-4 rounded-card bg-surface-secondary border border-border-secondary"
              >
                <p className="text-body text-content-primary">{notification.title}</p>
                {notification.body && (
                  <p className="text-callout text-content-secondary mt-1">{notification.body}</p>
                )}
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}