'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { HomeHeader } from '@/components/home/header'
import { HomeTabs } from '@/components/home/tabs'

export default function HomePage() {
  const { user, profile, loading, initialized } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!initialized) return

    if (!user) {
      router.replace('/auth')
    } else if (!profile?.onboarding_completed) {
      router.replace('/onboarding')
    }
  }, [user, profile, initialized, router])

  if (!initialized || loading) {
    return <LoadingScreen message="Loading..." />
  }

  if (!user || !profile) {
    return <LoadingScreen />
  }

  return (
    <div className="min-h-screen bg-surface-primary safe-top safe-bottom">
      <HomeHeader profile={profile} />
      <main className="px-4 py-4">
        <HomeTabs />
      </main>
    </div>
  )
}