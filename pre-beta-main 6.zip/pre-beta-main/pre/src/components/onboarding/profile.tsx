'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar } from '@/components/ui/avatar'
import { OnboardingLayout } from './layout'
import { Camera, Loader2 } from 'lucide-react'

interface Props {
  bio: string
  avatarUrl?: string
  onChangeBio: (bio: string) => void
  onChangeAvatar: (url: string) => void
  onComplete: () => void
  onBack: () => void
}

export function OnboardingProfile({ bio, avatarUrl, onChangeBio, onChangeAvatar, onComplete, onBack }: Props) {
  const [loading, setLoading] = useState(false)
  const [uploading, setUploading] = useState(false)

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Validate file
    if (!file.type.startsWith('image/')) {
      alert('Please select an image file')
      return
    }
    if (file.size > 5 * 1024 * 1024) {
      alert('Image must be less than 5MB')
      return
    }

    setUploading(true)

    // For now, create a local preview URL
    // In production, this would upload to Supabase Storage
    const url = URL.createObjectURL(file)
    onChangeAvatar(url)
    setUploading(false)
  }

  const handleComplete = async () => {
    setLoading(true)
    try {
      await onComplete()
    } catch (error) {
      console.error('Error completing onboarding:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <OnboardingLayout
      step={9}
      totalSteps={9}
      title="Complete your profile"
      subtitle="Add a photo and bio. You can always change these later."
      onBack={onBack}
    >
      <div className="space-y-8">
        {/* Avatar Upload */}
        <div className="flex flex-col items-center space-y-4">
          <div className="relative">
            <Avatar src={avatarUrl} size="xl" />
            <label
              className="absolute bottom-0 right-0 h-8 w-8 rounded-full bg-content-primary flex items-center justify-center cursor-pointer border-2 border-surface-primary"
            >
              {uploading ? (
                <Loader2 className="h-4 w-4 animate-spin text-content-inverse" />
              ) : (
                <Camera className="h-4 w-4 text-content-inverse" />
              )}
              <input
                type="file"
                accept="image/*"
                onChange={handleAvatarChange}
                className="hidden"
                data-testid="onboarding-avatar-input"
              />
            </label>
          </div>
          <p className="text-caption text-content-secondary">Tap to add a photo</p>
        </div>

        {/* Bio */}
        <div className="space-y-2">
          <label className="text-callout font-medium text-content-primary">Bio</label>
          <textarea
            placeholder="Tell us a bit about yourself..."
            value={bio}
            onChange={(e) => onChangeBio(e.target.value)}
            maxLength={200}
            rows={4}
            className="flex w-full rounded-input border bg-surface-secondary px-4 py-3 text-body text-content-primary placeholder:text-content-tertiary border-border-primary focus:border-border-focus focus:outline-none focus:ring-1 focus:ring-border-focus resize-none"
            data-testid="onboarding-bio-input"
          />
          <p className="text-caption text-content-tertiary text-right">
            {bio.length}/200
          </p>
        </div>

        {/* Complete Button */}
        <Button
          className="w-full"
          size="lg"
          onClick={handleComplete}
          loading={loading}
          data-testid="onboarding-complete-button"
        >
          Complete Profile
        </Button>
      </div>
    </OnboardingLayout>
  )
}