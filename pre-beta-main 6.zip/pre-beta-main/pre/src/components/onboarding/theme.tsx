'use client'

import { Button } from '@/components/ui/button'
import { SegmentedControl } from '@/components/ui/segmented-control'
import { Toggle } from '@/components/ui/toggle'
import { OnboardingLayout } from './layout'
import { useTheme } from '@/components/providers/theme-provider'
import { useEffect } from 'react'

interface Props {
  mode: 'light' | 'dark' | 'system'
  amoled: boolean
  onChangeMode: (mode: 'light' | 'dark' | 'system') => void
  onChangeAmoled: (amoled: boolean) => void
  onNext: () => void
  onBack: () => void
}

export function OnboardingTheme({ mode, amoled, onChangeMode, onChangeAmoled, onNext, onBack }: Props) {
  const { setMode, setAmoledEnabled, resolvedTheme } = useTheme()

  // Apply theme changes immediately for preview
  useEffect(() => {
    setMode(mode)
    setAmoledEnabled(amoled)
  }, [mode, amoled, setMode, setAmoledEnabled])

  const showAmoledToggle = mode === 'dark' || (mode === 'system' && resolvedTheme === 'dark')

  return (
    <OnboardingLayout
      step={8}
      totalSteps={9}
      title="Choose your theme"
      subtitle="Customize how pre looks and feels."
      onBack={onBack}
    >
      <div className="space-y-8">
        {/* Theme Mode */}
        <div className="space-y-4">
          <label className="text-callout font-medium text-content-primary">Appearance</label>
          <SegmentedControl
            options={[
              { value: 'light', label: 'Light' },
              { value: 'dark', label: 'Dark' },
              { value: 'system', label: 'System' },
            ]}
            value={mode}
            onChange={(v) => onChangeMode(v as 'light' | 'dark' | 'system')}
          />
        </div>

        {/* AMOLED Toggle */}
        {showAmoledToggle && (
          <div className="p-4 rounded-card bg-surface-secondary border border-border-secondary">
            <Toggle
              enabled={amoled}
              onChange={onChangeAmoled}
              label="AMOLED Dark Mode"
              description="Pure black backgrounds for OLED displays"
            />
          </div>
        )}

        {/* Preview */}
        <div className="space-y-3">
          <label className="text-callout font-medium text-content-secondary">Preview</label>
          <div className="p-4 rounded-card bg-surface-secondary border border-border-secondary space-y-3">
            <div className="h-3 w-3/4 bg-surface-tertiary rounded" />
            <div className="h-3 w-1/2 bg-surface-tertiary rounded" />
            <div className="flex gap-2 mt-4">
              <div className="h-8 w-16 bg-content-primary rounded-button" />
              <div className="h-8 w-16 bg-surface-tertiary rounded-button border border-border-primary" />
            </div>
          </div>
        </div>

        <Button
          className="w-full"
          size="lg"
          onClick={onNext}
          data-testid="onboarding-theme-next"
        >
          Continue
        </Button>
      </div>
    </OnboardingLayout>
  )
}