'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Users, Plus } from 'lucide-react'

export function CirclesTab() {
  // TODO: Fetch circles from Supabase
  const circles: any[] = []

  if (circles.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <div className="h-16 w-16 rounded-full bg-surface-secondary flex items-center justify-center mb-4">
          <Users className="h-8 w-8 text-content-tertiary" />
        </div>
        <h3 className="text-headline text-content-primary mb-2">No circles yet</h3>
        <p className="text-body text-content-secondary mb-6 max-w-xs">
          Join circles to connect with people who share your interests.
        </p>
        <Button data-testid="circles-explore-button">
          <Plus className="h-4 w-4" />
          Explore Circles
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {circles.map((circle) => (
        <Card key={circle.id}>
          <CardHeader>
            <CardTitle>{circle.name}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-callout text-content-secondary">{circle.description}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}