'use client'

import Link from 'next/link'
import { Avatar } from '@/components/ui/avatar'
import { Bell, Settings } from 'lucide-react'
import type { Profile } from '@/types/database'
import { formatEarlySupporterNumber } from '@/lib/utils'

interface Props {
  profile: Profile
}

export function HomeHeader({ profile }: Props) {
  return (
    <header className="px-4 py-4 border-b border-border-secondary">
      <div className="flex items-center justify-between">
        {/* Logo */}
        <h1 className="font-brand text-2xl text-content-primary">pre</h1>

        {/* Actions */}
        <div className="flex items-center gap-2">
          {/* Notifications */}
          <Link
            href="/notifications"
            className="p-2 rounded-full hover:bg-accent-muted transition-colors relative"
            data-testid="home-notifications-link"
          >
            <Bell className="h-5 w-5 text-content-primary" />
          </Link>

          {/* Settings */}
          <Link
            href="/settings"
            className="p-2 rounded-full hover:bg-accent-muted transition-colors"
            data-testid="home-settings-link"
          >
            <Settings className="h-5 w-5 text-content-primary" />
          </Link>

          {/* Profile */}
          <Link
            href="/profile"
            className="flex items-center gap-2 pl-2"
            data-testid="home-profile-link"
          >
            <Avatar src={profile.avatar_url} size="sm" />
            {profile.early_supporter_number && (
              <span className="text-caption text-content-secondary font-medium">
                {formatEarlySupporterNumber(profile.early_supporter_number)}
              </span>
            )}
          </Link>
        </div>
      </div>
    </header>
  )
}