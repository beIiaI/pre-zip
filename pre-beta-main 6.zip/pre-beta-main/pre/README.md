# pre

A clean, production-ready iOS-first social app for connecting people globally through genuine friendships.

## Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Styling**: Tailwind CSS with custom design tokens
- **Backend**: Supabase (Auth + Postgres + Storage)
- **Language**: TypeScript
- **Future**: Capacitor for iOS packaging

## Getting Started

### Prerequisites

- Node.js 18+
- npm or yarn
- Supabase account (for backend)

### Environment Setup

1. Copy the example env file:
   ```bash
   cp .env.local.example .env.local
   ```

2. Add your Supabase credentials to `.env.local`:
   ```
   NEXT_PUBLIC_SUPABASE_URL=your-project-url
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
   ```

### Database Setup

1. Go to your Supabase project dashboard
2. Navigate to SQL Editor
3. Run the migration file: `supabase/migrations/001_initial_schema.sql`

### Running Locally

```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Building for Production

```bash
npm run build
npm start
```

## Project Structure

```
src/
├── app/                    # Next.js App Router pages
│   ├── auth/               # Authentication pages
│   ├── onboarding/         # Onboarding flow
│   ├── home/               # Main app hub
│   ├── profile/            # User profile
│   ├── settings/           # App settings
│   ├── badges/             # Badges & points
│   ├── safety/             # Safety features
│   └── notifications/      # Notifications feed
├── components/             # React components
│   ├── ui/                 # Base UI components
│   ├── providers/          # Context providers
│   ├── home/               # Home page components
│   └── onboarding/         # Onboarding steps
├── lib/                    # Utilities
│   ├── supabase/           # Supabase clients
│   └── utils.ts            # Helper functions
└── types/                  # TypeScript types
    ├── database.ts         # Supabase schema types
    └── index.ts            # App types
```

## Design System

The app uses a premium monochrome design system with:

- **Typography Scale**: 32/22/18/16/14/12px
- **System Font**: SF Pro (or equivalent)
- **Color Palette**: Monochrome-first with minimal accents
- **Theme Modes**: Light, Dark, AMOLED
- **Spacing Grid**: 12/16px base
- **Components**: Hairline borders, pill chips, subtle shadows

Design tokens are defined in:
- `tailwind.config.ts` - Tailwind theme extensions
- `src/app/globals.css` - CSS custom properties

## Features

### Phase 0 (Current)
- [x] Project scaffold
- [x] Design system tokens
- [x] Auth flow (sign in/up)
- [x] Onboarding flow (9 steps)
- [x] Profile screen
- [x] Settings with theme switcher
- [x] Badges & points screen
- [x] Safety screen
- [x] Notifications screen
- [x] Database schema

### Phase 1 (Next)
- [ ] Connect Supabase backend
- [ ] Real auth with email confirmation
- [ ] Profile data persistence
- [ ] Onboarding state sync
- [ ] Early supporter number assignment

### Phase 2 (Later)
- [ ] Circles CRUD
- [ ] Events CRUD
- [ ] Join/Leave circles
- [ ] RSVP to events
- [ ] Profile editing with upload
- [ ] Circle chat

### Phase 3 (Future)
- [ ] Points system
- [ ] Badge progression
- [ ] Notifications
- [ ] Report/Block
- [ ] Referral system

### Phase 4 (iOS)
- [ ] Capacitor setup
- [ ] iOS packaging
- [ ] Push notifications
- [ ] App Store submission

## Testing Flows

### Auth Flow
1. Visit `/auth`
2. Sign up with email/password
3. Check email for confirmation (if enabled)
4. Sign in

### Onboarding Flow
1. After auth, redirects to `/onboarding`
2. Complete 9 steps:
   - Intro
   - Full name
   - Username (optional)
   - Intent selection
   - Interest selection (min 3)
   - Date of birth (18+)
   - Location
   - Theme selection
   - Profile photo & bio
3. Redirects to `/home`

### Home Hub
- View Circles/People/Events tabs
- Navigate to profile, settings, notifications
- Empty states shown until backend connected

## Capacitor iOS Setup (Phase 4)

```bash
# Install Capacitor
npm install @capacitor/core @capacitor/ios

# Initialize Capacitor
npx cap init pre com.yourcompany.pre

# Add iOS platform
npx cap add ios

# Build Next.js
npm run build

# Copy to native project
npx cap copy ios

# Open in Xcode
npx cap open ios
```

## License

Private - All rights reserved.