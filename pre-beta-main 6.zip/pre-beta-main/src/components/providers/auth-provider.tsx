'use client'

import { createContext, useContext, useEffect, useState, useCallback, useMemo, ReactNode, useRef } from 'react'
import { createClient } from '@/lib/supabase/client'
import type { User as SupabaseUser, Session } from '@supabase/supabase-js'
import type { Profile } from '@/types/database'

interface AuthContextType {
  user: SupabaseUser | null
  profile: Profile | null
  session: Session | null
  loading: boolean
  initialized: boolean
  profileLoaded: boolean
  signUp: (email: string, password: string) => Promise<{ error: Error | null }>
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>
  signOut: () => Promise<void>
  refreshProfile: () => Promise<Profile | null>
  updateProfile: (updates: Record<string, unknown>) => Promise<{ error: Error | null; profile?: Profile | null }>
  setProfileState: (profile: Profile | null) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

const PROFILE_RESOLVE_TIMEOUT_MS = 8000

async function withTimeout<T>(promise: Promise<T>, timeoutMs: number, fallbackValue: T): Promise<T> {
  let timeoutId: ReturnType<typeof setTimeout> | null = null

  try {
    return await Promise.race([
      promise,
      new Promise<T>((resolve) => {
        timeoutId = setTimeout(() => resolve(fallbackValue), timeoutMs)
      }),
    ])
  } finally {
    if (timeoutId) {
      clearTimeout(timeoutId)
    }
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<SupabaseUser | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [loading, setLoading] = useState(true)
  const [initialized, setInitialized] = useState(false)
  const [profileLoaded, setProfileLoaded] = useState(false)
  
  // Use ref to get stable supabase client
  const supabaseRef = useRef(createClient())
  const supabase = supabaseRef.current

  const ensureProfile = useCallback(async (authUser: SupabaseUser | null): Promise<Profile | null> => {
    if (!authUser) return null
    try {
      const response = await fetch('/api/profile/ensure', {
        method: 'POST',
        credentials: 'include',
        cache: 'no-store',
      })
      if (response.ok) {
        const data = await response.json()
        return (data.profile as Profile) ?? null
      }

      // Fallback: attempt client insert if server route fails
      const email = authUser.email ?? (authUser.user_metadata?.email as string | undefined)
      if (!email) return null

      const { data: inserted, error } = await supabase
        .from('profiles')
        .insert({ id: authUser.id, email })
        .select()
        .maybeSingle()

      if (error) {
        return null
      }

      return (inserted as Profile) ?? null
    } catch {
      return null
    }
  }, [supabase])

  // Fetch profile for user with retry logic
  const fetchProfile = useCallback(async (userId: string, retries = 3): Promise<Profile | null> => {
    for (let i = 0; i < retries; i++) {
      try {
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', userId)
          .single()

        if (error) {
          // Profile doesn't exist yet - this is OK for new users
          if (error.code === 'PGRST116') {
            // Wait a bit and retry - profile might be being created by trigger
            if (i < retries - 1) {
              await new Promise(resolve => setTimeout(resolve, 500 * (i + 1)))
              continue
            }
            return null
          }
          return null
        }

        return data as Profile
      } catch {
        if (i < retries - 1) {
          await new Promise(resolve => setTimeout(resolve, 500 * (i + 1)))
          continue
        }
        return null
      }
    }
    return null
  }, [supabase])

  const resolveProfile = useCallback(async (authUser: SupabaseUser): Promise<Profile | null> => {
    const fetchedProfile = await withTimeout(fetchProfile(authUser.id), PROFILE_RESOLVE_TIMEOUT_MS, null)
    if (fetchedProfile) {
      return fetchedProfile
    }

    return withTimeout(ensureProfile(authUser), PROFILE_RESOLVE_TIMEOUT_MS, null)
  }, [fetchProfile, ensureProfile])

  // Initialize auth state
  useEffect(() => {
    let mounted = true
    
    const initAuth = async () => {
      try {
        const { data: { session: initialSession } } = await supabase.auth.getSession()
        
        if (!mounted) return
        
        if (initialSession?.user) {
          setUser(initialSession.user)
          setSession(initialSession)
          setProfileLoaded(false)
          const userProfile = await resolveProfile(initialSession.user)
          if (mounted) {
            setProfile(userProfile)
            setProfileLoaded(true)
          }
        } else {
          setProfileLoaded(true)
        }
    } catch {
      if (mounted) {
        setProfileLoaded(true)
      }
      } finally {
        if (mounted) {
          setLoading(false)
          setInitialized(true)
        }
      }
    }

    initAuth()

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, currentSession) => {
        if (!mounted) return
        
        setSession(currentSession)
        setUser(currentSession?.user ?? null)

        if (event === 'TOKEN_REFRESHED' || event === 'INITIAL_SESSION') {
          setLoading(false)
          return
        }

        if (currentSession?.user) {
          setProfileLoaded(false)
          const userProfile = await resolveProfile(currentSession.user)
          if (mounted) {
            setProfile(userProfile)
            setProfileLoaded(true)
          }
        } else {
          setProfile(null)
          setProfileLoaded(true)
        }

        setLoading(false)
      }
    )

    return () => {
      mounted = false
      subscription.unsubscribe()
    }
  }, [supabase, resolveProfile])

  const hydrateFromSession = useCallback(async () => {
    const {
      data: { session: refreshedSession },
    } = await supabase.auth.getSession()

    setSession(refreshedSession)
    setUser(refreshedSession?.user ?? null)

    if (refreshedSession?.user) {
      setProfileLoaded(false)
      const userProfile = await resolveProfile(refreshedSession.user)
      setProfile(userProfile)
      setProfileLoaded(true)
    }
  }, [supabase, resolveProfile])

  const signUp = async (email: string, password: string) => {
    setLoading(true)
    const attemptDirectClientSignUp = async () => {
      const redirectOrigin = typeof window !== 'undefined'
        ? window.location.origin
        : process.env.NEXT_PUBLIC_SITE_URL || ''
      const redirectTo = redirectOrigin
        ? `${redirectOrigin}/auth/callback?next=${encodeURIComponent('/onboarding')}`
        : undefined

      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: redirectTo
          ? {
              emailRedirectTo: redirectTo,
            }
          : undefined,
      })

      if (error) {
        return { error: new Error(error.message || 'Unable to create account') }
      }
      return { error: null }
    }
    try {
      const response = await fetch('/api/auth/sign-up', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
        credentials: 'include',
        cache: 'no-store',
      })
      const data = await response.json().catch(() => ({}))
      if (!response.ok) {
        const message = (data?.error as string) || 'Unable to create account'
        const shouldFallbackToClient =
          message.toLowerCase().includes('unable to create account') ||
          message.toLowerCase().includes('operation was aborted') ||
          message.toLowerCase().includes('internal') ||
          message.toLowerCase().includes('try again in a moment')
        if (shouldFallbackToClient) {
          const fallback = await attemptDirectClientSignUp()
          if (!fallback.error) {
            return fallback
          }
          return { error: fallback.error }
        }
        return { error: new Error(message) }
      }
      return { error: null }
    } catch (err) {
      const fallback = await attemptDirectClientSignUp()
      if (!fallback.error) {
        return fallback
      }
      return { error: fallback.error ?? (err as Error) }
    } finally {
      setLoading(false)
    }
  }

  const signIn = async (email: string, password: string) => {
    setLoading(true)
    const attemptDirectClientSignIn = async () => {
      const { error } = await supabase.auth.signInWithPassword({ email, password })
      if (error) {
        return { error: new Error(error.message || 'Could not authenticate user') }
      }
      await hydrateFromSession()
      return { error: null }
    }
    try {
      const response = await fetch('/api/auth/sign-in', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
        credentials: 'include',
        cache: 'no-store',
      })
      const data = await response.json().catch(() => ({}))
      if (!response.ok) {
        const message = (data?.error as string) || 'Email or password is incorrect'
        if (message.toLowerCase().includes('operation was aborted')) {
          return attemptDirectClientSignIn()
        }
        return { error: new Error(message) }
      }

      await hydrateFromSession()
      return { error: null }
    } catch (err) {
      // Safari occasionally aborts same-origin fetch requests while keeping network alive.
      // Fall back to direct Supabase client auth to avoid false negatives.
      const fallback = await attemptDirectClientSignIn()
      if (!fallback.error) {
        return fallback
      }
      return { error: fallback.error ?? (err as Error) }
    } finally {
      setLoading(false)
    }
  }

  const signOut = async () => {
    setLoading(true)
    try {
      await supabase.auth.signOut()
      setUser(null)
      setProfile(null)
      setSession(null)
      setProfileLoaded(true)
    } catch (error) {
      // no-op
    } finally {
      setLoading(false)
    }
  }

  const setProfileState = useCallback((nextProfile: Profile | null) => {
    setProfile(nextProfile)
    setProfileLoaded(true)
  }, [])

  const refreshProfile = useCallback(async (): Promise<Profile | null> => {
    if (user) {
      setProfileLoaded(false)
      try {
        const userProfile = await withTimeout(fetchProfile(user.id), PROFILE_RESOLVE_TIMEOUT_MS, null)
        if (userProfile) {
          setProfile(userProfile)
        }
        return userProfile
      } finally {
        setProfileLoaded(true)
      }
    }
    setProfileLoaded(true)
    return null
  }, [user, fetchProfile])

  const updateProfile = async (updates: Record<string, unknown>): Promise<{ error: Error | null; profile?: Profile | null }> => {
    if (!user) {
      return { error: new Error('No user logged in') }
    }

    try {
      const response = await fetch('/api/profile/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
        cache: 'no-store',
        credentials: 'include',
        keepalive: true,
      })

      const data = await response.json().catch(() => ({}))

      if (!response.ok) {
        const message = typeof data?.error === 'string' ? data.error : 'Update failed'
        return { error: new Error(message) }
      }

      const updatedProfile = (data.profile as Profile) ?? null
      if (updatedProfile) {
        setProfile(updatedProfile)
      }
      return { error: null, profile: updatedProfile }
    } catch (err) {
      return { error: err as Error }
    }
  }

  const contextValue = useMemo<AuthContextType>(() => ({
    user,
    profile,
    session,
    loading,
    initialized,
    profileLoaded,
    signUp,
    signIn,
    signOut,
    refreshProfile,
    updateProfile,
    setProfileState,
  }), [
    user,
    profile,
    session,
    loading,
    initialized,
    profileLoaded,
    signUp,
    signIn,
    signOut,
    refreshProfile,
    updateProfile,
    setProfileState,
    hydrateFromSession,
  ])

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  )
}

const defaultAuthContext: AuthContextType = {
  user: null,
  profile: null,
  session: null,
  loading: true,
  initialized: false,
  profileLoaded: false,
  signUp: async () => ({ error: null }),
  signIn: async () => ({ error: null }),
  signOut: async () => {},
  refreshProfile: async () => null,
  updateProfile: async () => ({ error: null }),
  setProfileState: () => {},
}

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext)
  // Return defaults if context is not yet available (hydration)
  if (context === undefined) {
    return defaultAuthContext
  }
  return context
}
