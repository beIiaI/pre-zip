'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { ChipGroup } from '@/components/ui/chip'
import { OnboardingLayout } from './layout'

const INTENT_OPTIONS = [
  'Make new friends',
  'Find local events',
  'Join group activities',
  'Meet people with similar interests',
  'Network professionally',
  'Explore my city',
  'Find workout buddies',
  'Join study groups',
]

interface Props {
  value: string[]
  onChange: (value: string[]) => void
  onNext: () => void
  onBack: () => void
}

export function OnboardingIntent({ value, onChange, onNext, onBack }: Props) {
  const [error, setError] = useState<string | null>(null)

  const handleNext = () => {
    if (value.length < 1) {
      setError('Please select at least one option')
      return
    }
    onNext()
  }

  return (
    <OnboardingLayout
      step={4}
      totalSteps={9}
      title="I'm here to..."
      subtitle="Select what brings you to pre. Choose at least one."
      onBack={onBack}
    >
      <div className="space-y-6">
        <ChipGroup
          options={INTENT_OPTIONS}
          selected={value}
          onChange={(selected) => {
            onChange(selected)
            setError(null)
          }}
        />
        
        {error && (
          <p className="text-caption text-error">{error}</p>
        )}

        <Button
          className="w-full"
          size="lg"
          onClick={handleNext}
          disabled={value.length < 1}
          data-testid="onboarding-intent-next"
        >
          Continue
        </Button>
      </div>
    </OnboardingLayout>
  )
}
