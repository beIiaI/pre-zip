'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { OnboardingLayout } from './layout'

interface Props {
  value: string
  onChange: (value: string) => void
  onNext: () => void
  onBack: () => void
}

export function OnboardingDOB({ value, onChange, onNext, onBack }: Props) {
  const [error, setError] = useState<string | null>(null)

  const handleNext = () => {
    // Validate date format if provided
    if (value) {
      const date = new Date(value)
      if (isNaN(date.getTime())) {
        setError('Please enter a valid date')
        return
      }
      // Check if date is in the future
      if (date > new Date()) {
        setError('Date of birth cannot be in the future')
        return
      }
    }
    onNext()
  }

  // Calculate max date (today)
  const maxDate = new Date()
  const maxDateStr = maxDate.toISOString().split('T')[0]

  return (
    <OnboardingLayout
      step={6}
      totalSteps={9}
      title="When's your birthday?"
      subtitle="Optional — used to gate 18+ features. Your age won't be shown publicly."
      onBack={onBack}
    >
      <div className="space-y-6">
        <Input
          type="date"
          label="Date of Birth (optional)"
          value={value}
          onChange={(e) => {
            onChange(e.target.value)
            setError(null)
          }}
          max={maxDateStr}
          error={error || undefined}
          data-testid="onboarding-dob-input"
        />

        <div className="flex gap-3">
          <Button
            variant="secondary"
            className="flex-1"
            size="lg"
            onClick={onNext}
            data-testid="onboarding-dob-skip"
          >
            Skip
          </Button>
          <Button
            className="flex-1"
            size="lg"
            onClick={handleNext}
            data-testid="onboarding-dob-next"
          >
            Continue
          </Button>
        </div>
      </div>
    </OnboardingLayout>
  )
}
