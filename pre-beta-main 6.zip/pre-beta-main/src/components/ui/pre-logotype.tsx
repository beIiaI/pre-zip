'use client'

import { cn } from '@/lib/utils'
import { PreWordmark } from '@/components/ui/pre-wordmark'

type PreLogotypeSize = 'micro' | 'small' | 'medium' | 'large' | 'hero'

const SIZE_MAP: Record<PreLogotypeSize, string> = {
  micro: 'w-[clamp(2.2rem,9.4vw,2.9rem)]',
  small: 'w-[clamp(2.8rem,11.8vw,3.6rem)]',
  medium: 'w-[clamp(3.4rem,14vw,4.4rem)]',
  large: 'w-[clamp(4.1rem,16.5vw,5.2rem)]',
  hero: 'w-[clamp(4.7rem,18.5vw,6.1rem)]',
}

interface PreLogotypeProps {
  size?: PreLogotypeSize
  className?: string
  wordmarkClassName?: string
  clearspace?: boolean
  label?: string
}

export function PreLogotype({
  size = 'small',
  className,
  wordmarkClassName,
  clearspace = true,
  label = 'pre',
}: PreLogotypeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center justify-center',
        clearspace && 'pre-logotype-clearspace',
        className
      )}
    >
      <PreWordmark
        label={label}
        className={cn('h-auto brand-wordmark-tone', SIZE_MAP[size], wordmarkClassName)}
      />
    </span>
  )
}
