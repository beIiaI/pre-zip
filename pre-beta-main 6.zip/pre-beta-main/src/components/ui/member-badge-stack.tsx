import { cn } from '@/lib/utils'
import { FounderBadge } from '@/components/ui/founder-badge'
import { EarlySupporterBadge } from '@/components/ui/early-supporter-badge'

interface MemberBadgeStackProps {
  isFounder?: boolean | null
  founderNumber?: number | null
  earlySupporterNumber?: number | null
  size?: 'sm' | 'md'
  className?: string
}

export function MemberBadgeStack({
  isFounder,
  founderNumber,
  earlySupporterNumber,
  size = 'md',
  className,
}: MemberBadgeStackProps) {
  const showFounder = isFounder === true
  const showEarlySupporter = earlySupporterNumber !== null && earlySupporterNumber !== undefined

  if (!showFounder && !showEarlySupporter) {
    return null
  }

  return (
    <div className={cn('flex flex-wrap items-center gap-2', className)}>
      {showFounder && <FounderBadge number={founderNumber} size={size} />}
      {showEarlySupporter && <EarlySupporterBadge number={earlySupporterNumber!} size={size} />}
    </div>
  )
}
