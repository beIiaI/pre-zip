import { BrandLoader } from '@/components/ui/brand-loader'

export function LoadingScreen({
  message,
  name,
  showWelcome = false,
}: {
  message?: string
  name?: string | null
  showWelcome?: boolean
}) {
  return (
    <div className="min-h-[100dvh] w-full overflow-visible px-4 safe-top safe-bottom flex flex-col items-center justify-center bg-surface-primary text-content-primary">
      <BrandLoader message={message} name={name} showWelcome={showWelcome} />
    </div>
  )
}
