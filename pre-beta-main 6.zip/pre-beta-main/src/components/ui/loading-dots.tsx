import { cn } from '@/lib/utils'

type LoadingDotsProps = {
  size?: 'sm' | 'md' | 'lg'
  className?: string
}

export function LoadingDots({ size = 'sm', className }: LoadingDotsProps) {
  const sizes = {
    sm: 'h-1.5 w-1.5',
    md: 'h-2 w-2',
    lg: 'h-2.5 w-2.5',
  }

  return (
    <span className={cn('inline-flex items-center gap-1', className)} aria-hidden="true">
      <span
        className={cn('rounded-full bg-current opacity-70 animate-pulse', sizes[size])}
        style={{ animationDelay: '0ms', animationDuration: '1.1s' }}
      />
      <span
        className={cn('rounded-full bg-current opacity-70 animate-pulse', sizes[size])}
        style={{ animationDelay: '200ms', animationDuration: '1.1s' }}
      />
      <span
        className={cn('rounded-full bg-current opacity-70 animate-pulse', sizes[size])}
        style={{ animationDelay: '400ms', animationDuration: '1.1s' }}
      />
    </span>
  )
}
