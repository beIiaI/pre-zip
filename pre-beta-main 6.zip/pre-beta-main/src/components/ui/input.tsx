import * as React from 'react'
import { cn } from '@/lib/utils'

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string
  error?: string
  hint?: string
  prefix?: string
}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, type, label, error, hint, prefix, id, style, ...props }, ref) => {
    const inputId = id || React.useId()
    
    return (
      <div className="w-full space-y-2">
        {label && (
          <label
            htmlFor={inputId}
            className="block text-caption font-medium uppercase tracking-[0.14em] text-content-secondary"
          >
            {label}
          </label>
        )}
        <div className="relative">
          {prefix && (
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-content-tertiary">
              {prefix}
            </span>
          )}
          <input
            type={type}
            id={inputId}
            className={cn(
              'flex h-[clamp(2.875rem,12vw,3.2rem)] w-full rounded-button border bg-[var(--input-background)] text-[var(--input-text)] placeholder:text-[var(--input-placeholder)] transition-colors',
              'border-[var(--input-border)] focus:border-content-primary/22 focus:outline-none focus:ring-2 focus:ring-content-primary/8',
              'disabled:cursor-not-allowed disabled:opacity-50',
              error && 'border-error focus:border-error',
              prefix ? 'pl-[clamp(2rem,8.5vw,2.25rem)] pr-[clamp(0.875rem,4vw,1rem)] py-3' : 'px-[clamp(0.875rem,4vw,1rem)] py-3',
              className
            )}
            style={{ WebkitTextFillColor: 'var(--input-text)', ...style }}
            ref={ref}
            {...props}
          />
        </div>
        {error && (
          <p className="text-sm text-error">{error}</p>
        )}
        {hint && !error && (
          <p className="text-sm text-content-tertiary">{hint}</p>
        )}
      </div>
    )
  }
)
Input.displayName = 'Input'

export { Input }
