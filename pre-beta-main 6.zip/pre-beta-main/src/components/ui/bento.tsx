import * as React from 'react'
import { cn } from '@/lib/utils'

type DivProps = React.HTMLAttributes<HTMLDivElement>

export const BentoFrame = React.forwardRef<HTMLDivElement, DivProps>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn('bento-frame', className)}
    {...props}
  />
))
BentoFrame.displayName = 'BentoFrame'

export const BentoGrid = React.forwardRef<HTMLDivElement, DivProps>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn('bento-grid', className)}
    {...props}
  />
))
BentoGrid.displayName = 'BentoGrid'

export const BentoCell = React.forwardRef<HTMLDivElement, DivProps>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn('bento-cell', className)}
    {...props}
  />
))
BentoCell.displayName = 'BentoCell'

interface BentoDividerProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'primary' | 'secondary'
  orientation?: 'horizontal' | 'vertical'
}

export function BentoDivider({
  className,
  variant = 'primary',
  orientation = 'horizontal',
  ...props
}: BentoDividerProps) {
  const dividerClass =
    orientation === 'vertical'
      ? variant === 'secondary'
        ? 'bento-divider-secondary-v'
        : 'bento-divider-v'
      : variant === 'secondary'
        ? 'bento-divider-secondary'
        : 'bento-divider'

  return <div className={cn(dividerClass, className)} {...props} />
}

export function BentoLabel({ className, ...props }: React.HTMLAttributes<HTMLSpanElement>) {
  return <span className={cn('bento-label', className)} {...props} />
}
