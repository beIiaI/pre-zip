import { cn, formatEarlySupporterNumber } from '@/lib/utils'

interface Props {
  number: number
  size?: 'sm' | 'md'
  className?: string
}

export function EarlySupporterBadge({ number, size = 'md', className }: Props) {
  const isSmall = size === 'sm'

  return (
    <div
      className={cn(
        'inline-flex items-center gap-2 rounded-full border border-[#1A1A1A]/15 bg-gradient-to-r from-[#FFF3C4] via-[#F5D89A] to-[#E7B970] text-[#4A2E00]',
        'dark:border-white/10 dark:from-[#3B2A10] dark:via-[#4A3215] dark:to-[#5A3A18] dark:text-[#F5D89A]',
        isSmall ? 'px-2.5 py-0.5 text-[10px]' : 'px-3.5 py-1 text-xs',
        className
      )}
    >
      <span className={cn('uppercase tracking-[0.28em] font-semibold', isSmall ? 'text-[8px]' : 'text-[10px]')}>
        Early Supporter
      </span>
      <span className={cn('font-mono font-semibold', isSmall ? 'text-[10px]' : 'text-[11px]')}>
        {formatEarlySupporterNumber(number)}
      </span>
    </div>
  )
}
