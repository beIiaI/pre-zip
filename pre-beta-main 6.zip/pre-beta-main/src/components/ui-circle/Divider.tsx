export function Divider({ spacing = 'default' }: { spacing?: 'none' | 'default' | 'large' }) {
  const spacingClass = {
    none: '',
    default: 'my-4',
    large: 'my-6',
  }[spacing]

  return <div className={`h-px bg-[color:var(--divider-soft)] ${spacingClass}`} />
}
