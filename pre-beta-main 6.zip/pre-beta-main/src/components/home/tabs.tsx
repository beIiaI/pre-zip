'use client'

import { useEffect, useMemo, useState } from 'react'
import { SegmentedControl } from '@/components/ui/segmented-control'
import { CirclesTab } from './circles-tab'
import { PeopleTab } from './people-tab'
import { EventsTab } from './events-tab'
import { BentoDivider } from '@/components/ui/bento'

type Tab = 'circles' | 'people' | 'events'
type FeedMode = 'discover' | 'following'
type FollowingUser = { id: string }

export function HomeTabs() {
  const [activeTab, setActiveTab] = useState<Tab>('circles')
  const [feedMode, setFeedMode] = useState<FeedMode>('discover')
  const [followingIds, setFollowingIds] = useState<string[]>([])
  const [followingLoading, setFollowingLoading] = useState(false)

  const visualMeta: Record<Tab, { title: string; subtitle: string }> = {
    circles: { title: 'Small groups, real momentum', subtitle: 'Circles' },
    people: { title: 'Find people who match your pace', subtitle: 'People' },
    events: { title: 'Plan something worth showing up for', subtitle: 'Events' },
  }
  const activeVisual = visualMeta[activeTab]
  const followingSet = useMemo(() => new Set(followingIds), [followingIds])

  useEffect(() => {
    if (feedMode !== 'following') return
    let active = true

    const loadFollowing = () => {
      setFollowingLoading(true)
      fetch('/api/following')
        .then((response) => {
          if (!response.ok) throw new Error('Failed to load following')
          return response.json() as Promise<{ results?: FollowingUser[] }>
        })
        .then((data) => {
          if (!active) return
          const ids = (data.results ?? []).map((row) => row.id).filter(Boolean)
          setFollowingIds(ids)
        })
        .catch(() => {
          if (!active) return
          setFollowingIds([])
        })
        .finally(() => {
          if (active) setFollowingLoading(false)
        })
    }

    loadFollowing()
    const onFollowingChanged = () => loadFollowing()
    window.addEventListener('pre:following-changed', onFollowingChanged)

    return () => {
      active = false
      window.removeEventListener('pre:following-changed', onFollowingChanged)
    }
  }, [feedMode])

  return (
    <div className="space-y-5">
      <section className="home-discover-shell animate-section-reveal">
        <div className="home-discover-surface">
          <div className="home-discover-content">
            <p className="type-eyebrow text-center text-[10px] text-content-tertiary sm:text-[11px]">
              {activeVisual.subtitle}
            </p>
            <h2 className="type-h2 mt-1 text-center text-[clamp(1.34rem,4.2vw,1.88rem)] text-content-primary">
              {activeVisual.title}
            </h2>

            <div className="home-section-divider mt-4" />

            <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
              <p className="text-callout text-content-secondary">Live social graph</p>
              <div className="feature-callout-raised rounded-full border border-border-secondary/28 bg-surface-primary/55 p-1">
                <div className="inline-flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setFeedMode('discover')}
                    className={`rounded-full px-3 py-1 text-eyebrow transition-colors ${
                      feedMode === 'discover'
                        ? 'bg-surface-primary text-content-primary'
                        : 'text-content-secondary'
                    }`}
                  >
                    Discover
                  </button>
                  <button
                    type="button"
                    onClick={() => setFeedMode('following')}
                    className={`rounded-full px-3 py-1 text-eyebrow transition-colors ${
                      feedMode === 'following'
                        ? 'bg-surface-primary text-content-primary'
                        : 'text-content-secondary'
                    }`}
                  >
                    Following
                  </button>
                </div>
              </div>
            </div>

            <BentoDivider variant="secondary" className="mt-4" />
            <p className="mt-2 text-caption text-content-tertiary type-align-body">
              {feedMode === 'discover'
                ? 'Discover highlights from the full network.'
                : 'Following mode shows updates from accounts you follow.'}
            </p>
          </div>
        </div>

        <div className="home-section-divider mt-4" />

        <div className="mt-4 flex justify-center">
          <SegmentedControl
            options={[
              { value: 'circles', label: 'Circles' },
              { value: 'people', label: 'People' },
              { value: 'events', label: 'Events' },
            ]}
            value={activeTab}
            onChange={(v) => setActiveTab(v as Tab)}
            className="home-discover-tabs"
          />
        </div>
      </section>

      <div key={activeTab} className="animate-fade-in">
        {activeTab === 'circles' && (
          <CirclesTab
            feedMode={feedMode}
            followingSet={followingSet}
            followingLoading={followingLoading}
          />
        )}
        {activeTab === 'people' && (
          <PeopleTab
            feedMode={feedMode}
            followingSet={followingSet}
            followingLoading={followingLoading}
          />
        )}
        {activeTab === 'events' && (
          <EventsTab
            feedMode={feedMode}
            followingSet={followingSet}
            followingLoading={followingLoading}
          />
        )}
      </div>
    </div>
  )
}
