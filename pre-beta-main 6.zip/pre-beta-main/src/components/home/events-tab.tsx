'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { BentoDivider } from '@/components/ui/bento'
import { VisualSurface } from '@/components/ui/visual-surface'
import { Calendar, MapPin, Plus } from 'lucide-react'

type EventItem = {
  id: string
  host_id: string
  title: string
  description: string | null
  starts_at: string
  location_text: string | null
  rsvp_counts: { going: number; interested: number; cant_go: number }
}

interface EventsTabProps {
  feedMode: 'discover' | 'following'
  followingSet: Set<string>
  followingLoading: boolean
}

const formatDateTime = (value: string) => {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return date.toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })
}

export function EventsTab({ feedMode, followingSet, followingLoading }: EventsTabProps) {
  const router = useRouter()
  const [events, setEvents] = useState<EventItem[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let active = true
    setLoading(true)
    fetch('/api/events')
      .then((res) => res.json())
      .then((data) => {
        if (!active) return
        setEvents(data.events ?? [])
      })
      .finally(() => {
        if (active) setLoading(false)
      })
    return () => {
      active = false
    }
  }, [])

  const visibleEvents =
    feedMode === 'following'
      ? events.filter((event) => followingSet.has(event.host_id))
      : events

  if (loading) {
    return (
      <section className="space-y-3">
        <div className="home-panel-soft">
          <div className="flex flex-col items-center justify-center py-12 text-center animate-section-reveal">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-surface-secondary">
              <Calendar className="h-8 w-8 text-content-tertiary" />
            </div>
            <h3 className="mb-2 text-headline type-h3 text-content-primary">Loading events</h3>
            <p className="max-w-xs text-body text-content-secondary">
              Fetching the latest community plans.
            </p>
          </div>
        </div>
      </section>
    )
  }

  if (feedMode === 'following' && followingLoading) {
    return (
      <section className="space-y-3">
        <div className="home-panel-soft">
          <div className="flex flex-col items-center justify-center py-12 text-center animate-section-reveal">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-surface-secondary">
              <Calendar className="h-8 w-8 text-content-tertiary" />
            </div>
            <h3 className="mb-2 text-headline type-h3 text-content-primary">Loading followed events</h3>
            <p className="max-w-xs text-body text-content-secondary">
              Pulling events hosted by people you follow.
            </p>
          </div>
        </div>
      </section>
    )
  }

  if (visibleEvents.length === 0) {
    return (
      <section className="space-y-3">
        <div className="home-panel-soft">
          <div className="flex flex-col items-center justify-center py-12 text-center animate-section-reveal">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-surface-secondary">
              <Calendar className="h-8 w-8 text-content-tertiary" />
            </div>
            <h3 className="mb-2 text-headline type-h3 text-content-primary">
              {feedMode === 'following' ? 'No events from followed people' : 'No events nearby'}
            </h3>
            <p className="mb-6 max-w-xs text-body text-content-secondary">
              {feedMode === 'following'
                ? 'Follow more people to personalize this feed, or switch back to Discover.'
                : 'Be the first to host an event in your area!'}
            </p>
            <Button data-testid="events-create-button" onClick={() => router.push('/events/new')}>
              <Plus className="h-4 w-4" />
              Create Event
            </Button>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="space-y-3">
      <div className="home-section-head px-1.5 py-1">
        <div>
          <h3 className="text-title type-h2 text-content-primary">Events</h3>
          <p className="text-callout text-content-secondary">Campus and public plans</p>
        </div>
        <Button size="sm" variant="secondary" onClick={() => router.push('/events/new')}>
          <Plus className="h-4 w-4" />
          New
        </Button>
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        {visibleEvents.slice(0, 3).map((event, index) => (
          <article
            key={event.id}
            className={`home-panel-soft dynamic-card animate-section-reveal space-y-2 p-[clamp(0.9rem,3.6vw,1rem)] ${
              index === 0 ? 'feature-callout-raised' : ''
            }`}
            style={{ animationDelay: `${index * 70}ms` }}
          >
            <VisualSurface
              seed={`${event.id}-${event.title}`}
              variant="fullWidth"
              showWordmark={false}
              className="mb-1"
            />
            <p className="text-headline type-h3 text-content-primary">{event.title}</p>
            <div className="flex items-center gap-2 text-callout text-content-secondary">
              <Calendar className="h-4 w-4" />
              <span>{formatDateTime(event.starts_at)}</span>
            </div>
            {event.location_text && (
              <a
                href={`https://maps.google.com/?q=${encodeURIComponent(event.location_text)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-callout text-content-secondary hover:text-content-primary transition-colors"
                onClick={(e) => e.stopPropagation()}
              >
                <MapPin className="h-4 w-4 flex-shrink-0" />
                <span className="underline decoration-dotted underline-offset-2">{event.location_text}</span>
              </a>
            )}
            {event.description && (
              <>
                <BentoDivider variant="secondary" />
                <p className="line-clamp-2 text-callout text-content-secondary type-align-body">{event.description}</p>
              </>
            )}
          </article>
        ))}

        <div className="md:col-span-2">
          <Button variant="secondary" className="w-full animate-section-reveal" onClick={() => router.push('/events')}>
            View all events
          </Button>
        </div>
      </div>
    </section>
  )
}
