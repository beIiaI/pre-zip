'use client'

import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { usePathname } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/screens/LoadingScreen'

export function AppShell({ children }: { children: ReactNode }) {
  const { user, profile, initialized, loading, profileLoaded } = useAuth()
  const [showLoading, setShowLoading] = useState(false)
  const [appReady, setAppReady] = useState(false)
  const lastUserIdRef = useRef<string | null>(null)
  const hasShownWelcomeRef = useRef(
    typeof window !== 'undefined' && sessionStorage.getItem('appReady') === '1'
  )
  const pathname = usePathname()
  const displayName = useMemo(() => {
    const profileName = profile?.full_name?.trim()
    if (profileName) return profileName

    const username = profile?.username?.trim() ?? ''
    const emailLocal = user?.email?.split('@')[0]?.trim() ?? ''
    const blocked = new Set(
      [username, emailLocal]
        .map((value) => value.toLowerCase().replace(/[^a-z0-9]/g, ''))
        .filter(Boolean)
    )

    const metadataCandidates = [
      typeof user?.user_metadata?.full_name === 'string' ? user.user_metadata.full_name : null,
      typeof user?.user_metadata?.name === 'string' ? user.user_metadata.name : null,
    ]

    for (const candidate of metadataCandidates) {
      const value = typeof candidate === 'string' ? candidate.trim() : ''
      if (!value || value.includes('@')) continue

      const normalized = value.toLowerCase().replace(/[^a-z0-9]/g, '')
      if (!normalized || blocked.has(normalized)) continue

      return value
    }

    return undefined
  }, [profile?.full_name, profile?.username, user?.email, user?.user_metadata?.full_name, user?.user_metadata?.name])

  useEffect(() => {
    const currentId = user?.id ?? null
    if (currentId !== lastUserIdRef.current) {
      lastUserIdRef.current = currentId
      setAppReady(false)
      setShowLoading(false)
      if (!currentId && typeof window !== 'undefined') {
        sessionStorage.removeItem('appReady')
        hasShownWelcomeRef.current = false
      }
    }
  }, [user])

  useEffect(() => {
    if (!initialized || loading || !profileLoaded) return

    if (user && profile?.onboarding_completed) {
      if (!appReady) {
        // On the root/splash page the LoadingScreen is suppressed by the
        // render guard (pathname !== '/'), so onLoadComplete never fires and
        // showLoading stays true. When the router then navigates to /home or
        // /messages the stale flag causes the loading screen to appear there
        // instead. Skip the animation on '/' and go straight to ready.
        if (hasShownWelcomeRef.current || pathname === '/') {
          if (typeof window !== 'undefined') {
            sessionStorage.setItem('appReady', '1')
            hasShownWelcomeRef.current = true
          }
          setAppReady(true)
        } else {
          setShowLoading(true)
        }
      }
      return
    }

    setShowLoading(false)
    setAppReady(false)
  }, [initialized, loading, profileLoaded, user, profile?.onboarding_completed, appReady, pathname])

  const handleLoadComplete = () => {
    setShowLoading(false)
    setAppReady(true)
    if (typeof window !== 'undefined') {
      sessionStorage.setItem('appReady', '1')
      hasShownWelcomeRef.current = true
    }
  }

  return (
    <>
      <div aria-hidden className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        <span className="absolute left-[-16%] top-[18%] h-[34vmax] w-[34vmax] rounded-full bg-content-primary/[0.03] blur-[140px] animate-app-shell-orb-a" />
        <span className="absolute right-[-20%] bottom-[12%] h-[36vmax] w-[36vmax] rounded-full bg-content-primary/[0.025] blur-[150px] animate-app-shell-orb-b" />
      </div>
      <div className="relative z-[1] min-h-screen w-full max-w-full overflow-x-hidden animate-route-enter">
        {children}
      </div>
      {showLoading && pathname !== '/' && (
        <LoadingScreen
          onLoadComplete={handleLoadComplete}
          name={displayName}
        />
      )}
    </>
  )
}
