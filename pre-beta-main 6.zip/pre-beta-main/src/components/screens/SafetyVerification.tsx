'use client'

import { useEffect, useRef, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { ArrowLeft, Shield, Check, AlertCircle, Mail, Search, UserPlus, MapPin, Lock, LockOpen, GraduationCap, CalendarDays, Building2, Phone } from 'lucide-react'
import { useAuth } from '@/components/providers/auth-provider'
import { AppBar } from '@/components/ui-circle/AppBar'
import { Button } from '@/components/ui-circle/Button'
import { Divider } from '@/components/ui-circle/Divider'
import { BottomSheet } from '@/components/ui-circle/BottomSheet'
import { Alert } from '@/components/ui/alert'
import { Avatar } from '@/components/ui/avatar'
import { validateEmail } from '@/lib/utils'
import { getNormalizedUniversityName } from '@/lib/verification/university'

interface SafetyVerificationProps {
  onBack: () => void
}

type ContactProfile = {
  id: string
  username: string | null
  full_name: string | null
  avatar_url: string | null
}

type EmergencyContact = {
  id: string
  type: 'user' | 'phone'
  contact_user_id: string | null
  external_name: string | null
  external_phone: string | null
  username: string | null
  full_name: string | null
  avatar_url: string | null
}

type PanicAlert = {
  id: string
  owner_id: string
  lat: number | null
  lng: number | null
  created_at: string
  owner: ContactProfile | null
}

type CollegeState = {
  college_name: string | null
  college_self_reported: boolean
  college_updated_at: string | null
  college_change_count: number
}

const YEAR_MS = 365 * 24 * 60 * 60 * 1000
const MIN_GRAD_YEAR = 1900
const MAX_GRAD_YEAR = 2300
const COLLEGE_MAX_SAVES = 2
const SUPPORT_EMAIL = 'support@presocial.app'

const defaultCollegeState: CollegeState = {
  college_name: null,
  college_self_reported: false,
  college_updated_at: null,
  college_change_count: 0,
}

function normalizeCollegeState(value: unknown): CollegeState {
  if (!value || typeof value !== 'object') return defaultCollegeState
  const row = value as Partial<CollegeState>
  return {
    college_name: typeof row.college_name === 'string' && row.college_name.trim() ? row.college_name : null,
    college_self_reported: row.college_self_reported === true,
    college_updated_at: typeof row.college_updated_at === 'string' ? row.college_updated_at : null,
    college_change_count:
      typeof row.college_change_count === 'number' && Number.isFinite(row.college_change_count)
        ? Math.max(0, row.college_change_count)
        : 0,
  }
}

export function SafetyVerification({ onBack }: SafetyVerificationProps) {
  const { user, profile, refreshProfile } = useAuth()
  const [showPanicSheet, setShowPanicSheet] = useState(false)
  const [email, setEmail] = useState('')
  const [emailTouched, setEmailTouched] = useState(false)
  const [emailUnlocked, setEmailUnlocked] = useState(false)
  const [verificationStatus, setVerificationStatus] = useState<'idle' | 'sending' | 'sent' | 'verifying' | 'verified' | 'error'>('idle')
  const [verificationMessage, setVerificationMessage] = useState<string | null>(null)
  const [unlockLoading, setUnlockLoading] = useState<'change_email' | 'graduated' | null>(null)
  const [graduationYear, setGraduationYear] = useState('')
  const [gradYearLoading, setGradYearLoading] = useState(false)
  const [gradYearMessage, setGradYearMessage] = useState<string | null>(null)
  const [gradYearConfirmed, setGradYearConfirmed] = useState(false)
  const [collegeDraft, setCollegeDraft] = useState('')
  const [collegeSaving, setCollegeSaving] = useState(false)
  const [collegeLoading, setCollegeLoading] = useState(false)
  const [collegeMessage, setCollegeMessage] = useState<string | null>(null)
  const [collegeError, setCollegeError] = useState<string | null>(null)
  const [collegeState, setCollegeState] = useState<CollegeState>(defaultCollegeState)
  const [collegeOptions, setCollegeOptions] = useState<string[]>([])
  const [collegeEditing, setCollegeEditing] = useState(false)
  const [contacts, setContacts] = useState<EmergencyContact[]>([])
  const [contactsLoading, setContactsLoading] = useState(true)
  const [contactQuery, setContactQuery] = useState('')
  const [contactResults, setContactResults] = useState<ContactProfile[]>([])
  const [contactSearching, setContactSearching] = useState(false)
  const [externalContactName, setExternalContactName] = useState('')
  const [externalContactPhone, setExternalContactPhone] = useState('')
  const [externalContactSaving, setExternalContactSaving] = useState(false)
  const [contactError, setContactError] = useState<string | null>(null)
  const [panicMessage, setPanicMessage] = useState<string | null>(null)
  const [panicError, setPanicError] = useState<string | null>(null)
  const [panicLoading, setPanicLoading] = useState(false)
  const [alerts, setAlerts] = useState<PanicAlert[]>([])
  const [alertsLoading, setAlertsLoading] = useState(true)
  const searchTimerRef = useRef<number | null>(null)
  const router = useRouter()
  const searchParams = useSearchParams()

  const isUniversityVerified = profile?.university_verified === true
  const profileEmail = profile?.university_email ?? ''
  const profileDomain = profile?.university_domain || (profileEmail ? profileEmail.split('@')[1] : null)
  const profileName = getNormalizedUniversityName(profileDomain, profile?.university_name ?? null)
  const profileCollege = collegeState.college_name
  const collegeChangeCount = collegeState.college_change_count
  const hasSavedCollege = !!profileCollege
  const collegeLocked = hasSavedCollege && collegeChangeCount >= COLLEGE_MAX_SAVES
  const collegeChangesRemaining = Math.max(0, COLLEGE_MAX_SAVES - collegeChangeCount)
  const profileGraduationYear = profile?.university_graduation_year ?? null
  const gradConfirmedAt = profile?.university_grad_year_confirmed_at ?? null
  const gradYearLockUntil = gradConfirmedAt
    ? new Date(new Date(gradConfirmedAt).getTime() + YEAR_MS)
    : null
  const gradYearChangeLocked =
    profileGraduationYear !== null &&
    gradYearLockUntil !== null &&
    gradYearLockUntil.getTime() > Date.now()
  const emailLocked = isUniversityVerified && !emailUnlocked
  const annualGradCheckDue =
    isUniversityVerified &&
    (!gradConfirmedAt || Date.now() - new Date(gradConfirmedAt).getTime() > YEAR_MS)
  const statusCopy = {
    idle: null,
    sending: 'Sending verification email…',
    sent: 'Verification email sent. Check your inbox.',
    verifying: 'Verifying your email…',
    verified: 'Verified.',
    error: null,
  } as const

  useEffect(() => {
    if (!emailTouched) {
      setEmail(profileEmail)
    }
  }, [profileEmail, emailTouched])

  useEffect(() => {
    if (isUniversityVerified) {
      setVerificationStatus('verified')
      setVerificationMessage(null)
      setEmailUnlocked(false)
    }
  }, [isUniversityVerified])

  useEffect(() => {
    setGraduationYear(profileGraduationYear ? String(profileGraduationYear) : '')
    setGradYearConfirmed(false)
  }, [profileGraduationYear])

  useEffect(() => {
    setCollegeDraft(collegeState.college_name ?? '')
    setCollegeEditing(!(collegeState.college_name && collegeState.college_name.trim()))
  }, [collegeState.college_name])

  useEffect(() => {
    if (!user) {
      setCollegeState(defaultCollegeState)
      setCollegeOptions([])
      return
    }

    let active = true
    setCollegeLoading(true)

    fetch('/api/verification/college', { cache: 'no-store' })
      .then((res) => res.json().catch(() => null))
      .then((data) => {
        if (!active || !data?.ok) return
        setCollegeState(normalizeCollegeState(data.profile))
        setCollegeOptions(Array.isArray(data.collegeOptions) ? data.collegeOptions.filter((item: unknown): item is string => typeof item === 'string' && item.trim().length > 0) : [])
      })
      .finally(() => {
        if (active) setCollegeLoading(false)
      })

    return () => {
      active = false
    }
  }, [user?.id])

  useEffect(() => {
    const status = searchParams.get('status')
    if (!status) return

    const message = searchParams.get('message') ?? ''
    const clearParams = () => {
      router.replace('/settings/safety-verification')
    }

    if (status === 'verified') {
      setVerificationStatus('verifying')
      setVerificationMessage('Finalizing verification…')
      refreshProfile().finally(() => {
        setVerificationStatus('verified')
        setVerificationMessage(null)
        setEmailTouched(false)
        clearParams()
      })
      return
    }

    if (status === 'error') {
      const mapped =
        message === 'token_expired'
          ? 'That verification link has expired. Please request a new email.'
          : message === 'token_used'
            ? 'That verification link has already been used.'
            : message === 'domain_stoplisted'
              ? 'That domain is not eligible for verification.'
              : message === 'domain_not_academic'
                ? 'That email domain is not recognized as academic.'
                : 'Unable to verify email. Please try again.'
      setVerificationStatus('error')
      setVerificationMessage(mapped)
      clearParams()
      return
    }

    clearParams()
  }, [searchParams, refreshProfile, router])

  useEffect(() => {
    if (!user) return
    const loadContacts = () => {
      setContactsLoading(true)
      fetch('/api/emergency-contacts')
        .then((res) => res.json())
        .then((data) => {
          setContacts(data.contacts ?? [])
        })
        .finally(() => setContactsLoading(false))
    }

    const loadAlerts = () => {
      setAlertsLoading(true)
      fetch('/api/panic/alerts')
        .then((res) => res.json())
        .then((data) => {
          setAlerts(data.alerts ?? [])
        })
        .finally(() => setAlertsLoading(false))
    }

    loadContacts()
    loadAlerts()
  }, [user])

  useEffect(() => {
    if (!showPanicSheet) return
    if (!contactQuery.trim()) {
      setContactResults([])
      setContactSearching(false)
      return
    }

    if (searchTimerRef.current) {
      window.clearTimeout(searchTimerRef.current)
    }

    setContactSearching(true)
    searchTimerRef.current = window.setTimeout(() => {
      fetch(`/api/users/search?q=${encodeURIComponent(contactQuery.trim())}`)
        .then((res) => res.json())
        .then((data) => {
          const exclude = new Set<string>([
            user?.id ?? '',
            ...contacts
              .map((contact) => contact.contact_user_id)
              .filter((id): id is string => typeof id === 'string' && id.length > 0),
          ])
          const filtered = (data.results ?? []).filter((person: ContactProfile) => !exclude.has(person.id))
          setContactResults(filtered)
        })
        .finally(() => setContactSearching(false))
    }, 300)

    return () => {
      if (searchTimerRef.current) {
        window.clearTimeout(searchTimerRef.current)
      }
    }
  }, [contactQuery, showPanicSheet, contacts, user?.id])

  useEffect(() => {
    if (!showPanicSheet) {
      setContactQuery('')
      setContactResults([])
      setContactSearching(false)
    }
  }, [showPanicSheet])

  const handleAddContact = async (person: ContactProfile) => {
    setContactError(null)
    const response = await fetch('/api/emergency-contacts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contact_user_id: person.id }),
    })
    const data = await response.json().catch(() => null)
    if (!response.ok) {
      setContactError(data?.error || 'Unable to add contact')
      return
    }
    setContacts((prev) => {
      const next = data?.contact as EmergencyContact | undefined
      if (!next) return prev
      if (prev.some((item) => item.id === next.id)) return prev
      return [...prev, next]
    })
    setContactQuery('')
    setContactResults([])
  }

  const handleAddExternalContact = async () => {
    if (externalContactSaving) return
    const phone = externalContactPhone.trim()
    if (!phone) {
      setContactError('Enter a phone number to add an external emergency contact.')
      return
    }

    setContactError(null)
    setExternalContactSaving(true)
    try {
      const response = await fetch('/api/emergency-contacts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          external_name: externalContactName.trim(),
          external_phone: phone,
        }),
      })
      const data = await response.json().catch(() => null)
      if (!response.ok) {
        throw new Error(data?.error || 'Unable to add phone contact')
      }
      const next = data?.contact as EmergencyContact | undefined
      if (!next) {
        throw new Error('Unable to add phone contact')
      }
      setContacts((prev) => {
        if (prev.some((item) => item.id === next.id)) return prev
        return [...prev, next]
      })
      setExternalContactName('')
      setExternalContactPhone('')
    } catch (err) {
      setContactError(err instanceof Error ? err.message : 'Unable to add phone contact')
    } finally {
      setExternalContactSaving(false)
    }
  }

  const handleRemoveContact = async (contactId: string) => {
    setContactError(null)
    const response = await fetch('/api/emergency-contacts', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contact_id: contactId }),
    })
    if (!response.ok) {
      const data = await response.json().catch(() => null)
      setContactError(data?.error || 'Unable to remove contact')
      return
    }
    setContacts((prev) => prev.filter((item) => item.id !== contactId))
  }

  const handlePanic = async () => {
    if (panicLoading) return
    setPanicError(null)
    setPanicMessage(null)
    setPanicLoading(true)

    const smsTargets = contacts
      .map((contact) => contact.external_phone)
      .filter((phone): phone is string => typeof phone === 'string' && phone.length > 0)

    if (smsTargets.length === 0) {
      setPanicLoading(false)
      setPanicError('Add at least one external phone number in Emergency Contacts to open an emergency SMS draft.')
      return
    }

    let lat: number | null = null
    let lng: number | null = null
    let locationDenied = false

    if (typeof window !== 'undefined' && navigator.geolocation) {
      try {
        const coords = await new Promise<GeolocationCoordinates | null>((resolve) => {
          navigator.geolocation.getCurrentPosition(
            (pos) => resolve(pos.coords),
            (error) => {
              if (error.code === error.PERMISSION_DENIED) {
                locationDenied = true
              }
              resolve(null)
            },
            { enableHighAccuracy: false, timeout: 5000 }
          )
        })
        if (coords) {
          lat = coords.latitude
          lng = coords.longitude
        }
      } catch {
        locationDenied = true
      }
    }

    if (locationDenied && lat === null && lng === null) {
      const continueWithoutLocation = window.confirm(
        'Location is currently disabled. Enable location to include coordinates in your emergency SMS sent from your own phone number. Press OK to continue without location, or Cancel to enable location and try again.'
      )
      if (!continueWithoutLocation) {
        setPanicLoading(false)
        setPanicError('Enable location services for pre, then tap Panic Alert again to include your live location.')
        return
      }
    }

    try {
      // Keep server-side panic event logging for audit/history.
      await fetch('/api/panic', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lat, lng }),
      })
    } catch {
      // SMS drafting still proceeds even if panic event logging fails.
    }

    try {
      const senderName = profile?.full_name || profile?.username || 'A pre user'
      const timestamp = new Date().toLocaleString()
      const mapLink = lat !== null && lng !== null
        ? `https://maps.apple.com/?q=${lat},${lng}`
        : null
      const bodyLines = [
        `Emergency alert from ${senderName}.`,
        'I need help right now. Please check in with me immediately.',
        mapLink ? `My current location: ${mapLink}` : 'Location unavailable. Please call me now.',
        `Sent from pre at ${timestamp}.`,
      ]
      const messageBody = bodyLines.join('\n')

      const ua = typeof navigator !== 'undefined' ? navigator.userAgent : ''
      const isIOS = /iPad|iPhone|iPod/i.test(ua)
      const recipientDelimiter = isIOS ? ',' : ';'
      const recipients = smsTargets.join(recipientDelimiter)
      const queryPrefix = isIOS ? '&' : '?'
      const smsUrl = `sms:${recipients}${queryPrefix}body=${encodeURIComponent(messageBody)}`

      window.location.href = smsUrl
      setPanicMessage('Emergency SMS draft opened. Review it and tap send.')

      const alertResponse = await fetch('/api/panic/alerts')
      const alertData = await alertResponse.json().catch(() => ({}))
      setAlerts(alertData.alerts ?? [])
    } catch (err) {
      setPanicError(err instanceof Error ? err.message : 'Unable to open emergency SMS draft')
    } finally {
      setPanicLoading(false)
    }
  }

  const handleUnlockUniversityEmail = async (reason: 'change_email' | 'graduated') => {
    if (unlockLoading) return
    setVerificationMessage(null)
    setGradYearMessage(null)
    setUnlockLoading(reason)

    try {
      const response = await fetch('/api/verification/university/unlock', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason }),
      })
      const data = await response.json().catch(() => ({}))
      if (!response.ok) {
        throw new Error(data?.error || 'Unable to update university verification.')
      }

      if (reason === 'change_email') {
        setEmail('')
        setEmailTouched(true)
        setEmailUnlocked(true)
        setVerificationStatus('idle')
        setVerificationMessage('University email unlocked. Enter your new university email to verify again.')
      } else {
        setEmailUnlocked(false)
        setVerificationStatus('idle')
        setVerificationMessage('Marked as graduated. Campus-only verification has been removed.')
      }

      await refreshProfile()
    } catch (err) {
      setVerificationStatus('error')
      setVerificationMessage(err instanceof Error ? err.message : 'Unable to update university verification.')
    } finally {
      setUnlockLoading(null)
    }
  }

  const handleSaveGraduationYear = async () => {
    if (gradYearLoading) return
    if (gradYearChangeLocked && profileGraduationYear !== null) {
      const lockUntil = gradYearLockUntil?.toLocaleDateString() ?? 'next year'
      setGradYearMessage(
        `Graduation year is locked until ${lockUntil}. Contact ${SUPPORT_EMAIL} if you need an earlier correction.`
      )
      return
    }
    if (!gradYearConfirmed) {
      setGradYearMessage('Please confirm your graduation year before saving.')
      return
    }
    const parsedYear = Number(graduationYear)
    if (!Number.isInteger(parsedYear) || parsedYear < MIN_GRAD_YEAR || parsedYear > MAX_GRAD_YEAR) {
      setGradYearMessage('Enter a valid graduation year.')
      return
    }

    setGradYearLoading(true)
    setGradYearMessage(null)

    try {
      const response = await fetch('/api/verification/university/graduation-year', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ graduationYear: parsedYear }),
      })
      const data = await response.json().catch(() => ({}))
      if (!response.ok) {
        const nextAllowedAt =
          typeof data?.nextAllowedAt === 'string'
            ? new Date(data.nextAllowedAt).toLocaleDateString()
            : null
        const supportEmail =
          typeof data?.supportEmail === 'string' && data.supportEmail
            ? data.supportEmail
            : SUPPORT_EMAIL
        const message =
          data?.reason === 'graduation_year_locked_support'
            ? `Graduation year is locked until ${nextAllowedAt ?? 'next year'}. Contact ${supportEmail} to correct it sooner.`
            : data?.error || 'Unable to save graduation year.'
        throw new Error(message)
      }

      if (data?.graduated) {
        setVerificationStatus('idle')
        setVerificationMessage('Graduation year saved. Campus-only verification has been removed.')
      } else {
        setGradYearMessage('Graduation year saved. You can change it again in one year.')
      }

      setGradYearConfirmed(false)
      await refreshProfile()
    } catch (err) {
      setGradYearMessage(err instanceof Error ? err.message : 'Unable to save graduation year.')
    } finally {
      setGradYearLoading(false)
    }
  }

  const handleSaveCollege = async () => {
    if (collegeSaving) return
    if (!isUniversityVerified) {
      setCollegeError('Verify your university email first.')
      return
    }
    if (collegeLocked) {
      setCollegeError(`College is locked. Contact ${SUPPORT_EMAIL} to make changes.`)
      return
    }
    if (collegeOptions.length === 0) {
      setCollegeError('College self-report is unavailable for your university domain.')
      return
    }

    const normalizedCollege = collegeDraft.trim()
    if (!normalizedCollege) {
      setCollegeError('Select your college from the listed options.')
      return
    }

    const isAllowed = collegeOptions.some(
      (option) => option.trim().toLowerCase() === normalizedCollege.toLowerCase()
    )
    if (!isAllowed) {
      setCollegeError('Select your college from the listed options.')
      return
    }

    setCollegeSaving(true)
    setCollegeMessage(null)
    setCollegeError(null)

    try {
      const response = await fetch('/api/verification/college', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ collegeName: normalizedCollege }),
      })
      const data = await response.json().catch(() => ({}))
      if (!response.ok) {
        const message =
          data?.reason === 'university_verification_required'
              ? 'Verify your university email first.'
              : data?.reason === 'college_subdivisions_unavailable'
                ? 'College self-report is unavailable for your university domain.'
                : data?.reason === 'invalid_college_option'
                  ? 'Select your college from the listed options.'
                  : data?.reason === 'college_locked_support'
                    ? `College is locked. Contact ${data?.supportEmail || SUPPORT_EMAIL} to make changes.`
              : data?.error || 'Unable to save college.'
        throw new Error(message)
      }

      const nextCollegeState = normalizeCollegeState(data?.profile)
      setCollegeState(nextCollegeState)
      setCollegeDraft(nextCollegeState.college_name ?? normalizedCollege)
      setCollegeEditing(false)
      if (data?.noChange) {
        setCollegeMessage('College is already up to date.')
      } else if ((nextCollegeState.college_change_count ?? 0) >= COLLEGE_MAX_SAVES) {
        setCollegeMessage(`College saved. Further changes now require ${SUPPORT_EMAIL}.`)
      } else {
        setCollegeMessage('College saved. You have one final edit remaining.')
      }
    } catch (err) {
      setCollegeError(err instanceof Error ? err.message : 'Unable to save college.')
    } finally {
      setCollegeSaving(false)
    }
  }

  const handleVerify = async () => {
    if (verificationStatus === 'sending') return
    if (emailLocked) {
      setVerificationStatus('error')
      setVerificationMessage('Your verified university email is locked. Request an email change first.')
      return
    }
    const trimmed = email.trim().toLowerCase()
    if (!trimmed) {
      setVerificationStatus('error')
      setVerificationMessage('Enter your university email to continue.')
      return
    }
    if (!validateEmail(trimmed)) {
      setVerificationStatus('error')
      setVerificationMessage('Enter a valid university email.')
      return
    }

    setVerificationStatus('sending')
    setVerificationMessage(null)
    const normalizedGradYear = /^\d{4}$/.test(graduationYear.trim())
      ? Number(graduationYear.trim())
      : undefined
    const isGradYearChanged =
      normalizedGradYear !== undefined &&
      (profileGraduationYear === null || normalizedGradYear !== profileGraduationYear)
    const shouldSendGradYear =
      normalizedGradYear !== undefined &&
      (profileGraduationYear === null || normalizedGradYear !== profileGraduationYear)

    if (isGradYearChanged && !gradYearConfirmed) {
      setVerificationStatus('error')
      setVerificationMessage('Please confirm your graduation year before continuing.')
      return
    }

    if (isGradYearChanged && gradYearChangeLocked && profileGraduationYear !== null) {
      setVerificationStatus('error')
      setVerificationMessage(
        `Graduation year is locked until ${gradYearLockUntil?.toLocaleDateString() ?? 'next year'}. Contact ${SUPPORT_EMAIL} to correct it sooner.`
      )
      return
    }

    try {
      const response = await fetch('/api/verification/university/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: trimmed,
          allowEmailChange: emailUnlocked,
          graduationYear: shouldSendGradYear ? normalizedGradYear : undefined,
        }),
      })
      const data = await response.json().catch(() => ({}))
      if (!response.ok) {
        const message =
          data?.reason === 'email_locked_change_required'
            ? 'Your verified email is locked. Request an email change first.'
            : data?.reason === 'invalid_graduation_year'
              ? 'Enter a valid graduation year.'
              : data?.reason === 'consumer_domain'
                ? 'Personal email providers are not eligible.'
                : data?.reason === 'domain_stoplisted'
              ? 'That domain is not eligible for verification.'
                : data?.reason === 'domain_not_academic'
                ? 'That email domain is not recognized as academic.'
                  : data?.reason === 'graduation_year_locked_support'
                  ? `Graduation year is locked for one year. Contact ${data?.supportEmail || SUPPORT_EMAIL} to correct it sooner.`
                  : data?.reason === 'rate_limited'
                  ? 'Too many attempts. Please try again in a few minutes.'
                    : data?.reason === 'swot_unavailable'
                    ? 'Verification is temporarily unavailable.'
                      : data?.reason === 'invalid_email'
                      ? 'Enter a valid university email.'
                        : data?.error || 'Unable to send verification email.'
        throw new Error(message)
      }

      setVerificationStatus('sent')
      setVerificationMessage(`Verification email sent to ${trimmed}.`)
      setEmailTouched(false)
      await refreshProfile()
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to send verification email.'
      setVerificationStatus('error')
      setVerificationMessage(message)
    }
  }

  return (
    <div className="min-h-screen bg-surface-primary safe-top safe-bottom flex flex-col">
      {/* ORIENTATION */}
      <AppBar
        title="Safety & Verification"
        subtitle="Keep your account secure"
        left={
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-surface-secondary flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-content-primary" strokeWidth={1.5} />
          </button>
        }
      />

      {/* CONTENT */}
      <div className="flex-1 overflow-y-auto pb-24">
        {/* Verification Status */}
        <div className="px-6 py-6">
          <h2 className="text-[22px] leading-tight text-content-primary mb-4">Verification</h2>

          {verificationMessage && (
            <div className="mb-4">
              <Alert
                variant={verificationStatus === 'error' ? 'error' : verificationStatus === 'verified' ? 'success' : 'info'}
                dismissible
                onDismiss={() => {
                  setVerificationMessage(null)
                  if (verificationStatus === 'error') setVerificationStatus('idle')
                }}
              >
                {verificationMessage}
              </Alert>
            </div>
          )}

          <div className="surface-block p-5 mb-4">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-start gap-3">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                    isUniversityVerified ? 'bg-content-primary' : 'bg-surface-tertiary'
                  }`}
                >
                  {isUniversityVerified ? (
                    <Check className="w-5 h-5 text-content-inverse" strokeWidth={1.5} />
                  ) : (
                    <Mail className="w-5 h-5 text-content-tertiary" strokeWidth={1.5} />
                  )}
                </div>
                <div>
                  <h3 className="text-[18px] leading-tight text-content-primary mb-1">
                    {isUniversityVerified ? 'University verification active' : 'Verify with university email'}
                  </h3>
                  <p className="text-base text-content-secondary">
                    {isUniversityVerified
                      ? 'University verification is active.'
                      : 'Use your university email to unlock campus-only events.'}
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-4 space-y-3">
              <div className="flex items-center gap-2 rounded-xl border border-border-secondary bg-surface-primary/70 px-4 py-3">
                {emailLocked ? (
                  <Lock className="h-4 w-4 text-content-tertiary" />
                ) : (
                  <Mail className="h-4 w-4 text-content-tertiary" />
                )}
                <input
                  value={email}
                  onChange={(event) => {
                    if (emailLocked) return
                    setEmail(event.target.value)
                    setEmailTouched(true)
                    setVerificationStatus('idle')
                    setVerificationMessage(null)
                  }}
                  placeholder="name@university.edu"
                  className="flex-1 bg-transparent text-sm text-content-primary placeholder:text-content-tertiary focus:outline-none"
                  inputMode="email"
                  autoComplete="email"
                  disabled={emailLocked}
                />
              </div>
              {isUniversityVerified && profileEmail && email.trim().toLowerCase() !== profileEmail.toLowerCase() && (
                <p className="text-xs text-content-tertiary">
                  Changing your university email will require re-verification.
                </p>
              )}
              {emailLocked ? (
                <>
                  <p className="text-xs text-content-tertiary">
                    This verified university email is locked. Request a change to edit it.
                  </p>
                  <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                    <Button
                      variant="secondary"
                      size="default"
                      fullWidth
                      loading={unlockLoading === 'change_email'}
                      onClick={() => handleUnlockUniversityEmail('change_email')}
                    >
                      <span className="inline-flex items-center gap-2">
                        <LockOpen className="h-4 w-4" />
                        Request Email Change
                      </span>
                    </Button>
                    <Button
                      variant="secondary"
                      size="default"
                      fullWidth
                      loading={unlockLoading === 'graduated'}
                      onClick={() => handleUnlockUniversityEmail('graduated')}
                    >
                      <span className="inline-flex items-center gap-2">
                        <GraduationCap className="h-4 w-4" />
                        I Graduated
                      </span>
                    </Button>
                  </div>
                </>
              ) : (
                <Button
                  variant="secondary"
                  size="default"
                  fullWidth
                  loading={verificationStatus === 'sending'}
                  disabled={verificationStatus === 'sending' || !validateEmail(email.trim().toLowerCase())}
                  onClick={handleVerify}
                >
                  {verificationStatus === 'sent' ? 'Resend verification email' : 'Send verification email'}
                </Button>
              )}
              {statusCopy[verificationStatus] && (
                <p className="text-xs text-content-tertiary">{statusCopy[verificationStatus]}</p>
              )}
            </div>

            <div className="mt-4 rounded-xl border border-border-secondary bg-surface-primary/70 px-4 py-4 space-y-3">
              <div className="flex items-start gap-2">
                <CalendarDays className="h-4 w-4 text-content-tertiary mt-0.5" />
                <div>
                  <p className="text-sm text-content-primary">Graduation year</p>
                  <p className="text-xs text-content-tertiary">
                    We ask for this yearly to keep campus access accurate.
                  </p>
                </div>
              </div>
              {annualGradCheckDue && (
                <Alert variant="info">
                  Please confirm your graduation year for this year.
                </Alert>
              )}
              {gradYearChangeLocked && profileGraduationYear !== null && (
                <Alert variant="info">
                  Your graduation year is currently locked until {gradYearLockUntil?.toLocaleDateString()}. Contact {SUPPORT_EMAIL} if you need an earlier correction.
                </Alert>
              )}

              {gradYearChangeLocked && profileGraduationYear !== null ? (
                <div className="rounded-xl border border-border-secondary bg-surface-secondary px-3 py-2">
                  <p className="text-xs text-content-secondary">
                    Confirmed graduation year: <span className="text-content-primary">{profileGraduationYear}</span>
                  </p>
                </div>
              ) : (
                <>
                  <div className="flex items-center gap-2 rounded-xl border border-border-secondary bg-surface-secondary px-3 py-2">
                    <CalendarDays className="h-4 w-4 text-content-tertiary" />
                    <input
                      value={graduationYear}
                      onChange={(event) => {
                        setGraduationYear(event.target.value.replace(/\D/g, '').slice(0, 4))
                        setGradYearConfirmed(false)
                        setGradYearMessage(null)
                      }}
                      placeholder="2028"
                      className="flex-1 bg-transparent text-sm text-content-primary placeholder:text-content-tertiary focus:outline-none"
                      inputMode="numeric"
                      maxLength={4}
                    />
                  </div>
                  <label className="flex items-start gap-2 rounded-xl border border-border-secondary bg-surface-secondary px-3 py-2">
                    <input
                      type="checkbox"
                      checked={gradYearConfirmed}
                      onChange={(event) => setGradYearConfirmed(event.target.checked)}
                      className="mt-0.5 h-4 w-4 accent-content-primary"
                    />
                    <span className="text-xs text-content-secondary">
                      I confirm this graduation year is correct. Once saved, it is locked for 1 year.
                      If it is wrong, contact support at {SUPPORT_EMAIL}.
                    </span>
                  </label>
                  <Button
                    variant="secondary"
                    size="default"
                    fullWidth
                    loading={gradYearLoading}
                    onClick={handleSaveGraduationYear}
                    disabled={gradYearLoading || graduationYear.trim().length !== 4 || !gradYearConfirmed}
                  >
                    Save Graduation Year
                  </Button>
                </>
              )}
              {gradYearMessage && (
                <p className="text-xs text-content-tertiary">{gradYearMessage}</p>
              )}
            </div>

            {isUniversityVerified && (collegeOptions.length > 0 || hasSavedCollege) && (
              <div className="mt-4 rounded-xl border border-border-secondary bg-surface-primary/70 px-4 py-4 space-y-3">
                <div className="flex items-start gap-2">
                  <Building2 className="h-4 w-4 text-content-tertiary mt-0.5" />
                  <div>
                    <p className="text-sm text-content-primary">College</p>
                    <p className="text-xs text-content-tertiary">
                      Self-reported. You can save once, then make one final edit.
                    </p>
                  </div>
                </div>

                {(collegeEditing || !hasSavedCollege) && collegeOptions.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {collegeOptions.map((collegeOption) => {
                      const isSelected = collegeDraft.trim().toLowerCase() === collegeOption.toLowerCase()
                      return (
                        <button
                          key={collegeOption}
                          type="button"
                          onClick={() => {
                            setCollegeDraft(collegeOption)
                            setCollegeError(null)
                            setCollegeMessage(null)
                          }}
                          className={`rounded-xl border px-3 py-2 text-left text-sm transition-colors ${
                            isSelected
                              ? 'border-content-primary bg-surface-secondary text-content-primary'
                              : 'border-border-secondary bg-surface-secondary text-content-secondary'
                          }`}
                        >
                          {collegeOption}
                        </button>
                      )
                    })}
                  </div>
                ) : (
                  profileCollege && (
                    <div className="rounded-xl border border-border-secondary bg-surface-secondary p-3 text-sm text-content-secondary">
                      College: <span className="text-content-primary">{profileCollege}</span>
                    </div>
                  )
                )}

                {collegeOptions.length > 0 && (collegeEditing || !hasSavedCollege) && (
                  <Button
                    variant="secondary"
                    size="default"
                    fullWidth
                    loading={collegeSaving}
                    onClick={handleSaveCollege}
                    disabled={collegeSaving || collegeLoading || !collegeDraft.trim()}
                  >
                    Save College
                  </Button>
                )}

                {hasSavedCollege && !collegeLocked && !collegeEditing && collegeChangesRemaining > 0 && (
                  <Button
                    variant="secondary"
                    size="default"
                    fullWidth
                    onClick={() => {
                      setCollegeEditing(true)
                      setCollegeError(null)
                      setCollegeMessage(null)
                    }}
                  >
                    Edit College (Final Change)
                  </Button>
                )}

                {hasSavedCollege && collegeLocked && (
                  <p className="text-xs text-content-secondary">
                    College is locked after your final edit. Contact {SUPPORT_EMAIL} for corrections.
                  </p>
                )}
                {collegeError && (
                  <p className="text-xs text-error">{collegeError}</p>
                )}
                {collegeMessage && !collegeError && (
                  <p className="text-xs text-content-tertiary">{collegeMessage}</p>
                )}
              </div>
            )}

            {(profileName || profileDomain) && (
              <div className="mt-4 rounded-xl border border-border-secondary bg-surface-primary px-4 py-3 space-y-1">
                {profileName && (
                  <p className="text-xs text-content-secondary">
                    University: <span className="text-content-primary">{profileName}</span>
                  </p>
                )}
                {profileDomain && (
                  <p className="text-xs text-content-secondary">
                    Domain: <span className="text-content-primary">{profileDomain}</span>
                  </p>
                )}
              </div>
            )}
          </div>
        </div>

        <Divider spacing="none" />

        {/* Safety Tools */}
        <div className="px-6 py-6 bg-surface-secondary">
          <h2 className="text-[22px] leading-tight text-content-primary mb-4">Safety Tools</h2>

          {(panicMessage || panicError) && (
            <div className="mb-4">
              <Alert
                variant={panicError ? 'error' : 'success'}
                dismissible
                onDismiss={() => {
                  setPanicMessage(null)
                  setPanicError(null)
                }}
              >
                {panicError || panicMessage}
              </Alert>
            </div>
          )}

          <div className="space-y-3">
            {/* Emergency Contacts */}
            <button
              onClick={() => setShowPanicSheet(true)}
              className="w-full p-5 rounded-xl bg-surface-primary border border-border-secondary text-left"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <AlertCircle className="w-5 h-5 text-content-tertiary" strokeWidth={1.5} />
                  <div>
                    <h3 className="text-[18px] leading-tight text-content-primary mb-1">Emergency Contacts</h3>
                    <p className="text-sm text-content-secondary">Quick access in case of emergency</p>
                  </div>
                </div>
              </div>
            </button>

            {/* Panic Alert */}
            <button
              onClick={handlePanic}
              disabled={panicLoading}
              className="w-full p-5 rounded-xl bg-surface-primary border border-border-secondary text-left"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <AlertCircle className="w-5 h-5 text-content-tertiary" strokeWidth={1.5} />
                  <div>
                    <h3 className="text-[18px] leading-tight text-content-primary mb-1">Panic Alert</h3>
                    <p className="text-sm text-content-secondary">Open a pre-drafted emergency SMS in your messaging app</p>
                  </div>
                </div>
                {panicLoading && (
                  <span className="text-xs text-content-tertiary">Preparing…</span>
                )}
              </div>
            </button>

            {/* Block List */}
            <button
              onClick={() => router.push('/settings/privacy/blocked')}
              className="w-full p-5 rounded-xl bg-surface-primary border border-border-secondary text-left"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Shield className="w-5 h-5 text-content-tertiary" strokeWidth={1.5} />
                  <div>
                    <h3 className="text-[18px] leading-tight text-content-primary mb-1">Blocked Users</h3>
                    <p className="text-sm text-content-secondary">Manage your block list</p>
                  </div>
                </div>
              </div>
            </button>
          </div>

          {alertsLoading ? null : alerts.length > 0 && (
            <div className="mt-6 space-y-3">
              <h3 className="text-[18px] leading-tight text-content-primary">Active Alerts</h3>
              {alerts.map((alert) => {
                const name = alert.owner?.full_name || alert.owner?.username || 'Contact'
                const mapLink = alert.lat && alert.lng
                  ? `https://maps.apple.com/?q=${alert.lat},${alert.lng}`
                  : null
                return (
                  <div
                    key={alert.id}
                    className="w-full p-4 rounded-xl bg-surface-primary border border-border-secondary"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <Avatar src={alert.owner?.avatar_url} size="sm" />
                        <div>
                          <p className="text-body text-content-primary">{name}</p>
                          <p className="text-xs text-content-tertiary">Active alert</p>
                        </div>
                      </div>
                      <MapPin className="w-4 h-4 text-content-tertiary" />
                    </div>
                    {mapLink && (
                      <a
                        href={mapLink}
                        target="_blank"
                        rel="noreferrer"
                        className="mt-3 inline-flex text-sm text-content-primary underline"
                      >
                        View location
                      </a>
                    )}
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>

      {/* Panic Bottom Sheet */}
      <BottomSheet
        isOpen={showPanicSheet}
        onClose={() => setShowPanicSheet(false)}
        title="Emergency Contacts"
      >
        <div className="px-6 py-6 space-y-6">
          {contactError && (
            <Alert variant="error" dismissible onDismiss={() => setContactError(null)}>
              {contactError}
            </Alert>
          )}

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-[18px] leading-tight text-content-primary">Saved contacts</h4>
              <span className="text-xs text-content-tertiary">{contacts.length}</span>
            </div>

            {contactsLoading ? (
              <p className="text-sm text-content-tertiary">Loading contacts…</p>
            ) : contacts.length === 0 ? (
              <div className="rounded-xl border border-border-secondary bg-surface-secondary p-4 text-sm text-content-secondary">
                Add trusted contacts. Panic Alert opens your messaging app with a pre-drafted SMS.
              </div>
            ) : (
              <div className="space-y-3">
                {contacts.map((contact) => (
                  <div
                    key={contact.id}
                    className="flex items-center justify-between gap-3 rounded-xl border border-border-secondary bg-surface-secondary p-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      {contact.type === 'user' ? (
                        <Avatar src={contact.avatar_url} size="sm" />
                      ) : (
                        <div className="h-8 w-8 rounded-full border border-border-secondary bg-surface-primary flex items-center justify-center">
                          <Phone className="h-4 w-4 text-content-tertiary" />
                        </div>
                      )}
                      <div>
                        <p className="text-sm text-content-primary">
                          {contact.full_name || contact.username || contact.external_name || contact.external_phone || 'Contact'}
                        </p>
                        {contact.type === 'user' && contact.username && (
                          <p className="text-xs text-content-tertiary">@{contact.username}</p>
                        )}
                        {contact.type === 'phone' && contact.external_phone && (
                          <p className="text-xs text-content-tertiary">{contact.external_phone}</p>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={() => handleRemoveContact(contact.id)}
                      className="text-xs text-content-tertiary underline"
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-3">
            <h4 className="text-[18px] leading-tight text-content-primary">Add external phone number</h4>
            <div className="grid grid-cols-1 gap-2">
              <input
                value={externalContactName}
                onChange={(event) => setExternalContactName(event.target.value.slice(0, 80))}
                placeholder="Name (optional)"
                className="w-full px-4 py-3 rounded-xl border border-border-secondary bg-surface-primary text-sm text-content-primary placeholder:text-content-tertiary focus:outline-none"
              />
              <div className="relative">
                <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-content-tertiary" />
                <input
                  value={externalContactPhone}
                  onChange={(event) => setExternalContactPhone(event.target.value)}
                  placeholder="+1 555 123 4567"
                  className="w-full pl-11 pr-4 py-3 rounded-xl border border-border-secondary bg-surface-primary text-sm text-content-primary placeholder:text-content-tertiary focus:outline-none"
                  style={{ color: 'var(--content-primary)', WebkitTextFillColor: 'var(--content-primary)' }}
                  inputMode="tel"
                />
              </div>
              <Button
                variant="secondary"
                fullWidth
                loading={externalContactSaving}
                onClick={handleAddExternalContact}
                disabled={externalContactSaving || !externalContactPhone.trim()}
              >
                Add Phone Contact
              </Button>
              <p className="text-xs text-content-tertiary">
                Panic Alert opens your device messaging app and pre-fills an emergency SMS to these numbers.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="text-[18px] leading-tight text-content-primary">Add a contact</h4>
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-content-tertiary" />
              <input
                value={contactQuery}
                onChange={(event) => setContactQuery(event.target.value)}
                placeholder="Search by name or @username"
                className="w-full pl-11 pr-4 py-3 rounded-xl border border-border-secondary bg-surface-primary text-sm text-content-primary placeholder:text-content-tertiary focus:outline-none"
                style={{ color: 'var(--content-primary)', WebkitTextFillColor: 'var(--content-primary)' }}
              />
            </div>

            {contactSearching ? (
              <p className="text-sm text-content-tertiary">Searching…</p>
            ) : contactQuery.trim() && contactResults.length === 0 ? (
              <p className="text-sm text-content-tertiary">No results</p>
            ) : (
              <div className="space-y-2">
                {contactResults.map((person) => (
                  <button
                    key={person.id}
                    onClick={() => handleAddContact(person)}
                    className="w-full flex items-center justify-between gap-3 rounded-xl border border-border-secondary bg-surface-secondary p-3 text-left"
                  >
                    <div className="flex items-center gap-3">
                      <Avatar src={person.avatar_url} size="sm" />
                      <div>
                        <p className="text-sm text-content-primary">
                          {person.full_name || person.username || 'User'}
                        </p>
                        {person.username && (
                          <p className="text-xs text-content-tertiary">@{person.username}</p>
                        )}
                      </div>
                    </div>
                    <UserPlus className="h-4 w-4 text-content-tertiary" />
                  </button>
                ))}
              </div>
            )}
          </div>

          <Button variant="secondary" fullWidth onClick={() => setShowPanicSheet(false)}>
            Close
          </Button>
        </div>
      </BottomSheet>
    </div>
  )
}
