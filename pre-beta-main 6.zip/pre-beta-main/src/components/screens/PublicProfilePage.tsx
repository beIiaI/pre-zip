'use client'

import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Avatar } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { ArrowLeft } from 'lucide-react'
import { MemberBadgeStack } from '@/components/ui/member-badge-stack'
import { Alert } from '@/components/ui/alert'

type ProfileDetail = {
  id: string
  username: string | null
  full_name: string | null
  avatar_url: string | null
  bio: string | null
  location: string | null
  early_supporter_number: number | null
  founder_number: number | null
  is_founder: boolean
  followers_count: number
  following_count: number
  is_following: boolean
  interests?: string[]
  university_name?: string | null
  college_name?: string | null
}

const isUuid = (value: string) =>
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value)

export function PublicProfilePage() {
  const params = useParams()
  const router = useRouter()
  const { user, profile, loading, initialized } = useAuth()
  const [data, setData] = useState<ProfileDetail | null>(null)
  const [loadingProfile, setLoadingProfile] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [messageError, setMessageError] = useState<string | null>(null)
  const [messageLoading, setMessageLoading] = useState(false)

  const handle = typeof params.username === 'string' ? params.username : params.username?.[0]

  useEffect(() => {
    if (!initialized || loading) return
    if (!user) {
      router.replace('/')
      return
    }
    if (profile?.username && handle && profile.username.toLowerCase() === handle.toLowerCase()) {
      router.replace('/profile')
      return
    }
    if (user?.id && handle && user.id === handle) {
      router.replace('/profile')
      return
    }
  }, [initialized, loading, user, profile?.username, handle, router])

  useEffect(() => {
    if (!initialized || loading || !user || !handle) return
    let active = true
    setLoadingProfile(true)
    setError(null)
    const loadProfile = async () => {
      const byUsername = await fetch(`/api/users/username?u=${encodeURIComponent(handle)}`)
      if (byUsername.ok) {
        return byUsername.json()
      }
      if (byUsername.status === 404 && isUuid(handle)) {
        const byId = await fetch(`/api/users/preview?id=${encodeURIComponent(handle)}`)
        if (byId.ok) {
          return byId.json()
        }
      }
      throw new Error('Not found')
    }

    loadProfile()
      .then((payload) => {
        if (!active) return
        setData(payload.profile ?? null)
      })
      .catch(() => {
        if (active) setError('Profile not found')
      })
      .finally(() => {
        if (active) setLoadingProfile(false)
      })
    return () => {
      active = false
    }
  }, [initialized, loading, user, handle])

  if (!initialized || loading || !user || loadingProfile) {
    return <LoadingScreen />
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-surface-primary safe-top safe-bottom flex flex-col items-center justify-center">
        <p className="text-body text-content-secondary mb-4">{error || 'Profile not found'}</p>
        <Button variant="secondary" onClick={() => router.back()}>Go back</Button>
      </div>
    )
  }

  const hasEarlySupporter =
    data.early_supporter_number !== null && data.early_supporter_number !== undefined
  const hasFounderBadge = data.is_founder === true
  const hasMemberBadges = hasFounderBadge || hasEarlySupporter
  const handleFollowToggle = async () => {
    const next = !data.is_following
    setData((prev) => prev ? {
      ...prev,
      is_following: next,
      followers_count: Math.max(0, prev.followers_count + (next ? 1 : -1)),
    } : prev)
    const endpoint = next ? '/api/follow' : '/api/unfollow'
    await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ following_id: data.id }),
    }).catch(() => {
      setData((prev) => prev ? {
        ...prev,
        is_following: !next,
        followers_count: Math.max(0, prev.followers_count + (next ? -1 : 1)),
      } : prev)
    })
  }

  const handleMessage = async () => {
    if (messageLoading) return
    setMessageError(null)
    setMessageLoading(true)
    try {
      const response = await fetch('/api/dms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: data.id }),
      })
      const payload = await response.json()
      if (!response.ok) {
        throw new Error(payload.error || 'Unable to start message')
      }
      if (payload.thread_id) {
        router.push(`/messages/${payload.thread_id}`)
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to start a message right now.'
      setMessageError(message)
    } finally {
      setMessageLoading(false)
    }
  }

  return (
    <div className="relative min-h-screen bg-surface-primary safe-top safe-bottom animate-route-enter">
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <span className="absolute left-[-12%] top-[14%] h-44 w-44 rounded-full bg-content-primary/5 blur-3xl animate-ambient-float-soft" />
        <span className="absolute right-[-12%] bottom-[18%] h-44 w-44 rounded-full bg-content-primary/5 blur-3xl animate-ambient-float-soft-reverse" />
      </div>

      <header className="relative z-10 px-4 py-4 flex items-center justify-between border-b border-border-secondary animate-section-reveal">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">Profile</h1>
        <div className="w-9" />
      </header>

      <main className="relative z-10 px-6 py-8">
        <div className="max-w-md mx-auto space-y-8">
          {messageError && (
            <Alert variant="error" dismissible onDismiss={() => setMessageError(null)}>
              {messageError}
            </Alert>
          )}
          <section className="animate-section-reveal flex flex-col items-center text-center space-y-4">
            <Avatar src={data.avatar_url} size="xl" />
            <div>
              <h2 className="text-title text-content-primary">{data.full_name || data.username || 'Unknown'}</h2>
              {data.username && <p className="text-body text-content-secondary">@{data.username}</p>}
            </div>
            {(data.university_name || data.college_name || hasMemberBadges) && (
              <div className="flex flex-wrap items-center justify-center gap-2">
                {data.university_name && (
                  <span className="px-3 py-1 rounded-full border border-border-secondary bg-surface-secondary text-caption text-content-primary">
                    {data.university_name}
                  </span>
                )}
                {data.college_name && (
                  <span className="px-3 py-1 rounded-full border border-border-secondary bg-surface-secondary text-caption text-content-primary">
                    {data.college_name}
                  </span>
                )}
                {hasMemberBadges && (
                  <Link href={`/badges/early-supporter?uid=${encodeURIComponent(data.id)}`}>
                    <MemberBadgeStack
                      isFounder={data.is_founder}
                      founderNumber={data.founder_number}
                      earlySupporterNumber={data.early_supporter_number}
                    />
                  </Link>
                )}
              </div>
            )}
          </section>

          <div className="h-px bg-border-secondary animate-section-reveal" style={{ animationDelay: '40ms' }} />

          <section className="space-y-3 animate-section-reveal" style={{ animationDelay: '70ms' }}>
            <p className="text-label-caps text-content-tertiary">Community</p>
            <div className="rounded-[1.2rem] border border-border-secondary bg-surface-secondary/70 p-2.5">
              <div className="grid grid-cols-2 divide-x divide-border-secondary">
                <Link
                  href={data.username
                    ? `/profile/${data.username}/followers`
                    : `/profile/followers?uid=${encodeURIComponent(data.id)}`}
                  className="flex flex-col items-center py-2"
                >
                  <p className="text-title text-content-primary">{data.followers_count}</p>
                  <p className="text-caption text-content-secondary">Followers</p>
                </Link>
                <Link
                  href={data.username
                    ? `/profile/${data.username}/following`
                    : `/profile/following?uid=${encodeURIComponent(data.id)}`}
                  className="flex flex-col items-center py-2"
                >
                  <p className="text-title text-content-primary">{data.following_count}</p>
                  <p className="text-caption text-content-secondary">Following</p>
                </Link>
              </div>
            </div>
          </section>

          {data.bio && (
            <section className="space-y-2 animate-section-reveal" style={{ animationDelay: '105ms' }}>
              <p className="text-label-caps text-content-tertiary">About</p>
              <p className="text-body text-content-secondary type-align-body whitespace-pre-wrap break-words">
                {data.bio}
              </p>
            </section>
          )}

          {data.interests && data.interests.length > 0 && (
            <section className="space-y-3 text-left animate-section-reveal" style={{ animationDelay: '135ms' }}>
              <p className="text-label-caps text-content-tertiary">Interests</p>
              <div className="flex flex-wrap gap-2">
                {data.interests.map((interest) => (
                  <span
                    key={interest}
                    className="px-3 py-1.5 rounded-full bg-surface-secondary/60 border border-border-secondary text-caption text-content-primary"
                  >
                    {interest}
                  </span>
                ))}
              </div>
            </section>
          )}

          <div className="grid grid-cols-2 gap-3 animate-section-reveal" style={{ animationDelay: '170ms' }}>
            <Button onClick={handleFollowToggle} variant={data.is_following ? 'secondary' : 'primary'} className="w-full">
              {data.is_following ? 'Following' : 'Follow'}
            </Button>
            <Button onClick={handleMessage} variant="secondary" className="w-full" loading={messageLoading}>
              Message
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}
