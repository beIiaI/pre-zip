'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Alert } from '@/components/ui/alert'
import { Toggle } from '@/components/ui/toggle'
import { ArrowLeft } from 'lucide-react'
import Link from 'next/link'

export default function NewEventPage() {
  const { user, profile, loading, initialized, profileLoaded } = useAuth()
  const router = useRouter()
  const [redirecting, setRedirecting] = useState(false)
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [location, setLocation] = useState('')
  const [startsAt, setStartsAt] = useState('')
  const [endsAt, setEndsAt] = useState('')
  const [isCampusOnly, setIsCampusOnly] = useState(false)
  const [maxAttendees, setMaxAttendees] = useState<string>('')
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const canCampus = profile?.university_verified === true

  useEffect(() => {
    if (!initialized || loading) return
    if (!user) {
      setRedirecting(true)
      router.replace('/')
    }
  }, [initialized, loading, user, router])

  if (!initialized || loading || !profileLoaded || redirecting) {
    return <LoadingScreen />
  }

  if (!user) {
    return <LoadingScreen />
  }

  const handleSubmit = async () => {
    setError(null)
    if (!title.trim()) {
      setError('Title is required')
      return
    }
    if (!startsAt) {
      setError('Start time is required')
      return
    }
    if (isCampusOnly && !canCampus) {
      setError('Verification required for campus-only events')
      return
    }

    setSubmitting(true)
    try {
      const response = await fetch('/api/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: title.trim(),
          description: description.trim() || null,
          starts_at: new Date(startsAt).toISOString(),
          ends_at: endsAt ? new Date(endsAt).toISOString() : null,
          location_text: location.trim() || null,
          is_public: !isCampusOnly,
          is_campus_only: isCampusOnly,
          max_attendees: maxAttendees ? Number(maxAttendees) : null,
        }),
      })
      const data = await response.json()
      if (!response.ok) {
        throw new Error(data.error || 'Failed to create event')
      }
      router.push(`/events/${data.event.id}`)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create event')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-surface-primary safe-top safe-bottom">
      <header className="px-4 py-4 flex items-center justify-between border-b border-border-secondary">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">New Event</h1>
        <div className="w-9" />
      </header>

      <main className="px-4 py-6">
        <div className="max-w-md mx-auto space-y-6">
          {error && (
            <Alert variant="error" dismissible onDismiss={() => setError(null)}>
              {error}
            </Alert>
          )}

          <Input
            label="Title"
            placeholder="Event title"
            value={title}
            onChange={(event) => setTitle(event.target.value)}
          />

          <div className="space-y-2">
            <label className="text-callout font-medium text-content-primary">Description</label>
            <textarea
              placeholder="What’s happening?"
              value={description}
              onChange={(event) => setDescription(event.target.value)}
              rows={4}
              className="flex w-full rounded-input border bg-surface-secondary px-4 py-3 text-body text-content-primary placeholder:text-content-tertiary border-border-primary focus:border-border-focus focus:outline-none focus:ring-1 focus:ring-border-focus resize-none"
            />
          </div>

          <Input
            label="Location"
            placeholder="City, venue, or link"
            value={location}
            onChange={(event) => setLocation(event.target.value)}
          />

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <label className="text-callout font-medium text-content-primary">Starts</label>
              <input
                type="datetime-local"
                value={startsAt}
                onChange={(event) => setStartsAt(event.target.value)}
                className="w-full rounded-input border bg-surface-secondary px-3 py-2 text-body text-content-primary border-border-primary focus:border-border-focus focus:outline-none focus:ring-1 focus:ring-border-focus"
              />
            </div>
            <div className="space-y-2">
              <label className="text-callout font-medium text-content-primary">Ends</label>
              <input
                type="datetime-local"
                value={endsAt}
                onChange={(event) => setEndsAt(event.target.value)}
                className="w-full rounded-input border bg-surface-secondary px-3 py-2 text-body text-content-primary border-border-primary focus:border-border-focus focus:outline-none focus:ring-1 focus:ring-border-focus"
              />
            </div>
          </div>

          <Input
            label="Max attendees (optional)"
            placeholder="e.g. 30"
            value={maxAttendees}
            onChange={(event) => setMaxAttendees(event.target.value.replace(/\D/g, ''))}
          />

          <div className="rounded-card border border-border-secondary bg-surface-secondary p-4 space-y-3">
            <Toggle
              enabled={isCampusOnly}
              onChange={setIsCampusOnly}
              disabled={!canCampus}
              label="Campus-only event"
              description={
                canCampus
                  ? 'Visible only to verified students'
                  : 'Verify with your university email to create campus-only events'
              }
            />
            {!canCampus && (
              <Link href="/settings/safety-verification" className="inline-flex">
                <Button variant="secondary" size="sm">
                  Verify with university email
                </Button>
              </Link>
            )}
          </div>

          <Button className="w-full" onClick={handleSubmit} loading={submitting}>
            Create Event
          </Button>
        </div>
      </main>
    </div>
  )
}
