'use client'

import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Button } from '@/components/ui/button'
import { Avatar } from '@/components/ui/avatar'
import { BentoCell, BentoDivider, BentoFrame, BentoGrid, BentoLabel } from '@/components/ui/bento'
import { VisualSurface } from '@/components/ui/visual-surface'
import { ArrowLeft, Calendar, MapPin, Users } from 'lucide-react'

type EventDetail = {
  id: string
  title: string
  description: string | null
  starts_at: string
  ends_at: string | null
  location_text: string | null
  max_attendees: number | null
  is_campus_only?: boolean
}

type Attendee = {
  id: string
  username: string | null
  full_name: string | null
  avatar_url: string | null
}

type RsvpCounts = {
  going: number
  interested: number
  cant_go: number
}

const formatDateTime = (value: string) => {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return date.toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })
}

export default function EventDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { user, loading, initialized } = useAuth()
  const [event, setEvent] = useState<EventDetail | null>(null)
  const [attendees, setAttendees] = useState<Attendee[]>([])
  const [counts, setCounts] = useState<RsvpCounts>({ going: 0, interested: 0, cant_go: 0 })
  const [myRsvp, setMyRsvp] = useState<'going' | 'interested' | 'cant_go' | null>(null)
  const [loadingEvent, setLoadingEvent] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [rsvpError, setRsvpError] = useState<string | null>(null)
  const [redirecting, setRedirecting] = useState(false)

  const eventId = typeof params.id === 'string' ? params.id : params.id?.[0]

  useEffect(() => {
    if (!initialized || loading) return
    if (!user) {
      setRedirecting(true)
      router.replace('/')
    }
  }, [initialized, loading, user, router])

  useEffect(() => {
    if (!user || !eventId) return
    let active = true
    setLoadingEvent(true)
    setError(null)
    fetch(`/api/events/${encodeURIComponent(eventId)}`)
      .then((res) => {
        if (!res.ok) {
          throw new Error('Event not found')
        }
        return res.json()
      })
      .then((data) => {
        if (!active) return
        setEvent(data.event ?? null)
        setCounts(data.rsvp_counts ?? { going: 0, interested: 0, cant_go: 0 })
        setMyRsvp(data.my_rsvp ?? null)
        setAttendees(data.attendees ?? [])
      })
      .catch((err) => {
        if (!active) return
        setError(err instanceof Error ? err.message : 'Event not found')
      })
      .finally(() => {
        if (active) setLoadingEvent(false)
      })
    return () => {
      active = false
    }
  }, [user, eventId])

  if (!initialized || loading || redirecting) {
    return <LoadingScreen />
  }

  if (!user) {
    return <LoadingScreen />
  }

  if (loadingEvent) {
    return <LoadingScreen />
  }

  if (error || !event) {
    return (
      <div className="min-h-screen bg-surface-primary safe-top safe-bottom flex flex-col items-center justify-center px-6 text-center">
        <p className="text-body text-content-secondary mb-4">{error || 'Event not found'}</p>
        <Button variant="secondary" onClick={() => router.back()}>
          Go back
        </Button>
      </div>
    )
  }

  const handleRsvp = async (status: 'going' | 'interested' | 'cant_go') => {
    setRsvpError(null)
    const previous = myRsvp
    setMyRsvp(status)
    setCounts((prev) => {
      const next = { ...prev }
      if (previous === 'going') next.going -= 1
      if (previous === 'interested') next.interested -= 1
      if (previous === 'cant_go') next.cant_go -= 1
      if (status === 'going') next.going += 1
      if (status === 'interested') next.interested += 1
      if (status === 'cant_go') next.cant_go += 1
      return next
    })

    try {
      const response = await fetch('/api/events/rsvp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ event_id: eventId, status }),
      })
      const data = await response.json().catch(() => null)
      if (!response.ok) {
        throw new Error(data?.error || 'Failed to RSVP')
      }
      if (data?.counts) {
        setCounts(data.counts)
      }
    } catch (err) {
      setMyRsvp(previous)
      setRsvpError(err instanceof Error ? err.message : 'Unable to update RSVP. Please try again.')
    }
  }

  const isFull =
    event.max_attendees !== null &&
    event.max_attendees !== undefined &&
    counts.going >= event.max_attendees &&
    myRsvp !== 'going'

  return (
    <div className="relative min-h-screen bg-surface-primary safe-top safe-bottom animate-route-enter">
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <span className="absolute left-[-12%] top-[14%] h-44 w-44 rounded-full bg-content-primary/5 blur-3xl animate-ambient-float-soft" />
        <span className="absolute right-[-14%] bottom-[20%] h-48 w-48 rounded-full bg-content-primary/5 blur-3xl animate-ambient-float-soft-reverse" />
      </div>

      <header className="relative z-10 px-4 py-4 flex items-center justify-between border-b border-border-secondary animate-section-reveal">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">Event</h1>
        <div className="w-9" />
      </header>

      <main className="relative z-10 px-4 py-6">
        <div className="max-w-md mx-auto">
          <BentoFrame>
            <BentoGrid>
              <BentoCell className="bento-tint-peach hierarchy-hero border-t-0 border-l-0 space-y-3 animate-section-reveal">
                <VisualSurface
                  seed={`${event.id}-${event.title}`}
                  variant="door"
                  title={event.title}
                  className="mx-auto w-[min(72vw,14rem)]"
                />
                <div className="flex items-center justify-center">
                  {event.is_campus_only && (
                    <BentoLabel>Campus-only</BentoLabel>
                  )}
                </div>
                <BentoDivider />
                <div className="flex items-center gap-2 text-callout text-content-secondary">
                  <Calendar className="h-4 w-4" />
                  <span>{formatDateTime(event.starts_at)}</span>
                </div>
                {event.location_text && (
                  <a
                    href={`https://maps.google.com/?q=${encodeURIComponent(event.location_text)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-callout text-content-secondary hover:text-content-primary transition-colors"
                  >
                    <MapPin className="h-4 w-4 flex-shrink-0" />
                    <span className="underline decoration-dotted underline-offset-2">{event.location_text}</span>
                  </a>
                )}
              </BentoCell>

              {event.description && (
                <BentoCell className="bento-tint-mist animate-section-reveal" style={{ animationDelay: '70ms' }}>
                  <p className="text-body text-content-secondary type-align-body whitespace-pre-line">{event.description}</p>
                </BentoCell>
              )}

              {rsvpError && (
                <BentoCell className="text-sm text-error">
                  {rsvpError}
                </BentoCell>
              )}

              <BentoCell className="dynamic-card bento-tint-lilac space-y-3 animate-section-reveal" style={{ animationDelay: '110ms' }}>
                <div className="flex items-center justify-between text-caption text-content-tertiary">
                  <span>Going {counts.going}</span>
                  <span>Interested {counts.interested}</span>
                  <span>Can't go {counts.cant_go}</span>
                </div>
                <BentoDivider />
                {event.max_attendees && (
                  <p className="text-caption text-content-secondary">
                    Capacity {counts.going}/{event.max_attendees}
                  </p>
                )}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <Button
                    variant={myRsvp === 'going' ? 'primary' : 'secondary'}
                    className="w-full"
                    onClick={() => handleRsvp('going')}
                    disabled={isFull}
                  >
                    {isFull ? 'Full' : 'Going'}
                  </Button>
                  <Button
                    variant={myRsvp === 'interested' ? 'primary' : 'secondary'}
                    className="w-full"
                    onClick={() => handleRsvp('interested')}
                  >
                    Interested
                  </Button>
                  <Button
                    variant={myRsvp === 'cant_go' ? 'primary' : 'secondary'}
                    className="w-full"
                    onClick={() => handleRsvp('cant_go')}
                  >
                    Can't go
                  </Button>
                </div>
              </BentoCell>

              <BentoCell className="bento-tint-honey animate-section-reveal" style={{ animationDelay: '150ms' }}>
                <Button variant="secondary" className="w-full" onClick={() => router.push(`/events/${event.id}/chat`)}>
                  Open Event Chat
                </Button>
              </BentoCell>

              <BentoCell className="dynamic-card bento-tint-sage animate-section-reveal" style={{ animationDelay: '190ms' }}>
                <div className="flex items-center gap-2 text-callout text-content-secondary mb-3">
                  <Users className="h-4 w-4" />
                  <span>Attendees</span>
                </div>
                <BentoDivider className="mb-3" />
                {attendees.length === 0 ? (
                  <p className="text-body text-content-tertiary">Be the first to RSVP.</p>
                ) : (
                  <div className="flex items-center">
                    {attendees.map((person, index) => (
                      <div key={person.id} className={index === 0 ? '' : '-ml-3'}>
                        <Avatar src={person.avatar_url} size="sm" />
                      </div>
                    ))}
                    {counts.going > attendees.length && (
                      <span className="ml-3 text-caption text-content-secondary">
                        +{counts.going - attendees.length} more
                      </span>
                    )}
                  </div>
                )}
              </BentoCell>
            </BentoGrid>
          </BentoFrame>
        </div>
      </main>
    </div>
  )
}
