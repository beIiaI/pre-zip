'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Button } from '@/components/ui/button'
import { BentoCell, BentoDivider, BentoFrame, BentoGrid, BentoLabel } from '@/components/ui/bento'
import { VisualSurface } from '@/components/ui/visual-surface'
import { Calendar, MapPin, Plus } from 'lucide-react'
import { cn } from '@/lib/utils'

type EventItem = {
  id: string
  title: string
  description: string | null
  starts_at: string
  location_text: string | null
  rsvp_counts: { going: number; interested: number; cant_go: number }
  my_rsvp: 'going' | 'interested' | 'cant_go' | null
  is_campus_only?: boolean
}

const formatDateTime = (value: string) => {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return date.toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })
}

export default function EventsPage() {
  const { user, profile, loading, initialized, profileLoaded } = useAuth()
  const router = useRouter()
  const [events, setEvents] = useState<EventItem[]>([])
  const [loadingEvents, setLoadingEvents] = useState(true)
  const [redirecting, setRedirecting] = useState(false)
  const [scope, setScope] = useState<'public' | 'campus'>('public')

  const canViewCampus = profile?.university_verified === true
  const campusLocked = scope === 'campus' && !canViewCampus

  useEffect(() => {
    if (!initialized || loading) return
    if (!user) {
      setRedirecting(true)
      router.replace('/')
    }
  }, [initialized, loading, user, router])

  useEffect(() => {
    if (!user || !profileLoaded) return
    if (scope === 'campus' && !canViewCampus) {
      setEvents([])
      setLoadingEvents(false)
      return
    }
    let active = true
    setLoadingEvents(true)
    fetch(`/api/events?scope=${scope}`)
      .then((res) => res.json())
      .then((data) => {
        if (!active) return
        setEvents(data.events ?? [])
      })
      .finally(() => {
        if (active) setLoadingEvents(false)
      })
    return () => {
      active = false
    }
  }, [user, profileLoaded, scope, canViewCampus])

  if (!initialized || loading || !profileLoaded || redirecting) {
    return <LoadingScreen />
  }

  if (!user) {
    return <LoadingScreen />
  }

  return (
    <div className="app-page safe-top safe-bottom">
      <header className="app-header px-4 py-4">
        <div className="mx-auto flex w-full max-w-[42rem] items-center justify-between">
          <h1 className="text-headline">Events</h1>
          <Button size="sm" onClick={() => router.push('/events/new')}>
            <Plus className="h-4 w-4" />
            New
          </Button>
        </div>
      </header>

      <main className="app-content">
        <BentoFrame className="mb-5">
          <BentoCell className="bento-tint-peach hierarchy-hero border-t-0 border-l-0 flex items-center gap-3">
            <div className="flex-1 rounded-full border border-border-secondary bg-surface-secondary p-1">
              <div className="grid grid-cols-2 gap-1">
                <button
                  type="button"
                  onClick={() => setScope('public')}
                  className={cn(
                    'rounded-full py-2 text-sm font-medium transition-colors',
                    scope === 'public'
                      ? 'bg-surface-primary text-content-primary'
                      : 'text-content-secondary'
                  )}
                >
                  Public
                </button>
                <button
                  type="button"
                  onClick={() => setScope('campus')}
                  className={cn(
                    'rounded-full py-2 text-sm font-medium transition-colors',
                    scope === 'campus'
                      ? 'bg-surface-primary text-content-primary'
                      : 'text-content-secondary'
                  )}
                >
                  Campus
                </button>
              </div>
            </div>
            {canViewCampus && (
              <BentoLabel>Verified</BentoLabel>
            )}
          </BentoCell>
        </BentoFrame>

        {campusLocked ? (
          <BentoFrame>
            <BentoCell className="border-t-0 border-l-0 text-center">
              <h3 className="text-headline text-content-primary mb-2">Campus events are locked</h3>
              <p className="text-body text-content-secondary mb-4">
                Verify with your university email to access campus-only events and chats.
              </p>
              <Link href="/settings/safety-verification">
                <Button>Verify with university email</Button>
              </Link>
            </BentoCell>
          </BentoFrame>
        ) : loadingEvents ? (
          <LoadingScreen />
        ) : events.length === 0 ? (
          <BentoFrame>
            <BentoCell className="border-t-0 border-l-0 flex flex-col items-center justify-center py-16 text-center">
              <div className="h-16 w-16 rounded-full bg-surface-secondary flex items-center justify-center mb-4">
                <Calendar className="h-8 w-8 text-content-tertiary" />
              </div>
              <h3 className="text-headline text-content-primary mb-2">No events yet</h3>
              <p className="text-body text-content-secondary mb-6 max-w-xs">
                {scope === 'campus'
                  ? 'Campus events will appear here once they’re created.'
                  : 'Create the first event in your community.'}
              </p>
              <Button onClick={() => router.push('/events/new')}>
                <Plus className="h-4 w-4" />
                Create Event
              </Button>
            </BentoCell>
          </BentoFrame>
        ) : (
          <BentoFrame>
            <BentoGrid>
            {events.map((event, index) => (
              <Link
                key={event.id}
                href={`/events/${event.id}`}
                className={`bento-cell dynamic-card block ${
                  index % 3 === 0
                    ? 'bento-tint-honey'
                    : index % 3 === 1
                      ? 'bento-tint-mist'
                      : 'bento-tint-lilac'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <h3 className="text-headline text-content-primary">{event.title}</h3>
                  {event.is_campus_only && (
                    <BentoLabel>
                      Campus-only
                    </BentoLabel>
                  )}
                </div>
                <VisualSurface
                  seed={`${event.id}-${event.title}`}
                  variant="fullWidth"
                  showWordmark={false}
                />
                <div className="space-y-2 mt-3">
                  <div className="flex items-center gap-2 text-callout text-content-secondary">
                    <Calendar className="h-4 w-4" />
                    <span>{formatDateTime(event.starts_at)}</span>
                  </div>
                  {event.location_text && (
                    <a
                      href={`https://maps.google.com/?q=${encodeURIComponent(event.location_text)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-callout text-content-secondary hover:text-content-primary transition-colors"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <MapPin className="h-4 w-4 flex-shrink-0" />
                      <span className="underline decoration-dotted underline-offset-2">{event.location_text}</span>
                    </a>
                  )}
                  {event.description && (
                    <>
                      <BentoDivider />
                      <p className="text-body text-content-secondary line-clamp-2 type-align-body">{event.description}</p>
                    </>
                  )}
                  <div className="flex items-center gap-4 text-caption text-content-tertiary pt-1">
                    <span>Going {event.rsvp_counts.going}</span>
                    <span>Interested {event.rsvp_counts.interested}</span>
                    <span>Can't go {event.rsvp_counts.cant_go}</span>
                    {event.my_rsvp && (
                      <span className="uppercase tracking-wide text-content-primary">
                        {event.my_rsvp.replace('_', ' ')}
                      </span>
                    )}
                  </div>
                </div>
              </Link>
            ))}
            </BentoGrid>
          </BentoFrame>
        )}
      </main>
    </div>
  )
}
