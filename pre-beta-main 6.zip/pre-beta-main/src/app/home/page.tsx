'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { HomeHeader } from '@/components/home/header'
import { HomeTabs } from '@/components/home/tabs'
import { LoadingScreen } from '@/components/ui/spinner'

export default function HomePage() {
  const { user, profile, loading, initialized, profileLoaded } = useAuth()
  const router = useRouter()
  const booting = !initialized || loading || !profileLoaded
  const redirectTarget = !booting
    ? (!user ? '/' : (!profile || profile.onboarding_completed !== true ? '/onboarding' : null))
    : null

  useEffect(() => {
    if (redirectTarget) {
      router.replace(redirectTarget)
    }
  }, [redirectTarget, router])

  if (booting || redirectTarget || !user || !profile || profile.onboarding_completed !== true) {
    return <LoadingScreen />
  }

  return (
    <div className="app-page safe-top safe-bottom">
      <HomeHeader profile={profile} />
      <main className="mx-auto w-full max-w-[64rem] px-4 pb-4 pt-3 sm:px-5">
        <HomeTabs />
      </main>
    </div>
  )
}
