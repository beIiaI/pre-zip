'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Alert } from '@/components/ui/alert'
import { validatePassword } from '@/lib/utils'
import { Check, X, Mail } from 'lucide-react'

export default function ResetPasswordPage() {
  const { user, loading, initialized, profileLoaded } = useAuth()
  const router = useRouter()
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  const checks = {
    length: password.length >= 8,
    lower: /[a-z]/.test(password),
    upper: /[A-Z]/.test(password),
    number: /[0-9]/.test(password),
    symbol: /[^A-Za-z0-9]/.test(password),
  }

  const handleSubmit = async () => {
    setError(null)
    setSuccess(null)

    const validation = validatePassword(password)
    if (!validation.valid) {
      setError(validation.error || 'Invalid password')
      return
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match')
      return
    }

    setSubmitting(true)
    try {
      const response = await fetch('/api/auth/password/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      })
      const data = await response.json().catch(() => ({}))
      if (!response.ok) {
        throw new Error(data?.error || 'Unable to update password')
      }
      setSuccess('Password updated.')
      setPassword('')
      setConfirmPassword('')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to update password')
    } finally {
      setSubmitting(false)
    }
  }

  if (!initialized || loading || !profileLoaded) {
    return <LoadingScreen />
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-surface-primary safe-top safe-bottom flex flex-col items-center justify-center px-6 text-center">
        <div className="w-12 h-12 rounded-full bg-surface-secondary border border-border-secondary flex items-center justify-center mb-4">
          <Mail className="h-5 w-5 text-content-primary" />
        </div>
        <p className="text-body text-content-primary">Open the reset link from your email to continue.</p>
        <Button
          variant="secondary"
          className="mt-4 w-full max-w-xs"
          onClick={() => {
            if (typeof window !== 'undefined') {
              window.location.href = 'mailto:'
            }
          }}
        >
          Open Mail App
        </Button>
        <Button
          variant="ghost"
          className="mt-2 w-full max-w-xs"
          onClick={() => router.replace('/auth?mode=signin')}
        >
          Back to sign in
        </Button>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-surface-primary safe-top safe-bottom px-6 py-10">
      <div className="max-w-sm mx-auto space-y-6">
        <div>
          <h1 className="text-display text-content-primary font-display">Reset password</h1>
          <p className="text-body text-content-secondary">
            Choose a strong password to secure your account.
          </p>
        </div>

        {error && (
          <Alert variant="error" dismissible onDismiss={() => setError(null)}>
            {error}
          </Alert>
        )}
        {success && (
          <Alert variant="success" dismissible onDismiss={() => setSuccess(null)}>
            {success}
          </Alert>
        )}

        <Input
          type="password"
          label="New password"
          placeholder="Enter your new password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          autoComplete="new-password"
        />
        <Input
          type="password"
          label="Confirm password"
          placeholder="Re-enter your new password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          autoComplete="new-password"
        />

        <div className="rounded-card border border-border-secondary bg-surface-secondary px-4 py-3 space-y-2">
          <p className="text-caption text-content-secondary">Password must include:</p>
          {[
            { label: 'At least 8 characters', ok: checks.length },
            { label: 'One lowercase letter', ok: checks.lower },
            { label: 'One uppercase letter', ok: checks.upper },
            { label: 'One number', ok: checks.number },
            { label: 'One symbol', ok: checks.symbol },
          ].map((rule) => (
            <div key={rule.label} className="flex items-center gap-2 text-caption">
              {rule.ok ? (
                <Check className="h-3.5 w-3.5 text-success" />
              ) : (
                <X className="h-3.5 w-3.5 text-content-tertiary" />
              )}
              <span className={rule.ok ? 'text-content-primary' : 'text-content-tertiary'}>
                {rule.label}
              </span>
            </div>
          ))}
        </div>

        <Button className="w-full" loading={submitting} onClick={handleSubmit}>
          Update password
        </Button>
        {success && (
          <Button variant="secondary" className="w-full" onClick={() => router.replace('/home')}>
            Continue to app
          </Button>
        )}
      </div>
    </div>
  )
}
