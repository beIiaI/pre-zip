import { ResetLinkErrorScreen, type RecoveryReason } from '@/components/screens/ResetLinkErrorScreen'

type PageSearchParams = Promise<{
  reason?: string
}>

function normalizeReason(reason: string | undefined): RecoveryReason {
  if (reason === 'invalid') return 'invalid'
  if (reason === 'missing') return 'missing'
  return 'expired'
}

export default async function ResetLinkErrorPage({
  searchParams,
}: {
  searchParams: PageSearchParams
}) {
  const params = await searchParams
  const reason = normalizeReason(params.reason)
  return <ResetLinkErrorScreen reason={reason} />
}
