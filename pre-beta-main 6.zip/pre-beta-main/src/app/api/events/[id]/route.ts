import { NextRequest } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import { enforceRateLimit, serverFailure, unauthorized, validationFailed } from '@/lib/security/guards'

const PROFILE_FIELDS = 'id, username, full_name, avatar_url, early_supporter_number, founder_number, is_founder'

export const runtime = 'nodejs'

export async function GET(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const requestId = createRequestId()
  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'events:detail',
    request,
    requestId,
    userId: user.id,
    limit: 80,
    windowMs: 15 * 60 * 1000,
  })
  if (rateLimitResponse) return rateLimitResponse

  const { id } = await context.params
  if (!id) {
    return validationFailed(requestId, 'Missing event id.')
  }

  const { data: event, error: eventError } = await supabase
    .from('events')
    .select('*')
    .eq('id', id)
    .maybeSingle()

  if (eventError) {
    logServerError('events.detail.event', requestId, eventError, { eventId: id, userId: user.id })
    return serverFailure(requestId)
  }

  if (!event) {
    return validationFailed(requestId, 'Event not found.')
  }

  const { data: rsvps, error: rsvpError } = await supabase
    .from('event_rsvps')
    .select('event_id, status, user_id')
    .eq('event_id', id)

  if (rsvpError) {
    logServerError('events.detail.rsvps', requestId, rsvpError, { eventId: id })
    return serverFailure(requestId)
  }

  const counts = { going: 0, interested: 0, cant_go: 0 }
  let myRsvp: string | null = null
  const goingIds: string[] = []

  for (const rsvp of rsvps ?? []) {
    if (rsvp.status === 'going') {
      counts.going += 1
      goingIds.push(rsvp.user_id)
    }
    if (rsvp.status === 'interested') counts.interested += 1
    if (rsvp.status === 'cant_go') counts.cant_go += 1
    if (rsvp.user_id === user.id) myRsvp = rsvp.status
  }

  const attendeeIds = goingIds.slice(0, 6)
  const admin = createAdminClient() as any
  const { data: attendees, error: attendeesError } = attendeeIds.length
    ? await admin
        .from('profiles')
        .select(PROFILE_FIELDS)
        .in('id', attendeeIds)
    : { data: [], error: null }

  if (attendeesError) {
    logServerError('events.detail.attendees', requestId, attendeesError, { eventId: id })
    return serverFailure(requestId)
  }

  return successResponse(requestId, {
    event,
    rsvp_counts: counts,
    my_rsvp: myRsvp,
    attendees: attendees ?? [],
  })
}
