import { NextRequest } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import {
  enforceRateLimit,
  enforceSameOrigin,
  serverFailure,
  unauthorized,
  validationFailed,
} from '@/lib/security/guards'
import { parseJsonObject, readString, ValidationError } from '@/lib/security/validation'

const MESSAGE_SELECT =
  'id, content, created_at, sender_id, sender:profiles!event_messages_sender_id_fkey(id, username, full_name, avatar_url)'

const mapMessages = (rows: any[]) =>
  (rows ?? []).map((row) => ({
    id: row.id,
    content: row.content,
    created_at: row.created_at,
    sender: row.sender ?? null,
  }))

export const runtime = 'nodejs'

export async function GET(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const requestId = createRequestId()
  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'events:chat:get',
    request,
    requestId,
    userId: user.id,
    limit: 80,
    windowMs: 15 * 60 * 1000,
  })
  if (rateLimitResponse) return rateLimitResponse

  const { id: eventId } = await context.params
  if (!eventId) {
    return validationFailed(requestId, 'Missing event id.')
  }

  const { data: event, error: eventError } = await supabase
    .from('events')
    .select('id, title, starts_at, is_campus_only')
    .eq('id', eventId)
    .maybeSingle()

  if (eventError) {
    logServerError('events.chat.get.event', requestId, eventError, { userId: user.id, eventId })
    return serverFailure(requestId)
  }

  if (!event) {
    return validationFailed(requestId, 'Event not found.')
  }

  const { data: messages, error: messageError } = await supabase
    .from('event_messages')
    .select(MESSAGE_SELECT)
    .eq('event_id', eventId)
    .order('created_at', { ascending: true })
    .limit(200)

  if (messageError) {
    logServerError('events.chat.get.messages', requestId, messageError, { eventId })
    return serverFailure(requestId)
  }

  return successResponse(requestId, {
    event,
    messages: mapMessages(messages ?? []),
  })
}

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const requestId = createRequestId()
  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'events:chat:post',
    request,
    requestId,
    userId: user.id,
    limit: 80,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 30_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  const { id: eventId } = await context.params
  if (!eventId) {
    return validationFailed(requestId, 'Missing event id.')
  }

  let payload: Record<string, unknown>
  try {
    payload = await parseJsonObject(request)
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid message payload.')
    }
    return validationFailed(requestId, 'Invalid message payload.')
  }

  let content = ''
  try {
    content = readString(payload, 'content', { required: true, max: 2000 })
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Message cannot be empty.')
    }
    return validationFailed(requestId, 'Message cannot be empty.')
  }

  if (!content.trim()) {
    return validationFailed(requestId, 'Message cannot be empty.')
  }

  const { data: event, error: eventError } = await supabase
    .from('events')
    .select('id')
    .eq('id', eventId)
    .maybeSingle()

  if (eventError) {
    logServerError('events.chat.post.event_lookup', requestId, eventError, { userId: user.id, eventId })
    return serverFailure(requestId)
  }

  if (!event) {
    return validationFailed(requestId, 'Event not found.')
  }

  const { data: message, error } = await supabase
    .from('event_messages')
    .insert({
      event_id: eventId,
      sender_id: user.id,
      content: content.trim(),
    })
    .select(MESSAGE_SELECT)
    .single()

  if (error) {
    logServerError('events.chat.post.insert', requestId, error, { userId: user.id, eventId })
    return serverFailure(requestId)
  }

  return successResponse(requestId, { message: mapMessages([message])[0] })
}

