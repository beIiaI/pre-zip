import { createClient } from '@/lib/supabase/server'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import {
  enforceRateLimit,
  enforceSameOrigin,
  serverFailure,
  unauthorized,
  validationFailed,
} from '@/lib/security/guards'
import { parseJsonObject, readString, ValidationError } from '@/lib/security/validation'

const ALLOWED = new Set(['going', 'interested', 'cant_go'])

export const runtime = 'nodejs'

export async function POST(request: Request) {
  const requestId = createRequestId()
  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'events:rsvp',
    request,
    requestId,
    userId: user.id,
    limit: 30,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 60_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  let payload: Record<string, unknown>
  try {
    payload = await parseJsonObject(request)
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid RSVP payload.')
    }
    return validationFailed(requestId, 'Invalid RSVP payload.')
  }

  let eventId = ''
  let status = ''
  try {
    eventId = readString(payload, 'event_id', { required: true })
    status = readString(payload, 'status')
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid RSVP payload.')
    }
    return validationFailed(requestId, 'Invalid RSVP payload.')
  }

  if (!eventId) {
    return validationFailed(requestId, 'Missing event id.')
  }

  const { data: event, error: eventError } = await supabase
    .from('events')
    .select('id, host_id, is_campus_only, max_attendees')
    .eq('id', eventId)
    .maybeSingle()

  if (eventError) {
    logServerError('events.rsvp.event_lookup', requestId, eventError, { userId: user.id, eventId })
    return serverFailure(requestId)
  }

  if (!event) {
    return validationFailed(requestId, 'Event not found.')
  }

  if (event.is_campus_only) {
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('university_verified')
      .eq('id', user.id)
      .maybeSingle()

    if (profileError) {
      logServerError('events.rsvp.profile', requestId, profileError, {
        userId: user.id,
        eventId,
      })
      return serverFailure(requestId)
    }

    if (!profile?.university_verified) {
      return validationFailed(requestId, 'University verification is required for this event.')
    }
  }

  if (status === 'none' || status === '') {
    const { error: deleteError } = await supabase
      .from('event_rsvps')
      .delete()
      .eq('event_id', eventId)
      .eq('user_id', user.id)

    if (deleteError) {
      logServerError('events.rsvp.delete', requestId, deleteError, { userId: user.id, eventId })
      return serverFailure(requestId)
    }

    return successResponse(requestId, { ok: true, status: null })
  }

  if (!ALLOWED.has(status)) {
    return validationFailed(requestId, 'Invalid RSVP status.')
  }

  const { data: existingRsvp, error: existingRsvpError } = await supabase
    .from('event_rsvps')
    .select('status')
    .eq('event_id', eventId)
    .eq('user_id', user.id)
    .maybeSingle()

  if (existingRsvpError) {
    logServerError('events.rsvp.existing', requestId, existingRsvpError, { userId: user.id, eventId })
    return serverFailure(requestId)
  }

  if (status === 'going' && event.max_attendees !== null && event.max_attendees !== undefined) {
    if (existingRsvp?.status !== 'going') {
      const { count, error: countError } = await supabase
        .from('event_rsvps')
        .select('id', { count: 'exact', head: true })
        .eq('event_id', eventId)
        .eq('status', 'going')

      if (countError) {
        logServerError('events.rsvp.capacity_count', requestId, countError, { eventId })
        return serverFailure(requestId)
      }

      if ((count ?? 0) >= event.max_attendees) {
        return validationFailed(requestId, 'Event is full.')
      }
    }
  }

  const { error } = await supabase
    .from('event_rsvps')
    .upsert(
      {
        event_id: eventId,
        user_id: user.id,
        status,
      },
      { onConflict: 'event_id,user_id' }
    )

  if (error) {
    logServerError('events.rsvp.upsert', requestId, error, { userId: user.id, eventId })
    return serverFailure(requestId)
  }

  if (status === 'going') {
    const { error: butterflyError } = await supabase.rpc('award_social_butterfly_if_eligible', { target_user: user.id })
    if (butterflyError) {
      logServerError('events.rsvp.badge_social_butterfly', requestId, butterflyError, {
        userId: user.id,
        eventId,
      })
    }
    const { error: initiatorError } = await supabase.rpc('award_initiator_if_eligible', { event_id: eventId })
    if (initiatorError) {
      logServerError('events.rsvp.badge_initiator', requestId, initiatorError, { eventId })
    }
  }

  const { data: rsvps, error: rsvpCountError } = await supabase
    .from('event_rsvps')
    .select('status')
    .eq('event_id', eventId)

  if (rsvpCountError) {
    logServerError('events.rsvp.counts', requestId, rsvpCountError, { eventId })
    return serverFailure(requestId)
  }

  const counts = { going: 0, interested: 0, cant_go: 0 }
  for (const rsvp of rsvps ?? []) {
    if (rsvp.status === 'going') counts.going += 1
    if (rsvp.status === 'interested') counts.interested += 1
    if (rsvp.status === 'cant_go') counts.cant_go += 1
  }

  return successResponse(requestId, { ok: true, status, counts })
}

