import { NextRequest, NextResponse } from 'next/server'

// Nominatim (OpenStreetMap) — free, no API key required.
// Usage policy requires a User-Agent and max 1 req/sec per IP.
const NOMINATIM_URL = 'https://nominatim.openstreetmap.org/reverse'
const USER_AGENT = 'pre-beta-app/1.0'

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const lat = searchParams.get('lat')
  const lon = searchParams.get('lon')

  if (!lat || !lon) {
    return NextResponse.json({ error: 'lat and lon are required' }, { status: 400 })
  }

  const parsedLat = parseFloat(lat)
  const parsedLon = parseFloat(lon)
  if (!Number.isFinite(parsedLat) || !Number.isFinite(parsedLon)) {
    return NextResponse.json({ error: 'Invalid coordinates' }, { status: 400 })
  }

  try {
    const url = new URL(NOMINATIM_URL)
    url.searchParams.set('lat', String(parsedLat))
    url.searchParams.set('lon', String(parsedLon))
    url.searchParams.set('format', 'json')
    url.searchParams.set('addressdetails', '1')

    const response = await fetch(url.toString(), {
      headers: {
        Accept: 'application/json',
        'User-Agent': USER_AGENT,
      },
    })

    if (!response.ok) {
      return NextResponse.json({ error: 'Geocoding API error' }, { status: 502 })
    }

    const data = await response.json()
    const addr = data.address ?? {}

    const city = addr.city || addr.town || addr.village || addr.suburb || addr.hamlet
    const region = addr.state || addr.county
    const country = addr.country

    let label: string | null = null
    if (city && country) label = `${city}, ${country}`
    else if (region && country) label = `${region}, ${country}`
    else if (country) label = country
    else if (city) label = city

    return NextResponse.json({ label })
  } catch {
    return NextResponse.json({ error: 'Failed to reverse geocode' }, { status: 500 })
  }
}
