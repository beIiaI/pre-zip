import { NextRequest, NextResponse } from 'next/server'

// Nominatim (OpenStreetMap) — free, no API key required.
// Usage policy requires a User-Agent and max 1 req/sec per IP.
// Server-side calls share a single IP, so this is fine for pre-beta traffic.
const NOMINATIM_URL = 'https://nominatim.openstreetmap.org/search'
const USER_AGENT = 'pre-beta-app/1.0'

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const text = searchParams.get('text')

  if (!text || text.length < 2) {
    return NextResponse.json({ results: [] })
  }

  try {
    const url = new URL(NOMINATIM_URL)
    url.searchParams.set('q', text)
    url.searchParams.set('format', 'json')
    url.searchParams.set('addressdetails', '1')
    url.searchParams.set('limit', '12') // fetch extra to allow deduplication
    url.searchParams.set('featuretype', 'city')

    const response = await fetch(url.toString(), {
      headers: {
        Accept: 'application/json',
        'User-Agent': USER_AGENT,
      },
    })

    if (!response.ok) {
      console.error('Nominatim API error:', response.status, response.statusText)
      return NextResponse.json({ error: 'Geocoding API error' }, { status: 502 })
    }

    const data: any[] = await response.json()

    // Deduplicate by city+country — Nominatim often returns the same city
    // multiple times (different admin boundaries, postal districts, etc.)
    const seen = new Set<string>()
    const results = data
      .map((place) => {
        const addr = place.address ?? {}
        const city =
          addr.city || addr.town || addr.village || addr.suburb || addr.hamlet || place.name
        const state = addr.state || addr.county
        const country = addr.country

        return {
          id: String(place.place_id),
          name: city || place.display_name,
          formatted: place.display_name,
          city: city || undefined,
          state: state || undefined,
          country: country || undefined,
          lat: parseFloat(place.lat),
          lon: parseFloat(place.lon),
        }
      })
      .filter((r) => {
        if (!r.city || !r.country) return false
        const key = `${r.city}|${r.country}`
        if (seen.has(key)) return false
        seen.add(key)
        return true
      })
      .slice(0, 8)

    return NextResponse.json({ results })
  } catch (error) {
    console.error('Location autocomplete error:', error)
    return NextResponse.json({ error: 'Failed to fetch locations' }, { status: 500 })
  }
}
