import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { validateUsername } from '@/lib/utils'
import { isRestrictedBio, isRestrictedDisplayName, isRestrictedUsername } from '@/lib/moderation/restrictedWords'

const ALLOWED_FIELDS = [
  'full_name',
  'username',
  'user_intent',
  'interests',
  'date_of_birth',
  'location',
  'location_lat',
  'location_lng',
  'theme_mode',
  'amoled_enabled',
  'bio',
  'avatar_url',
] as const

type AllowedField = (typeof ALLOWED_FIELDS)[number]

export async function POST(request: Request) {
  const supabase = await createClient()

  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  let payload: Record<string, unknown> = {}
  try {
    payload = (await request.json()) as Record<string, unknown>
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload' }, { status: 400 })
  }

  const updatePayload: Record<string, unknown> = {
    onboarding_completed: true,
    onboarding_step: 9,
    updated_at: new Date().toISOString(),
  }

  for (const key of ALLOWED_FIELDS) {
    if (key in payload) {
      updatePayload[key as AllowedField] = payload[key]
    }
  }

  if (typeof updatePayload.username === 'string') {
    const normalized = updatePayload.username.trim().toLowerCase()
    const validation = validateUsername(normalized)
    if (!validation.valid) {
      return NextResponse.json({ error: validation.error || 'Invalid username' }, { status: 400 })
    }
    if (isRestrictedUsername(normalized)) {
      return NextResponse.json({ error: "That username isn't available." }, { status: 409 })
    }
    updatePayload.username = normalized
  } else {
    return NextResponse.json({ error: 'Username is required' }, { status: 400 })
  }

  if (typeof updatePayload.full_name === 'string') {
    const trimmed = updatePayload.full_name.trim().replace(/\s+/g, ' ')
    if (!trimmed) {
      return NextResponse.json({ error: 'Name is required' }, { status: 400 })
    }
    if (isRestrictedDisplayName(trimmed)) {
      return NextResponse.json({ error: "That name isn't available." }, { status: 400 })
    }
    updatePayload.full_name = trimmed
  }

  if (typeof updatePayload.bio === 'string') {
    const trimmed = updatePayload.bio.trim()
    if (!trimmed) {
      updatePayload.bio = null
    } else if (isRestrictedBio(trimmed)) {
      return NextResponse.json({ error: 'Bio contains restricted words.' }, { status: 400 })
    } else {
      updatePayload.bio = trimmed
    }
  }

  const { data, error } = await supabase
    .from('profiles')
    .update(updatePayload)
    .eq('id', user.id)
    .select()
    .maybeSingle()

  if (error) {
    const message = error.message || 'Update failed'
    if (message.toLowerCase().includes('duplicate key') || message.toLowerCase().includes('unique')) {
      return NextResponse.json({ error: 'Username already taken' }, { status: 409 })
    }
    return NextResponse.json({ error: message }, { status: 500 })
  }

  if (data) {
    return NextResponse.json({ profile: data })
  }

  const email = user.email ?? (user.user_metadata?.email as string | undefined)
  if (!email) {
    return NextResponse.json({ error: 'User email not available for profile insert' }, { status: 500 })
  }

  const insertPayload: Record<string, unknown> = {
    id: user.id,
    email,
    ...updatePayload,
  }

  const { data: inserted, error: insertError } = await supabase
    .from('profiles')
    .insert(insertPayload)
    .select()
    .maybeSingle()

  if (insertError) {
    const message = insertError.message || 'Insert failed'
    if (message.toLowerCase().includes('duplicate key') || message.toLowerCase().includes('unique')) {
      return NextResponse.json({ error: 'Username already taken' }, { status: 409 })
    }
    return NextResponse.json({ error: message }, { status: 500 })
  }

  if (!inserted) {
    return NextResponse.json({ error: 'Profile insert did not return data' }, { status: 500 })
  }

  return NextResponse.json({ profile: inserted })
}
