import { NextResponse } from 'next/server'

/**
 * Health check endpoint
 * Used by mobile app and monitoring to verify backend is reachable
 * Always returns 200 OK with { ok: true }
 */
export async function GET() {
  return NextResponse.json(
    { ok: true, timestamp: new Date().toISOString() },
    { status: 200 }
  )
}
