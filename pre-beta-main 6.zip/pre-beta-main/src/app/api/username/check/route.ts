import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { isRestrictedUsername } from '@/lib/moderation/restrictedWords'

const USERNAME_REGEX = /^[a-z0-9_]+$/

export const runtime = 'nodejs'

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const raw = (searchParams.get('u') || '').trim().toLowerCase()

  if (!raw) {
    return NextResponse.json({ available: false, reason: 'missing' }, { status: 400 })
  }

  if (raw.length < 3 || raw.length > 20 || !USERNAME_REGEX.test(raw) || !/^[a-z]/.test(raw)) {
    return NextResponse.json({ available: false, reason: 'invalid' })
  }

  if (isRestrictedUsername(raw)) {
    return NextResponse.json({ available: false, reason: 'restricted' })
  }

  const supabase = await createClient()
  const admin = createAdminClient() as any
  const { data: userData } = await supabase.auth.getUser()
  if (!userData?.user) {
    return NextResponse.json({ available: false, reason: 'unauthorized' }, { status: 401 })
  }

  const { data, error } = await admin
    .from('profiles')
    .select('id')
    .ilike('username', raw)
    .neq('id', userData.user.id)
    .limit(1)
    .maybeSingle()

  if (error) {
    return NextResponse.json({ available: false, reason: 'error' }, { status: 500 })
  }

  return NextResponse.json({ available: !data })
}
