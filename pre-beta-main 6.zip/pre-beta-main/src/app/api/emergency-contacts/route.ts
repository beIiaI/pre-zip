import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'

const CONTACT_FIELDS = 'id, username, full_name, avatar_url'
const MAX_CONTACT_NAME_LENGTH = 80

export const runtime = 'nodejs'

type EmergencyContactPayload = {
  contact_user_id?: string
  external_name?: string
  external_phone?: string
  contact_id?: string
}

type EmergencyContactRow = {
  id: string
  contact_user_id: string | null
  external_name: string | null
  external_phone: string | null
}

type ContactProfile = {
  id: string
  username: string | null
  full_name: string | null
  avatar_url: string | null
}

function normalizePhone(value: string): string | null {
  const trimmed = value.trim()
  if (!trimmed) return null

  let candidate = trimmed
  if (candidate.startsWith('00')) {
    candidate = `+${candidate.slice(2)}`
  }

  if (candidate.startsWith('+')) {
    candidate = `+${candidate.slice(1).replace(/\D/g, '')}`
  } else {
    candidate = `+${candidate.replace(/\D/g, '')}`
  }

  const digits = candidate.slice(1)
  if (!/^\d{7,15}$/.test(digits)) return null
  return candidate
}

function toContactResponse(row: EmergencyContactRow, profile?: ContactProfile | null) {
  if (row.contact_user_id) {
    return {
      id: row.id,
      type: 'user' as const,
      contact_user_id: row.contact_user_id,
      external_name: row.external_name,
      external_phone: row.external_phone,
      username: profile?.username ?? null,
      full_name: profile?.full_name ?? null,
      avatar_url: profile?.avatar_url ?? null,
    }
  }

  return {
    id: row.id,
    type: 'phone' as const,
    contact_user_id: null,
    external_name: row.external_name,
    external_phone: row.external_phone,
    username: null,
    full_name: null,
    avatar_url: null,
  }
}

export async function GET() {
  const supabase = await createClient()
  const admin = createAdminClient() as any
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { data: rows, error } = await supabase
    .from('emergency_contacts')
    .select('id, contact_user_id, external_name, external_phone')
    .eq('owner_id', user.id)
    .order('created_at', { ascending: true })

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  const typedRows = (rows ?? []) as EmergencyContactRow[]
  const contactUserIds = typedRows
    .map((row) => row.contact_user_id)
    .filter((id): id is string => typeof id === 'string' && id.length > 0)

  let profilesById = new Map<string, ContactProfile>()
  if (contactUserIds.length > 0) {
    const { data: profiles, error: profileError } = await admin
      .from('profiles')
      .select(CONTACT_FIELDS)
      .in('id', contactUserIds)

    if (profileError) {
      return NextResponse.json({ error: profileError.message }, { status: 500 })
    }

    profilesById = new Map(
      ((profiles ?? []) as ContactProfile[]).map((profile) => [profile.id, profile])
    )
  }

  const contacts = typedRows.map((row) => toContactResponse(row, row.contact_user_id ? profilesById.get(row.contact_user_id) ?? null : null))
  return NextResponse.json({ contacts })
}

export async function POST(request: Request) {
  const supabase = await createClient()
  const admin = createAdminClient() as any
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  let payload: EmergencyContactPayload = {}
  try {
    payload = (await request.json()) as EmergencyContactPayload
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload' }, { status: 400 })
  }

  const contactUserId = typeof payload.contact_user_id === 'string' ? payload.contact_user_id : null
  const rawPhone = typeof payload.external_phone === 'string' ? payload.external_phone : ''
  const normalizedPhone = rawPhone ? normalizePhone(rawPhone) : null
  const externalName =
    typeof payload.external_name === 'string'
      ? payload.external_name.trim().slice(0, MAX_CONTACT_NAME_LENGTH)
      : ''

  if (contactUserId && rawPhone) {
    return NextResponse.json({ error: 'Provide either contact_user_id or external_phone, not both.' }, { status: 400 })
  }

  if (!contactUserId && !rawPhone) {
    return NextResponse.json({ error: 'Missing contact target.' }, { status: 400 })
  }

  if (contactUserId) {
    if (contactUserId === user.id) {
      return NextResponse.json({ error: 'Cannot add yourself.' }, { status: 400 })
    }

    const { data: targetProfile, error: targetError } = await admin
      .from('profiles')
      .select(CONTACT_FIELDS)
      .eq('id', contactUserId)
      .single()

    if (targetError || !targetProfile) {
      return NextResponse.json({ error: 'User not found.' }, { status: 404 })
    }

    const insertPayload = {
      owner_id: user.id,
      contact_user_id: contactUserId,
      external_name: null,
      external_phone: null,
    }

    const { data: inserted, error: insertError } = await supabase
      .from('emergency_contacts')
      .insert(insertPayload)
      .select('id, contact_user_id, external_name, external_phone')
      .maybeSingle()

    if (insertError && insertError.code !== '23505' && !insertError.message.toLowerCase().includes('duplicate')) {
      return NextResponse.json({ error: insertError.message }, { status: 500 })
    }

    let contactRow = inserted as EmergencyContactRow | null
    if (!contactRow) {
      const { data: existingRow, error: existingError } = await supabase
        .from('emergency_contacts')
        .select('id, contact_user_id, external_name, external_phone')
        .eq('owner_id', user.id)
        .eq('contact_user_id', contactUserId)
        .maybeSingle()
      if (existingError || !existingRow) {
        return NextResponse.json({ error: existingError?.message || 'Unable to load emergency contact.' }, { status: 500 })
      }
      contactRow = existingRow as EmergencyContactRow
    }

    return NextResponse.json({ contact: toContactResponse(contactRow, targetProfile as ContactProfile) })
  }

  if (!normalizedPhone) {
    return NextResponse.json({ error: 'Enter a valid phone number (7-15 digits).' }, { status: 400 })
  }

  const { data: insertedPhone, error: phoneInsertError } = await supabase
    .from('emergency_contacts')
    .insert({
      owner_id: user.id,
      contact_user_id: null,
      external_name: externalName || null,
      external_phone: normalizedPhone,
    })
    .select('id, contact_user_id, external_name, external_phone')
    .maybeSingle()

  if (phoneInsertError && phoneInsertError.code !== '23505' && !phoneInsertError.message.toLowerCase().includes('duplicate')) {
    return NextResponse.json({ error: phoneInsertError.message }, { status: 500 })
  }

  let phoneRow = insertedPhone as EmergencyContactRow | null
  if (!phoneRow) {
    const { data: existingPhoneRow, error: existingPhoneError } = await supabase
      .from('emergency_contacts')
      .select('id, contact_user_id, external_name, external_phone')
      .eq('owner_id', user.id)
      .eq('external_phone', normalizedPhone)
      .maybeSingle()

    if (existingPhoneError || !existingPhoneRow) {
      return NextResponse.json({ error: existingPhoneError?.message || 'Unable to load emergency contact.' }, { status: 500 })
    }

    phoneRow = existingPhoneRow as EmergencyContactRow
  }

  return NextResponse.json({ contact: toContactResponse(phoneRow) })
}

export async function DELETE(request: Request) {
  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  let payload: EmergencyContactPayload = {}
  try {
    payload = (await request.json()) as EmergencyContactPayload
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload' }, { status: 400 })
  }

  const contactId = typeof payload.contact_id === 'string' ? payload.contact_id : null
  const contactUserId = typeof payload.contact_user_id === 'string' ? payload.contact_user_id : null
  const normalizedPhone =
    typeof payload.external_phone === 'string' && payload.external_phone.trim()
      ? normalizePhone(payload.external_phone)
      : null

  if (!contactId && !contactUserId && !normalizedPhone) {
    return NextResponse.json({ error: 'Missing contact identifier.' }, { status: 400 })
  }

  let query = supabase
    .from('emergency_contacts')
    .delete()
    .eq('owner_id', user.id)

  if (contactId) {
    query = query.eq('id', contactId)
  } else if (contactUserId) {
    query = query.eq('contact_user_id', contactUserId)
  } else if (normalizedPhone) {
    query = query.eq('external_phone', normalizedPhone)
  }

  const { error } = await query
  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ ok: true })
}
