import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

const OWNER_FIELDS = 'id, username, full_name, avatar_url'

export async function GET() {
  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { data: alerts, error } = await supabase
    .from('panic_events')
    .select(`id, owner_id, lat, lng, status, created_at, owner:profiles(${OWNER_FIELDS})`)
    .eq('status', 'active')
    .order('created_at', { ascending: false })
    .limit(20)

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  const results = (alerts ?? []).map((alert: any) => ({
    id: alert.id,
    owner_id: alert.owner_id,
    lat: alert.lat,
    lng: alert.lng,
    status: alert.status,
    created_at: alert.created_at,
    owner: alert.owner ?? null,
  }))

  return NextResponse.json({ alerts: results })
}
