import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'

const BLOCKED_PROFILE = 'id, blocked_id'
const PROFILE_FIELDS = 'id, username, full_name, avatar_url'

export const runtime = 'nodejs'

export async function GET() {
  const supabase = await createClient()
  const admin = createAdminClient() as any
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { data: blocks, error } = await supabase
    .from('blocks')
    .select(BLOCKED_PROFILE)
    .eq('blocker_id', user.id)
    .order('created_at', { ascending: false })

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  const blockedIds = (blocks ?? []).map((row) => row.blocked_id).filter(Boolean)
  const { data: profiles } = blockedIds.length
    ? await admin
        .from('profiles')
        .select(PROFILE_FIELDS)
        .in('id', blockedIds)
    : { data: [] }

  const profileMap = new Map((profiles ?? []).map((profile: any) => [profile.id, profile]))
  const results = (blocks ?? []).map((row) => ({
    blocked_id: row.blocked_id,
    profile: row.blocked_id ? profileMap.get(row.blocked_id) ?? null : null,
  }))

  return NextResponse.json({ results })
}

export async function POST(request: Request) {
  const supabase = await createClient()
  const admin = createAdminClient() as any
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  let payload: Record<string, any> = {}
  try {
    payload = await request.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload' }, { status: 400 })
  }

  const blockedId = typeof payload.blocked_id === 'string' ? payload.blocked_id : null
  if (!blockedId) {
    return NextResponse.json({ error: 'Missing blocked_id' }, { status: 400 })
  }
  if (blockedId === user.id) {
    return NextResponse.json({ error: 'Cannot block yourself' }, { status: 400 })
  }

  const { data: target, error: targetError } = await admin
    .from('profiles')
    .select('id')
    .eq('id', blockedId)
    .single()

  if (targetError || !target) {
    return NextResponse.json({ error: 'User not found' }, { status: 404 })
  }

  const { error } = await supabase
    .from('blocks')
    .insert({ blocker_id: user.id, blocked_id: blockedId })

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ ok: true })
}
