import { createClient } from '@/lib/supabase/server'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import { enforceRateLimit, enforceSameOrigin, validationFailed } from '@/lib/security/guards'
import { parseJsonObject, readString, ValidationError } from '@/lib/security/validation'
import { validateEmail } from '@/lib/utils'
import { validatePasswordPolicy } from '@/lib/security/password-policy'
import { logEmailEvent } from '@/lib/email/observability'
import {
  buildAuthCallbackUrl,
  buildAuthOriginCandidates,
} from '@/lib/auth/origin'

export const runtime = 'nodejs'

const isExistingUserError = (message: string) => {
  const text = message.toLowerCase()
  return (
    text.includes('already registered') ||
    text.includes('already exists') ||
    text.includes('user already registered')
  )
}

const isRedirectUrlError = (message: string) => {
  const text = message.toLowerCase()
  return (
    text.includes('redirect') &&
    (text.includes('not allowed') ||
      text.includes('invalid') ||
      text.includes('mismatch'))
  )
}

const isConfirmationSendError = (message: string) => {
  const text = message.toLowerCase()
  return text.includes('confirmation email') || text.includes('error sending confirmation email')
}

const isTransientAuthError = (message: string) => {
  const text = message.toLowerCase()
  return (
    text.includes('operation was aborted') ||
    text.includes('request timed out') ||
    text.includes('timed out') ||
    text.includes('fetch failed') ||
    text.includes('network') ||
    text.includes('unexpected_failure')
  )
}

const isPasswordPolicyError = (message: string) => {
  const text = message.toLowerCase()
  return text.includes('password')
}

const isEmailFormatError = (message: string) => {
  const text = message.toLowerCase()
  return text.includes('email') && text.includes('invalid')
}

const isAuthRateLimitError = (message: string) => {
  const text = message.toLowerCase()
  return text.includes('security purposes') || text.includes('rate limit')
}

export async function POST(request: Request) {
  const requestId = createRequestId()

  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  let body: Record<string, unknown>
  try {
    body = await parseJsonObject(request)
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, error.message)
    }
    return validationFailed(requestId)
  }

  let email = ''
  let password = ''
  try {
    email = readString(body, 'email', { required: true, toLowerCase: true })
    password = readString(body, 'password', { required: true, trim: false, min: 1 })
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, error.message)
    }
    return validationFailed(requestId)
  }

  if (!validateEmail(email)) {
    return validationFailed(requestId, 'Invalid email address.')
  }

  const passwordValidation = validatePasswordPolicy(password, { email })
  if (!passwordValidation.valid) {
    return validationFailed(requestId, passwordValidation.error || 'Password does not meet requirements.')
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'auth:sign-up',
    request,
    requestId,
    email,
    limit: 5,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 60_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  const supabase = await createClient()
  const originCandidates = buildAuthOriginCandidates(request)

  let data: Awaited<ReturnType<typeof supabase.auth.signUp>>['data'] | null = null
  let error: Awaited<ReturnType<typeof supabase.auth.signUp>>['error'] | null = null

  for (const origin of originCandidates) {
    const result = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: buildAuthCallbackUrl(origin, '/onboarding'),
      },
    })

    data = result.data
    error = result.error

    if (!error) break
    if (isExistingUserError(error.message || '')) break
    if (isTransientAuthError(error.message || '')) {
      logServerError('auth.signup.transient_retry', requestId, error, {
        email,
        attemptedOrigin: origin,
      })
      continue
    }
    if (!isRedirectUrlError(error.message || '')) break

    logServerError('auth.signup.redirect_retry', requestId, error, {
      email,
      attemptedOrigin: origin,
    })
  }

  if (error && !isExistingUserError(error.message || '')) {
    logServerError('auth.signup', requestId, error, {
      email,
      originsTried: originCandidates,
    })
    const errorMessage = error.message || ''

    if (isConfirmationSendError(errorMessage) && data?.user?.id) {
      logEmailEvent({
        requestId,
        provider: 'supabase-auth',
        emailType: 'signup_verification',
        recipient: email,
        status: 'failed',
        error,
        meta: {
          mode: 'signup',
          userId: data.user.id,
          originsTried: originCandidates,
        },
      })

      return successResponse(requestId, {
        ok: true,
        status: 'pending_verification',
        message:
          'Account created. We could not send the first verification email. Continue to verification and tap Resend verification email.',
      })
    }

    if (isRedirectUrlError(error.message || '')) {
      return validationFailed(
        requestId,
        'Auth redirect is not configured for this domain. Add /auth/callback in Supabase redirect URLs.'
      )
    }
    if (isPasswordPolicyError(errorMessage)) {
      return validationFailed(
        requestId,
        'Password does not meet security requirements. Use 8+ chars with upper/lowercase, number, and symbol.'
      )
    }
    if (isEmailFormatError(errorMessage)) {
      return validationFailed(requestId, 'Invalid email address.')
    }
    if (isAuthRateLimitError(errorMessage)) {
      return validationFailed(
        requestId,
        'Too many attempts. Please wait a minute and try again.'
      )
    }
    return validationFailed(
      requestId,
      'Unable to create account right now. Please try again in a moment.'
    )
  }

  // Supabase may return a user with empty identities if account already exists.
  const identities = data?.user?.identities
  const accountExists =
    !!error || (identities !== undefined && Array.isArray(identities) && identities.length === 0)

  if (!error) {
    logEmailEvent({
      requestId,
      provider: 'supabase-auth',
      emailType: 'signup_verification',
      recipient: email,
      status: 'sent',
    })
  }

  if (accountExists) {
    return successResponse(requestId, {
      ok: true,
      status: 'pending_verification',
      message:
        'If the account can be verified, a verification email has been sent. Please check your inbox.',
    })
  }

  return successResponse(requestId, {
    ok: true,
    status: 'pending_verification',
    message: 'If the account can be verified, a verification email has been sent. Please check your inbox.',
  })
}
