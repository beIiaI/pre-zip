import { createClient } from '@/lib/supabase/server'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import { clearAuthFailures, getAuthBackoff, registerAuthFailure } from '@/lib/security/rate-limit'
import { enforceRateLimit, enforceSameOrigin, validationFailed } from '@/lib/security/guards'
import { parseJsonObject, readString, ValidationError } from '@/lib/security/validation'
import { validateEmail } from '@/lib/utils'

export const runtime = 'nodejs'

const getSignInErrorMessage = (message: string) => {
  const text = message.toLowerCase()
  if (text.includes('email not confirmed')) {
    return 'Email not confirmed. Enter the verification code from your inbox first.'
  }
  if (text.includes('invalid login credentials') || text.includes('invalid credentials')) {
    return 'Email or password is incorrect.'
  }
  if (text.includes('too many')) {
    return 'Too many sign-in attempts. Please wait and try again.'
  }
  if (text.includes('operation was aborted')) {
    return 'The operation was aborted. Refresh and try again.'
  }
  return message || 'Could not authenticate user.'
}

export async function POST(request: Request) {
  const requestId = createRequestId()

  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  let body: Record<string, unknown>
  try {
    body = await parseJsonObject(request)
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, error.message)
    }
    return validationFailed(requestId)
  }

  let email = ''
  let password = ''
  try {
    email = readString(body, 'email', { required: true, toLowerCase: true })
    password = readString(body, 'password', { required: true, trim: false, min: 1 })
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid email or password.')
    }
    return validationFailed(requestId)
  }
  if (!validateEmail(email)) {
    return validationFailed(requestId, 'Invalid email or password.')
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'auth:sign-in',
    request,
    requestId,
    email,
    limit: 8,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 30_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  const backoffKey = `auth:signin:${email}`
  const backoff = getAuthBackoff({ key: backoffKey })
  if (!backoff.ok) {
    const response = validationFailed(requestId, 'Invalid email or password.')
    response.headers.set('retry-after', String(Math.max(1, Math.ceil(backoff.retryAfterMs / 1000))))
    return response
  }

  const supabase = await createClient()
  const { error } = await supabase.auth.signInWithPassword({
    email,
    password,
  })

  if (error) {
    registerAuthFailure({ key: backoffKey })
    logServerError('auth.signin', requestId, error, {
      email,
      origin: request.headers.get('origin'),
      host: request.headers.get('host'),
      userAgent: request.headers.get('user-agent'),
      errorCode: (error as { code?: string }).code ?? null,
      errorStatus: (error as { status?: number }).status ?? null,
    })
    return validationFailed(requestId, getSignInErrorMessage(error.message || ''))
  }

  clearAuthFailures(backoffKey)

  try {
    const {
      data: { user },
    } = await supabase.auth.getUser()
    return successResponse(requestId, {
      ok: true,
      userId: user?.id ?? null,
    })
  } catch (error) {
    logServerError('auth.signin.user', requestId, error)
    return successResponse(requestId, { ok: true })
  }
}
