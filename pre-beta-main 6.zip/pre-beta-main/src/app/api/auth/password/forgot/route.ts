import { createClient } from '@/lib/supabase/server'
import { logEmailEvent } from '@/lib/email/observability'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import { enforceRateLimit, enforceSameOrigin, validationFailed } from '@/lib/security/guards'
import { parseJsonObject, readString, ValidationError } from '@/lib/security/validation'
import { validateEmail } from '@/lib/utils'
import { buildAuthCallbackUrl, buildAuthOriginCandidates } from '@/lib/auth/origin'

export const runtime = 'nodejs'

const isRedirectUrlError = (message: string) => {
  const text = message.toLowerCase()
  return text.includes('redirect') && (text.includes('not allowed') || text.includes('invalid') || text.includes('mismatch'))
}

const buildResetRedirectCandidates = (origins: string[]) => {
  return origins.map((origin) => buildAuthCallbackUrl(origin, '/auth/reset'))
}

export async function POST(request: Request) {
  const requestId = createRequestId()

  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  let payload: Record<string, unknown>
  try {
    payload = await parseJsonObject(request)
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, error.message)
    }
    return validationFailed(requestId)
  }

  let email = ''
  try {
    email = readString(payload, 'email', { required: true, toLowerCase: true })
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid email.')
    }
    return validationFailed(requestId, 'Invalid email.')
  }

  if (!email || !validateEmail(email)) {
    return validationFailed(requestId, 'Invalid email.')
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'auth:password:forgot',
    request,
    requestId,
    email,
    limit: 5,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 60_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  const supabase = await createClient()
  const originCandidates = buildAuthOriginCandidates(request)
  const redirectCandidates = buildResetRedirectCandidates(originCandidates)

  let sent = false
  let lastError: Error | null = null

  for (const redirectTo of redirectCandidates) {
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo })
    if (!error) {
      sent = true
      logEmailEvent({
        requestId,
        provider: 'supabase-auth',
        emailType: 'password_recovery',
        recipient: email,
        status: 'sent',
        meta: { redirectTo },
      })
      break
    }

    lastError = error
    if (!isRedirectUrlError(error.message || '')) {
      break
    }

    logServerError('auth.password.forgot.redirect_retry', requestId, error, { email, redirectTo })
  }

  // Last fallback uses Supabase Auth Site URL / template defaults.
  if (!sent) {
    const { error } = await supabase.auth.resetPasswordForEmail(email)
    if (!error) {
      sent = true
      logEmailEvent({
        requestId,
        provider: 'supabase-auth',
        emailType: 'password_recovery',
        recipient: email,
        status: 'sent',
        meta: { redirectTo: 'default' },
      })
    } else {
      lastError = error
    }
  }

  if (!sent && lastError) {
    logServerError('auth.password.forgot.failed', requestId, lastError, {
      email,
      redirectCandidates,
    })
    logEmailEvent({
      requestId,
      provider: 'supabase-auth',
      emailType: 'password_recovery',
      recipient: email,
      status: 'failed',
      error: lastError,
      meta: { redirectCandidates },
    })
    return validationFailed(
      requestId,
      'Unable to send reset email right now. Please try again.'
    )
  }

  // Generic response to prevent account enumeration.
  return successResponse(requestId, {
    ok: true,
    message:
      'If an account exists for that email, password reset instructions have been sent.',
  })
}
