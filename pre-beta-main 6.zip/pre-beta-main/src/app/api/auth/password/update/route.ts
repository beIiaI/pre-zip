import { createClient } from '@/lib/supabase/server'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import {
  enforceRateLimit,
  enforceSameOrigin,
  unauthorized,
  validationFailed,
} from '@/lib/security/guards'
import { parseJsonObject, readString, ValidationError } from '@/lib/security/validation'
import { validatePasswordPolicy } from '@/lib/security/password-policy'

export const runtime = 'nodejs'

export async function POST(request: Request) {
  const requestId = createRequestId()
  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'auth:password:update',
    request,
    requestId,
    userId: user.id,
    limit: 8,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 60_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  let payload: Record<string, unknown>
  try {
    payload = await parseJsonObject(request)
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, error.message)
    }
    return validationFailed(requestId)
  }

  let password = ''
  try {
    password = readString(payload, 'password', { required: true, trim: false, min: 1 })
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, error.message)
    }
    return validationFailed(requestId)
  }

  const validation = validatePasswordPolicy(password, { email: user.email })
  if (!validation.valid) {
    return validationFailed(requestId, validation.error || 'Invalid password.')
  }

  const { error } = await supabase.auth.updateUser({ password })
  if (error) {
    logServerError('auth.password.update', requestId, error, { userId: user.id })
    return validationFailed(requestId, 'Unable to update password.')
  }

  return successResponse(requestId, { ok: true })
}
