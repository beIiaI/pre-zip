import { createClient } from '@/lib/supabase/server'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import { enforceRateLimit, enforceSameOrigin, validationFailed } from '@/lib/security/guards'
import { parseJsonObject, readString, ValidationError } from '@/lib/security/validation'
import { validateEmail } from '@/lib/utils'
import { buildAuthCallbackUrl, buildAuthOriginCandidates } from '@/lib/auth/origin'
import { logEmailEvent } from '@/lib/email/observability'

export const runtime = 'nodejs'

const isRedirectUrlError = (message: string) => {
  const text = message.toLowerCase()
  return (
    text.includes('redirect') &&
    (text.includes('not allowed') ||
      text.includes('invalid') ||
      text.includes('mismatch'))
  )
}

export async function POST(request: Request) {
  const requestId = createRequestId()

  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  let body: Record<string, unknown>
  try {
    body = await parseJsonObject(request)
  } catch (error) {
    if (error instanceof ValidationError) return validationFailed(requestId, error.message)
    return validationFailed(requestId)
  }

  let email = ''
  try {
    email = readString(body, 'email', { required: true, toLowerCase: true })
  } catch (error) {
    if (error instanceof ValidationError) return validationFailed(requestId, error.message)
    return validationFailed(requestId)
  }

  if (!validateEmail(email)) {
    return validationFailed(requestId, 'Invalid email address.')
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'auth:otp:resend',
    request,
    requestId,
    email,
    limit: 5,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 45_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  const supabase = await createClient()
  const originCandidates = buildAuthOriginCandidates(request)
  let error: Awaited<ReturnType<typeof supabase.auth.resend>>['error'] | null = null

  for (const origin of originCandidates) {
    const result = await supabase.auth.resend({
      type: 'signup',
      email,
      options: {
        emailRedirectTo: buildAuthCallbackUrl(origin, '/onboarding'),
      },
    })
    error = result.error
    if (!error) break
    if (!isRedirectUrlError(error.message || '')) break

    logServerError('auth.otp.resend.redirect_retry', requestId, error, {
      email,
      attemptedOrigin: origin,
    })
  }

  // Generic success message to avoid account/email enumeration.
  if (error) {
    logServerError('auth.otp.resend', requestId, error, { email, originsTried: originCandidates })
    logEmailEvent({
      requestId,
      provider: 'supabase-auth',
      emailType: 'signup_verification_resend',
      recipient: email,
      status: 'failed',
      error,
      meta: { originsTried: originCandidates },
    })
  } else {
    logEmailEvent({
      requestId,
      provider: 'supabase-auth',
      emailType: 'signup_verification_resend',
      recipient: email,
      status: 'sent',
    })
  }

  return successResponse(requestId, {
    ok: true,
    message:
      'If the account can be verified, a verification email has been sent. Please check your inbox.',
  })
}
