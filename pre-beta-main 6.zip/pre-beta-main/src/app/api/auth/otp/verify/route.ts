import { createClient } from '@/lib/supabase/server'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import { enforceRateLimit, enforceSameOrigin, validationFailed } from '@/lib/security/guards'
import { parseJsonObject, readString, ValidationError } from '@/lib/security/validation'
import { validateEmail } from '@/lib/utils'

export const runtime = 'nodejs'

export async function POST(request: Request) {
  const requestId = createRequestId()

  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  let body: Record<string, unknown>
  try {
    body = await parseJsonObject(request)
  } catch (error) {
    if (error instanceof ValidationError) return validationFailed(requestId, error.message)
    return validationFailed(requestId)
  }

  let email = ''
  let token = ''
  try {
    email = readString(body, 'email', { required: true, toLowerCase: true })
    token = readString(body, 'token', { required: true, trim: true, min: 8, max: 8 })
  } catch (error) {
    if (error instanceof ValidationError) return validationFailed(requestId, 'Invalid verification code.')
    return validationFailed(requestId)
  }

  if (!validateEmail(email) || !/^\d{8}$/.test(token)) {
    return validationFailed(requestId, 'Invalid verification code.')
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'auth:otp:verify',
    request,
    requestId,
    email,
    limit: 10,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 30_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  const supabase = await createClient()
  const { error } = await supabase.auth.verifyOtp({
    email,
    token,
    type: 'signup',
  })

  if (error) {
    logServerError('auth.otp.verify', requestId, error, { email })
    return validationFailed(requestId, 'Invalid or expired verification code.')
  }

  return successResponse(requestId, {
    ok: true,
    status: 'verified',
  })
}

