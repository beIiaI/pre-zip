import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { normalizeInviteEmail } from '@/lib/invites'
import { sendAccessApplicationNotification } from '@/lib/email'
import { createRequestId, logServerError } from '@/lib/security/api'
import { validateEmail } from '@/lib/utils'

type AccessApplyBody = {
  email?: string
  fullName?: string
  note?: string
}

const MAX_RECENT_SUBMISSIONS = 3

export async function POST(request: Request) {
  const requestId = createRequestId()
  let body: AccessApplyBody = {}
  try {
    body = (await request.json()) as AccessApplyBody
  } catch {
    return NextResponse.json({ error: 'Invalid payload.' }, { status: 400, headers: { 'x-request-id': requestId } })
  }

  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const email = normalizeInviteEmail(body.email ?? user?.email ?? '')
  const fullName = typeof body.fullName === 'string' ? body.fullName.trim().slice(0, 120) : ''
  const note = typeof body.note === 'string' ? body.note.trim().slice(0, 600) : ''

  if (!validateEmail(email)) {
    return NextResponse.json({ error: 'Please enter a valid email address.' }, { status: 400, headers: { 'x-request-id': requestId } })
  }

  const admin = createAdminClient() as any
  const now = Date.now()
  const twentyFourHoursAgoIso = new Date(now - 24 * 60 * 60 * 1000).toISOString()
  const fourteenDaysAgoIso = new Date(now - 14 * 24 * 60 * 60 * 1000).toISOString()

  const { count: recentCount, error: recentCountError } = await admin
    .from('access_applications')
    .select('id', { count: 'exact', head: true })
    .eq('email', email)
    .gte('created_at', twentyFourHoursAgoIso)

  if (recentCountError) {
    logServerError('access.apply.recent_count', requestId, recentCountError, { email })
    return NextResponse.json({ error: 'Unable to submit request right now.' }, { status: 500, headers: { 'x-request-id': requestId } })
  }

  if ((recentCount ?? 0) >= MAX_RECENT_SUBMISSIONS) {
    return NextResponse.json(
      { error: 'Too many requests. Please try again tomorrow.' },
      { status: 429, headers: { 'x-request-id': requestId } }
    )
  }

  const { data: pendingApplication, error: pendingError } = await admin
    .from('access_applications')
    .select('id,created_at')
    .eq('email', email)
    .eq('status', 'pending')
    .gte('created_at', fourteenDaysAgoIso)
    .order('created_at', { ascending: false })
    .maybeSingle()

  if (pendingError) {
    logServerError('access.apply.pending_lookup', requestId, pendingError, { email })
    return NextResponse.json({ error: 'Unable to check existing requests.' }, { status: 500, headers: { 'x-request-id': requestId } })
  }

  if (pendingApplication) {
    return NextResponse.json({
      ok: true,
      alreadySubmitted: true,
      createdAt: pendingApplication.created_at,
      reviewQueue: 'access_applications',
    }, { headers: { 'x-request-id': requestId } })
  }

  const { data: inserted, error: insertError } = await admin
    .from('access_applications')
    .insert({
      email,
      full_name: fullName || null,
      note: note || null,
      status: 'pending',
    })
    .select('id,created_at,status')
    .maybeSingle()

  if (insertError?.code === '23505') {
    return NextResponse.json({
      ok: true,
      alreadySubmitted: true,
      reviewQueue: 'access_applications',
    }, { headers: { 'x-request-id': requestId } })
  }

  if (insertError || !inserted) {
    if (insertError) {
      logServerError('access.apply.insert', requestId, insertError, { email })
    }
    return NextResponse.json({ error: 'Unable to submit access request.' }, { status: 500, headers: { 'x-request-id': requestId } })
  }

  const reviewInbox = process.env.ACCESS_REVIEW_EMAIL || 'support@presocial.app'
  try {
    await sendAccessApplicationNotification({
      requestId,
      to: reviewInbox,
      applicationId: inserted.id,
      email,
      fullName: fullName || null,
      note: note || null,
      submittedAt: inserted.created_at,
    })
  } catch (error) {
    // Request stays persisted in DB queue even if notification delivery fails.
    logServerError('access.apply.notification', requestId, error, {
      applicationId: inserted.id,
      email,
      reviewInbox,
    })
  }

  return NextResponse.json({
    ok: true,
    request: inserted,
    reviewQueue: 'access_applications',
  }, { headers: { 'x-request-id': requestId } })
}
