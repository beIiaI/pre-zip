import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

const CIRCLE_FIELDS = 'id, name, description, cover_image_url, creator_id, is_public, category, created_at'

export async function GET() {
  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { data: circles, error } = await supabase
    .from('circles')
    .select(CIRCLE_FIELDS)
    .order('created_at', { ascending: false })
    .limit(50)

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  const circleIds = (circles ?? []).map((circle) => circle.id)
  const { data: memberships } = circleIds.length
    ? await supabase
        .from('circle_members')
        .select('circle_id')
        .eq('user_id', user.id)
        .in('circle_id', circleIds)
    : { data: [] }

  const memberSet = new Set((memberships ?? []).map((row) => row.circle_id))

  const response = (circles ?? []).map((circle) => ({
    id: circle.id,
    name: circle.name,
    description: circle.description,
    cover_image_url: circle.cover_image_url,
    creator_id: circle.creator_id,
    is_public: circle.is_public,
    category: circle.category,
    created_at: circle.created_at,
    is_member: memberSet.has(circle.id),
  }))

  return NextResponse.json({ circles: response })
}

export async function POST(request: Request) {
  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  let payload: Record<string, unknown> = {}
  try {
    payload = (await request.json()) as Record<string, unknown>
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload' }, { status: 400 })
  }

  const name = typeof payload.name === 'string' ? payload.name.trim() : ''
  if (!name) {
    return NextResponse.json({ error: 'Name is required' }, { status: 400 })
  }

  const description = typeof payload.description === 'string' ? payload.description.trim() : ''
  const category = typeof payload.category === 'string' ? payload.category.trim() : ''
  const isPublic = payload.is_public !== false

  const { data: circle, error } = await supabase
    .from('circles')
    .insert({
      name,
      description: description || null,
      category: category || null,
      creator_id: user.id,
      is_public: isPublic,
    })
    .select(CIRCLE_FIELDS)
    .single()

  if (error || !circle) {
    return NextResponse.json({ error: error?.message || 'Failed to create circle' }, { status: 500 })
  }

  await supabase
    .from('circle_members')
    .insert({ circle_id: circle.id, user_id: user.id, role: 'admin' })

  return NextResponse.json({ circle })
}
