import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export const runtime = 'nodejs'

export async function DELETE(
  _request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const supabase = await createClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { id: circleId } = await context.params
  if (!circleId) {
    return NextResponse.json({ error: 'Missing circle id' }, { status: 400 })
  }

  const { data: circle, error: circleLookupError } = await supabase
    .from('circles')
    .select('id, creator_id')
    .eq('id', circleId)
    .maybeSingle()

  if (circleLookupError) {
    return NextResponse.json({ error: 'Unable to load circle' }, { status: 500 })
  }

  if (!circle) {
    return NextResponse.json({ error: 'Circle not found' }, { status: 404 })
  }

  if (circle.creator_id !== user.id) {
    return NextResponse.json({ error: 'Only the circle creator can delete this circle' }, { status: 403 })
  }

  const { error: deleteError } = await supabase
    .from('circles')
    .delete()
    .eq('id', circleId)
    .eq('creator_id', user.id)

  if (deleteError) {
    return NextResponse.json({ error: 'Unable to delete circle' }, { status: 500 })
  }

  return NextResponse.json({ ok: true, id: circleId })
}
