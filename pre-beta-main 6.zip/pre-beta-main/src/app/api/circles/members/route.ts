import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST(request: Request) {
  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  let payload: Record<string, unknown> = {}
  try {
    payload = (await request.json()) as Record<string, unknown>
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload' }, { status: 400 })
  }

  const circleId = typeof payload.circle_id === 'string' ? payload.circle_id : null
  if (!circleId) {
    return NextResponse.json({ error: 'Missing circle_id' }, { status: 400 })
  }

  const { data: circle } = await supabase
    .from('circles')
    .select('id, is_public')
    .eq('id', circleId)
    .single()

  if (!circle) {
    return NextResponse.json({ error: 'Circle not found' }, { status: 404 })
  }

  if (circle.is_public === false) {
    return NextResponse.json({ error: 'Private circles are invite-only' }, { status: 403 })
  }

  const { error } = await supabase
    .from('circle_members')
    .insert({ circle_id: circleId, user_id: user.id, role: 'member' })

  if (error && error.code !== '23505' && !error.message.toLowerCase().includes('duplicate')) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ ok: true })
}

export async function DELETE(request: Request) {
  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  let payload: Record<string, unknown> = {}
  try {
    payload = (await request.json()) as Record<string, unknown>
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload' }, { status: 400 })
  }

  const circleId = typeof payload.circle_id === 'string' ? payload.circle_id : null
  if (!circleId) {
    return NextResponse.json({ error: 'Missing circle_id' }, { status: 400 })
  }

  const { error } = await supabase
    .from('circle_members')
    .delete()
    .eq('circle_id', circleId)
    .eq('user_id', user.id)

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ ok: true })
}
