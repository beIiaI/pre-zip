import { createClient } from '@/lib/supabase/server'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import { enforceRateLimit, enforceSameOrigin, serverFailure, unauthorized, validationFailed } from '@/lib/security/guards'
import { parseJsonObject, readOptionalNumber, ValidationError } from '@/lib/security/validation'

type GraduationYearBody = {
  graduationYear?: number | string
}

const MIN_YEAR = 1900
const MAX_YEAR = 2300
const YEAR_MS = 365 * 24 * 60 * 60 * 1000
const SUPPORT_EMAIL = 'support@presocial.app'

export const runtime = 'nodejs'

export async function POST(request: Request) {
  const requestId = createRequestId()
  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'verification:university:graduation-year',
    request,
    requestId,
    userId: user.id,
    limit: 6,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 60_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  let payload: GraduationYearBody = {}
  try {
    payload = (await parseJsonObject(request)) as GraduationYearBody
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid graduation year payload.')
    }
    return validationFailed(requestId, 'Invalid graduation year payload.')
  }

  let parsedYear: number | null = null
  try {
    parsedYear = readOptionalNumber(payload as Record<string, unknown>, 'graduationYear', {
      min: MIN_YEAR,
      max: MAX_YEAR,
      integer: true,
    })
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Enter a valid graduation year.')
    }
    return validationFailed(requestId, 'Enter a valid graduation year.')
  }

  if (!parsedYear) {
    return validationFailed(requestId, 'Enter a valid graduation year.')
  }

  const { data: currentProfile, error: profileError } = await supabase
    .from('profiles')
    .select(
      'id, university_verified, verification_type, is_verified, university_graduation_year, university_grad_year_confirmed_at'
    )
    .eq('id', user.id)
    .maybeSingle()

  if (profileError || !currentProfile) {
    if (profileError) {
      logServerError('verification.university.grad_year.profile', requestId, profileError, {
        userId: user.id,
      })
    }
    return validationFailed(requestId, 'Profile not found.')
  }

  const existingGradYear =
    typeof currentProfile.university_graduation_year === 'number'
      ? currentProfile.university_graduation_year
      : null
  const confirmedAtMs = currentProfile.university_grad_year_confirmed_at
    ? new Date(currentProfile.university_grad_year_confirmed_at).getTime()
    : null
  const canChangeAfterMs =
    confirmedAtMs && Number.isFinite(confirmedAtMs) ? confirmedAtMs + YEAR_MS : null

  const isLockedForSupport =
    existingGradYear !== null &&
    canChangeAfterMs !== null &&
    Number.isFinite(canChangeAfterMs) &&
    canChangeAfterMs > Date.now()

  if (isLockedForSupport) {
    return validationFailed(
      requestId,
      `Graduation year is locked for one year. Contact ${SUPPORT_EMAIL} to change it.`
    )
  }

  const nowIso = new Date().toISOString()
  const currentYear = new Date().getFullYear()
  const hasGraduated = parsedYear < currentYear
  const updatePayload: Record<string, unknown> = {
    university_graduation_year: parsedYear,
    university_grad_year_confirmed_at: nowIso,
    university_graduated_at: hasGraduated ? nowIso : null,
    updated_at: nowIso,
  }

  if (hasGraduated && currentProfile.university_verified) {
    updatePayload.university_verified = false
    updatePayload.university_verified_at = null
  }

  if (hasGraduated && currentProfile.verification_type === 'university_email') {
    updatePayload.verification_type = null
    updatePayload.is_verified = false
  }

  const { data: updatedProfile, error: updateError } = await supabase
    .from('profiles')
    .update(updatePayload)
    .eq('id', user.id)
    .select('university_graduation_year, university_grad_year_confirmed_at, university_graduated_at, university_verified, verification_type')
    .maybeSingle()

  if (updateError || !updatedProfile) {
    if (updateError) {
      logServerError('verification.university.grad_year.update', requestId, updateError, {
        userId: user.id,
      })
    }
    return serverFailure(requestId)
  }

  return successResponse(requestId, {
    ok: true,
    graduated: hasGraduated,
    profile: updatedProfile,
    lockUntil: new Date(Date.now() + YEAR_MS).toISOString(),
  })
}

