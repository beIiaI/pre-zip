import { createClient } from '@/lib/supabase/server'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import { enforceRateLimit, enforceSameOrigin, serverFailure, unauthorized, validationFailed } from '@/lib/security/guards'
import { parseJsonObject, readString, ValidationError } from '@/lib/security/validation'

type UnlockBody = {
  reason?: 'change_email' | 'graduated'
}

export const runtime = 'nodejs'

export async function POST(request: Request) {
  const requestId = createRequestId()
  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'verification:university:unlock',
    request,
    requestId,
    userId: user.id,
    limit: 4,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 60_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  let payload: UnlockBody
  try {
    payload = (await parseJsonObject(request)) as UnlockBody
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid unlock request.')
    }
    return validationFailed(requestId, 'Invalid unlock request.')
  }

  let reason = ''
  try {
    reason = readString(payload as Record<string, unknown>, 'reason', { required: true })
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid unlock reason.')
    }
    return validationFailed(requestId, 'Invalid unlock reason.')
  }

  if (reason !== 'change_email' && reason !== 'graduated') {
    return validationFailed(requestId, 'Invalid unlock reason.')
  }

  const { data: currentProfile, error: profileError } = await supabase
    .from('profiles')
    .select('id, verification_type')
    .eq('id', user.id)
    .maybeSingle()

  if (profileError || !currentProfile) {
    if (profileError) {
      logServerError('verification.university.unlock.profile', requestId, profileError, {
        userId: user.id,
      })
    }
    return validationFailed(requestId, 'Profile not found.')
  }

  const nowIso = new Date().toISOString()
  const updatePayload: Record<string, unknown> = {
    university_verified: false,
    university_verified_at: null,
    updated_at: nowIso,
  }

  if (currentProfile.verification_type === 'university_email') {
    updatePayload.is_verified = false
    updatePayload.verification_type = null
  }

  if (reason === 'change_email') {
    updatePayload.university_email = null
    updatePayload.university_domain = null
    updatePayload.university_name = null
  }

  if (reason === 'graduated') {
    updatePayload.university_graduated_at = nowIso
  }

  const { data: updatedProfile, error: updateError } = await supabase
    .from('profiles')
    .update(updatePayload)
    .eq('id', user.id)
    .select('university_email, university_domain, university_name, university_verified, university_verified_at, university_graduated_at')
    .maybeSingle()

  if (updateError || !updatedProfile) {
    if (updateError) {
      logServerError('verification.university.unlock.update', requestId, updateError, {
        userId: user.id,
      })
    }
    return serverFailure(requestId)
  }

  return successResponse(requestId, {
    ok: true,
    reason,
    profile: updatedProfile,
  })
}

