import crypto from 'crypto'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { extractDomain, isAcademicDomain } from '@/lib/verification/swot'
import { getNormalizedUniversityName, isConsumerDomain } from '@/lib/verification/university'
import { validateEmail } from '@/lib/utils'
import { hashToken, sendUniversityVerificationEmail } from '@/lib/email'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import { enforceRateLimit, enforceSameOrigin, serverFailure, unauthorized, validationFailed } from '@/lib/security/guards'
import { parseJsonObject, readBoolean, readOptionalNumber, readString, ValidationError } from '@/lib/security/validation'
import { getPreferredAuthOrigin } from '@/lib/auth/origin'

export const runtime = 'nodejs'

const MAX_PER_USER = 3
const MAX_PER_EMAIL = 5
const WINDOW_MINUTES = 15
const YEAR_MS = 365 * 24 * 60 * 60 * 1000
const MIN_GRAD_YEAR = 1900
const MAX_GRAD_YEAR = 2300
const SUPPORT_EMAIL = 'support@presocial.app'

export async function POST(request: Request) {
  const requestId = createRequestId()
  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const requestRateLimit = enforceRateLimit({
    namespace: 'verification:university:request',
    request,
    requestId,
    userId: user.id,
    limit: 8,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 60_000,
  })
  if (requestRateLimit) return requestRateLimit

  let payload: Record<string, unknown>
  try {
    payload = await parseJsonObject(request)
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid request payload.')
    }
    return validationFailed(requestId, 'Invalid request payload.')
  }

  let rawEmail = ''
  let allowEmailChange = false
  let parsedGradYear: number | null = null
  try {
    rawEmail = readString(payload, 'email', { required: true, toLowerCase: true })
    allowEmailChange = readBoolean(payload, 'allowEmailChange', { defaultValue: false })
    parsedGradYear = readOptionalNumber(payload, 'graduationYear', {
      integer: true,
      min: MIN_GRAD_YEAR,
      max: MAX_GRAD_YEAR,
    })
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid verification request.')
    }
    return validationFailed(requestId, 'Invalid verification request.')
  }

  if (!rawEmail || !validateEmail(rawEmail)) {
    return validationFailed(requestId, 'Please enter a valid university email.')
  }

  const domain = extractDomain(rawEmail)
  if (!domain) {
    return validationFailed(requestId, 'Please enter a valid university email.')
  }

  if (isConsumerDomain(domain)) {
    return validationFailed(requestId, 'Please use your university email domain.')
  }

  const swot = isAcademicDomain(domain)
  if (!swot.ok) {
    if (swot.reason === 'stoplisted') {
      return validationFailed(requestId, 'This domain is blocked from verification.')
    }
    if (swot.reason === 'swot_missing') {
      return serverFailure(requestId)
    }
    return validationFailed(requestId, 'This domain is not eligible for university verification.')
  }

  const admin = createAdminClient() as any
  const windowStart = new Date(Date.now() - WINDOW_MINUTES * 60 * 1000).toISOString()

  const { count: userCount } = await admin
    .from('university_verifications')
    .select('id', { count: 'exact', head: true })
    .eq('user_id', user.id)
    .gte('created_at', windowStart)

  if ((userCount ?? 0) >= MAX_PER_USER) {
    return validationFailed(requestId, 'Too many attempts. Please try again shortly.')
  }

  const { count: emailCount } = await admin
    .from('university_verifications')
    .select('id', { count: 'exact', head: true })
    .eq('email', rawEmail)
    .gte('created_at', windowStart)

  if ((emailCount ?? 0) >= MAX_PER_EMAIL) {
    return validationFailed(requestId, 'Too many attempts. Please try again shortly.')
  }

  const { data: currentProfile } = await admin
    .from('profiles')
    .select('university_email, university_verified, verification_type, is_verified, university_graduation_year, university_grad_year_confirmed_at')
    .eq('id', user.id)
    .maybeSingle()

  const existingUniversityEmail = (currentProfile?.university_email ?? '').toLowerCase()
  const emailChanged = existingUniversityEmail !== rawEmail
  if (currentProfile?.university_verified && emailChanged && !allowEmailChange) {
    return validationFailed(
      requestId,
      'Your university email is currently locked. Request an email change first.'
    )
  }

  let shouldPersistGraduationYear = false
  if (parsedGradYear !== null) {
    const existingGradYear =
      typeof currentProfile?.university_graduation_year === 'number'
        ? currentProfile.university_graduation_year
        : null
    const confirmedAtMs = currentProfile?.university_grad_year_confirmed_at
      ? new Date(currentProfile.university_grad_year_confirmed_at).getTime()
      : null
    const canChangeAfterMs =
      confirmedAtMs && Number.isFinite(confirmedAtMs) ? confirmedAtMs + YEAR_MS : null
    const isLockedForSupport =
      existingGradYear !== null &&
      canChangeAfterMs !== null &&
      Number.isFinite(canChangeAfterMs) &&
      canChangeAfterMs > Date.now()

    if (isLockedForSupport && parsedGradYear !== existingGradYear) {
      return validationFailed(
        requestId,
        `Graduation year is locked for one year. Contact ${SUPPORT_EMAIL} for help.`
      )
    }

    // Keep the lock window stable: do not refresh confirmation timestamp
    // when the same year is resubmitted while the lock is still active.
    shouldPersistGraduationYear = !isLockedForSupport || existingGradYear !== parsedGradYear
  }

  const nowIso = new Date().toISOString()
  const nextDomain = swot.domain ?? domain
  const nextName = getNormalizedUniversityName(nextDomain, swot.schoolName)

  const profileUpdate: Record<string, unknown> = {
    university_email: rawEmail,
    university_domain: nextDomain,
    university_name: nextName,
    updated_at: nowIso,
  }

  if (emailChanged) {
    profileUpdate.university_verified = false
    profileUpdate.university_verified_at = null
    profileUpdate.university_graduated_at = null
    if (currentProfile?.verification_type === 'university_email') {
      profileUpdate.is_verified = false
      profileUpdate.verification_type = null
    }
  }

  if (parsedGradYear !== null && shouldPersistGraduationYear) {
    profileUpdate.university_graduation_year = parsedGradYear
    profileUpdate.university_grad_year_confirmed_at = nowIso
    if (parsedGradYear >= new Date().getFullYear()) {
      profileUpdate.university_graduated_at = null
    }
  }

  const { error: profileError } = await admin
    .from('profiles')
    .update(profileUpdate)
    .eq('id', user.id)

  if (profileError) {
    logServerError('verification.university.request.profile', requestId, profileError, { userId: user.id })
    return serverFailure(requestId)
  }

  const token = crypto.randomBytes(32).toString('hex')
  const tokenHash = hashToken(token)
  const expiresAt = new Date(Date.now() + WINDOW_MINUTES * 60 * 1000).toISOString()

  const { data: insertedVerification, error: insertError } = await admin
    .from('university_verifications')
    .insert({
      user_id: user.id,
      email: rawEmail,
      token_hash: tokenHash,
      expires_at: expiresAt,
    })
    .select('id')
    .maybeSingle()

  if (insertError) {
    logServerError('verification.university.request.token_insert', requestId, insertError, { userId: user.id })
    return serverFailure(requestId)
  }

  const origin = getPreferredAuthOrigin(request)
  if (!origin) {
    return serverFailure(requestId)
  }

  const link = `${origin}/api/verification/university/confirm?token=${token}`

  try {
    await sendUniversityVerificationEmail({
      requestId,
      to: rawEmail,
      link,
      domain: nextDomain,
      schoolName: nextName,
    })
  } catch (err) {
    if (insertedVerification?.id) {
      await admin
        .from('university_verifications')
        .delete()
        .eq('id', insertedVerification.id)
        .eq('user_id', user.id)
    }
    logServerError('verification.university.request.email', requestId, err, {
      userId: user.id,
      domain: nextDomain,
    })
    return serverFailure(requestId)
  }

  return successResponse(requestId, {
    ok: true,
    status: 'sent',
    email: rawEmail,
    domain: nextDomain,
    schoolName: nextName,
  })
}
