import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import { reconcileInvitesForInviter } from '@/lib/invites/reconcile'
import {
  enforceRateLimit,
  enforceSameOrigin,
  serverFailure,
  unauthorized,
  validationFailed,
} from '@/lib/security/guards'
import { parseJsonObject, readString, ValidationError } from '@/lib/security/validation'

type RevokeInviteBody = {
  inviteId?: string
}

export const runtime = 'nodejs'

export async function POST(request: Request) {
  const requestId = createRequestId()
  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'invites:revoke',
    request,
    requestId,
    userId: user.id,
    limit: 10,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 60_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  let body: RevokeInviteBody
  try {
    body = (await parseJsonObject(request)) as RevokeInviteBody
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid revoke payload.')
    }
    return validationFailed(requestId, 'Invalid revoke payload.')
  }

  let inviteId = ''
  try {
    inviteId = readString(body as Record<string, unknown>, 'inviteId', { required: true })
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invite id is required.')
    }
    return validationFailed(requestId, 'Invite id is required.')
  }

  const admin = createAdminClient() as any
  await reconcileInvitesForInviter({
    admin,
    inviterId: user.id,
    requestId,
  })

  const { data: currentInvite, error: currentInviteError } = await admin
    .from('access_invites')
    .select('id,status')
    .eq('id', inviteId)
    .eq('inviter_id', user.id)
    .maybeSingle()

  if (currentInviteError) {
    logServerError('invites.revoke.current', requestId, currentInviteError, { userId: user.id, inviteId })
    return serverFailure(requestId)
  }

  if (!currentInvite) {
    return validationFailed(requestId, 'Invite not found.')
  }

  if (currentInvite.status !== 'pending') {
    if (currentInvite.status === 'accepted') {
      return validationFailed(requestId, 'Invite has already been used and cannot be revoked.')
    }
    return validationFailed(requestId, 'Invite not found or already processed.')
  }

  const { data: updated, error: updateError } = await admin
    .from('access_invites')
    .update({
      status: 'revoked',
      updated_at: new Date().toISOString(),
    })
    .eq('id', inviteId)
    .eq('inviter_id', user.id)
    .eq('status', 'pending')
    .select('id,status')
    .maybeSingle()

  if (updateError) {
    logServerError('invites.revoke', requestId, updateError, { userId: user.id, inviteId })
    return serverFailure(requestId)
  }

  if (!updated) {
    return validationFailed(requestId, 'Invite not found or already processed.')
  }

  return successResponse(requestId, { ok: true, invite: updated })
}
