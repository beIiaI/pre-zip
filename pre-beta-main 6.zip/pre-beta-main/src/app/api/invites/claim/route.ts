import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { normalizeInviteCode, normalizeInviteEmail } from '@/lib/invites'
import { validateEmail } from '@/lib/utils'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import {
  enforceRateLimit,
  enforceSameOrigin,
  serverFailure,
  unauthorized,
  validationFailed,
} from '@/lib/security/guards'
import { parseJsonObject, readString, ValidationError } from '@/lib/security/validation'

type ClaimInviteBody = {
  code?: string
  email?: string
}

export const runtime = 'nodejs'

export async function POST(request: Request) {
  const requestId = createRequestId()
  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'invites:claim',
    request,
    requestId,
    userId: user.id,
    email: user.email ?? null,
    limit: 10,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 60_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  let body: ClaimInviteBody
  try {
    body = (await parseJsonObject(request)) as ClaimInviteBody
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid invite claim payload.')
    }
    return validationFailed(requestId, 'Invalid invite claim payload.')
  }

  let codeInput = ''
  let emailInput = ''
  try {
    codeInput = readString(body as Record<string, unknown>, 'code', { required: true })
    emailInput = readString(body as Record<string, unknown>, 'email')
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid invite claim payload.')
    }
    return validationFailed(requestId, 'Invalid invite claim payload.')
  }

  const code = normalizeInviteCode(codeInput)
  const authEmail = normalizeInviteEmail(user.email ?? '')
  const bodyEmail = normalizeInviteEmail(emailInput)
  if (!code) {
    return validationFailed(requestId, 'Invite code is required.')
  }
  if (!validateEmail(authEmail)) {
    return validationFailed(requestId, 'Unable to verify account email.')
  }
  if (bodyEmail && bodyEmail !== authEmail) {
    return validationFailed(requestId, 'Invite email must match your account email.')
  }

  const admin = createAdminClient() as any
  const { data: invite, error: inviteError } = await admin
    .from('access_invites')
    .select('id,inviter_id,invitee_email,status,accepted_user_id,expires_at,invite_code')
    .eq('invite_code', code)
    .maybeSingle()

  if (inviteError) {
    logServerError('invites.claim.lookup', requestId, inviteError)
    return serverFailure(requestId)
  }

  if (!invite) {
    return validationFailed(requestId, 'Invite code not found.')
  }

  if (invite.expires_at && invite.expires_at <= new Date().toISOString()) {
    return validationFailed(requestId, 'Invite code has expired.')
  }

  const expectedEmail = invite.invitee_email ? normalizeInviteEmail(invite.invitee_email) : ''
  const isOpenInvite = !expectedEmail
  if (!isOpenInvite && expectedEmail !== authEmail) {
    return validationFailed(requestId, 'This invite is reserved for another email.')
  }

  if (invite.status === 'accepted' && invite.accepted_user_id === user.id) {
    return successResponse(requestId, { ok: true, alreadyClaimed: true })
  }

  if (invite.status !== 'pending') {
    return validationFailed(requestId, 'Invite code is no longer active.')
  }

  const nowIso = new Date().toISOString()
  const { data: claimed, error: claimError } = await admin
    .from('access_invites')
    .update({
      status: 'accepted',
      invitee_email: invite.invitee_email ?? authEmail,
      accepted_user_id: user.id,
      accepted_at: nowIso,
      updated_at: nowIso,
    })
    .eq('id', invite.id)
    .eq('status', 'pending')
    .select('id,inviter_id,invite_code')
    .maybeSingle()

  if (claimError) {
    logServerError('invites.claim.update', requestId, claimError, {
      inviteId: invite.id,
      userId: user.id,
    })
    return serverFailure(requestId)
  }

  if (!claimed) {
    return validationFailed(requestId, 'Invite has already been claimed.')
  }

  const { data: existingReferral, error: referralLookupError } = await admin
    .from('referrals')
    .select('id')
    .eq('referrer_id', claimed.inviter_id)
    .eq('referred_id', user.id)
    .maybeSingle()

  if (referralLookupError) {
    logServerError('invites.claim.referral_lookup', requestId, referralLookupError, {
      inviterId: claimed.inviter_id,
      userId: user.id,
    })
    return serverFailure(requestId)
  }

  if (!existingReferral) {
    const { error: referralInsertError } = await admin.from('referrals').insert({
      referrer_id: claimed.inviter_id,
      referred_id: user.id,
      code: claimed.invite_code,
      status: 'completed',
      completed_at: nowIso,
    })
    if (referralInsertError) {
      logServerError('invites.claim.referral_insert', requestId, referralInsertError, {
        inviterId: claimed.inviter_id,
        userId: user.id,
      })
      return serverFailure(requestId)
    }
  }

  return successResponse(requestId, { ok: true })
}

