import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'

const SELECT_FIELDS = 'id, username, full_name, avatar_url, bio, location, early_supporter_number, founder_number, is_founder, profile_visibility, discoverable, show_location'

export const runtime = 'nodejs'

export async function GET(request: Request) {
  const supabase = await createClient()

  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { searchParams } = new URL(request.url)
  const rawQuery = searchParams.get('q')?.trim() ?? ''
  const normalized = rawQuery.replace(/^@/, '').trim()
  if (!normalized) {
    return NextResponse.json({ results: [] })
  }

  const admin = createAdminClient() as any

  const prefixResult = await admin
    .from('profiles')
    .select(SELECT_FIELDS)
    .ilike('username', `${normalized}%`)
    .neq('id', user.id)
    .order('username', { ascending: true })
    .limit(20)

  if (prefixResult.error) {
    return NextResponse.json({ error: 'Search failed' }, { status: 500 })
  }

  const secondaryResult = await admin
    .from('profiles')
    .select(SELECT_FIELDS)
    .or(`username.ilike.%${normalized}%,full_name.ilike.%${normalized}%`)
    .neq('id', user.id)
    .order('username', { ascending: true })
    .limit(20)

  if (secondaryResult.error) {
    return NextResponse.json({ error: 'Search failed' }, { status: 500 })
  }

  const combined: Record<string, any> = {}
  const ordered: any[] = []

  for (const row of prefixResult.data ?? []) {
    if (!combined[row.id]) {
      combined[row.id] = row
      ordered.push(row)
    }
  }

  for (const row of secondaryResult.data ?? []) {
    if (!combined[row.id]) {
      combined[row.id] = row
      ordered.push(row)
    }
  }

  const limited = ordered.slice(0, 20)

  const ids = limited.map((row) => row.id)
  const followingSet = new Set<string>()
  const followerSet = new Set<string>()
  const blockedSet = new Set<string>()
  if (ids.length > 0) {
    const { data: followRows } = await supabase
      .from('follows')
      .select('following_id')
      .eq('follower_id', user.id)
      .in('following_id', ids)

    for (const row of followRows ?? []) {
      if (row.following_id) {
        followingSet.add(row.following_id)
      }
    }

    const { data: followerRows } = await supabase
      .from('follows')
      .select('follower_id')
      .eq('following_id', user.id)
      .in('follower_id', ids)

    for (const row of followerRows ?? []) {
      if (row.follower_id) {
        followerSet.add(row.follower_id)
      }
    }

    const { data: blockedByMe } = await supabase
      .from('blocks')
      .select('blocked_id')
      .eq('blocker_id', user.id)
      .in('blocked_id', ids)

    for (const row of blockedByMe ?? []) {
      if (row.blocked_id) {
        blockedSet.add(row.blocked_id)
      }
    }

    const { data: blockedMe } = await supabase
      .from('blocks')
      .select('blocker_id')
      .eq('blocked_id', user.id)
      .in('blocker_id', ids)

    for (const row of blockedMe ?? []) {
      if (row.blocker_id) {
        blockedSet.add(row.blocker_id)
      }
    }
  }

  const results = limited
    .filter((row) => (row.discoverable ?? true) !== false)
    .filter((row) => !blockedSet.has(row.id))
    .filter((row) => {
      const visibility = row.profile_visibility ?? 'public'
      if (visibility === 'private') return false
      if (visibility === 'friends') {
        return followingSet.has(row.id) && followerSet.has(row.id)
      }
      return true
    })
    .map((row) => ({
      id: row.id,
      username: row.username,
      full_name: row.full_name,
      avatar_url: row.avatar_url,
      bio: typeof row.bio === 'string' ? row.bio.trim() : null,
      location: (row.show_location ?? true) ? row.location : null,
      early_supporter_number: row.early_supporter_number,
      founder_number: row.founder_number,
      is_founder: row.is_founder,
      is_following: followingSet.has(row.id),
    }))

  return NextResponse.json({ results })
}
