'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowLeft, UserX } from 'lucide-react'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Avatar } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'

type BlockedItem = {
  blocked_id: string
  profile: {
    id: string
    username: string | null
    full_name: string | null
    avatar_url: string | null
  } | null
}

export default function BlockedUsersPage() {
  const { user, loading, initialized } = useAuth()
  const router = useRouter()
  const [items, setItems] = useState<BlockedItem[]>([])
  const [loadingList, setLoadingList] = useState(true)

  useEffect(() => {
    if (!initialized || loading) return
    if (!user) {
      router.replace('/')
    }
  }, [initialized, loading, user, router])

  useEffect(() => {
    if (!user) return
    let active = true
    setLoadingList(true)
    fetch('/api/blocks')
      .then((res) => res.json())
      .then((data) => {
        if (!active) return
        setItems(data.results ?? [])
      })
      .finally(() => {
        if (active) setLoadingList(false)
      })
    return () => {
      active = false
    }
  }, [user])

  const handleUnblock = async (blockedId: string) => {
    setItems((prev) => prev.filter((item) => item.blocked_id !== blockedId))
    const response = await fetch(`/api/blocks/${encodeURIComponent(blockedId)}`, {
      method: 'DELETE',
    })
    if (!response.ok) {
      // rollback by refetching
      fetch('/api/blocks')
        .then((res) => res.json())
        .then((data) => setItems(data.results ?? []))
        .catch(() => {})
    }
  }

  if (!initialized || loading) {
    return <LoadingScreen />
  }

  if (!user) {
    return <LoadingScreen />
  }

  return (
    <div className="app-page safe-top safe-bottom">
      <header className="app-header px-4 py-4 flex items-center justify-between">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">Blocked Users</h1>
        <div className="w-9" />
      </header>

      <main className="app-content">
        {loadingList ? (
          <LoadingScreen />
        ) : items.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="h-16 w-16 rounded-full bg-surface-secondary flex items-center justify-center mb-4">
              <UserX className="h-8 w-8 text-content-tertiary" />
            </div>
            <h3 className="text-headline text-content-primary mb-2">No blocked users</h3>
            <p className="text-body text-content-secondary max-w-xs">
              You haven’t blocked anyone yet.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {items.map((item) => {
              const profile = item.profile
              const name = profile?.full_name || profile?.username || 'Unknown'
              return (
                <div
                  key={item.blocked_id}
                  className="flex items-center gap-4 p-4 rounded-[1rem] bg-surface-secondary/75 border border-border-secondary"
                >
                  <Avatar src={profile?.avatar_url} size="lg" />
                  <div className="flex-1 min-w-0">
                    <p className="text-body font-medium text-content-primary truncate">{name}</p>
                    {profile?.username && (
                      <p className="text-callout text-content-secondary">@{profile.username}</p>
                    )}
                  </div>
                  <Button size="sm" variant="secondary" onClick={() => handleUnblock(item.blocked_id)}>
                    Unblock
                  </Button>
                </div>
              )
            })}
          </div>
        )}
      </main>
    </div>
  )
}
