'use client'

import NotificationsPage from '@/app/notifications/page'

export default NotificationsPage
