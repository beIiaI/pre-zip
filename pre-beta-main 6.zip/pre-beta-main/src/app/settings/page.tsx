'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { useTheme } from '@/components/providers/theme-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Button } from '@/components/ui/button'
import { SegmentedControl } from '@/components/ui/segmented-control'
import { Toggle } from '@/components/ui/toggle'
import { Input } from '@/components/ui/input'
import { ArrowLeft, ChevronRight, Shield, Bell, HelpCircle, LogOut, Palette, User, Lock, KeyRound, UserPlus, ClipboardList } from 'lucide-react'
import Link from 'next/link'

export default function SettingsPage() {
  const { user, profile, loading, initialized, signOut, updateProfile } = useAuth()
  const { mode, amoledEnabled, setMode, setAmoledEnabled, resolvedTheme } = useTheme()
  const router = useRouter()
  const [redirecting, setRedirecting] = useState(false)
  const [founderId, setFounderId] = useState('')
  const [founderNumber, setFounderNumber] = useState('')
  const [founderStatus, setFounderStatus] = useState<string | null>(null)
  const [founderLoading, setFounderLoading] = useState(false)

  useEffect(() => {
    if (!initialized || loading) return
    if (!user) {
      setRedirecting(true)
      router.replace('/')
    }
  }, [initialized, loading, user, router])

  if (!initialized || loading || redirecting) {
    return <LoadingScreen />
  }

  if (!user) {
    return <LoadingScreen />
  }

  const handleSignOut = async () => {
    await signOut()
    router.replace('/')
  }

  const handleThemeChange = async (newMode: 'light' | 'dark' | 'system') => {
    setMode(newMode)
    await updateProfile({ theme_mode: newMode })
  }

  const handleAmoledChange = async (enabled: boolean) => {
    setAmoledEnabled(enabled)
    await updateProfile({ amoled_enabled: enabled })
  }

  const handleMarkFounder = async () => {
    if (!founderId.trim() || founderLoading) return
    setFounderStatus(null)
    setFounderLoading(true)
    try {
      const response = await fetch('/api/admin/founder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: founderId.trim(),
          founder_number: founderNumber.trim() ? Number(founderNumber.trim()) : undefined,
        }),
      })
      const data = await response.json()
      if (!response.ok) {
        throw new Error(data.error || 'Unable to update founder')
      }
      setFounderStatus('Founder status updated.')
      setFounderId('')
      setFounderNumber('')
    } catch (err) {
      setFounderStatus(err instanceof Error ? err.message : 'Unable to update founder')
    } finally {
      setFounderLoading(false)
    }
  }

  const showAmoledToggle = mode === 'dark' || (mode === 'system' && resolvedTheme === 'dark')

  return (
    <div className="app-page safe-top safe-bottom">
      <header className="app-header px-4 py-4 flex items-center justify-between">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
          data-testid="settings-back-button"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">Settings</h1>
        <div className="w-9" />
      </header>

      <main className="app-content space-y-6">
        <section className="app-section">
          <h2 className="app-section-label">Appearance</h2>
          <div className="surface-group divide-y divide-border-secondary">
            <div className="p-4 space-y-3">
                <div className="flex items-center gap-3">
                  <Palette className="h-5 w-5 text-content-tertiary" />
                  <span className="text-body text-content-primary">Theme</span>
                </div>
                <SegmentedControl
                  options={[
                    { value: 'light', label: 'Light' },
                    { value: 'dark', label: 'Dark' },
                    { value: 'system', label: 'System' },
                  ]}
                  value={mode}
                  onChange={(v) => handleThemeChange(v as 'light' | 'dark' | 'system')}
                />
              </div>
              {showAmoledToggle && (
                <div className="p-4">
                  <Toggle
                    enabled={amoledEnabled}
                    onChange={handleAmoledChange}
                    label="AMOLED Mode"
                    description="Pure black backgrounds"
                  />
                </div>
              )}
          </div>
        </section>

        <section className="app-section">
          <h2 className="app-section-label">Account</h2>
          <div className="surface-group">
              <Link
                href="/profile/edit"
                className="surface-row hover:bg-accent-muted transition-colors"
                data-testid="settings-edit-profile"
              >
                <div className="flex items-center gap-3">
                  <User className="h-5 w-5 text-content-tertiary" />
                  <span className="text-body text-content-primary">Edit Profile</span>
                </div>
                <ChevronRight className="h-5 w-5 text-content-tertiary" />
              </Link>
              <Link
                href="/settings/notifications"
                className="surface-row hover:bg-accent-muted transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Bell className="h-5 w-5 text-content-tertiary" />
                  <span className="text-body text-content-primary">Notifications</span>
                </div>
                <ChevronRight className="h-5 w-5 text-content-tertiary" />
              </Link>
              <Link
                href="/settings/privacy"
                className="surface-row hover:bg-accent-muted transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Lock className="h-5 w-5 text-content-tertiary" />
                  <span className="text-body text-content-primary">Privacy</span>
                </div>
                <ChevronRight className="h-5 w-5 text-content-tertiary" />
              </Link>
              <Link
                href="/settings/password"
                className="surface-row hover:bg-accent-muted transition-colors"
              >
                <div className="flex items-center gap-3">
                  <KeyRound className="h-5 w-5 text-content-tertiary" />
                  <span className="text-body text-content-primary">Password</span>
                </div>
                <ChevronRight className="h-5 w-5 text-content-tertiary" />
              </Link>
              <Link
                href="/settings/invites"
                className="surface-row hover:bg-accent-muted transition-colors"
              >
                <div className="flex items-center gap-3">
                  <UserPlus className="h-5 w-5 text-content-tertiary" />
                  <span className="text-body text-content-primary">Invite Users</span>
                </div>
                <ChevronRight className="h-5 w-5 text-content-tertiary" />
              </Link>
          </div>
        </section>

        <section className="app-section">
          <h2 className="app-section-label">Safety</h2>
          <div className="surface-group">
              <Link
                href="/settings/safety-verification"
                className="surface-row hover:bg-accent-muted transition-colors"
                data-testid="settings-safety"
              >
                <div className="flex items-center gap-3">
                  <Shield className="h-5 w-5 text-content-tertiary" />
                  <span className="text-body text-content-primary">Safety & Verification</span>
                </div>
                <ChevronRight className="h-5 w-5 text-content-tertiary" />
              </Link>
          </div>
        </section>

        <section className="app-section">
          <h2 className="app-section-label">Support</h2>
          <div className="surface-group">
              <Link
                href="/settings/help"
                className="surface-row hover:bg-accent-muted transition-colors"
              >
                <div className="flex items-center gap-3">
                  <HelpCircle className="h-5 w-5 text-content-tertiary" />
                  <span className="text-body text-content-primary">Help & Support</span>
                </div>
                <ChevronRight className="h-5 w-5 text-content-tertiary" />
              </Link>
          </div>
        </section>

        <Button
          variant="outline"
          className="w-full"
          onClick={handleSignOut}
          data-testid="settings-sign-out"
        >
          <LogOut className="h-4 w-4" />
          Sign Out
        </Button>

        {profile?.is_internal && (
          <section className="app-section">
            <h2 className="app-section-label">Developer Tools</h2>
            <div className="surface-block p-4 space-y-3">
                <Link
                  href="/settings/access-review"
                  className="surface-row hover:bg-accent-muted transition-colors rounded-button border border-border-secondary"
                >
                  <div className="flex items-center gap-3">
                    <ClipboardList className="h-5 w-5 text-content-tertiary" />
                    <span className="text-body text-content-primary">Membership Review Queue</span>
                  </div>
                  <ChevronRight className="h-5 w-5 text-content-tertiary" />
                </Link>
                <Input
                  label="Founder user ID"
                  placeholder="Paste user UUID"
                  value={founderId}
                  onChange={(event) => setFounderId(event.target.value)}
                />
                <Input
                  label="Founder number (optional)"
                  placeholder="0-999"
                  value={founderNumber}
                  onChange={(event) => setFounderNumber(event.target.value.replace(/[^0-9]/g, ''))}
                />
                <Button
                  variant="secondary"
                  className="w-full"
                  onClick={handleMarkFounder}
                  loading={founderLoading}
                  disabled={!founderId.trim() || founderLoading}
                >
                  Mark as Founder
                </Button>
                {founderStatus && (
                  <p className="text-caption text-content-tertiary">{founderStatus}</p>
                )}
            </div>
          </section>
        )}

        <p className="text-center text-caption text-content-tertiary">
          pre v1.0.0
        </p>
      </main>
    </div>
  )
}
