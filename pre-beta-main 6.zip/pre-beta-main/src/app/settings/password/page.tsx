'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowLeft, Check, X } from 'lucide-react'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Alert } from '@/components/ui/alert'
import { validatePassword } from '@/lib/utils'

export default function PasswordSettingsPage() {
  const { user, loading, initialized, profileLoaded } = useAuth()
  const router = useRouter()
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [redirecting, setRedirecting] = useState(false)

  useEffect(() => {
    if (!initialized || loading || !profileLoaded) return
    if (!user) {
      setRedirecting(true)
      router.replace('/')
    }
  }, [initialized, loading, profileLoaded, user, router])

  const checks = {
    length: password.length >= 8,
    lower: /[a-z]/.test(password),
    upper: /[A-Z]/.test(password),
    number: /[0-9]/.test(password),
    symbol: /[^A-Za-z0-9]/.test(password),
  }

  const handleUpdate = async () => {
    setError(null)
    setSuccess(null)
    const validation = validatePassword(password)
    if (!validation.valid) {
      setError(validation.error || 'Invalid password')
      return
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match')
      return
    }
    setSubmitting(true)
    try {
      const response = await fetch('/api/auth/password/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      })
      const data = await response.json().catch(() => ({}))
      if (!response.ok) {
        throw new Error(data?.error || 'Unable to update password')
      }
      setSuccess('Password updated.')
      setPassword('')
      setConfirmPassword('')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to update password')
    } finally {
      setSubmitting(false)
    }
  }

  if (!initialized || loading || !profileLoaded || redirecting) {
    return <LoadingScreen />
  }

  if (!user) {
    return <LoadingScreen />
  }

  return (
    <div className="app-page safe-top safe-bottom flex flex-col">
      <header className="app-header px-4 py-4 flex items-center justify-between">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">Password</h1>
        <div className="w-9" />
      </header>

      <main className="app-content flex-1 space-y-4">
          {error && (
            <Alert variant="error" dismissible onDismiss={() => setError(null)}>
              {error}
            </Alert>
          )}
          {success && (
            <Alert variant="success" dismissible onDismiss={() => setSuccess(null)}>
              {success}
            </Alert>
          )}

          <Input
            type="password"
            label="New password"
            placeholder="Enter your new password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="new-password"
          />
          <Input
            type="password"
            label="Confirm password"
            placeholder="Re-enter your new password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            autoComplete="new-password"
          />

          <div className="surface-block px-4 py-3 space-y-2">
            <p className="text-caption text-content-secondary">Password must include:</p>
            {[
              { label: 'At least 8 characters', ok: checks.length },
              { label: 'One lowercase letter', ok: checks.lower },
              { label: 'One uppercase letter', ok: checks.upper },
              { label: 'One number', ok: checks.number },
              { label: 'One symbol', ok: checks.symbol },
            ].map((rule) => (
              <div key={rule.label} className="flex items-center gap-2 text-caption">
                {rule.ok ? (
                  <Check className="h-3.5 w-3.5 text-success" />
                ) : (
                  <X className="h-3.5 w-3.5 text-content-tertiary" />
                )}
                <span className={rule.ok ? 'text-content-primary' : 'text-content-tertiary'}>
                  {rule.label}
                </span>
              </div>
            ))}
          </div>

          <Button className="w-full" loading={submitting} onClick={handleUpdate}>
            Update password
          </Button>
      </main>
    </div>
  )
}
