'use client'

import { PublicProfilePage } from '@/components/screens/PublicProfilePage'

export default function UserProfilePage() {
  return <PublicProfilePage />
}
