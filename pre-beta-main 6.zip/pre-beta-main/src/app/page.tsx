'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { SplashScreen } from '@/components/screens/SplashScreen'
import { LoadingScreen } from '@/components/ui/spinner'

export default function HomePage() {
  const { user, profile, loading, initialized, profileLoaded } = useAuth()
  const router = useRouter()
  const profileName = profile?.full_name?.trim() || ''
  const username = profile?.username?.trim() || ''
  const emailLocal = user?.email?.split('@')[0]?.trim() || ''
  const blockedMetadataValues = new Set(
    [username, emailLocal]
      .map((value) => value.toLowerCase().replace(/[^a-z0-9]/g, ''))
      .filter(Boolean)
  )
  const metadataNameCandidates = [
    typeof user?.user_metadata?.full_name === 'string' ? user.user_metadata.full_name.trim() : '',
    typeof user?.user_metadata?.name === 'string' ? user.user_metadata.name.trim() : '',
  ]
  const metadataName = metadataNameCandidates.find((value) => {
    if (!value || value.includes('@')) return false
    const normalized = value.toLowerCase().replace(/[^a-z0-9]/g, '')
    return !!normalized && !blockedMetadataValues.has(normalized)
  }) || ''
  const displayName = profileName || metadataName || null
  const booting = !initialized || loading || !profileLoaded
  const redirectTarget = !booting && user
    ? (profile?.onboarding_completed ? '/home' : '/onboarding')
    : null

  useEffect(() => {
    if (redirectTarget) {
      router.replace(redirectTarget)
    }
  }, [redirectTarget, router])

  if (booting) {
    return <LoadingScreen name={displayName} showWelcome={!!user} />
  }

  if (!user) {
    return (
      <SplashScreen
        showActions
        onGetStarted={() => router.push('/auth?mode=signup')}
        onSignIn={() => router.push('/auth?mode=signin')}
      />
    )
  }

  if (redirectTarget) {
    return <LoadingScreen name={displayName} showWelcome />
  }

  return <LoadingScreen name={displayName} showWelcome />
}
