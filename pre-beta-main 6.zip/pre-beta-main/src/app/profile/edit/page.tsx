'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowLeft, Building2, Camera, School } from 'lucide-react'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Alert } from '@/components/ui/alert'
import { BottomSheet } from '@/components/ui-circle/BottomSheet'
import { validateUsername } from '@/lib/utils'
import { isRestrictedBio, isRestrictedDisplayName, isRestrictedUsername } from '@/lib/moderation/restrictedWordsClient'
import { createClient } from '@/lib/supabase/client'
import { LoadingDots } from '@/components/ui/loading-dots'
import { getNormalizedUniversityName } from '@/lib/verification/university'

const LOCATION_OPTIONS = [
  'San Francisco, CA',
  'Los Angeles, CA',
  'New York, NY',
  'Austin, TX',
  'Seattle, WA',
  'Portland, OR',
  'Denver, CO',
  'Boston, MA',
]

interface EditProfileFormProps {
  userId: string
  initialProfile: NonNullable<ReturnType<typeof useAuth>['profile']>
  updateProfile: ReturnType<typeof useAuth>['updateProfile']
  refreshProfile: ReturnType<typeof useAuth>['refreshProfile']
}

type CollegeVisibilityResponse = {
  profile?: {
    college_name?: string | null
  }
  collegeOptions?: string[]
}

function EditProfileForm({ userId, initialProfile, updateProfile, refreshProfile }: EditProfileFormProps) {
  const router = useRouter()
  const supabase = useMemo(() => createClient(), [])
  const fileInputRef = useRef<HTMLInputElement | null>(null)

  const [name, setName] = useState(initialProfile.full_name || '')
  const [username, setUsername] = useState(initialProfile.username || '')
  const [bio, setBio] = useState(initialProfile.bio || '')
  const [location, setLocation] = useState(initialProfile.location || '')
  const [avatarUrl, setAvatarUrl] = useState<string | null>(initialProfile.avatar_url ?? null)
  const [showUniversity, setShowUniversity] = useState(initialProfile.show_university !== false)
  const [showCollege, setShowCollege] = useState(initialProfile.show_college === true)
  const [resolvedAvatar, setResolvedAvatar] = useState<string | null>(null)
  const [collegeName, setCollegeName] = useState<string | null>(null)
  const [hasSubdivisionOptions, setHasSubdivisionOptions] = useState(false)

  const [showPhotoSheet, setShowPhotoSheet] = useState(false)
  const [showLocationSheet, setShowLocationSheet] = useState(false)
  const [saving, setSaving] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [showSuccessToast, setShowSuccessToast] = useState(false)
  const [usernameError, setUsernameError] = useState<string | null>(null)
  const [checkingUsername, setCheckingUsername] = useState(false)
  const debounceRef = useRef<NodeJS.Timeout | null>(null)
  const abortRef = useRef<AbortController | null>(null)

  useEffect(() => {
    setName(initialProfile.full_name || '')
    setUsername(initialProfile.username || '')
    setBio(initialProfile.bio || '')
    setLocation(initialProfile.location || '')
    setAvatarUrl(initialProfile.avatar_url ?? null)
    setShowUniversity(initialProfile.show_university !== false)
    setShowCollege(initialProfile.show_college === true)
  }, [initialProfile])

  useEffect(() => {
    if (initialProfile.university_verified !== true) {
      setCollegeName(null)
      setHasSubdivisionOptions(false)
      return
    }

    let active = true
    fetch('/api/verification/college', {
      cache: 'no-store',
      credentials: 'include',
    })
      .then((response) => (response.ok ? response.json() : null))
      .then((payload: CollegeVisibilityResponse | null) => {
        if (!active || !payload) return
        const nextCollege =
          typeof payload.profile?.college_name === 'string' && payload.profile.college_name.trim()
            ? payload.profile.college_name.trim()
            : null
        setCollegeName(nextCollege)
        setHasSubdivisionOptions(Array.isArray(payload.collegeOptions) && payload.collegeOptions.length > 0)
      })
      .catch(() => {
        if (!active) return
        setCollegeName(null)
        setHasSubdivisionOptions(false)
      })

    return () => {
      active = false
    }
  }, [initialProfile.university_verified])

  useEffect(() => {
    if (!avatarUrl) {
      setResolvedAvatar(null)
      return
    }

    const normalized = avatarUrl.trim()
    if (/^(https?:|data:|blob:)/i.test(normalized)) {
      setResolvedAvatar(normalized)
      return
    }

    const path = normalized.startsWith('avatars/') ? normalized.replace(/^avatars\//, '') : normalized
    const { data } = supabase.storage.from('avatars').getPublicUrl(path)
    setResolvedAvatar(data?.publicUrl ?? null)
  }, [avatarUrl, supabase])

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (!file.type.startsWith('image/')) {
      setError('Please select an image file')
      return
    }
    if (file.size > 5 * 1024 * 1024) {
      setError('Image must be less than 5MB')
      return
    }

    setUploading(true)
    setError(null)

    try {
      const fileExt = file.name.split('.').pop() || 'jpg'
      const uuid = typeof crypto !== 'undefined' && 'randomUUID' in crypto
        ? crypto.randomUUID()
        : `${Date.now()}-${Math.random().toString(36).slice(2)}`
      const filePath = `${userId}/${uuid}.${fileExt}`

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file, { upsert: true })

      if (uploadError) {
        setError('Failed to upload avatar')
        setAvatarUrl(URL.createObjectURL(file))
        return
      }

      const { data } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath)

      if (data?.publicUrl) {
        setAvatarUrl(data.publicUrl)
        await updateProfile({ avatar_url: data.publicUrl })
        await refreshProfile()
      }
    } catch {
      setAvatarUrl(URL.createObjectURL(file))
    } finally {
      setUploading(false)
    }
  }

  const handleRemoveAvatar = async () => {
    setAvatarUrl(null)
    setResolvedAvatar(null)
    setShowPhotoSheet(false)
    const { error: updateError } = await updateProfile({ avatar_url: null })
    if (updateError) {
      setError(updateError.message)
      return
    }
    await refreshProfile()
  }

  const handleUsernameChange = (value: string) => {
    const cleaned = value.toLowerCase().replace(/[^a-z0-9_]/g, '')
    setUsername(cleaned)
    setUsernameError(null)
  }

  useEffect(() => {
    if (!username) {
      setUsernameError('Username is required')
      setCheckingUsername(false)
      return
    }

    const validation = validateUsername(username)
    if (!validation.valid) {
      setUsernameError(validation.error || null)
      setCheckingUsername(false)
      return
    }

    if (isRestrictedUsername(username)) {
      setUsernameError("That username isn't available.")
      setCheckingUsername(false)
      return
    }

    if (username === initialProfile.username) {
      setUsernameError(null)
      setCheckingUsername(false)
      return
    }

    setCheckingUsername(true)

    if (debounceRef.current) {
      clearTimeout(debounceRef.current)
    }

    debounceRef.current = setTimeout(async () => {
      if (abortRef.current) {
        abortRef.current.abort()
      }
      abortRef.current = new AbortController()

      try {
        const response = await fetch(`/api/username/check?u=${encodeURIComponent(username)}`, {
          signal: abortRef.current.signal,
          cache: 'no-store',
          credentials: 'include',
        })

        if (!response.ok) {
          setCheckingUsername(false)
          return
        }

        const data = await response.json()
        if (!data.available) {
          setUsernameError("That username isn't available.")
        } else {
          setUsernameError(null)
        }
      } catch (err) {
        if (err instanceof Error && err.name === 'AbortError') {
          return
        }
      } finally {
        setCheckingUsername(false)
      }
    }, 450)

    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current)
      }
      if (abortRef.current) {
        abortRef.current.abort()
      }
    }
  }, [username, initialProfile.username])

  const hasChanges =
    name !== (initialProfile.full_name || '') ||
    username !== (initialProfile.username || '') ||
    bio !== (initialProfile.bio || '') ||
    location !== (initialProfile.location || '') ||
    avatarUrl !== (initialProfile.avatar_url ?? null) ||
    showUniversity !== (initialProfile.show_university !== false) ||
    showCollege !== (initialProfile.show_college === true)

  const isNameValid = name.trim().length >= 2 && /[a-zA-Z]/.test(name)
  const isUniversityVerified = initialProfile.university_verified === true
  const universityDisplayName = getNormalizedUniversityName(
    initialProfile.university_domain ?? null,
    initialProfile.university_name ?? null
  )
  const canOfferSubdivisionToggle = isUniversityVerified && hasSubdivisionOptions && !!collegeName
  const canSave = hasChanges && isNameValid && !usernameError && !checkingUsername && !saving && !uploading

  const generateInitials = (fullName: string): string => {
    if (!fullName.trim()) {
      const fallback = initialProfile.full_name || initialProfile.username || ''
      if (!fallback.trim()) return '?'
      const parts = fallback.trim().split(/[\s-]+/).filter(Boolean)
      if (parts.length === 0) return '?'
      if (parts.length === 1) return parts[0][0].toUpperCase()
      return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
    }

    const parts = fullName.trim().split(/[\s-]+/).filter(Boolean)
    if (parts.length === 0) return '?'
    if (parts.length === 1) return parts[0][0].toUpperCase()
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
  }

  const currentInitials = generateInitials(name)

  const toggleShowUniversity = () => {
    const next = !showUniversity
    setShowUniversity(next)
    if (!next) {
      setShowCollege(false)
    }
  }

  const toggleShowCollege = () => {
    if (!canOfferSubdivisionToggle || !showUniversity) return
    setShowCollege((current) => !current)
  }

  const handleSave = async () => {
    if (!canSave) return

    setError(null)

    if (!name.trim()) {
      setError('Name is required')
      return
    }
    if (isRestrictedDisplayName(name)) {
      setError("That name isn't available.")
      return
    }
    if (bio.trim() && isRestrictedBio(bio)) {
      setError('Bio contains restricted words.')
      return
    }
    if (!username.trim()) {
      setError('Username is required')
      return
    }
    if (usernameError) {
      setError(usernameError)
      return
    }

    setSaving(true)
    try {
      const { error: updateError } = await updateProfile({
        full_name: name.trim() || null,
        username: username.trim() || null,
        bio: bio.trim() || null,
        location: location.trim() || null,
        avatar_url: avatarUrl,
        show_university: showUniversity,
        show_college: showUniversity ? showCollege : false,
      })

      if (updateError) {
        setError(updateError.message)
      } else {
        await refreshProfile()
        setShowSuccessToast(true)
        setTimeout(() => {
          router.push('/profile')
        }, 1000)
      }
    } catch {
      setError('Failed to save changes')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="app-page safe-top safe-bottom flex flex-col relative">
      <div className="app-header px-6 pt-14 pb-4 flex items-center justify-between">
        <button
          onClick={() => router.back()}
          className="w-10 h-10 rounded-full bg-surface-secondary flex items-center justify-center"
          data-testid="edit-profile-back"
        >
          <ArrowLeft className="w-5 h-5 text-content-primary" strokeWidth={1.5} />
        </button>
        <h2 className="text-content-primary">Edit Profile</h2>
        <button
          onClick={handleSave}
          disabled={!canSave}
          className="text-base text-content-primary disabled:opacity-30 transition-opacity"
          data-testid="edit-profile-save"
        >
          {saving ? 'Saving...' : 'Save'}
        </button>
      </div>

      {error && (
        <div className="px-6 pt-4">
          <Alert variant="error" dismissible onDismiss={() => setError(null)}>
            {error}
          </Alert>
        </div>
      )}

      <div className="flex-1 overflow-y-auto">
        <div className="px-6 py-8 flex justify-center border-b border-border-secondary">
          <button
            onClick={() => setShowPhotoSheet(true)}
            className="relative group"
            disabled={uploading}
          >
            <div className="w-24 h-24 rounded-full bg-content-primary flex items-center justify-center text-content-inverse text-2xl overflow-hidden">
              {resolvedAvatar ? (
                <img
                  src={resolvedAvatar}
                  alt="Profile"
                  className="w-full h-full object-cover"
                />
              ) : (
                currentInitials
              )}
            </div>
            <div className="absolute inset-0 rounded-full bg-black/40 flex items-center justify-center opacity-0 group-active:opacity-100 transition-opacity">
              {uploading ? (
                <LoadingDots size="md" className="text-content-inverse" />
              ) : (
                <Camera className="w-6 h-6 text-white" strokeWidth={1.5} />
              )}
            </div>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleAvatarChange}
            className="hidden"
            data-testid="edit-profile-avatar-input"
          />
        </div>

        <div className="divide-y divide-border-secondary">
          <div className="px-6 py-4">
            <label className="block mb-2 text-sm text-content-secondary">
              Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name"
              className="w-full text-base text-content-primary bg-transparent outline-none placeholder:text-content-tertiary"
              data-testid="edit-profile-name"
            />
          </div>

          <div className="px-6 py-4">
            <label className="block mb-2 text-sm text-content-secondary">
              Username
            </label>
            <div className="flex items-center gap-1">
              <span className="text-base text-content-secondary">@</span>
              <input
                type="text"
                value={username}
                onChange={(e) => handleUsernameChange(e.target.value.replace(/^@/, ''))}
                placeholder="username"
                className="flex-1 text-base text-content-primary bg-transparent outline-none placeholder:text-content-tertiary"
                data-testid="edit-profile-username"
              />
            </div>
            {usernameError ? (
              <p className="mt-2 text-xs text-error">{usernameError}</p>
            ) : checkingUsername ? (
              <p className="mt-2 text-xs text-content-tertiary">Checking...</p>
            ) : null}
          </div>

          <div className="px-6 py-4">
            <label className="block mb-2 text-sm text-content-secondary">
              Bio
            </label>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Tell people a bit about yourself"
              rows={3}
              maxLength={150}
              className="w-full text-base text-content-primary bg-transparent outline-none placeholder:text-content-tertiary resize-none"
              data-testid="edit-profile-bio"
            />
            <p className="mt-2 text-xs text-content-tertiary text-right">
              {bio.length}/150
            </p>
          </div>

          <div className="px-6 py-4">
            <label className="block mb-2 text-sm text-content-secondary">
              Location
            </label>
            <button
              onClick={() => setShowLocationSheet(true)}
              className="w-full text-left text-base text-content-primary"
              data-testid="edit-profile-location"
            >
              {location || <span className="text-content-tertiary">Add location</span>}
            </button>
          </div>

          {isUniversityVerified && (
            <div className="px-6 py-4 space-y-4">
              <div>
                <label className="block mb-1 text-sm text-content-secondary">
                  University on profile
                </label>
                <p className="text-xs text-content-tertiary">
                  {universityDisplayName
                    ? universityDisplayName
                    : 'Verified university'}
                </p>
              </div>

              <button
                type="button"
                onClick={toggleShowUniversity}
                className="w-full p-4 rounded-xl border border-border-secondary text-left"
                data-testid="edit-profile-show-university"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-surface-secondary flex items-center justify-center">
                      <School className="w-5 h-5 text-content-primary" strokeWidth={1.5} />
                    </div>
                    <div>
                      <h4 className="text-content-primary">Show university</h4>
                      <p className="text-sm text-content-secondary">Display your verified university on your public profile</p>
                    </div>
                  </div>
                  <div className={`w-11 h-6 rounded-full transition-colors ${showUniversity ? 'bg-content-primary' : 'bg-surface-tertiary'}`}>
                    <div className={`w-5 h-5 bg-surface-primary rounded-full shadow-sm transition-transform ${showUniversity ? 'translate-x-5' : 'translate-x-0.5'} translate-y-0.5`} />
                  </div>
                </div>
              </button>

              {hasSubdivisionOptions && (
                <button
                  type="button"
                  onClick={toggleShowCollege}
                  disabled={!showUniversity || !collegeName}
                  className={`w-full p-4 rounded-xl border text-left ${showUniversity && collegeName ? 'border-border-secondary' : 'border-border-secondary opacity-60 cursor-not-allowed'}`}
                  data-testid="edit-profile-show-college"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-surface-secondary flex items-center justify-center">
                        <Building2 className="w-5 h-5 text-content-primary" strokeWidth={1.5} />
                      </div>
                      <div>
                        <h4 className="text-content-primary">Show college</h4>
                        <p className="text-sm text-content-secondary">
                          {collegeName
                            ? `Add "${collegeName}" to your profile`
                            : 'Select your college first in Safety & Verification'}
                        </p>
                      </div>
                    </div>
                    <div className={`w-11 h-6 rounded-full transition-colors ${showCollege ? 'bg-content-primary' : 'bg-surface-tertiary'}`}>
                      <div className={`w-5 h-5 bg-surface-primary rounded-full shadow-sm transition-transform ${showCollege ? 'translate-x-5' : 'translate-x-0.5'} translate-y-0.5`} />
                    </div>
                  </div>
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      <BottomSheet isOpen={showPhotoSheet} onClose={() => setShowPhotoSheet(false)}>
        <div className="px-6 py-6">
          <h3 className="mb-6 text-center text-content-primary">Profile Photo</h3>
          <div className="space-y-3">
            <button
              className="w-full py-4 text-center text-base text-content-primary border-b border-border-secondary"
              onClick={() => {
                setShowPhotoSheet(false)
                fileInputRef.current?.click()
              }}
            >
              Choose photo
            </button>
            <button
              className="w-full py-4 text-center text-base text-red-500"
              onClick={handleRemoveAvatar}
            >
              Remove
            </button>
            <button
              onClick={() => setShowPhotoSheet(false)}
              className="w-full py-4 text-center text-base text-content-secondary"
            >
              Cancel
            </button>
          </div>
        </div>
      </BottomSheet>

      <BottomSheet isOpen={showLocationSheet} onClose={() => setShowLocationSheet(false)}>
        <div className="px-6 py-6">
          <h3 className="mb-6 text-center text-content-primary">Select Location</h3>
          <div className="space-y-1 max-h-96 overflow-y-auto">
            {LOCATION_OPTIONS.map((loc) => (
              <button
                key={loc}
                onClick={() => {
                  setLocation(loc)
                  setShowLocationSheet(false)
                }}
                className={`w-full py-4 px-4 text-left text-base rounded-lg transition-colors ${
                  location === loc
                    ? 'bg-surface-secondary text-content-primary'
                    : 'text-content-secondary active:bg-surface-secondary'
                }`}
              >
                {loc}
              </button>
            ))}
          </div>
        </div>
      </BottomSheet>

      {showSuccessToast && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 px-6 py-3 rounded-full bg-content-primary text-content-inverse shadow-lg z-50">
          <p className="text-sm">Saved</p>
        </div>
      )}
    </div>
  )
}

export default function EditProfilePage() {
  const { user, profile, loading, initialized, profileLoaded, updateProfile, refreshProfile } = useAuth()
  const router = useRouter()
  const [redirecting, setRedirecting] = useState(false)

  useEffect(() => {
    if (!initialized || loading || !profileLoaded) return
    if (!user) {
      setRedirecting(true)
      router.replace('/')
      return
    }
    if (!profile) {
      setRedirecting(true)
      router.replace('/onboarding')
    }
  }, [initialized, loading, profileLoaded, user, profile, router])

  if (!initialized || loading || !profileLoaded || redirecting) {
    return <LoadingScreen />
  }

  if (!user) {
    return <LoadingScreen />
  }

  if (!profile) {
    return <LoadingScreen />
  }

  return (
    <EditProfileForm
      userId={user.id}
      initialProfile={profile}
      updateProfile={updateProfile}
      refreshProfile={refreshProfile}
    />
  )
}
