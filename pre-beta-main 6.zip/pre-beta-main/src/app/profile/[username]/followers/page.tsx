'use client'

import { FollowListPage } from '@/components/screens/FollowListPage'

export default function ProfileFollowersPage() {
  return <FollowListPage mode="followers" />
}
