'use client'

import { useRouter } from 'next/navigation'
import { useEffect } from 'react'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'

export default function SafetyPage() {
  const { user, loading, initialized } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!initialized || loading) return
    if (!user) {
      router.replace('/')
      return
    }
    router.replace('/settings/safety-verification')
  }, [initialized, loading, user, router])

  return <LoadingScreen />
}
