import 'server-only'

import type { SupabaseClient } from '@supabase/supabase-js'
import type { Database } from '@/types/database'
import { normalizeInviteEmail } from '@/lib/invites'
import { logServerError } from '@/lib/security/api'

type AdminClient = SupabaseClient<Database>

type ReconcileParams = {
  admin: AdminClient
  inviterId: string
  requestId: string
}

type PendingInvite = Pick<
  Database['public']['Tables']['access_invites']['Row'],
  'id' | 'inviter_id' | 'invite_code' | 'invitee_email' | 'status' | 'created_at'
>

type ProfileMatch = Pick<
  Database['public']['Tables']['profiles']['Row'],
  'id' | 'email' | 'created_at'
>

type ReferralMatch = Pick<
  Database['public']['Tables']['referrals']['Row'],
  'id' | 'code' | 'referred_id' | 'completed_at'
>

function toAnonymizedMemberLabel(userId: string) {
  return `Member ${userId.slice(0, 6).toUpperCase()}`
}

export async function reconcileInvitesForInviter({
  admin,
  inviterId,
  requestId,
}: ReconcileParams) {
  const db = admin as any

  const { data: pendingInvites, error: pendingError } = await db
    .from('access_invites')
    .select('id,inviter_id,invite_code,invitee_email,status,created_at')
    .eq('inviter_id', inviterId)
    .eq('status', 'pending')

  if (pendingError) {
    logServerError('invites.reconcile.pending_lookup', requestId, pendingError, { inviterId })
    return { reconciledCount: 0 }
  }

  const invites = (pendingInvites ?? []) as PendingInvite[]
  if (!invites.length) {
    return { reconciledCount: 0 }
  }

  const pendingEmails = Array.from(
    new Set(
      invites
        .map((invite) => normalizeInviteEmail(invite.invitee_email ?? ''))
        .filter(Boolean)
    )
  )

  const pendingCodes = Array.from(new Set(invites.map((invite) => invite.invite_code)))

  const profileByEmail = new Map<string, ProfileMatch>()
  if (pendingEmails.length) {
    const { data: profileMatches, error: profileError } = await db
      .from('profiles')
      .select('id,email,created_at')
      .in('email', pendingEmails)

    if (profileError) {
      logServerError('invites.reconcile.profile_lookup', requestId, profileError, { inviterId })
    } else {
      for (const profile of (profileMatches ?? []) as ProfileMatch[]) {
        const normalized = normalizeInviteEmail(profile.email ?? '')
        if (normalized) profileByEmail.set(normalized, profile)
      }
    }
  }

  const referralByCode = new Map<string, ReferralMatch>()
  if (pendingCodes.length) {
    const { data: referralMatches, error: referralError } = await db
      .from('referrals')
      .select('id,code,referred_id,completed_at')
      .eq('referrer_id', inviterId)
      .eq('status', 'completed')
      .in('code', pendingCodes)

    if (referralError) {
      logServerError('invites.reconcile.referral_lookup', requestId, referralError, { inviterId })
    } else {
      for (const referral of (referralMatches ?? []) as ReferralMatch[]) {
        if (referral.code) referralByCode.set(referral.code, referral)
      }
    }
  }

  let reconciledCount = 0

  for (const invite of invites) {
    const normalizedInviteEmail = normalizeInviteEmail(invite.invitee_email ?? '')
    const matchedProfile = normalizedInviteEmail
      ? profileByEmail.get(normalizedInviteEmail) ?? null
      : null
    const matchedReferral = referralByCode.get(invite.invite_code) ?? null

    const acceptedUserId = matchedProfile?.id ?? matchedReferral?.referred_id ?? null
    if (!acceptedUserId) {
      continue
    }

    const acceptedAt =
      matchedReferral?.completed_at ??
      matchedProfile?.created_at ??
      new Date().toISOString()

    const { data: updatedInvite, error: updateError } = await db
      .from('access_invites')
      .update({
        status: 'accepted',
        accepted_user_id: acceptedUserId,
        accepted_at: acceptedAt,
        updated_at: new Date().toISOString(),
      })
      .eq('id', invite.id)
      .eq('status', 'pending')
      .select('id,invite_code,accepted_user_id')
      .maybeSingle()

    if (updateError) {
      logServerError('invites.reconcile.invite_update', requestId, updateError, {
        inviterId,
        inviteId: invite.id,
      })
      continue
    }

    if (!updatedInvite) {
      continue
    }

    reconciledCount += 1

    const { data: existingReferral, error: existingReferralError } = await db
      .from('referrals')
      .select('id')
      .eq('referrer_id', inviterId)
      .eq('referred_id', acceptedUserId)
      .maybeSingle()

    if (existingReferralError) {
      logServerError('invites.reconcile.referral_existing', requestId, existingReferralError, {
        inviterId,
        inviteId: invite.id,
        acceptedUserId,
      })
      continue
    }

    if (!existingReferral) {
      const { error: insertReferralError } = await db.from('referrals').insert({
        referrer_id: inviterId,
        referred_id: acceptedUserId,
        code: invite.invite_code,
        status: 'completed',
        completed_at: acceptedAt,
      })

      if (insertReferralError) {
        logServerError('invites.reconcile.referral_insert', requestId, insertReferralError, {
          inviterId,
          inviteId: invite.id,
          acceptedUserId,
        })
      }
    }
  }

  return { reconciledCount }
}

export function buildAcceptedMemberLabel({
  acceptedUserId,
  username,
}: {
  acceptedUserId: string
  username: string | null
}) {
  if (username) return `@${username}`
  return toAnonymizedMemberLabel(acceptedUserId)
}
