import { randomBytes } from 'crypto'

export const MAX_ACTIVE_INVITES = 5

type InviteQuotaInput = {
  isFounder?: boolean | null
  refreshCount?: number | null
}

export function normalizeInviteCode(value: string): string {
  return value.trim().toUpperCase().replace(/[^A-Z0-9]/g, '')
}

export function normalizeInviteEmail(value: string): string {
  return value.trim().toLowerCase()
}

export function generateInviteCode(length = 10): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  const bytes = randomBytes(length)
  let code = ''
  for (let i = 0; i < length; i += 1) {
    code += chars[bytes[i] % chars.length]
  }
  return code
}

export function getInviteRefreshCount(value: number | null | undefined): number {
  if (!Number.isFinite(value)) return 0
  return Math.max(0, Math.floor(value as number))
}

export function getInviteLimit({ isFounder, refreshCount }: InviteQuotaInput): number | null {
  if (isFounder) return null
  return MAX_ACTIVE_INVITES * (getInviteRefreshCount(refreshCount) + 1)
}

export function getRemainingInviteSlots({
  isFounder,
  refreshCount,
  usedNominations,
}: InviteQuotaInput & { usedNominations: number }): number | null {
  const limit = getInviteLimit({ isFounder, refreshCount })
  if (limit === null) return null
  return Math.max(0, limit - Math.max(0, usedNominations))
}
