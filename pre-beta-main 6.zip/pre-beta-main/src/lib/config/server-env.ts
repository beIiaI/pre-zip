import 'server-only'

type RequiredServerEnvKey =
  | 'NEXT_PUBLIC_SITE_URL'
  | 'SUPABASE_SERVICE_ROLE_KEY'
  | 'RESEND_API_KEY'
  | 'EMAIL_FROM'

const REQUIRED_SERVER_ENV_KEYS: RequiredServerEnvKey[] = [
  'NEXT_PUBLIC_SITE_URL',
  'SUPABASE_SERVICE_ROLE_KEY',
  'RESEND_API_KEY',
  'EMAIL_FROM',
]

export function getServerEnvStatus() {
  return REQUIRED_SERVER_ENV_KEYS.reduce<Record<RequiredServerEnvKey, boolean>>((acc, key) => {
    acc[key] = Boolean(process.env[key])
    return acc
  }, {} as Record<RequiredServerEnvKey, boolean>)
}

export function getMissingServerEnv() {
  return REQUIRED_SERVER_ENV_KEYS.filter((key) => !process.env[key])
}

export function assertServerEnv(options?: { throwOnMissing?: boolean }) {
  const missing = getMissingServerEnv()
  if (missing.length === 0) {
    return
  }

  const message = `Missing required server environment variables: ${missing.join(', ')}`
  if (options?.throwOnMissing) {
    throw new Error(message)
  }

  console.warn(`[config.env] ${message}`)
}

export type { RequiredServerEnvKey }
