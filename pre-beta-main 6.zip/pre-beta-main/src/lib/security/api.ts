import crypto from 'crypto'
import { NextResponse } from 'next/server'

type ErrorLogMeta = Record<string, unknown>

export function createRequestId(): string {
  return crypto.randomUUID()
}

export function sanitizeErrorForLog(error: unknown) {
  if (error instanceof Error) {
    return {
      name: error.name,
      message: error.message,
      stack: error.stack,
    }
  }

  return { message: String(error) }
}

export function logServerError(
  scope: string,
  requestId: string,
  error: unknown,
  meta?: ErrorLogMeta
) {
  const safeError = sanitizeErrorForLog(error)
  if (meta) {
    console.error(`[${scope}] request_id=${requestId}`, { ...meta, error: safeError })
    return
  }
  console.error(`[${scope}] request_id=${requestId}`, safeError)
}

export function errorResponse(
  requestId: string,
  status = 500,
  message = 'Something went wrong',
  code = 'internal_error'
) {
  return NextResponse.json(
    {
      error: message,
      code,
      requestId,
    },
    {
      status,
      headers: {
        'x-request-id': requestId,
      },
    }
  )
}

export function successResponse<T>(requestId: string, payload: T, status = 200) {
  return NextResponse.json(payload, {
    status,
    headers: {
      'x-request-id': requestId,
    },
  })
}

