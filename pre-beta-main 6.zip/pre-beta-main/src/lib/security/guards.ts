import { NextResponse } from 'next/server'
import { errorResponse } from '@/lib/security/api'
import { isAllowedOrigin } from '@/lib/security/origin'
import { rateLimit, resolveRateLimitIdentity } from '@/lib/security/rate-limit'

type RateLimitOptions = {
  namespace: string
  request: Request
  requestId: string
  userId?: string | null
  email?: string | null
  limit: number
  windowMs: number
  baseBlockMs?: number
}

export function enforceSameOrigin(request: Request, requestId: string) {
  if (isAllowedOrigin(request)) return null
  return errorResponse(requestId, 403, 'Something went wrong', 'origin_not_allowed')
}

export function enforceRateLimit(options: RateLimitOptions) {
  const identity = resolveRateLimitIdentity(options.request, {
    userId: options.userId,
    email: options.email,
  })
  const key = `${options.namespace}:${identity}`
  const result = rateLimit({
    key,
    limit: options.limit,
    windowMs: options.windowMs,
    baseBlockMs: options.baseBlockMs,
  })

  if (result.ok) {
    return null
  }

  const response = errorResponse(
    options.requestId,
    429,
    'Too many requests. Please try again shortly.',
    'rate_limited'
  )
  response.headers.set('retry-after', String(Math.max(1, Math.ceil(result.retryAfterMs / 1000))))
  return response
}

export function unauthorized(requestId: string) {
  return errorResponse(requestId, 401, 'Unauthorized', 'unauthorized')
}

export function forbidden(requestId: string) {
  return errorResponse(requestId, 403, 'Forbidden', 'forbidden')
}

export function badRequest(requestId: string, message = 'Invalid request') {
  return errorResponse(requestId, 400, message, 'bad_request')
}

export function notFound(requestId: string, message = 'Not found') {
  return errorResponse(requestId, 404, message, 'not_found')
}

export function conflict(requestId: string, message = 'Conflict') {
  return errorResponse(requestId, 409, message, 'conflict')
}

export function validationFailed(requestId: string, message = 'Invalid request') {
  return errorResponse(requestId, 400, message, 'validation_failed')
}

export function serverFailure(requestId: string) {
  return errorResponse(requestId, 500, 'Something went wrong', 'internal_error')
}

export function created(requestId: string, payload: unknown) {
  return NextResponse.json(payload, {
    status: 201,
    headers: {
      'x-request-id': requestId,
    },
  })
}

