type PasswordPolicyOptions = {
  email?: string | null
}

type PasswordPolicyResult = {
  valid: boolean
  error?: string
  reasons: string[]
}

const BRAND_BLOCKLIST = ['pre', 'presocial', 'password123']

const COMMON_PASSWORD_ROOTS = [
  'password',
  'qwerty',
  'admin',
  'welcome',
  'letmein',
  'monkey',
  'dragon',
  'football',
  'baseball',
  'iloveyou',
  'master',
  'shadow',
  'sunshine',
  'princess',
  'trustno1',
  'superman',
  'batman',
  'freedom',
  'whatever',
  'mustang',
  'charlie',
  'hello',
  'jordan',
  'jennifer',
  'michelle',
  'thomas',
  'pepper',
  'cookie',
  'computer',
  'internet',
  'andrew',
  'michael',
  'summer',
  'winter',
  'spring',
  'autumn',
  'default',
  'secret',
  'matrix',
  'linkedin',
  'facebook',
  'instagram',
  'google',
  'apple',
  'samsung',
  'pokemon',
  'naruto',
  'starwars',
  'liverpool',
  'arsenal',
  'chelsea',
  'manutd',
  'hockey',
  'soccer',
  'basketball',
  'passw0rd',
  'p@ssword',
  'qwertyuiop',
  'asdfgh',
  'zxcvbn',
  'abc123',
  '111111',
  '222222',
  '333333',
  '444444',
  '555555',
  '666666',
  '777777',
  '888888',
  '999999',
  '000000',
  'love',
  'money',
  'killer',
  'hunter',
  'flower',
  'donald',
  'daniel',
  'tigger',
  'buster',
  'harley',
  'ginger',
  'jessica',
  'nicole',
  'access',
  'qazwsx',
  'zaq12wsx',
  '1q2w3e',
  '1qaz2wsx',
  'hello123',
  'changeme',
]

const COMMON_PASSWORD_EXPLICIT = [
  '123456',
  '1234567',
  '12345678',
  '123456789',
  '1234567890',
  'qwerty123',
  'qwerty1',
  'password1',
  'password12',
  'password123',
  'admin123',
  'letmein123',
  'welcome123',
  'iloveyou123',
  'abc123456',
  'qwe123',
  '987654321',
  '123123123',
  '1q2w3e4r5t',
  'aa123456',
  'pass1234',
  'test1234',
  'changeme123',
  'root',
  'toor',
  'guest',
  'login',
  'administrator',
  'company123',
  'secret123',
]

const COMMON_PASSWORD_SET = (() => {
  const set = new Set<string>()
  for (const value of COMMON_PASSWORD_EXPLICIT) {
    set.add(value)
  }

  const numericSuffixes = [
    '',
    '1',
    '12',
    '123',
    '1234',
    '12345',
    '123456',
    '1234567',
    '12345678',
    '123456789',
    '0',
    '01',
    '007',
    '69',
    '99',
    '2020',
    '2021',
    '2022',
    '2023',
    '2024',
    '2025',
    '2026',
    '2027',
    '2028',
    '2029',
    '2030',
    '!',
    '@',
    '#',
    '!@#',
  ]

  for (const root of COMMON_PASSWORD_ROOTS) {
    const normalizedRoot = root.toLowerCase()
    set.add(normalizedRoot)

    for (const suffix of numericSuffixes) {
      set.add(`${normalizedRoot}${suffix}`)
    }

    for (let i = 0; i < 120; i += 1) {
      set.add(`${normalizedRoot}${i}`)
    }
  }

  return set
})()

const normalizePassword = (value: string) => value.trim().toLowerCase()
const alphaNumericOnly = (value: string) => value.replace(/[^a-z0-9]/g, '')

function looksSequential(value: string) {
  const lower = value.toLowerCase()
  return (
    lower.includes('12345') ||
    lower.includes('54321') ||
    lower.includes('qwerty') ||
    lower.includes('asdfg') ||
    lower.includes('zxcvb')
  )
}

export function isCommonPassword(password: string, email?: string | null): boolean {
  const normalized = normalizePassword(password)
  const simple = alphaNumericOnly(normalized)

  if (COMMON_PASSWORD_SET.has(normalized) || COMMON_PASSWORD_SET.has(simple)) {
    return true
  }

  if (looksSequential(normalized)) {
    return true
  }

  const repeated = /(.)\1{3,}/.test(normalized)
  if (repeated) {
    return true
  }

  const lowerEmail = (email ?? '').trim().toLowerCase()
  if (lowerEmail.includes('@')) {
    const [local] = lowerEmail.split('@')
    if (local && (normalized === local || simple === alphaNumericOnly(local))) {
      return true
    }
  }

  for (const term of BRAND_BLOCKLIST) {
    if (simple.includes(alphaNumericOnly(term))) {
      return true
    }
  }

  return false
}

export function getPasswordChecks(password: string, email?: string | null) {
  return {
    length: password.length >= 8,
    lower: /[a-z]/.test(password),
    upper: /[A-Z]/.test(password),
    number: /[0-9]/.test(password),
    symbol: /[^A-Za-z0-9]/.test(password),
    common: !isCommonPassword(password, email),
  }
}

export function validatePasswordPolicy(
  password: string,
  options?: PasswordPolicyOptions
): PasswordPolicyResult {
  const checks = getPasswordChecks(password, options?.email)
  const reasons: string[] = []

  if (!checks.length) reasons.push('Password must be at least 8 characters.')
  if (!checks.lower) reasons.push('Password must include a lowercase letter.')
  if (!checks.upper) reasons.push('Password must include an uppercase letter.')
  if (!checks.number) reasons.push('Password must include a number.')
  if (!checks.symbol) reasons.push('Password must include a symbol.')
  if (!checks.common) {
    reasons.push('Password is too common or easy to guess.')
  }

  if (reasons.length === 0) {
    return { valid: true, reasons: [] }
  }

  return {
    valid: false,
    error: reasons[0],
    reasons,
  }
}

