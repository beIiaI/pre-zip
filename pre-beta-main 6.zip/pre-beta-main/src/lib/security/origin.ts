const parseOrigin = (value: string | null | undefined): string | null => {
  if (!value) return null
  try {
    return new URL(value).origin
  } catch {
    return null
  }
}

const getAllowedOrigins = (request: Request) => {
  const allowed = new Set<string>()

  const requestOrigin = parseOrigin(request.url)
  if (requestOrigin) {
    allowed.add(requestOrigin)
  }

  const siteOrigin = parseOrigin(process.env.NEXT_PUBLIC_SITE_URL)
  if (siteOrigin) {
    allowed.add(siteOrigin)
  }

  const appOrigin = parseOrigin(process.env.NEXT_PUBLIC_APP_URL)
  if (appOrigin) {
    allowed.add(appOrigin)
  }

  if (process.env.NODE_ENV !== 'production') {
    allowed.add('http://localhost:3000')
    allowed.add('http://127.0.0.1:3000')
  }

  return allowed
}

export function isAllowedOrigin(request: Request): boolean {
  const originHeader = request.headers.get('origin')
  if (!originHeader) {
    return true
  }

  const origin = parseOrigin(originHeader)
  if (!origin) return false

  const allowed = getAllowedOrigins(request)
  return allowed.has(origin)
}

