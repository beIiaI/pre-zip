import 'server-only'

import fs from 'fs'
import path from 'path'
import { RESERVED_WORDS, getNormalizedVariants } from './restrictedWordsShared'

interface WordIndex {
  exact: Set<string>
  highRisk: string[]
}

let cachedIndexWithReserved: WordIndex | null = null
let cachedIndexWithoutReserved: WordIndex | null = null

const LIST_DIR = path.join(process.cwd(), 'src/data/restricted-words')
const IGNORED_FILES = new Set(['README.md', 'LICENSE', 'USERS.md'])

function buildIndex(includeReserved: boolean): WordIndex {
  const exact = new Set<string>()
  const highRisk = new Set<string>()

  const addWord = (word: string, isHighRisk: boolean) => {
    if (!word) return
    const variants = getNormalizedVariants(word)
    const allVariants = [
      variants.base,
      variants.joined,
      ...variants.leet,
      ...variants.joinedLeet,
    ].filter(Boolean)

    for (const variant of allVariants) {
      exact.add(variant)
    }

    if (isHighRisk) {
      const highRiskVariants = [variants.joined, ...variants.joinedLeet].filter(Boolean)
      for (const variant of highRiskVariants) {
        if (variant.length >= 3) {
          highRisk.add(variant)
        }
      }
    }
  }

  const entries = fs.readdirSync(LIST_DIR, { withFileTypes: true })
  for (const entry of entries) {
    if (!entry.isFile()) continue
    if (IGNORED_FILES.has(entry.name)) continue
    const isEnglish = entry.name === 'en'
    const content = fs.readFileSync(path.join(LIST_DIR, entry.name), 'utf8')
    const words = content.split(/\r?\n/).map(line => line.trim()).filter(Boolean)
    for (const word of words) {
      addWord(word, isEnglish)
    }
  }

  if (includeReserved) {
    for (const word of RESERVED_WORDS) {
      addWord(word, true)
    }
  }

  return { exact, highRisk: Array.from(highRisk) }
}

function getIndex(includeReserved: boolean): WordIndex {
  if (includeReserved) {
    if (!cachedIndexWithReserved) {
      cachedIndexWithReserved = buildIndex(true)
    }
    return cachedIndexWithReserved
  }
  if (!cachedIndexWithoutReserved) {
    cachedIndexWithoutReserved = buildIndex(false)
  }
  return cachedIndexWithoutReserved
}

function isRestricted(value: string, includeReserved: boolean, checkSubstrings = true): boolean {
  if (!value || !value.trim()) return false
  const { exact, highRisk } = getIndex(includeReserved)
  const variants = getNormalizedVariants(value)
  const exactCandidates = [
    variants.base,
    variants.joined,
    ...variants.leet,
    ...variants.joinedLeet,
  ].filter(Boolean)

  if (exactCandidates.some(candidate => exact.has(candidate))) {
    return true
  }

  if (checkSubstrings) {
    const joinedCandidates = [variants.joined, ...variants.joinedLeet].filter(Boolean)
    for (const candidate of joinedCandidates) {
      for (const word of highRisk) {
        if (candidate.includes(word)) {
          return true
        }
      }
    }
  }

  return false
}

export function isRestrictedUsername(value: string): boolean {
  return isRestricted(value, true)
}

export function isRestrictedDisplayName(value: string): boolean {
  // Display names allow spaces, so joining strips them and creates false positives
  // (e.g. "Hassan Ahmed" → "hassanahmed" contains "ass").
  // Use exact-match-only: no substring scan on the joined form.
  return isRestricted(value, true, false)
}

export function isRestrictedBio(value: string): boolean {
  return isRestricted(value, false)
}
