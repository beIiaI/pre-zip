const CONSUMER_DOMAINS = new Set([
  'gmail.com',
  'googlemail.com',
  'yahoo.com',
  'yahoo.co.uk',
  'outlook.com',
  'hotmail.com',
  'live.com',
  'msn.com',
  'icloud.com',
  'me.com',
  'mac.com',
  'aol.com',
  'proton.me',
  'protonmail.com',
  'pm.me',
  'fastmail.com',
  'hey.com',
  'zoho.com',
  'gmx.com',
  'gmx.net',
  'mail.com',
])

export function isConsumerDomain(domain: string): boolean {
  return CONSUMER_DOMAINS.has(domain.toLowerCase())
}

export function deriveSchoolName(domain: string): string {
  const normalized = domain.toLowerCase().trim()
  const parts = normalized.split('.').filter(Boolean)
  if (parts.length === 0) return normalized
  const base = parts.length > 2 ? parts[parts.length - 2] : parts[0]
  return base
    .replace(/-/g, ' ')
    .split(' ')
    .map((word) => (word ? word[0].toUpperCase() + word.slice(1) : ''))
    .join(' ')
}

export function isUniversityOfTorontoDomain(domain: string | null | undefined): boolean {
  if (!domain) return false
  const normalized = domain.toLowerCase().trim()
  return normalized === 'utoronto.ca' || normalized.endsWith('.utoronto.ca')
}

export function getNormalizedUniversityName(
  domain: string | null | undefined,
  schoolName: string | null | undefined
): string | null {
  if (isUniversityOfTorontoDomain(domain)) {
    return 'University of Toronto'
  }

  const trimmedSchoolName = schoolName?.trim()
  if (trimmedSchoolName) return trimmedSchoolName

  const trimmedDomain = domain?.trim()
  if (!trimmedDomain) return null
  return deriveSchoolName(trimmedDomain)
}

function normalizeText(value: string): string {
  return value.replace(/\s+/g, ' ').trim()
}

function normalizeForCompare(value: string): string {
  return normalizeText(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '')
}

function stripUniversityPrefixForCollege(value: string): string {
  const trimmed = normalizeText(value)
  if (/^university of /i.test(trimmed) && /college/i.test(trimmed)) {
    return trimmed.replace(/^university of /i, '')
  }
  return trimmed
}

export function deriveCollegeOptionsFromSwot(params: {
  domain: string
  universityName?: string | null
  schoolNames?: string[] | null
}): string[] {
  const { domain, universityName, schoolNames } = params
  if (!schoolNames || schoolNames.length === 0) return []

  const canonicalUniversity =
    getNormalizedUniversityName(domain, universityName) ?? normalizeText(universityName ?? '')
  const canonicalUniversityKey = canonicalUniversity
    ? normalizeForCompare(canonicalUniversity)
    : ''

  const seen = new Set<string>()
  const options: string[] = []

  for (const rawLine of schoolNames) {
    const line = normalizeText(rawLine)
    if (!line) continue

    const lineKey = normalizeForCompare(line)
    if (canonicalUniversityKey && lineKey === canonicalUniversityKey) {
      continue
    }

    let candidate = line
    if (line.includes(',')) {
      const [firstPart, secondPart] = line.split(',', 2).map((part) => normalizeText(part))
      if (firstPart && secondPart) {
        const secondKey = normalizeForCompare(secondPart)
        if (canonicalUniversityKey && secondKey === canonicalUniversityKey) {
          candidate = firstPart
        }
      }
    }

    candidate = stripUniversityPrefixForCollege(candidate)
    const candidateKey = normalizeForCompare(candidate)
    if (!candidate || !candidateKey || candidateKey === canonicalUniversityKey) {
      continue
    }

    const subdivisionHint =
      /college|school|campus|faculty|institute|academy|division/i.test(candidate) ||
      line.includes(',')
    if (!subdivisionHint) {
      continue
    }

    if (!seen.has(candidateKey)) {
      seen.add(candidateKey)
      options.push(candidate)
    }
  }

  if (options.length === 0) return options
  if (!options.some((item) => item.toLowerCase() === 'other / not sure')) {
    options.push('Other / Not sure')
  }
  return options
}
