import 'server-only'

import fs from 'fs'
import path from 'path'

const SWOT_ROOT = path.join(process.cwd(), 'data', 'swot', 'lib')
const ALLOWLIST_DIRS = ['domains', 'domains-edu', 'domains-gtlds', 'domains-custom']
const STOPLIST_DIR = 'domains-stoplist'
const STOPLIST_FILES = [
  path.join(SWOT_ROOT, 'domains', 'stoplist.txt'),
  path.join(SWOT_ROOT, 'domains', 'abused.txt'),
  path.join(SWOT_ROOT, 'domains-stoplist.txt'),
]

const existsCache = new Map<string, boolean>()
const schoolLinesCache = new Map<string, string[]>()
let stoplistCache: Set<string> | null = null

const dirExists = (dirPath: string) => {
  try {
    return fs.existsSync(dirPath)
  } catch {
    return false
  }
}

const fileExists = (filePath: string) => {
  const cached = existsCache.get(filePath)
  if (cached !== undefined) return cached
  let exists = false
  try {
    exists = fs.existsSync(filePath)
  } catch {
    exists = false
  }
  existsCache.set(filePath, exists)
  return exists
}

const readSchoolLines = (filePath: string): string[] => {
  const cached = schoolLinesCache.get(filePath)
  if (cached) return cached

  try {
    const content = fs.readFileSync(filePath, 'utf8')
    const lines = content
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter((line) => line.length > 0 && !line.startsWith('#'))
    schoolLinesCache.set(filePath, lines)
    return lines
  } catch {
    schoolLinesCache.set(filePath, [])
    return []
  }
}

export const extractDomain = (email: string): string | null => {
  if (!email) return null
  const atIndex = email.lastIndexOf('@')
  if (atIndex < 0) return null
  const domain = email.slice(atIndex + 1).trim().toLowerCase().replace(/\.$/, '')
  if (!domain || !domain.includes('.')) return null
  return domain
}

const buildCandidates = (domain: string): string[] => {
  const labels = domain.split('.').map((label) => label.trim()).filter(Boolean)
  if (labels.length < 2) return []
  const candidates: string[] = []
  for (let i = 0; i <= labels.length - 2; i += 1) {
    const candidate = labels.slice(i).join('.')
    if (candidate.split('.').length >= 2) {
      candidates.push(candidate)
    }
  }
  return candidates
}

const buildPaths = (rootDir: string, candidate: string): string[] => {
  const labels = candidate.split('.').filter(Boolean)
  if (labels.length < 2) return []
  const tld = labels[labels.length - 1]
  const name = labels[0]
  const mids = labels.slice(1, -1).reverse()
  const nestedPath = path.join(rootDir, tld, ...mids, `${name}.txt`)
  const flatPath = path.join(rootDir, tld, `${name}.txt`)
  if (nestedPath === flatPath) return [nestedPath]
  return [nestedPath, flatPath]
}

const loadStoplist = (): Set<string> => {
  if (stoplistCache) return stoplistCache

  const values = new Set<string>()
  for (const filePath of STOPLIST_FILES) {
    if (!fileExists(filePath)) continue
    const lines = readSchoolLines(filePath)
    for (const line of lines) {
      values.add(line.toLowerCase())
    }
  }
  stoplistCache = values
  return values
}

type SwotMatch =
  | {
      ok: true
      domain: string
      schoolName: string | null
      schoolNames: string[]
      source: string
    }
  | {
      ok: false
      reason: 'stoplisted' | 'not_found' | 'swot_missing'
    }

const findSwotMatch = (domain: string): SwotMatch => {
  if (!dirExists(SWOT_ROOT)) {
    return { ok: false, reason: 'swot_missing' }
  }

  const candidates = buildCandidates(domain)
  if (candidates.length === 0) {
    return { ok: false, reason: 'not_found' }
  }

  const stoplistEntries = loadStoplist()
  const stoplistRoot = path.join(SWOT_ROOT, STOPLIST_DIR)
  const stoplistAvailable = dirExists(stoplistRoot)

  const allowlistRoots = ALLOWLIST_DIRS
    .map((dir) => ({ dir, root: path.join(SWOT_ROOT, dir) }))
    .filter((entry) => dirExists(entry.root))

  for (const candidate of candidates) {
    if (stoplistEntries.has(candidate.toLowerCase())) {
      return { ok: false, reason: 'stoplisted' }
    }

    if (stoplistAvailable) {
      const stoplistPaths = buildPaths(stoplistRoot, candidate)
      if (stoplistPaths.some((filePath) => fileExists(filePath))) {
        return { ok: false, reason: 'stoplisted' }
      }
    }

    for (const { dir, root } of allowlistRoots) {
      const pathsToCheck = buildPaths(root, candidate)
      for (const filePath of pathsToCheck) {
        if (fileExists(filePath)) {
          const lines = readSchoolLines(filePath)
          return {
            ok: true,
            domain: candidate,
            schoolName: lines[0] ?? null,
            schoolNames: lines,
            source: dir,
          }
        }
      }
    }
  }

  return { ok: false, reason: 'not_found' }
}

export type SwotResult = {
  ok: boolean
  domain?: string
  schoolName?: string | null
  schoolNames?: string[]
  source?: string
  reason?: 'stoplisted' | 'not_found' | 'swot_missing'
}

export const isAcademicDomain = (domain: string): SwotResult => {
  const result = findSwotMatch(domain.toLowerCase().trim())
  if (!result.ok) {
    return { ok: false, reason: result.reason }
  }

  return {
    ok: true,
    domain: result.domain,
    schoolName: result.schoolName,
    schoolNames: result.schoolNames,
    source: result.source,
  }
}

export const getAcademicDomainSchools = (
  domain: string
): { ok: true; domain: string; schoolNames: string[]; schoolName: string | null } | { ok: false; reason: 'stoplisted' | 'not_found' | 'swot_missing' } => {
  const result = findSwotMatch(domain.toLowerCase().trim())
  if (!result.ok) {
    return { ok: false, reason: result.reason }
  }
  return {
    ok: true,
    domain: result.domain,
    schoolName: result.schoolName,
    schoolNames: result.schoolNames,
  }
}
