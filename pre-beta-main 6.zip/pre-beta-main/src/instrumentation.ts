import { assertServerEnv } from '@/lib/config/server-env'

export async function register() {
  assertServerEnv({ throwOnMissing: process.env.NODE_ENV === 'production' })
}
