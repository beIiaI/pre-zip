interface StatusChipProps {
  children: React.ReactNode;
  variant?: "default" | "verified" | "limited" | "waitlist";
}

export function StatusChip({ children, variant = "default" }: StatusChipProps) {
  const styles = {
    default: "bg-[#F5F5F5] dark:bg-[#2A2A2A] text-[#666666] dark:text-[#999999]",
    verified: "bg-[#C7E5FF] dark:bg-[#1A4D7A] text-[#1A1A1A] dark:text-[#C7E5FF]",
    limited: "bg-[#E8F4FF] dark:bg-[#1A3A5A] text-[#666666] dark:text-[#A8D4FF]",
    waitlist: "bg-[#F5F5F5] dark:bg-[#2A2A2A] text-[#999999] dark:text-[#888888]"
  };

  return (
    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[11px] leading-none ${styles[variant]}`}>
      {children}
    </span>
  );
}