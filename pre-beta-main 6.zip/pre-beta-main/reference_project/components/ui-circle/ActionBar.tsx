import { ReactNode } from "react";

interface ActionBarProps {
  children: ReactNode;
}

export function ActionBar({ children }: ActionBarProps) {
  return (
    <div className="fixed bottom-20 left-0 right-0 bg-white/95 backdrop-blur-sm border-t border-[#1A1A1A]/10 p-4">
      {children}
    </div>
  );
}
