import { motion } from "motion/react";
import { ReactNode } from "react";
import { X } from "lucide-react";

interface BottomSheetProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
}

export function BottomSheet({ isOpen, onClose, title, children }: BottomSheetProps) {
  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-end bg-black/20 dark:bg-black/60"
      onClick={onClose}
    >
      <motion.div
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        transition={{ type: "spring", damping: 30, stiffness: 300 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-h-[90vh] rounded-t-2xl bg-white dark:bg-[#1A1A1A] border-t border-[#1A1A1A]/10 dark:border-white/10 overflow-hidden"
      >
        {/* Handle */}
        <div className="flex justify-center pt-3 pb-2">
          <div className="w-10 h-1 rounded-full bg-[#E0E0E0] dark:bg-[#3A3A3A]" />
        </div>

        {/* Header */}
        {title && (
          <div className="px-6 py-4 border-b border-[#1A1A1A]/10 dark:border-white/10 flex items-center justify-between">
            <h2 className="text-[22px] leading-tight text-[#1A1A1A] dark:text-white">{title}</h2>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-[#F5F5F5] dark:bg-[#2A2A2A] flex items-center justify-center"
            >
              <X className="w-4 h-4 dark:text-white" strokeWidth={1.5} />
            </button>
          </div>
        )}

        {/* Content */}
        <div className="overflow-y-auto" style={{ maxHeight: title ? "calc(90vh - 120px)" : "calc(90vh - 40px)" }}>
          {children}
        </div>
      </motion.div>
    </motion.div>
  );
}