import { ReactNode } from "react";

interface NavBarProps {
  items: {
    icon: ReactNode;
    label: string;
    active?: boolean;
    onClick?: () => void;
  }[];
}

export function NavBar({ items }: NavBarProps) {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-[#FAFAFA] dark:bg-[#1A1A1A] border-t border-[#1A1A1A]/10 dark:border-white/10">
      <div className="flex items-center justify-around px-6 py-3 bg-[rgba(0,0,0,0.9)]">
        {items.map((item, index) => (
          <button
            key={index}
            onClick={item.onClick}
            className="flex flex-col items-center gap-1 py-2 px-4 min-w-[64px]"
          >
            <div className={item.active ? "text-[#1A1A1A] dark:text-white" : "text-[#CCCCCC] dark:text-[#555555]"}>
              {item.icon}
            </div>
            <span className={`text-[10px] ${item.active ? "text-[#1A1A1A] dark:text-white" : "text-[#CCCCCC] dark:text-[#555555]"}`}>
              {item.label}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}