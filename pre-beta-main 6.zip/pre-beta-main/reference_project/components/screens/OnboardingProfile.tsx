import { useState, useEffect } from "react";
import { ChevronLeft, Check } from "lucide-react";
import { Button } from "../ui-circle/Button";
import { useTheme } from "../ThemeContext";

interface OnboardingProfileProps {
  onContinue: (data: { name: string; username: string }) => void;
  onBack: () => void;
}

export function OnboardingProfile({ onContinue, onBack }: OnboardingProfileProps) {
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [nameError, setNameError] = useState("");
  const [usernameError, setUsernameError] = useState("");
  const [isCheckingUsername, setIsCheckingUsername] = useState(false);
  const [isUsernameAvailable, setIsUsernameAvailable] = useState<boolean | null>(null);
  const { getBackgroundClass } = useTheme();

  // Mock taken usernames for demo
  const takenUsernames = ["devansh", "john", "sarah", "alex", "jordan", "test", "user", "admin"];

  // Validate name
  const validateName = (value: string): { isValid: boolean; error?: string } => {
    if (!value.trim()) {
      return { isValid: false, error: "Please enter your name." };
    }
    if (value.trim().length < 2) {
      return { isValid: false, error: "Please enter your name." };
    }
    return { isValid: true };
  };

  // Validate username format
  const validateUsername = (value: string): { isValid: boolean; error?: string; warnings?: string[] } => {
    if (!value) {
      return { isValid: false, error: "Username is required." };
    }
    
    if (value.length < 3 || value.length > 20) {
      return { isValid: false, error: "Username must be 3–20 characters." };
    }
    
    if (!/^[a-z0-9_]+$/.test(value)) {
      return { isValid: false, error: "Only letters, numbers, and underscores." };
    }
    
    if (!/^[a-z]/.test(value)) {
      return { isValid: false, error: "Username must start with a letter." };
    }
    
    return { isValid: true };
  };

  // Check username availability
  const checkAvailability = async (value: string) => {
    const validation = validateUsername(value);
    if (!validation.isValid) {
      setIsUsernameAvailable(null);
      return;
    }

    setIsCheckingUsername(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 400));

    const isTaken = takenUsernames.includes(value.toLowerCase());
    setIsUsernameAvailable(!isTaken);
    setIsCheckingUsername(false);

    if (isTaken) {
      setUsernameError("That username is taken.");
    }
  };

  // Debounce username check
  useEffect(() => {
    if (!username) {
      setIsUsernameAvailable(null);
      setIsCheckingUsername(false);
      return;
    }

    const validation = validateUsername(username);
    if (!validation.isValid) {
      setIsUsernameAvailable(null);
      setIsCheckingUsername(false);
      return;
    }

    const timer = setTimeout(() => {
      checkAvailability(username);
    }, 500);

    return () => clearTimeout(timer);
  }, [username]);

  const handleNameChange = (value: string) => {
    setName(value);
    if (nameError) {
      setNameError("");
    }
  };

  const handleUsernameChange = (value: string) => {
    // Force lowercase and remove invalid characters as user types
    const cleaned = value.toLowerCase().replace(/[^a-z0-9_]/g, "");
    setUsername(cleaned);
    
    if (usernameError) {
      setUsernameError("");
    }
  };

  const handleContinue = () => {
    // Validate name
    const nameValidation = validateName(name);
    if (!nameValidation.isValid) {
      setNameError(nameValidation.error || "");
      return;
    }

    // Validate username
    const usernameValidation = validateUsername(username);
    if (!usernameValidation.isValid) {
      setUsernameError(usernameValidation.error || "");
      return;
    }

    // Check availability
    if (isUsernameAvailable === false) {
      setUsernameError("That username is taken.");
      return;
    }

    if (isUsernameAvailable !== true) {
      return;
    }

    onContinue({ name: name.trim(), username: username.toLowerCase() });
  };

  // Username validation checklist
  const usernameValidation = validateUsername(username);
  const hasMinLength = username.length >= 3 && username.length <= 20;
  const hasValidChars = /^[a-z0-9_]*$/.test(username);
  const startsWithLetter = /^[a-z]/.test(username);

  const isFormValid = 
    validateName(name).isValid && 
    usernameValidation.isValid && 
    isUsernameAvailable === true;

  return (
    <div className={`h-screen ${getBackgroundClass()} flex flex-col`}>
      <div className="flex flex-col h-full px-6 pt-16">
        {/* Back Button */}
        <button 
          onClick={onBack}
          className="mb-8 w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#1A1A1A] flex items-center justify-center"
        >
          <ChevronLeft className="w-5 h-5 dark:text-white" />
        </button>

        {/* Title */}
        <h2 className="mb-2 text-[#1A1A1A] dark:text-white">Create your profile</h2>
        <p className="text-[#666666] dark:text-[#999999] mb-8">
          Pick a name and username. You can change this later.
        </p>

        {/* Content */}
        <div className="flex-1 overflow-y-auto mb-4">
          {/* Name Input */}
          <div className="mb-6">
            <input
              type="text"
              placeholder="Your name"
              value={name}
              onChange={(e) => handleNameChange(e.target.value)}
              onBlur={() => {
                const validation = validateName(name);
                if (!validation.isValid && name) {
                  setNameError(validation.error || "");
                }
              }}
              className={`w-full px-4 py-4 rounded-xl border outline-none transition-colors text-base bg-white dark:bg-[#1A1A1A] text-[#1A1A1A] dark:text-white placeholder:text-[#999999] dark:placeholder:text-[#666666] ${
                nameError
                  ? "border-red-500 focus:border-red-500"
                  : "border-[#1A1A1A]/10 dark:border-white/10 focus:border-[#1A1A1A]/30 dark:focus:border-white/30"
              }`}
            />
            {nameError && (
              <p className="mt-2 text-sm text-red-500 dark:text-red-400">{nameError}</p>
            )}
          </div>

          {/* Username Input */}
          <div className="mb-3">
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-base text-[#999999] dark:text-[#666666]">
                @
              </span>
              <input
                type="text"
                placeholder="username"
                value={username}
                onChange={(e) => handleUsernameChange(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && isFormValid) {
                    handleContinue();
                  }
                }}
                className={`w-full pl-9 pr-4 py-4 rounded-xl border outline-none transition-colors text-base bg-white dark:bg-[#1A1A1A] text-[#1A1A1A] dark:text-white placeholder:text-[#999999] dark:placeholder:text-[#666666] ${
                  usernameError
                    ? "border-red-500 focus:border-red-500"
                    : "border-[#1A1A1A]/10 dark:border-white/10 focus:border-[#1A1A1A]/30 dark:focus:border-white/30"
                }`}
              />
            </div>
            
            {/* Helper text - Your handle */}
            {!usernameError && !username && (
              <p className="mt-2 text-sm text-[#999999] dark:text-[#666666]">
                Your handle will appear as @username
              </p>
            )}

            {/* Error Message */}
            {usernameError && (
              <p className="mt-2 text-sm text-red-500 dark:text-red-400">{usernameError}</p>
            )}

            {/* Checking/Available Status */}
            {username && !usernameError && (
              <div className="mt-2">
                {isCheckingUsername ? (
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 border-2 border-[#999999] border-t-transparent rounded-full animate-spin" />
                    <p className="text-sm text-[#999999] dark:text-[#666666]">Checking…</p>
                  </div>
                ) : isUsernameAvailable === true ? (
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600 dark:text-green-500" strokeWidth={2} />
                    <p className="text-sm text-green-600 dark:text-green-500">Available</p>
                  </div>
                ) : null}
              </div>
            )}
          </div>

          {/* Validation Rules */}
          {username && (
            <div className="mb-6">
              <div className="space-y-1.5">
                <ValidationRule met={hasMinLength} text="3–20 characters" />
                <ValidationRule met={hasValidChars} text="lowercase letters, numbers, underscores only" />
                <ValidationRule met={startsWithLetter} text="must start with a letter" />
              </div>
            </div>
          )}
        </div>

        {/* Action Bar */}
        <div className="pb-8">
          <Button
            onClick={handleContinue}
            disabled={!isFormValid}
            fullWidth
            size="large"
          >
            Continue
          </Button>
        </div>
      </div>
    </div>
  );
}

// Validation Rule Component
function ValidationRule({ met, text }: { met: boolean; text: string }) {
  return (
    <div className="flex items-center gap-2">
      <div className={`w-4 h-4 rounded-full flex items-center justify-center transition-colors ${
        met 
          ? "bg-green-600 dark:bg-green-500" 
          : "bg-[#E5E5E5] dark:bg-[#2A2A2A]"
      }`}>
        {met && <Check className="w-3 h-3 text-white" strokeWidth={3} />}
      </div>
      <p className={`text-xs transition-colors ${
        met 
          ? "text-green-600 dark:text-green-500" 
          : "text-[#999999] dark:text-[#666666]"
      }`}>
        {text}
      </p>
    </div>
  );
}
