import { useState } from "react";
import { ArrowLeft, Shield, Check, AlertCircle } from "lucide-react";
import { AppBar } from "../ui-circle/AppBar";
import { Button } from "../ui-circle/Button";
import { Divider } from "../ui-circle/Divider";
import { BottomSheet } from "../ui-circle/BottomSheet";
import { NavBar } from "../ui-circle/NavBar";
import { useTheme } from "../ThemeContext";

interface SafetyVerificationProps {
  onBack: () => void;
}

export function SafetyVerification({ onBack }: SafetyVerificationProps) {
  const { getBackgroundClass } = useTheme();
  const [showPanicSheet, setShowPanicSheet] = useState(false);

  return (
    <div className={`h-screen ${getBackgroundClass()} flex flex-col`}>
      {/* ORIENTATION */}
      <AppBar
        title="Safety & Verification"
        subtitle="Keep your account secure"
        left={
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#2A2A2A] flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-[#1A1A1A] dark:text-white" strokeWidth={1.5} />
          </button>
        }
      />

      {/* CONTENT */}
      <div className="flex-1 overflow-y-auto pb-24">
        {/* Verification Status */}
        <div className="px-6 py-6">
          <h2 className="text-[22px] leading-tight text-[#1A1A1A] mb-4">
            Verification Status
          </h2>

          {/* ID Verification */}
          <div className="p-5 rounded-xl border border-[#1A1A1A]/10 mb-4">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-[#1A1A1A] flex items-center justify-center flex-shrink-0">
                  <Check className="w-5 h-5 text-white" strokeWidth={1.5} />
                </div>
                <div>
                  <h3 className="text-[18px] leading-tight text-[#1A1A1A] mb-1">
                    ID Verified
                  </h3>
                  <p className="text-base text-[#666666]">
                    Your identity has been confirmed
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* University Verification */}
          <div className="p-5 rounded-xl border border-[#1A1A1A]/10 mb-4">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-[#F5F5F5] flex items-center justify-center flex-shrink-0">
                  <Shield className="w-5 h-5 text-[#666666]" strokeWidth={1.5} />
                </div>
                <div className="flex-1">
                  <h3 className="text-[18px] leading-tight text-[#1A1A1A] mb-1">
                    University Verification
                  </h3>
                  <p className="text-base text-[#666666] mb-4">
                    Access campus-only circles and events
                  </p>
                  <Button variant="secondary" size="default">
                    Verify with university email
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <Divider spacing="none" />

        {/* Safety Tools */}
        <div className="px-6 py-6 bg-[#FAFAFA]">
          <h2 className="text-[22px] leading-tight text-[#1A1A1A] mb-4">
            Safety Tools
          </h2>

          <div className="space-y-3">
            {/* Panic Button */}
            <button
              onClick={() => setShowPanicSheet(true)}
              className="w-full p-5 rounded-xl bg-white border border-[#1A1A1A]/10 text-left"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <AlertCircle className="w-5 h-5 text-[#666666]" strokeWidth={1.5} />
                  <div>
                    <h3 className="text-[18px] leading-tight text-[#1A1A1A] mb-1">
                      Emergency Contacts
                    </h3>
                    <p className="text-sm text-[#666666]">
                      Quick access in case of emergency
                    </p>
                  </div>
                </div>
              </div>
            </button>

            {/* Block List */}
            <button className="w-full p-5 rounded-xl bg-white border border-[#1A1A1A]/10 text-left">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Shield className="w-5 h-5 text-[#666666]" strokeWidth={1.5} />
                  <div>
                    <h3 className="text-[18px] leading-tight text-[#1A1A1A] mb-1">
                      Blocked Users
                    </h3>
                    <p className="text-sm text-[#666666]">
                      Manage your block list
                    </p>
                  </div>
                </div>
              </div>
            </button>
          </div>
        </div>

        <Divider spacing="none" />

        {/* Privacy Controls */}
        <div className="px-6 py-6">
          <h2 className="text-[22px] leading-tight text-[#1A1A1A] mb-4">
            Privacy Controls
          </h2>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-base text-[#1A1A1A] mb-1">Show on campus feed</h4>
                <p className="text-sm text-[#666666]">Visible to verified students</p>
              </div>
              <div className="w-12 h-7 rounded-full bg-[#1A1A1A] relative">
                <div className="absolute right-1 top-1 w-5 h-5 rounded-full bg-white" />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-base text-[#1A1A1A] mb-1">Profile visibility</h4>
                <p className="text-sm text-[#666666]">Who can see your profile</p>
              </div>
              <button className="text-sm text-[#1A1A1A]">Circles only</button>
            </div>
          </div>
        </div>
      </div>

      {/* Panic Bottom Sheet */}
      <BottomSheet
        isOpen={showPanicSheet}
        onClose={() => setShowPanicSheet(false)}
        title="Emergency Contacts"
      >
        <div className="px-6 py-6">
          <div className="space-y-4 mb-6">
            <a
              href="tel:911"
              className="block p-5 rounded-xl border border-[#1A1A1A]/10 text-center"
            >
              <p className="text-[22px] text-[#1A1A1A] mb-2">Emergency Services</p>
              <p className="text-base text-[#666666]">911</p>
            </a>

            <a
              href="tel:988"
              className="block p-5 rounded-xl border border-[#1A1A1A]/10 text-center"
            >
              <p className="text-[22px] text-[#1A1A1A] mb-2">Crisis Support</p>
              <p className="text-base text-[#666666]">988 Suicide & Crisis Lifeline</p>
            </a>
          </div>

          <Button variant="secondary" fullWidth onClick={() => setShowPanicSheet(false)}>
            Close
          </Button>
        </div>
      </BottomSheet>

      {/* NAVIGATION */}
      <NavBar
        items={[
          { icon: <Shield className="w-6 h-6" strokeWidth={1.5} />, label: "Discover" },
          { icon: <Shield className="w-6 h-6" strokeWidth={1.5} />, label: "Circles" },
          { icon: <Shield className="w-6 h-6" strokeWidth={1.5} />, label: "Events" },
          { icon: <Shield className="w-6 h-6" strokeWidth={1.5} />, label: "Profile", active: true }
        ]}
      />
    </div>
  );
}
