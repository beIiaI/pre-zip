import { ArrowLeft } from "lucide-react";
import { useTheme } from "../ThemeContext";

interface BadgesScreenProps {
  onBack: () => void;
  earlySupporterNumber?: number | null;
}

const allBadges = [
  { id: "1", name: "Initiator", emoji: "🚀", description: "Create your first circle", earned: true },
  { id: "2", name: "Social Butterfly", emoji: "🦋", description: "Join 5 different circles", earned: true },
  { id: "3", name: "Community Pillar", emoji: "🏛️", description: "Be a member for 6 months", earned: false },
  { id: "4", name: "Event Enthusiast", emoji: "🎉", description: "Attend 10 events", earned: false },
  { id: "5", name: "Host with the Most", emoji: "🌟", description: "Host 3 successful events", earned: false },
  { id: "6", name: "Ambassador", emoji: "💫", description: "Refer 5 friends", earned: false }
];

export function BadgesScreen({ onBack, earlySupporterNumber }: BadgesScreenProps) {
  const { getBackgroundClass } = useTheme();

  return (
    <div className={`h-screen ${getBackgroundClass()} flex flex-col`}>
      {/* Header */}
      <div className="px-6 pt-14 pb-4 border-b border-[#1A1A1A]/10 dark:border-white/10">
        <div className="flex items-center gap-4 mb-4">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#2A2A2A] flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-[#1A1A1A] dark:text-white" strokeWidth={1.5} />
          </button>
          <h2 className="text-[#1A1A1A] dark:text-white">Badges</h2>
        </div>
        <p className="text-[#666666] dark:text-[#AAAAAA]">Earn badges by being active in the community</p>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-6 py-6">
        {/* Points Widget */}
        <div className="p-6 rounded-xl bg-gradient-to-br from-[#C7E5FF] to-[#A0D3FF] text-[#1A1A1A] mb-6">
          <p className="text-sm opacity-75 mb-2">Total Points</p>
          <h1 className="mb-1">240</h1>
          <p className="text-sm opacity-70">Keep going to unlock more badges</p>
        </div>

        {/* Badges Grid */}
        <div className="space-y-4">
          {/* Early Supporter Badge - Only if user qualifies */}
          {earlySupporterNumber !== null && earlySupporterNumber <= 250 && (
            <div className="p-6 rounded-xl border-2 border-[#1A1A1A]/20 dark:border-white/20 bg-gradient-to-br from-[#FAFAFA] via-white to-[#F5F5F5] dark:from-[#1A1A1A] dark:via-[#0A0A0A] dark:to-[#000000] shadow-sm">
              <div className="flex items-start gap-4">
                <div className="text-4xl flex-shrink-0">✦</div>
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h4 className="text-[#1A1A1A] dark:text-white mb-1">Early Supporter</h4>
                      <p className="text-[9px] tracking-[0.15em] font-medium text-[#999999] dark:text-[#666666]">
                        LIMITED EDITION
                      </p>
                    </div>
                    <div className="px-2.5 py-1 rounded-full bg-[#1A1A1A] dark:bg-white">
                      <span className="text-[10px] font-medium text-white dark:text-[#1A1A1A]">Earned</span>
                    </div>
                  </div>
                  <p className="text-sm text-[#666666] dark:text-[#AAAAAA] mb-3 leading-relaxed">
                    One of the first 250 members of pre. Founding member status.
                  </p>
                  <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#FAFAFA] dark:bg-[#1A1A1A] border border-[#1A1A1A]/10 dark:border-white/10">
                    <span className="font-mono text-xs text-[#1A1A1A] dark:text-white">
                      #{String(earlySupporterNumber).padStart(3, '0')}
                    </span>
                    <span className="text-[10px] text-[#999999] dark:text-[#666666]">of 250</span>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {allBadges.map((badge) => (
            <div
              key={badge.id}
              className={`p-5 rounded-xl border ${
                badge.earned
                  ? "border-[#1A1A1A]/10 bg-white"
                  : "border-[#1A1A1A]/5 bg-[#FAFAFA]"
              }`}
            >
              <div className="flex items-start gap-4">
                <div className="text-4xl flex-shrink-0">{badge.emoji}</div>
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="text-[#1A1A1A]">{badge.name}</h4>
                    {badge.earned && (
                      <div className="px-2 py-1 rounded-full bg-[#C7E5FF] text-[#1A1A1A] text-xs">
                        Earned
                      </div>
                    )}
                  </div>
                  <p className="text-sm text-[#666666] mb-3">
                    {badge.description}
                  </p>
                  {!badge.earned && (
                    <div>
                      <div className="flex items-center justify-between text-xs text-[#999999] mb-2">
                        <span>Progress</span>
                        <span>{badge.progress}/{badge.total}</span>
                      </div>
                      <div className="h-1.5 bg-[#F0F0F0] rounded-full overflow-hidden">
                        <div
                          className="h-full bg-[#C7E5FF] rounded-full"
                          style={{ width: `${(badge.progress / badge.total) * 100}%` }}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}