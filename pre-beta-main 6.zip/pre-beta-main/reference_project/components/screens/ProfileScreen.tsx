import { ArrowLeft, Settings, MapPin, Share2 } from "lucide-react";
import { Facepile } from "../ui-circle/Facepile";
import { StatusChip } from "../ui-circle/StatusChip";
import { ThemeToggle } from "../ThemeToggle";
import { useTheme } from "../ThemeContext";

interface ProfileScreenProps {
  onBack: () => void;
  onBadgesClick: () => void;
  onSafetyClick?: () => void;
  onSettingsClick?: () => void;
  onEditProfileClick?: () => void;
  onEarlySupporterClick?: () => void;
  earlySupporterNumber?: number | null;
  userName?: string;
  userInitials?: string;
  userUsername?: string;
  userLocation?: string;
  userBio?: string;
}

const circles = [
  { id: "1", name: "Coffee Enthusiasts", members: 24 },
  { id: "2", name: "Weekend Hikers", members: 18 },
  { id: "3", name: "Book Club", members: 32 }
];

const events = [
  { id: "1", name: "Sunday Morning Brew", date: "Tomorrow, 10AM" },
  { id: "2", name: "Mountain Trail Hike", date: "Sat, 7AM" }
];

const badges = [
  { id: "1", name: "Initiator", emoji: "🚀", earned: true },
  { id: "2", name: "Social Butterfly", emoji: "🦋", earned: true },
  { id: "3", name: "Community Pillar", emoji: "🏛️", earned: false }
];

export function ProfileScreen({ 
  onBack, 
  onBadgesClick, 
  onSafetyClick, 
  onSettingsClick,
  onEditProfileClick,
  onEarlySupporterClick,
  earlySupporterNumber = 37, // Default for demo
  userName = "",
  userInitials = "?",
  userUsername = null,
  userLocation = "San Francisco, CA",
  userBio = "Coffee lover and weekend explorer. Always up for meeting new people and trying new things."
}: ProfileScreenProps) {
  const { getBackgroundClass } = useTheme();
  return (
    <div className={`h-screen ${getBackgroundClass()} flex flex-col`}>
      {/* Header */}
      <div className="px-6 pt-14 pb-4 flex items-center justify-between border-b border-[#1A1A1A]/10 dark:border-white/10">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#2A2A2A] flex items-center justify-center"
        >
          <ArrowLeft className="w-5 h-5 text-[#1A1A1A] dark:text-white" strokeWidth={1.5} />
        </button>
        <h2 className="text-[#1A1A1A] dark:text-white">Profile</h2>
        <button
          onClick={onSettingsClick}
          className="w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#2A2A2A] flex items-center justify-center"
        >
          <Settings className="w-5 h-5 text-[#1A1A1A] dark:text-white" strokeWidth={1.5} />
        </button>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto">
        {/* Profile Header */}
        <div className="px-6 py-8 border-b border-[#1A1A1A]/10 dark:border-white/10">
          <div className="flex flex-col items-center text-center mb-6">
            <div className="w-24 h-24 rounded-full bg-[#1A1A1A] dark:bg-white flex items-center justify-center text-white dark:text-[#1A1A1A] text-2xl mb-4">
              {userInitials}
            </div>
            <h2 className="mb-2 text-[#1A1A1A] dark:text-white">{userName}</h2>
            
            {/* Username display */}
            {userUsername && (
              <p className="text-sm text-[#999999] dark:text-[#888888] mb-3">@{userUsername}</p>
            )}
            
            {/* Early Supporter Badge */}
            {earlySupporterNumber !== null && earlySupporterNumber <= 250 && (
              <button 
                onClick={onEarlySupporterClick}
                className="inline-flex items-center gap-2 px-4 py-2 mb-4 rounded-lg border border-[#1A1A1A]/20 dark:border-white/20 bg-gradient-to-br from-[#FAFAFA] to-[#F5F5F5] dark:from-[#1A1A1A] dark:to-[#0A0A0A] active:opacity-80 transition-all shadow-sm"
              >
                <div className="flex items-center gap-2">
                  <span className="text-[10px] tracking-wider font-medium text-[#1A1A1A] dark:text-white">EARLY SUPPORTER</span>
                  <span className="text-[10px] text-[#999999] dark:text-[#666666]">•</span>
                  <span className="font-mono text-xs text-[#1A1A1A] dark:text-white tracking-tight">
                    #{String(earlySupporterNumber).padStart(3, '0')}
                  </span>
                </div>
                <span className="text-[10px] text-[#999999] dark:text-[#666666]">✦</span>
              </button>
            )}
            
            <div className="flex items-center gap-2 mb-4">
              <MapPin className="w-4 h-4 text-[#999999] dark:text-[#888888]" strokeWidth={1.5} />
              <span className="text-sm text-[#999999] dark:text-[#888888]">{userLocation}</span>
            </div>
            <p className="text-[#666666] dark:text-[#AAAAAA] leading-relaxed max-w-sm mb-6">
              {userBio}
            </p>
            <button className="px-6 py-2 rounded-full border border-[#1A1A1A]/10 dark:border-white/10 text-sm text-[#1A1A1A] dark:text-white" onClick={onEditProfileClick}>
              Edit Profile
            </button>
          </div>

          {/* Stats */}
          <div className="flex items-center justify-center gap-8 pt-6 border-t border-[#1A1A1A]/10 dark:border-white/10">
            <div className="text-center">
              <p className="text-2xl text-[#1A1A1A] dark:text-white mb-1">3</p>
              <p className="text-xs text-[#999999] dark:text-[#888888]">Circles</p>
            </div>
            <div className="text-center">
              <p className="text-2xl text-[#1A1A1A] dark:text-white mb-1">12</p>
              <p className="text-xs text-[#999999] dark:text-[#888888]">Events</p>
            </div>
            <div className="text-center">
              <p className="text-2xl text-[#1A1A1A] dark:text-white mb-1">240</p>
              <p className="text-xs text-[#999999] dark:text-[#888888]">Points</p>
            </div>
          </div>
        </div>

        {/* Badges */}
        <div className="px-6 py-6 border-b border-[#1A1A1A]/10 dark:border-white/10">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-[#1A1A1A] dark:text-white">Badges</h3>
            <button onClick={onBadgesClick} className="text-sm text-[#1A1A1A] dark:text-white">
              See all
            </button>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {badges.map((badge) => (
              <div
                key={badge.id}
                className={`p-4 rounded-xl border text-center ${
                  badge.earned
                    ? "border-[#1A1A1A]/10 dark:border-white/10 bg-white dark:bg-[#222222]"
                    : "border-[#1A1A1A]/5 dark:border-white/5 bg-[#FAFAFA] dark:bg-[#2A2A2A] opacity-50"
                }`}
              >
                <div className="text-3xl mb-2">{badge.emoji}</div>
                <p className="text-xs text-[#1A1A1A] dark:text-white">{badge.name}</p>
              </div>
            ))}
          </div>
        </div>

        {/* My Circles */}
        <div className="px-6 py-6 border-b border-[#1A1A1A]/10 dark:border-white/10">
          <h3 className="mb-4 text-[#1A1A1A] dark:text-white">My Circles</h3>
          <div className="space-y-3">
            {circles.map((circle) => (
              <div
                key={circle.id}
                className="p-4 rounded-xl border border-[#1A1A1A]/10 dark:border-white/10 flex items-center justify-between bg-white dark:bg-[#222222]"
              >
                <div>
                  <h4 className="mb-1 text-[#1A1A1A] dark:text-white">{circle.name}</h4>
                  <p className="text-sm text-[#666666] dark:text-[#AAAAAA]">{circle.members} members</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* My Events */}
        <div className="px-6 py-6 border-b border-[#1A1A1A]/10 dark:border-white/10">
          <h3 className="mb-4 text-[#1A1A1A] dark:text-white">Upcoming Events</h3>
          <div className="space-y-3">
            {events.map((event) => (
              <div
                key={event.id}
                className="p-4 rounded-xl border border-[#1A1A1A]/10 dark:border-white/10 bg-white dark:bg-[#222222]"
              >
                <h4 className="mb-1 text-[#1A1A1A] dark:text-white">{event.name}</h4>
                <p className="text-sm text-[#666666] dark:text-[#AAAAAA]">{event.date}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Settings */}
        <div className="px-6 py-6">
          <h3 className="mb-4 text-[#1A1A1A] dark:text-white">Settings</h3>
          <ThemeToggle />
        </div>
      </div>
    </div>
  );
}