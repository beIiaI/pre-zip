import { useState, useEffect } from "react";
import { ArrowLeft, Camera } from "lucide-react";
import { BottomSheet } from "../ui-circle/BottomSheet";
import { useTheme } from "../ThemeContext";

interface EditProfileProps {
  onBack: () => void;
  onSave: (data: { name: string; username: string | null; bio: string; location: string }) => void;
  initialData?: {
    name: string;
    username?: string | null;
    bio?: string;
    location?: string;
    initials?: string;
  };
}

export function EditProfile({ onBack, onSave, initialData }: EditProfileProps) {
  const [name, setName] = useState(initialData?.name || "");
  const [username, setUsername] = useState(initialData?.username || "");
  const [bio, setBio] = useState(initialData?.bio || "");
  const [location, setLocation] = useState(initialData?.location || "");
  const [showPhotoSheet, setShowPhotoSheet] = useState(false);
  const [showLocationSheet, setShowLocationSheet] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [showSuccessToast, setShowSuccessToast] = useState(false);
  const { getBackgroundClass } = useTheme();

  // Check if there are any changes
  const hasChanges = 
    name !== initialData?.name ||
    username !== (initialData?.username || "") ||
    bio !== (initialData?.bio || "") ||
    location !== (initialData?.location || "");

  // Validate name
  const isNameValid = name.trim().length >= 2 && /[a-zA-Z]/.test(name);

  const canSave = hasChanges && isNameValid;

  // Generate initials
  const generateInitials = (fullName: string): string => {
    if (!fullName.trim()) return initialData?.initials || "?";
    
    const parts = fullName.trim().split(/[\s-]+/).filter(Boolean);
    
    if (parts.length === 0) return initialData?.initials || "?";
    if (parts.length === 1) return parts[0][0].toUpperCase();
    
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  };

  const initials = generateInitials(name);

  const handleSave = async () => {
    if (!canSave) return;

    setIsSaving(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 800));
    
    onSave({
      name: name.trim(),
      username: username.trim() || null,
      bio: bio.trim(),
      location: location.trim(),
    });

    setIsSaving(false);
    setShowSuccessToast(true);
    
    // Hide toast and go back after short delay
    setTimeout(() => {
      setShowSuccessToast(false);
      onBack();
    }, 1500);
  };

  const locations = [
    "San Francisco, CA",
    "Los Angeles, CA",
    "New York, NY",
    "Austin, TX",
    "Seattle, WA",
    "Portland, OR",
    "Denver, CO",
    "Boston, MA"
  ];

  return (
    <div className={`h-screen ${getBackgroundClass()} flex flex-col relative`}>
      {/* Header */}
      <div className="px-6 pt-14 pb-4 flex items-center justify-between border-b border-[#1A1A1A]/10 dark:border-white/10">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#2A2A2A] flex items-center justify-center"
        >
          <ArrowLeft className="w-5 h-5 text-[#1A1A1A] dark:text-white" strokeWidth={1.5} />
        </button>
        <h2 className="text-[#1A1A1A] dark:text-white">Edit Profile</h2>
        <button
          onClick={handleSave}
          disabled={!canSave || isSaving}
          className="text-base text-[#1A1A1A] dark:text-white disabled:opacity-30 transition-opacity"
        >
          {isSaving ? "Saving..." : "Save"}
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        {/* Avatar Section */}
        <div className="px-6 py-8 flex justify-center border-b border-[#1A1A1A]/10 dark:border-white/10">
          <button
            onClick={() => setShowPhotoSheet(true)}
            className="relative group"
          >
            <div className="w-24 h-24 rounded-full bg-[#1A1A1A] dark:bg-white flex items-center justify-center text-white dark:text-[#1A1A1A] text-2xl">
              {initials}
            </div>
            {/* Camera Overlay */}
            <div className="absolute inset-0 rounded-full bg-black/40 flex items-center justify-center opacity-0 group-active:opacity-100 transition-opacity">
              <Camera className="w-6 h-6 text-white" strokeWidth={1.5} />
            </div>
          </button>
        </div>

        {/* Form Fields */}
        <div className="divide-y divide-[#1A1A1A]/10 dark:divide-white/10">
          {/* Name */}
          <div className="px-6 py-4">
            <label className="block mb-2 text-sm text-[#999999] dark:text-[#888888]">
              Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name"
              className="w-full text-base text-[#1A1A1A] dark:text-white bg-transparent outline-none placeholder:text-[#CCCCCC] dark:placeholder:text-[#555555]"
            />
          </div>

          {/* Username */}
          <div className="px-6 py-4">
            <label className="block mb-2 text-sm text-[#999999] dark:text-[#888888]">
              Username
            </label>
            <div className="flex items-center gap-1">
              <span className="text-base text-[#999999] dark:text-[#666666]">@</span>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value.replace(/^@/, ""))}
                placeholder="username"
                className="flex-1 text-base text-[#1A1A1A] dark:text-white bg-transparent outline-none placeholder:text-[#CCCCCC] dark:placeholder:text-[#555555]"
              />
            </div>
          </div>

          {/* Bio */}
          <div className="px-6 py-4">
            <label className="block mb-2 text-sm text-[#999999] dark:text-[#888888]">
              Bio
            </label>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Tell people a bit about yourself"
              rows={3}
              maxLength={150}
              className="w-full text-base text-[#1A1A1A] dark:text-white bg-transparent outline-none placeholder:text-[#CCCCCC] dark:placeholder:text-[#555555] resize-none"
            />
            <p className="mt-2 text-xs text-[#999999] dark:text-[#666666] text-right">
              {bio.length}/150
            </p>
          </div>

          {/* Location */}
          <div className="px-6 py-4">
            <label className="block mb-2 text-sm text-[#999999] dark:text-[#888888]">
              Location
            </label>
            <button
              onClick={() => setShowLocationSheet(true)}
              className="w-full text-left text-base text-[#1A1A1A] dark:text-white"
            >
              {location || <span className="text-[#CCCCCC] dark:text-[#555555]">Add location</span>}
            </button>
          </div>
        </div>
      </div>

      {/* Photo Bottom Sheet */}
      <BottomSheet isOpen={showPhotoSheet} onClose={() => setShowPhotoSheet(false)}>
        <div className="px-6 py-6">
          <h3 className="mb-6 text-center text-[#1A1A1A] dark:text-white">
            Profile Photo
          </h3>
          <div className="space-y-3">
            <button className="w-full py-4 text-center text-base text-[#1A1A1A] dark:text-white border-b border-[#1A1A1A]/10 dark:border-white/10">
              Choose photo
            </button>
            <button className="w-full py-4 text-center text-base text-red-500">
              Remove
            </button>
            <button 
              onClick={() => setShowPhotoSheet(false)}
              className="w-full py-4 text-center text-base text-[#999999] dark:text-[#888888]"
            >
              Cancel
            </button>
          </div>
        </div>
      </BottomSheet>

      {/* Location Bottom Sheet */}
      <BottomSheet isOpen={showLocationSheet} onClose={() => setShowLocationSheet(false)}>
        <div className="px-6 py-6">
          <h3 className="mb-6 text-center text-[#1A1A1A] dark:text-white">
            Select Location
          </h3>
          <div className="space-y-1 max-h-96 overflow-y-auto">
            {locations.map((loc) => (
              <button
                key={loc}
                onClick={() => {
                  setLocation(loc);
                  setShowLocationSheet(false);
                }}
                className={`w-full py-4 px-4 text-left text-base rounded-lg transition-colors ${
                  location === loc
                    ? "bg-[#FAFAFA] dark:bg-[#1A1A1A] text-[#1A1A1A] dark:text-white"
                    : "text-[#666666] dark:text-[#AAAAAA] active:bg-[#FAFAFA] dark:active:bg-[#1A1A1A]"
                }`}
              >
                {loc}
              </button>
            ))}
          </div>
        </div>
      </BottomSheet>

      {/* Success Toast */}
      {showSuccessToast && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 px-6 py-3 rounded-full bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] shadow-lg z-50">
          <p className="text-sm">Saved</p>
        </div>
      )}
    </div>
  );
}
