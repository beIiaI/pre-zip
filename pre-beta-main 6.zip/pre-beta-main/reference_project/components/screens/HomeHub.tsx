import { useState } from "react";
import { Search, SlidersHorizontal, User } from "lucide-react";
import { SegmentedControl } from "../ui-circle/SegmentedControl";
import { CircleCard } from "../ui-circle/CircleCard";

interface HomeHubProps {
  onCircleClick: () => void;
  onProfileClick: () => void;
}

const circlesData = [
  {
    id: "1",
    title: "Coffee Enthusiasts",
    description: "A community of coffee lovers exploring the best cafés, learning about brewing techniques, and sharing our passion.",
    memberCount: 24,
    members: [
      { id: "1", initials: "SC" },
      { id: "2", initials: "MR" },
      { id: "3", initials: "ED" },
      { id: "4", initials: "JW" }
    ],
    category: "Food & Drink",
    verified: true
  },
  {
    id: "2",
    title: "Weekend Hikers",
    description: "Exploring local trails every Saturday morning. All skill levels welcome for outdoor adventures and fresh air.",
    memberCount: 18,
    members: [
      { id: "5", initials: "LP" },
      { id: "6", initials: "TA" },
      { id: "7", initials: "KM" },
      { id: "8", initials: "RJ" }
    ],
    category: "Outdoors",
    limited: true
  },
  {
    id: "3",
    title: "Book Club",
    description: "Monthly discussions of contemporary fiction and classic literature. Thoughtful conversations over tea.",
    memberCount: 32,
    members: [
      { id: "9", initials: "AM" },
      { id: "10", initials: "BK" },
      { id: "11", initials: "CL" },
      { id: "12", initials: "DN" }
    ],
    category: "Literature",
    verified: true
  }
];

const peopleData = [
  {
    id: "1",
    title: "Sarah Chen",
    description: "Coffee addict, weekend photographer, always looking for new cafés to explore. Based in Pacific Heights.",
    memberCount: 3,
    members: [
      { id: "1", initials: "SC" },
      { id: "2", initials: "MR" },
      { id: "3", initials: "ED" }
    ],
    category: "San Francisco"
  },
  {
    id: "2",
    title: "Michael Ross",
    description: "Tech professional who loves hiking and outdoor adventures. Let's explore the bay area trails together.",
    memberCount: 2,
    members: [
      { id: "5", initials: "LP" },
      { id: "6", initials: "TA" }
    ],
    category: "Oakland"
  }
];

const eventsData = [
  {
    id: "1",
    title: "Sunday Morning Brew",
    description: "Join us for our weekly coffee meetup at Downtown Café. Great conversations and amazing espresso.",
    memberCount: 12,
    members: [
      { id: "1", initials: "SC" },
      { id: "2", initials: "MR" },
      { id: "3", initials: "ED" },
      { id: "4", initials: "JW" }
    ],
    category: "Tomorrow, 10AM",
    limited: true
  },
  {
    id: "2",
    title: "Mountain Trail Hike",
    description: "Saturday morning hike on the Bay Ridge Trail. Moderate difficulty, bring water and snacks.",
    memberCount: 8,
    members: [
      { id: "5", initials: "LP" },
      { id: "6", initials: "TA" },
      { id: "7", initials: "KM" }
    ],
    category: "Sat, 7AM"
  }
];

export function HomeHub({ onCircleClick, onProfileClick }: HomeHubProps) {
  const [activeTab, setActiveTab] = useState("Circles");

  const getData = () => {
    switch (activeTab) {
      case "Circles":
        return circlesData;
      case "People":
        return peopleData;
      case "Events":
        return eventsData;
      default:
        return circlesData;
    }
  };

  const getActionLabel = () => {
    switch (activeTab) {
      case "Circles":
        return "Join Circle";
      case "People":
        return "Connect";
      case "Events":
        return "Join Event";
      default:
        return "Join";
    }
  };

  return (
    <div className="h-screen bg-white flex flex-col">
      {/* Header */}
      <div className="px-6 pt-14 pb-4 border-b border-[#1A1A1A]/10">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-[#1A1A1A]">Circle</h1>
          <button
            onClick={onProfileClick}
            className="w-10 h-10 rounded-full bg-[#1A1A1A] flex items-center justify-center"
          >
            <User className="w-5 h-5 text-white" strokeWidth={1.5} />
          </button>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#999999]" strokeWidth={1.5} />
          <input
            type="text"
            placeholder="Search circles, people, or events"
            className="w-full pl-12 pr-4 py-3 rounded-xl border border-[#1A1A1A]/10 outline-none focus:border-[#1A1A1A]/30 transition-colors"
          />
        </div>

        {/* Tabs */}
        <div className="flex items-center justify-between">
          <SegmentedControl
            options={["Circles", "People", "Events"]}
            value={activeTab}
            onChange={setActiveTab}
          />
          <button className="w-10 h-10 rounded-full bg-[#F5F5F5] flex items-center justify-center">
            <SlidersHorizontal className="w-5 h-5 text-[#1A1A1A]" strokeWidth={1.5} />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-6 py-6">
        <div className="space-y-4">
          {getData().map((item) => (
            <CircleCard
              key={item.id}
              title={item.title}
              description={item.description}
              memberCount={item.memberCount}
              members={item.members}
              verified={item.verified}
              limited={item.limited}
              category={item.category}
              onJoin={() => {}}
              onPass={activeTab === "People" ? () => {} : undefined}
              onClick={onCircleClick}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
