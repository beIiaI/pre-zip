import { useState } from "react";
import { ArrowLeft, Share2, MapPin, Calendar, Lock, Check as CheckIcon, Users, MessageCircle } from "lucide-react";
import { Facepile } from "../ui-circle/Facepile";
import { StatusChip } from "../ui-circle/StatusChip";
import { AppBar } from "../ui-circle/AppBar";
import { NavBar } from "../ui-circle/NavBar";
import { Divider } from "../ui-circle/Divider";
import { SegmentedControl } from "../ui-circle/SegmentedControl";
import { ActionBar } from "../ui-circle/ActionBar";
import { Button } from "../ui-circle/Button";
import { useTheme } from "../ThemeContext";

interface CircleProfileRevisedProps {
  onBack: () => void;
}

const members = [
  { id: "1", initials: "SC" },
  { id: "2", initials: "MR" },
  { id: "3", initials: "ED" },
  { id: "4", initials: "JW" },
  { id: "5", initials: "LP" },
  { id: "6", initials: "TA" },
  { id: "7", initials: "KM" },
  { id: "8", initials: "RJ" },
];

const events = [
  {
    id: "1",
    title: "Sunday Morning Brew",
    date: "Tomorrow, 10AM",
    attendees: 12,
  },
  {
    id: "2",
    title: "Latte Art Workshop",
    date: "Friday, 2PM",
    attendees: 8,
  },
];

export function CircleProfileRevised({ onBack }: CircleProfileRevisedProps) {
  const [activeTab, setActiveTab] = useState("Chat");
  const { getBackgroundClass } = useTheme();

  return (
    <div className={`h-screen ${getBackgroundClass()} flex flex-col`}>
      {/* ORIENTATION: App Bar */}
      <AppBar
        left={
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#2A2A2A] flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-[#1A1A1A] dark:text-white" strokeWidth={1.5} />
          </button>
        }
        right={
          <button className="w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#2A2A2A] flex items-center justify-center">
            <Share2 className="w-5 h-5 text-[#1A1A1A] dark:text-white" strokeWidth={1.5} />
          </button>
        }
      />

      {/* CONTENT: Scrollable */}
      <div className="flex-1 overflow-y-auto pb-32">
        {/* Cover Image */}
        <div className="h-48 bg-gradient-to-br from-[#F5F5F5] to-[#E5E5E5] dark:from-[#2A2A2A] dark:to-[#1A1A1A]" />

        {/* Main Info Section */}
        <div className="px-6 py-6">
          <h1 className="text-[32px] leading-tight text-[#1A1A1A] dark:text-white mb-3">
            Coffee Enthusiasts
          </h1>
          
          {/* Status Chips */}
          <div className="flex items-center gap-2 mb-4">
            <StatusChip>Food & Drink</StatusChip>
            <StatusChip variant="verified">Verified</StatusChip>
          </div>

          {/* Member Count */}
          <div className="flex items-center gap-2 text-[#666666] dark:text-[#999999] mb-6">
            <Users className="w-4 h-4" strokeWidth={1.5} />
            <span className="text-base">24 members</span>
          </div>

          {/* Description */}
          <p className="text-base text-[#666666] dark:text-[#999999] leading-relaxed mb-6">
            A community of coffee lovers exploring the best cafés, learning about brewing techniques, and sharing our passion for the perfect cup.
          </p>
        </div>

        <Divider spacing="none" />

        {/* Rules Section (Bento compartment) */}
        <div className="px-6 py-6 bg-[#FAFAFA] dark:bg-[#1A1A1A]">
          <div className="flex items-start gap-3">
            <Lock className="w-5 h-5 text-[#666666] dark:text-[#999999] flex-shrink-0 mt-0.5" strokeWidth={1.5} />
            <div>
              <h3 className="text-[18px] leading-tight text-[#1A1A1A] dark:text-white mb-3">Circle Rules</h3>
              <ul className="space-y-2 text-base text-[#666666] dark:text-[#999999]">
                <li>• Be respectful and welcoming to all members</li>
                <li>• Share coffee recommendations and tips freely</li>
                <li>• RSVP to events and show up on time</li>
              </ul>
            </div>
          </div>
        </div>

        <Divider spacing="none" />

        {/* Members Section */}
        <div className="px-6 py-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-[22px] leading-tight text-[#1A1A1A] dark:text-white">Members</h2>
            <button className="text-sm text-[#1A1A1A] dark:text-white">See all</button>
          </div>
          <Facepile avatars={members} max={8} size={36} overlap={12} />
        </div>

        <Divider spacing="none" />

        {/* Tabs */}
        <div className="px-6 py-4 bg-[#FAFAFA] dark:bg-[#1A1A1A]">
          <SegmentedControl
            options={["Chat", "Events"]}
            value={activeTab}
            onChange={setActiveTab}
          />
        </div>

        <Divider spacing="none" />

        {/* Tab Content */}
        <div className="px-6 py-6">
          {activeTab === "Chat" ? (
            <div className="text-center py-12">
              <MessageCircle className="w-12 h-12 text-[#CCCCCC] dark:text-[#555555] mx-auto mb-4" strokeWidth={1.5} />
              <h3 className="text-[18px] text-[#1A1A1A] dark:text-white mb-2">Join to see chat</h3>
              <p className="text-base text-[#666666] dark:text-[#999999]">
                Connect with members and join the conversation
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {events.map((event) => (
                <div
                  key={event.id}
                  className="p-5 rounded-xl border border-[#1A1A1A]/10 dark:border-white/10"
                >
                  <h3 className="text-[18px] leading-tight text-[#1A1A1A] dark:text-white mb-3">{event.title}</h3>
                  <div className="space-y-2 text-base text-[#666666] dark:text-[#999999]">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" strokeWidth={1.5} />
                      <span>{event.date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4" strokeWidth={1.5} />
                      <span>{event.attendees} going</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ACTION: Fixed CTA */}
      <ActionBar>
        <Button variant="primary" size="large" fullWidth>
          Request to Join
        </Button>
      </ActionBar>

      {/* NAVIGATION: Bottom Nav */}
      <NavBar
        items={[
          { icon: <Users className="w-6 h-6" strokeWidth={1.5} />, label: "Discover" },
          { icon: <Users className="w-6 h-6" strokeWidth={1.5} />, label: "Circles" },
          { icon: <Calendar className="w-6 h-6" strokeWidth={1.5} />, label: "Events" },
          { icon: <Users className="w-6 h-6" strokeWidth={1.5} />, label: "Profile" }
        ]}
      />
    </div>
  );
}