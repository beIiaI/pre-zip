import { createContext, useContext, useState, useEffect, ReactNode } from "react";

type ThemeMode = "light" | "dark" | "system";
type Theme = "light" | "dark";

interface ThemeContextType {
  theme: Theme;
  themeMode: ThemeMode;
  amoledMode: boolean;
  toggleTheme: () => void;
  setThemeMode: (mode: ThemeMode) => void;
  setAmoledMode: (enabled: boolean) => void;
  getBackgroundClass: () => string;
  getSecondaryBackgroundClass: () => string;
  getButtonBackgroundClass: () => string;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [themeMode, setThemeModeState] = useState<ThemeMode>(() => {
    // Check localStorage first, fallback to system
    const stored = localStorage.getItem("pre-theme-mode") as ThemeMode;
    return stored || "system";
  });

  const [amoledMode, setAmoledModeState] = useState<boolean>(() => {
    // Check localStorage for AMOLED preference
    const stored = localStorage.getItem("pre-amoled-mode");
    return stored === "true";
  });

  const [theme, setTheme] = useState<Theme>("light");

  // Helper functions to get correct background classes
  const getBackgroundClass = () => {
    if (theme === "dark" && amoledMode) {
      return "bg-white dark:bg-[#000000]";
    }
    return "bg-white dark:bg-[#1A1A1A]";
  };

  const getSecondaryBackgroundClass = () => {
    if (theme === "dark" && amoledMode) {
      return "bg-[#F5F5F5] dark:bg-[#0A0A0A]";
    }
    return "bg-[#F5F5F5] dark:bg-[#0A0A0A]";
  };

  const getButtonBackgroundClass = () => {
    if (theme === "dark" && amoledMode) {
      return "bg-[#F5F5F5] dark:bg-[#1A1A1A]";
    }
    return "bg-[#F5F5F5] dark:bg-[#2A2A2A]";
  };

  // Function to get effective theme based on mode
  const getEffectiveTheme = (mode: ThemeMode): Theme => {
    if (mode === "system") {
      return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches
        ? "dark"
        : "light";
    }
    return mode;
  };

  useEffect(() => {
    // Update effective theme
    const effectiveTheme = getEffectiveTheme(themeMode);
    setTheme(effectiveTheme);

    // Update localStorage
    localStorage.setItem("pre-theme-mode", themeMode);
    
    // Update document class
    if (effectiveTheme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }

    // Listen for system theme changes if in system mode
    if (themeMode === "system") {
      const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
      const handleChange = (e: MediaQueryListEvent) => {
        const newTheme = e.matches ? "dark" : "light";
        setTheme(newTheme);
        if (newTheme === "dark") {
          document.documentElement.classList.add("dark");
        } else {
          document.documentElement.classList.remove("dark");
        }
      };

      mediaQuery.addEventListener("change", handleChange);
      return () => mediaQuery.removeEventListener("change", handleChange);
    }
  }, [themeMode]);

  const toggleTheme = () => {
    setThemeModeState(prev => {
      if (prev === "light") return "dark";
      if (prev === "dark") return "system";
      return "light";
    });
  };

  const setThemeMode = (mode: ThemeMode) => {
    setThemeModeState(mode);
  };

  const setAmoledMode = (enabled: boolean) => {
    setAmoledModeState(enabled);
    localStorage.setItem("pre-amoled-mode", enabled.toString());
  };

  return (
    <ThemeContext.Provider value={{ theme, themeMode, amoledMode, toggleTheme, setThemeMode, setAmoledMode, getBackgroundClass, getSecondaryBackgroundClass, getButtonBackgroundClass }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error("useTheme must be used within a ThemeProvider");
  }
  return context;
}