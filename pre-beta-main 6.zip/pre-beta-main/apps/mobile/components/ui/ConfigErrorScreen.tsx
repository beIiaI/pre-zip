import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import * as Clipboard from 'expo-clipboard'
import { useTheme } from '@/contexts/ThemeContext'
import { PreWordmark } from '@/components/ui/PreWordmark'
import { Spacing, Typography } from '@/constants/theme'

interface ConfigErrorScreenProps {
  error: string
  apiUrl: string
}

/**
 * Fatal configuration error screen
 * Shown when app is misconfigured (e.g., HTTP in production)
 * Provides clear error message and allows copying API URL
 */
export function ConfigErrorScreen({ error, apiUrl }: ConfigErrorScreenProps) {
  const { colors } = useTheme()

  const handleCopyUrl = async () => {
    await Clipboard.setStringAsync(apiUrl)
    Alert.alert('Copied', `API URL copied to clipboard:\n${apiUrl}`)
  }

  const handleCopyError = async () => {
    await Clipboard.setStringAsync(error)
    Alert.alert('Copied', 'Error message copied to clipboard')
  }

  return (
    <SafeAreaView
      style={[styles.container, { backgroundColor: colors.surfacePrimary }]}
      edges={['top', 'bottom']}
    >
      <View style={styles.content}>
        <PreWordmark size="medium" color={colors.contentPrimary} />

        <View style={styles.errorSection}>
          <Text style={[styles.errorIcon, { color: colors.error }]}>⚠️</Text>
          <Text style={[styles.errorTitle, { color: colors.error }]}>
            Configuration Error
          </Text>
          <Text style={[styles.errorMessage, { color: colors.contentPrimary }]}>
            {error}
          </Text>
        </View>

        <View
          style={[
            styles.infoBox,
            { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary },
          ]}
        >
          <Text style={[styles.infoLabel, { color: colors.contentSecondary }]}>
            API URL:
          </Text>
          <Text style={[styles.infoValue, { color: colors.contentPrimary }]}>
            {apiUrl}
          </Text>
          <TouchableOpacity
            onPress={handleCopyUrl}
            style={[styles.copyButton, { backgroundColor: colors.accent }]}
          >
            <Text style={[styles.copyButtonText, { color: colors.contentInverse }]}>
              Copy URL
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.fixSection}>
          <Text style={[styles.fixTitle, { color: colors.contentPrimary }]}>
            How to Fix:
          </Text>
          <View style={styles.fixSteps}>
            <Text style={[styles.fixStep, { color: colors.contentSecondary }]}>
              1. Open <Text style={{ fontFamily: 'monospace' }}>.env</Text> file in the mobile app directory
            </Text>
            <Text style={[styles.fixStep, { color: colors.contentSecondary }]}>
              2. Update <Text style={{ fontFamily: 'monospace' }}>EXPO_PUBLIC_API_URL</Text> to use HTTPS
            </Text>
            <Text style={[styles.fixStep, { color: colors.contentSecondary }]}>
              3. Example: <Text style={{ fontFamily: 'monospace' }}>https://app.presocial.app</Text>
            </Text>
            <Text style={[styles.fixStep, { color: colors.contentSecondary }]}>
              4. Restart the app with <Text style={{ fontFamily: 'monospace' }}>npm start -- --clear</Text>
            </Text>
          </View>
        </View>

        <View style={styles.noteSection}>
          <Text style={[styles.noteText, { color: colors.contentTertiary }]}>
            For local development, set{' '}
            <Text style={{ fontFamily: 'monospace' }}>EXPO_PUBLIC_APP_ENV=development</Text> to allow HTTP.
          </Text>
        </View>

        <TouchableOpacity onPress={handleCopyError} style={styles.copyErrorButton}>
          <Text style={[styles.copyErrorText, { color: colors.contentTertiary }]}>
            Copy error message
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    padding: Spacing.lg,
    justifyContent: 'center',
    gap: Spacing.xl,
  },
  errorSection: {
    alignItems: 'center',
    gap: Spacing.sm,
  },
  errorIcon: {
    fontSize: 48,
    marginBottom: Spacing.sm,
  },
  errorTitle: {
    fontSize: Typography.title,
    fontWeight: Typography.medium,
  },
  errorMessage: {
    fontSize: Typography.body,
    textAlign: 'center',
    marginTop: Spacing.sm,
  },
  infoBox: {
    padding: Spacing.base,
    borderRadius: 12,
    borderWidth: 1,
    gap: Spacing.sm,
  },
  infoLabel: {
    fontSize: Typography.caption,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  infoValue: {
    fontSize: Typography.callout,
    fontFamily: 'monospace',
  },
  copyButton: {
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.base,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: Spacing.xs,
  },
  copyButtonText: {
    fontSize: Typography.callout,
    fontWeight: Typography.medium,
  },
  fixSection: {
    gap: Spacing.md,
  },
  fixTitle: {
    fontSize: Typography.headline,
    fontWeight: Typography.medium,
  },
  fixSteps: {
    gap: Spacing.sm,
  },
  fixStep: {
    fontSize: Typography.callout,
    lineHeight: Typography.lineHeightRelaxed * Typography.callout,
  },
  noteSection: {
    marginTop: Spacing.md,
  },
  noteText: {
    fontSize: Typography.caption,
    textAlign: 'center',
    lineHeight: Typography.lineHeightRelaxed * Typography.caption,
  },
  copyErrorButton: {
    alignItems: 'center',
    paddingVertical: Spacing.sm,
  },
  copyErrorText: {
    fontSize: Typography.caption,
    textDecorationLine: 'underline',
  },
})
