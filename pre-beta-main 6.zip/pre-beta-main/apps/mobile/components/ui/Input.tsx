import React, { useState } from 'react'
import {
  View,
  TextInput,
  Text,
  StyleSheet,
  TextInputProps,
  TouchableOpacity,
} from 'react-native'
import { useTheme } from '@/contexts/ThemeContext'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

interface InputProps extends TextInputProps {
  label?: string
  error?: string
  helperText?: string
  showPasswordToggle?: boolean
}

export function Input({
  label,
  error,
  helperText,
  showPasswordToggle,
  secureTextEntry,
  style,
  ...props
}: InputProps) {
  const { colors } = useTheme()
  const [isSecure, setIsSecure] = useState(secureTextEntry)

  return (
    <View style={styles.container}>
      {label && (
        <Text style={[styles.label, { color: colors.contentPrimary }]}>
          {label}
        </Text>
      )}
      <View style={styles.inputWrapper}>
        <TextInput
          style={[
            styles.input,
            {
              backgroundColor: colors.surfacePrimary,
              borderColor: error ? colors.error : colors.borderSecondary,
              color: colors.contentPrimary,
            },
            style,
          ]}
          placeholderTextColor={colors.contentTertiary}
          secureTextEntry={isSecure}
          {...props}
        />
        {showPasswordToggle && secureTextEntry && (
          <TouchableOpacity
            onPress={() => setIsSecure(!isSecure)}
            style={styles.passwordToggle}
          >
            <Text style={{ color: colors.contentSecondary, fontSize: 12 }}>
              {isSecure ? 'Show' : 'Hide'}
            </Text>
          </TouchableOpacity>
        )}
      </View>
      {error && <Text style={[styles.error, { color: colors.error }]}>{error}</Text>}
      {helperText && !error && (
        <Text style={[styles.helper, { color: colors.contentTertiary }]}>
          {helperText}
        </Text>
      )}
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.md,
  },
  label: {
    fontSize: Typography.callout,
    fontWeight: Typography.medium,
    marginBottom: Spacing.sm,
  },
  inputWrapper: {
    position: 'relative',
  },
  input: {
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    fontSize: Typography.body,
  },
  passwordToggle: {
    position: 'absolute',
    right: Spacing.base,
    top: '50%',
    transform: [{ translateY: -10 }],
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
  },
  error: {
    fontSize: Typography.caption,
    marginTop: Spacing.xs,
  },
  helper: {
    fontSize: Typography.caption,
    marginTop: Spacing.xs,
  },
})
