import React, { createContext, useContext, useEffect, useState } from 'react'
import { Platform } from 'react-native'
import { Session, User } from '@supabase/supabase-js'
import * as Notifications from 'expo-notifications'
import Constants from 'expo-constants'
import { supabase } from '@/lib/supabase'
import { Profile } from '@/types/database'

interface AuthContextType {
  user: User | null
  session: Session | null
  profile: Profile | null
  loading: boolean
  initialized: boolean
  profileLoaded: boolean
  signIn: (email: string, password: string) => Promise<{ error?: Error }>
  signUp: (email: string, password: string) => Promise<{ error?: Error }>
  signInWithApple: () => Promise<{ error?: Error }>
  signOut: () => Promise<void>
  refreshProfile: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)
  const [initialized, setInitialized] = useState(false)
  const [profileLoaded, setProfileLoaded] = useState(false)

  // ─── Push token registration ───────────────────────────────────────────────
  // Called after sign-in. Requests permission, gets the Expo Push Token, and
  // upserts it to `push_tokens`. Silently no-ops in Expo Go / simulators.
  const registerPushToken = async (userId: string) => {
    if (Platform.OS !== 'ios' && Platform.OS !== 'android') return

    try {
      const { status: existingStatus } = await Notifications.getPermissionsAsync()
      let finalStatus = existingStatus

      if (existingStatus !== 'granted') {
        const { status } = await Notifications.requestPermissionsAsync()
        finalStatus = status
      }

      if (finalStatus !== 'granted') return

      const projectId = Constants.expoConfig?.extra?.eas?.projectId
      if (!projectId) return // no-op in plain Expo Go without an EAS project

      const { data: tokenData } = await Notifications.getExpoPushTokenAsync({ projectId })

      await supabase.from('push_tokens').upsert(
        { user_id: userId, token: tokenData, platform: Platform.OS, updated_at: new Date().toISOString() },
        { onConflict: 'user_id' },
      )
    } catch {
      // Push token registration is best-effort — never crash the auth flow
    }
  }

  const fetchProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single()

      if (error) throw error
      setProfile(data)
      setProfileLoaded(true)
    } catch (error) {
      console.error('Error fetching profile:', error)
      setProfile(null)
      setProfileLoaded(true)
    }
  }

  const refreshProfile = async () => {
    if (user) {
      await fetchProfile(user.id)
    }
  }

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
      setUser(session?.user ?? null)
      setInitialized(true)

      if (session?.user) {
        fetchProfile(session.user.id)
      } else {
        setLoading(false)
        setProfileLoaded(true)
      }
    })

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session)
      setUser(session?.user ?? null)

      if (session?.user) {
        fetchProfile(session.user.id)
        if (event === 'SIGNED_IN') {
          registerPushToken(session.user.id)
        }
      } else {
        setProfile(null)
        setProfileLoaded(true)
        setLoading(false)
      }
    })

    return () => {
      subscription.unsubscribe()
    }
  }, [])

  useEffect(() => {
    if (initialized && profileLoaded) {
      setLoading(false)
    }
  }, [initialized, profileLoaded])

  const signIn = async (email: string, password: string) => {
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password })
      if (error) return { error }
      return {}
    } catch (error) {
      return { error: error as Error }
    }
  }

  const signUp = async (email: string, password: string) => {
    try {
      const { error } = await supabase.auth.signUp({ email, password })
      if (error) return { error }
      return {}
    } catch (error) {
      return { error: error as Error }
    }
  }

  // Native Sign in with Apple — iOS only.
  // Prerequisites:
  //   1. "Sign in with Apple" capability on App ID com.pre.social ✅ already done
  //   2. Apple provider in Supabase Dashboard → Auth → Providers → Apple
  //      Client ID     = com.pre-service.social  (Service ID, covers both web + native)
  //      Key ID        = HKJS4KV24G
  //      Team ID       = 3J5TREERRZ
  //      Secret key    = contents of the downloaded .p8 file
  const signInWithApple = async (): Promise<{ error?: Error }> => {
    if (Platform.OS !== 'ios') {
      return { error: new Error('Sign in with Apple is only available on iOS') }
    }

    try {
      const [AppleAuth, Crypto] = await Promise.all([
        import('expo-apple-authentication'),
        import('expo-crypto'),
      ])

      // Nonce prevents replay attacks.
      // We hash it before sending to Apple; Supabase receives the raw value.
      const rawNonce = Math.random().toString(36).substring(2, 18)
      const hashedNonce = await Crypto.digestStringAsync(
        Crypto.CryptoDigestAlgorithm.SHA256,
        rawNonce
      )

      const credential = await AppleAuth.signInAsync({
        requestedScopes: [
          AppleAuth.AppleAuthenticationScope.FULL_NAME,
          AppleAuth.AppleAuthenticationScope.EMAIL,
        ],
        nonce: hashedNonce,
      })

      if (!credential.identityToken) {
        return { error: new Error('Apple did not return an identity token') }
      }

      const { error } = await supabase.auth.signInWithIdToken({
        provider: 'apple',
        token: credential.identityToken,
        nonce: rawNonce,
      })

      if (error) return { error }
      return {}
    } catch (err: any) {
      if (err?.code === 'ERR_REQUEST_CANCELED') {
        return { error: new Error('cancelled') }
      }
      return { error: err instanceof Error ? err : new Error(String(err)) }
    }
  }

  const signOut = async () => {
    await supabase.auth.signOut()
    setProfile(null)
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        profile,
        loading,
        initialized,
        profileLoaded,
        signIn,
        signUp,
        signInWithApple,
        signOut,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
