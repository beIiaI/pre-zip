/**
 * API client for calling Next.js API routes
 * All privileged operations (email sending, admin actions) go through these endpoints
 * 
 * Cloud-first: Defaults to https://app.presocial.app (production)
 * Local override: Set EXPO_PUBLIC_API_URL for local testing
 */

const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL

// Runtime validation - API_BASE_URL is required
if (!API_BASE_URL) {
  throw new Error(
    'EXPO_PUBLIC_API_URL is required but not set.\n\n' +
    'Please configure .env file with:\n' +
    'EXPO_PUBLIC_API_URL=https://app.presocial.app\n\n' +
    'For local testing:\n' +
    'EXPO_PUBLIC_API_URL=http://YOUR_LAN_IP:3000'
  )
}

// Validate API URL is HTTPS in production (returns error instead of throwing)
export function validateApiConfig(): { valid: boolean; error?: string } {
  if (!API_BASE_URL) {
    return {
      valid: false,
      error: 'EXPO_PUBLIC_API_URL environment variable is not set.\n\nPlease add it to your .env file.',
    }
  }

  if (process.env.EXPO_PUBLIC_APP_ENV === 'production' && !API_BASE_URL.startsWith('https://')) {
    return {
      valid: false,
      error: `API URL must use HTTPS in production mode.\n\nCurrent: ${API_BASE_URL}\nExpected: https://app.presocial.app\n\nHTTP connections are insecure and not allowed in production builds.`,
    }
  }
  return { valid: true }
}

interface ApiOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH'
  body?: any
  headers?: Record<string, string>
  timeout?: number
}

interface ApiError {
  message: string
  code: 'NETWORK_ERROR' | 'TIMEOUT' | 'SERVER_ERROR' | 'INVALID_RESPONSE'
  statusCode?: number
}

export async function apiRequest<T = any>(
  endpoint: string,
  options: ApiOptions = {}
): Promise<{ data?: T; error?: string; apiError?: ApiError }> {
  const { method = 'GET', body, headers = {}, timeout = 30000 } = options

  // Validate endpoint starts with /
  if (!endpoint.startsWith('/')) {
    return {
      error: 'Invalid endpoint. Must start with /',
      apiError: {
        message: 'Invalid endpoint format',
        code: 'INVALID_RESPONSE',
      },
    }
  }

  const url = `${API_BASE_URL}${endpoint}`

  try {
    // Create abort controller for timeout
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), timeout)

    const response = await fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
      body: body ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    })

    clearTimeout(timeoutId)

    let data: any
    try {
      data = await response.json()
    } catch {
      data = {}
    }

    if (!response.ok) {
      const errorMessage = data?.error || data?.message || `Request failed with status ${response.status}`
      return {
        error: errorMessage,
        apiError: {
          message: errorMessage,
          code: response.status >= 500 ? 'SERVER_ERROR' : 'INVALID_RESPONSE',
          statusCode: response.status,
        },
      }
    }

    return { data }
  } catch (error) {
    // Network error or timeout
    if (error instanceof Error) {
      if (error.name === 'AbortError') {
        return {
          error: `Request timed out after ${timeout / 1000}s. Check your internet connection or API URL.`,
          apiError: {
            message: 'Request timeout',
            code: 'TIMEOUT',
          },
        }
      }

      // DNS/network failure
      if (error.message.includes('Network') || error.message.includes('Failed to fetch')) {
        return {
          error: `Cannot reach API server at ${API_BASE_URL}. Check:\n1. Internet connection\n2. API URL is correct\n3. Server is running`,
          apiError: {
            message: `Cannot reach ${API_BASE_URL}`,
            code: 'NETWORK_ERROR',
          },
        }
      }

      return {
        error: error.message,
        apiError: {
          message: error.message,
          code: 'NETWORK_ERROR',
        },
      }
    }

    return {
      error: 'Network request failed. Please check your connection.',
      apiError: {
        message: 'Unknown network error',
        code: 'NETWORK_ERROR',
      },
    }
  }
}

// Health check endpoint
export async function checkApiHealth(): Promise<{ reachable: boolean; message: string }> {
  try {
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 5000)

    const response = await fetch(`${API_BASE_URL}/api/health`, {
      method: 'GET',
      signal: controller.signal,
    })

    clearTimeout(timeoutId)

    if (response.ok) {
      return { reachable: true, message: 'API is reachable' }
    } else {
      return { reachable: false, message: `API returned ${response.status}` }
    }
  } catch (error) {
    if (error instanceof Error && error.name === 'AbortError') {
      return { reachable: false, message: 'API health check timed out' }
    }
    return { reachable: false, message: `Cannot reach ${API_BASE_URL}` }
  }
}

// Get API base URL (for display in UI)
export function getApiBaseUrl(): string {
  return API_BASE_URL
}

// Invite validation
export const validateInvite = (code: string, email: string) =>
  apiRequest('/api/invites/validate', {
    method: 'POST',
    body: { code, email },
  })

// Invite claim
export const claimInvite = (code: string, email: string) =>
  apiRequest('/api/invites/claim', {
    method: 'POST',
    body: { code, email },
  })

// Access request
export const requestAccess = (email: string, note?: string) =>
  apiRequest('/api/access/apply', {
    method: 'POST',
    body: { email, note },
  })

// University verification request
export const requestUniversityVerification = (email: string) =>
  apiRequest('/api/verification/university/request', {
    method: 'POST',
    body: { email },
  })

// Password reset request
export const requestPasswordReset = (email: string) =>
  apiRequest('/api/auth/password/forgot', {
    method: 'POST',
    body: { email },
  })
