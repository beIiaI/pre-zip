import React, { useState, useCallback, useEffect, useRef } from 'react'
import {
  View,
  Text,
  FlatList,
  Pressable,
  StyleSheet,
  ActivityIndicator,
  Image,
  TextInput,
  KeyboardAvoidingView,
  Platform,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useLocalSearchParams, useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

// ─── Types ────────────────────────────────────────────────────────────────────

interface Message {
  id: string
  body: string
  sender_id: string
  created_at: string
}

interface OtherUser {
  id: string
  full_name: string | null
  username: string | null
  avatar_url: string | null
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getInitials(name: string | null, username: string | null): string {
  if (name) return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
  if (username) return username[0].toUpperCase()
  return '?'
}

function formatMessageTime(iso: string): string {
  const d = new Date(iso)
  const now = new Date()
  const isToday = d.toDateString() === now.toDateString()
  if (isToday) return d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) +
    ' ' + d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function ConversationScreen() {
  const { id: threadId } = useLocalSearchParams<{ id: string }>()
  const router = useRouter()
  const { colors } = useTheme()
  const { user } = useAuth()

  const [messages, setMessages] = useState<Message[]>([])
  const [otherUser, setOtherUser] = useState<OtherUser | null>(null)
  const [loading, setLoading] = useState(true)
  const [draft, setDraft] = useState('')
  const [sending, setSending] = useState(false)
  const flatListRef = useRef<FlatList>(null)

  // ─── Load thread ───────────────────────────────────────────────────────────

  const loadThread = useCallback(async () => {
    if (!user || !threadId) return

    // Get other user
    const { data: thread } = await supabase
      .from('dm_threads')
      .select('id, user_a, user_b')
      .eq('id', threadId)
      .single()

    if (thread) {
      const otherId = thread.user_a === user.id ? thread.user_b : thread.user_a
      if (otherId) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('id, full_name, username, avatar_url')
          .eq('id', otherId)
          .single()
        if (profile) setOtherUser(profile)
      }
    }

    // Get messages (oldest first for display, FlatList is inverted)
    const { data: msgs } = await supabase
      .from('dm_messages')
      .select('id, body, sender_id, created_at')
      .eq('thread_id', threadId)
      .order('created_at', { ascending: false })
      .limit(100)

    if (msgs) setMessages(msgs)
    setLoading(false)

    // Mark thread as read
    await supabase
      .from('dm_participants')
      .update({ last_read_at: new Date().toISOString() })
      .match({ thread_id: threadId, user_id: user.id })
  }, [user, threadId])

  useEffect(() => { loadThread() }, [loadThread])

  // ─── Realtime subscription ─────────────────────────────────────────────────

  useEffect(() => {
    if (!threadId) return

    const channel = supabase
      .channel(`thread:${threadId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'dm_messages',
          filter: `thread_id=eq.${threadId}`,
        },
        (payload) => {
          const newMsg = payload.new as Message
          setMessages(prev => {
            // Avoid duplicates (we optimistically insert before the event arrives)
            if (prev.some(m => m.id === newMsg.id)) return prev
            return [newMsg, ...prev]
          })
          // Mark as read if message is from the other user
          if (newMsg.sender_id !== user?.id) {
            supabase
              .from('dm_participants')
              .update({ last_read_at: new Date().toISOString() })
              .match({ thread_id: threadId, user_id: user?.id })
          }
        }
      )
      .subscribe()

    return () => { supabase.removeChannel(channel) }
  }, [threadId, user?.id])

  // ─── Send ──────────────────────────────────────────────────────────────────

  const handleSend = async () => {
    const body = draft.trim()
    if (!body || !user || !threadId || sending) return

    setSending(true)
    setDraft('')
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)

    // Optimistic insert
    const optimisticId = `optimistic-${Date.now()}`
    const optimistic: Message = {
      id: optimisticId,
      body,
      sender_id: user.id,
      created_at: new Date().toISOString(),
    }
    setMessages(prev => [optimistic, ...prev])

    const { data, error } = await supabase
      .from('dm_messages')
      .insert({ thread_id: threadId, sender_id: user.id, body })
      .select('id, body, sender_id, created_at')
      .single()

    setSending(false)

    if (error) {
      // Roll back optimistic message
      setMessages(prev => prev.filter(m => m.id !== optimisticId))
      setDraft(body)
    } else if (data) {
      // Replace optimistic with real
      setMessages(prev => prev.map(m => m.id === optimisticId ? data : m))
    }
  }

  // ─── Render ────────────────────────────────────────────────────────────────

  const renderMessage = ({ item, index }: { item: Message; index: number }) => {
    const isMine = item.sender_id === user?.id
    const prevItem = messages[index + 1] // older (list is inverted)
    const showTime = !prevItem ||
      new Date(prevItem.created_at).getTime() < new Date(item.created_at).getTime() - 5 * 60_000

    return (
      <View style={[styles.msgOuter, isMine ? styles.msgOuterMine : styles.msgOuterTheirs]}>
        {showTime && (
          <Text style={[styles.msgTime, { color: colors.contentTertiary }]}>
            {formatMessageTime(item.created_at)}
          </Text>
        )}
        <View
          style={[
            styles.bubble,
            isMine
              ? [styles.bubbleMine, { backgroundColor: colors.contentPrimary }]
              : [styles.bubbleTheirs, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }],
          ]}
        >
          <Text style={[styles.bubbleText, { color: isMine ? colors.contentInverse : colors.contentPrimary }]}>
            {item.body}
          </Text>
        </View>
      </View>
    )
  }

  const initials = getInitials(otherUser?.full_name ?? null, otherUser?.username ?? null)

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
        <Pressable onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
        </Pressable>

        <View style={styles.headerUser}>
          {otherUser?.avatar_url ? (
            <Image source={{ uri: otherUser.avatar_url }} style={styles.headerAvatar} />
          ) : (
            <View style={[styles.headerAvatar, styles.headerAvatarFallback, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
              <Text style={[styles.headerAvatarText, { color: colors.contentPrimary }]}>{initials}</Text>
            </View>
          )}
          <View>
            <Text style={[styles.headerName, { color: colors.contentPrimary }]} numberOfLines={1}>
              {otherUser?.full_name || otherUser?.username || '…'}
            </Text>
            {otherUser?.username && (
              <Text style={[styles.headerUsername, { color: colors.contentSecondary }]}>
                @{otherUser.username}
              </Text>
            )}
          </View>
        </View>
      </View>

      {/* Messages */}
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={0}
      >
        {loading ? (
          <View style={styles.centered}>
            <ActivityIndicator color={colors.contentTertiary} />
          </View>
        ) : (
          <FlatList
            ref={flatListRef}
            data={messages}
            keyExtractor={item => item.id}
            renderItem={renderMessage}
            inverted
            contentContainerStyle={styles.listContent}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
              <View style={styles.emptyCentered}>
                <Text style={[styles.emptyText, { color: colors.contentTertiary }]}>
                  Start the conversation
                </Text>
              </View>
            }
          />
        )}

        {/* Input bar */}
        <View style={[styles.inputBar, { borderTopColor: colors.borderSecondary, backgroundColor: colors.surfacePrimary }]}>
          <TextInput
            value={draft}
            onChangeText={setDraft}
            placeholder="Message…"
            placeholderTextColor={colors.contentTertiary}
            style={[
              styles.inputField,
              {
                color: colors.contentPrimary,
                backgroundColor: colors.surfaceSecondary,
                borderColor: colors.borderSecondary,
              },
            ]}
            multiline
            maxLength={2000}
            onSubmitEditing={handleSend}
            blurOnSubmit={false}
          />
          <Pressable
            onPress={handleSend}
            disabled={!draft.trim() || sending}
            style={[
              styles.sendButton,
              {
                backgroundColor: draft.trim() ? colors.contentPrimary : colors.surfaceElevated,
              },
            ]}
          >
            {sending ? (
              <ActivityIndicator size="small" color={colors.contentInverse} />
            ) : (
              <Ionicons
                name="arrow-up"
                size={18}
                color={draft.trim() ? colors.contentInverse : colors.contentTertiary}
              />
            )}
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1 },
  flex: { flex: 1 },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.sm,
    borderBottomWidth: 1,
    gap: Spacing.sm,
  },
  backButton: { width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },
  headerUser: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, flex: 1 },
  headerAvatar: { width: 36, height: 36, borderRadius: 18 },
  headerAvatarFallback: { borderWidth: 1, justifyContent: 'center', alignItems: 'center' },
  headerAvatarText: { fontSize: 13, fontWeight: '600' },
  headerName: { fontSize: Typography.callout, fontWeight: '600', maxWidth: 200 },
  headerUsername: { fontSize: Typography.caption },

  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  listContent: { paddingHorizontal: Spacing.base, paddingVertical: Spacing.md, gap: 2 },

  emptyCentered: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: Spacing.xl },
  emptyText: { fontSize: Typography.callout },

  msgOuter: { marginVertical: 2 },
  msgOuterMine: { alignItems: 'flex-end' },
  msgOuterTheirs: { alignItems: 'flex-start' },
  msgTime: { fontSize: 11, textAlign: 'center', marginVertical: Spacing.sm, width: '100%' },

  bubble: { maxWidth: '78%', paddingHorizontal: 14, paddingVertical: 10, borderRadius: 18 },
  bubbleMine: { borderBottomRightRadius: 4 },
  bubbleTheirs: { borderWidth: 1, borderBottomLeftRadius: 4 },
  bubbleText: { fontSize: Typography.callout, lineHeight: Typography.callout * 1.45 },

  inputBar: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: Spacing.sm,
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.sm,
    borderTopWidth: 1,
  },
  inputField: {
    flex: 1,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    paddingHorizontal: Spacing.md,
    paddingVertical: 10,
    fontSize: Typography.callout,
    maxHeight: 120,
  },
  sendButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 2,
  },
})
