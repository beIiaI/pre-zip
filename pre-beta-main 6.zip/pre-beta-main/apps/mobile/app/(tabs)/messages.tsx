import React, { useState, useCallback, useEffect } from 'react'
import {
  View,
  Text,
  FlatList,
  Pressable,
  StyleSheet,
  RefreshControl,
  ActivityIndicator,
  Image,
  TextInput,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

// ─── Types ────────────────────────────────────────────────────────────────────

interface OtherUser {
  id: string
  full_name: string | null
  username: string | null
  avatar_url: string | null
}

interface Thread {
  id: string
  otherUser: OtherUser | null
  lastMessage: { body: string; sender_id: string; created_at: string } | null
  hasUnread: boolean
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getInitials(name: string | null, username: string | null): string {
  if (name) return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
  if (username) return username[0].toUpperCase()
  return '?'
}

function formatTime(iso: string): string {
  const d = new Date(iso)
  const now = new Date()
  const diffMs = now.getTime() - d.getTime()
  const diffDays = Math.floor(diffMs / 86400000)

  if (diffDays === 0) return d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
  if (diffDays === 1) return 'Yesterday'
  if (diffDays < 7) return d.toLocaleDateString('en-US', { weekday: 'short' })
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function MessagesScreen() {
  const router = useRouter()
  const { colors } = useTheme()
  const { user } = useAuth()

  const [threads, setThreads] = useState<Thread[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [search, setSearch] = useState('')

  const fetchThreads = useCallback(async (refresh = false) => {
    if (!user) return
    if (refresh) setRefreshing(true)
    else setLoading(true)

    // 1. Get all threads I'm part of
    const { data: rawThreads } = await supabase
      .from('dm_threads')
      .select('id, user_a, user_b')
      .or(`user_a.eq.${user.id},user_b.eq.${user.id}`)
      .limit(50)

    if (!rawThreads || rawThreads.length === 0) {
      setThreads([])
      setLoading(false)
      setRefreshing(false)
      return
    }

    const threadIds = rawThreads.map(t => t.id)
    const otherUserIds = rawThreads
      .map(t => (t.user_a === user.id ? t.user_b : t.user_a))
      .filter(Boolean) as string[]

    // 2. Fetch in parallel: other user profiles, last messages, my read timestamps
    const [profilesRes, messagesRes, participationsRes] = await Promise.all([
      supabase
        .from('profiles')
        .select('id, full_name, username, avatar_url')
        .in('id', otherUserIds),
      supabase
        .from('dm_messages')
        .select('id, thread_id, body, sender_id, created_at')
        .in('thread_id', threadIds)
        .order('created_at', { ascending: false })
        .limit(threadIds.length * 5),
      supabase
        .from('dm_participants')
        .select('thread_id, last_read_at')
        .eq('user_id', user.id)
        .in('thread_id', threadIds),
    ])

    const profileMap = new Map(profilesRes.data?.map(p => [p.id, p]) ?? [])
    const lastReadMap = new Map(participationsRes.data?.map(p => [p.thread_id, p.last_read_at]) ?? [])

    // Pick the latest message per thread
    const lastMsgMap = new Map<string, { body: string; sender_id: string; created_at: string }>()
    for (const msg of messagesRes.data ?? []) {
      if (!lastMsgMap.has(msg.thread_id)) {
        lastMsgMap.set(msg.thread_id, { body: msg.body, sender_id: msg.sender_id, created_at: msg.created_at })
      }
    }

    const assembled: Thread[] = rawThreads.map(t => {
      const otherId = t.user_a === user.id ? t.user_b : t.user_a
      const lastMsg = lastMsgMap.get(t.id) ?? null
      const lastReadAt = lastReadMap.get(t.id)
      const hasUnread = !!(lastMsg && lastMsg.sender_id !== user.id &&
        (!lastReadAt || new Date(lastMsg.created_at) > new Date(lastReadAt)))

      return {
        id: t.id,
        otherUser: otherId ? (profileMap.get(otherId) ?? null) : null,
        lastMessage: lastMsg,
        hasUnread,
      }
    })

    // Sort by most recent message
    assembled.sort((a, b) => {
      const aTime = a.lastMessage?.created_at ?? ''
      const bTime = b.lastMessage?.created_at ?? ''
      return bTime.localeCompare(aTime)
    })

    setThreads(assembled)
    setLoading(false)
    setRefreshing(false)
  }, [user])

  useEffect(() => { fetchThreads() }, [fetchThreads])

  const filtered = search.trim()
    ? threads.filter(t => {
        const name = (t.otherUser?.full_name ?? '').toLowerCase()
        const uname = (t.otherUser?.username ?? '').toLowerCase()
        const q = search.toLowerCase()
        return name.includes(q) || uname.includes(q)
      })
    : threads

  // ─── Render ──────────────────────────────────────────────────────────────────

  const renderThread = ({ item }: { item: Thread }) => {
    const other = item.otherUser
    const initials = getInitials(other?.full_name ?? null, other?.username ?? null)

    return (
      <Pressable
        style={({ pressed }) => [
          styles.threadRow,
          { borderBottomColor: colors.borderSecondary, opacity: pressed ? 0.7 : 1 },
        ]}
        onPress={() => router.push(`/conversation/${item.id}` as any)}
      >
        {/* Avatar */}
        <View style={styles.avatarWrap}>
          {other?.avatar_url ? (
            <Image source={{ uri: other.avatar_url }} style={styles.avatar} />
          ) : (
            <View style={[styles.avatar, styles.avatarFallback, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
              <Text style={[styles.avatarInitials, { color: colors.contentPrimary }]}>{initials}</Text>
            </View>
          )}
          {item.hasUnread && (
            <View style={[styles.unreadDot, { backgroundColor: colors.contentPrimary }]} />
          )}
        </View>

        {/* Content */}
        <View style={styles.threadContent}>
          <View style={styles.threadTop}>
            <Text style={[styles.threadName, { color: colors.contentPrimary, fontWeight: item.hasUnread ? '700' : '500' }]} numberOfLines={1}>
              {other?.full_name || other?.username || 'Unknown'}
            </Text>
            {item.lastMessage && (
              <Text style={[styles.threadTime, { color: colors.contentTertiary }]}>
                {formatTime(item.lastMessage.created_at)}
              </Text>
            )}
          </View>
          {item.lastMessage && (
            <Text
              style={[styles.threadPreview, { color: item.hasUnread ? colors.contentPrimary : colors.contentSecondary, fontWeight: item.hasUnread ? '500' : '400' }]}
              numberOfLines={1}
            >
              {item.lastMessage.sender_id === user?.id ? 'You: ' : ''}{item.lastMessage.body}
            </Text>
          )}
        </View>
      </Pressable>
    )
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
        <Text style={[styles.headerTitle, { color: colors.contentPrimary }]}>Messages</Text>
        <Pressable
          onPress={() => router.push('/new-message' as any)}
          style={styles.composeButton}
        >
          <Ionicons name="create-outline" size={22} color={colors.contentPrimary} />
        </Pressable>
      </View>

      {/* Search */}
      <View style={[styles.searchBar, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
        <Ionicons name="search" size={16} color={colors.contentTertiary} />
        <TextInput
          value={search}
          onChangeText={setSearch}
          placeholder="Search messages…"
          placeholderTextColor={colors.contentTertiary}
          style={[styles.searchInput, { color: colors.contentPrimary }]}
        />
        {search.length > 0 && (
          <Pressable onPress={() => setSearch('')}>
            <Ionicons name="close-circle" size={16} color={colors.contentTertiary} />
          </Pressable>
        )}
      </View>

      {/* List */}
      {loading ? (
        <View style={styles.centered}>
          <ActivityIndicator color={colors.contentTertiary} />
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={item => item.id}
          renderItem={renderThread}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => fetchThreads(true)}
              tintColor={colors.contentTertiary}
            />
          }
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <Ionicons name="chatbubble-outline" size={40} color={colors.contentTertiary} />
              <Text style={[styles.emptyTitle, { color: colors.contentPrimary }]}>
                {search ? 'No results' : 'No messages yet'}
              </Text>
              <Text style={[styles.emptySubtitle, { color: colors.contentSecondary }]}>
                {search ? 'Try a different name.' : 'Tap the compose icon to start a conversation.'}
              </Text>
            </View>
          }
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  )
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1 },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
  },
  headerTitle: { fontSize: Typography.title, fontWeight: '700' },
  composeButton: { width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },

  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginHorizontal: Spacing.base,
    marginVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    paddingVertical: 10,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
  },
  searchInput: { flex: 1, fontSize: Typography.callout, padding: 0 },

  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },

  threadRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    gap: Spacing.md,
  },
  avatarWrap: { position: 'relative' },
  avatar: { width: 50, height: 50, borderRadius: 25 },
  avatarFallback: { borderWidth: 1, justifyContent: 'center', alignItems: 'center' },
  avatarInitials: { fontSize: 18, fontWeight: '600' },
  unreadDot: {
    position: 'absolute',
    bottom: 1,
    right: 1,
    width: 12,
    height: 12,
    borderRadius: 6,
  },

  threadContent: { flex: 1, gap: 3 },
  threadTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  threadName: { fontSize: Typography.callout, flex: 1, marginRight: Spacing.sm },
  threadTime: { fontSize: Typography.caption },
  threadPreview: { fontSize: Typography.callout },

  emptyState: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: Spacing.xl, marginTop: 80, gap: Spacing.sm },
  emptyTitle: { fontSize: Typography.headline, fontWeight: '600', textAlign: 'center' },
  emptySubtitle: { fontSize: Typography.callout, textAlign: 'center', lineHeight: Typography.callout * 1.5 },
})
