import { View, Text, StyleSheet, ScrollView, Image, Pressable } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

function getInitials(name: string | null, email: string | null | undefined): string {
  if (name) return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
  if (email) return email[0].toUpperCase()
  return '?'
}

function formatMemberSince(iso: string): string {
  const d = new Date(iso)
  return d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })
}

export default function ProfileScreen() {
  const { colors } = useTheme()
  const { profile, user } = useAuth()
  const router = useRouter()

  const initials = getInitials(profile?.full_name ?? null, user?.email)

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header row */}
        <View style={styles.topRow}>
          <Text style={[styles.screenTitle, { color: colors.contentPrimary }]}>Profile</Text>
          <Pressable onPress={() => router.push('/profile/edit')} style={styles.editButton}>
            <Ionicons name="create-outline" size={20} color={colors.contentPrimary} />
            <Text style={[styles.editText, { color: colors.contentPrimary }]}>Edit</Text>
          </Pressable>
        </View>

        {/* Avatar + Name */}
        <View style={styles.heroSection}>
          <View style={styles.avatarWrap}>
            {profile?.avatar_url ? (
              <Image source={{ uri: profile.avatar_url }} style={styles.avatar} />
            ) : (
              <View style={[styles.avatar, styles.avatarFallback, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
                <Text style={[styles.avatarText, { color: colors.contentPrimary }]}>{initials}</Text>
              </View>
            )}
          </View>

          <Text style={[styles.name, { color: colors.contentPrimary }]}>
            {profile?.full_name || user?.email?.split('@')[0] || 'Your Name'}
          </Text>

          {profile?.username && (
            <View style={styles.usernameRow}>
              <Text style={[styles.username, { color: colors.contentSecondary }]}>@{profile.username}</Text>
              {profile?.is_verified && (
                <Ionicons name="checkmark-circle" size={15} color={colors.contentPrimary} style={{ marginLeft: 4 }} />
              )}
            </View>
          )}
        </View>

        {/* Badges */}
        {(profile?.early_supporter_number != null || profile?.is_founder) && (
          <View style={styles.badgesRow}>
            {profile.early_supporter_number != null && (
              <View style={[styles.badge, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
                <Ionicons name="star-outline" size={12} color={colors.contentSecondary} />
                <Text style={[styles.badgeText, { color: colors.contentSecondary }]}>
                  Early Supporter #{profile.early_supporter_number}
                </Text>
              </View>
            )}
            {profile.is_founder && profile.founder_number != null && (
              <View style={[styles.badge, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
                <Ionicons name="ribbon-outline" size={12} color={colors.contentSecondary} />
                <Text style={[styles.badgeText, { color: colors.contentSecondary }]}>
                  Founder #{profile.founder_number}
                </Text>
              </View>
            )}
          </View>
        )}

        {/* Stats row */}
        <View style={[styles.statsRow, { borderColor: colors.borderSecondary }]}>
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: colors.contentPrimary }]}>
              {(profile?.total_points ?? 0).toLocaleString()}
            </Text>
            <Text style={[styles.statLabel, { color: colors.contentTertiary }]}>Points</Text>
          </View>
          <View style={[styles.statDivider, { backgroundColor: colors.borderSecondary }]} />
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: colors.contentPrimary }]}>
              {profile?.created_at ? formatMemberSince(profile.created_at) : '—'}
            </Text>
            <Text style={[styles.statLabel, { color: colors.contentTertiary }]}>Member since</Text>
          </View>
        </View>

        {/* Bio */}
        {profile?.bio && (
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: colors.contentTertiary }]}>About</Text>
            <Text style={[styles.bioText, { color: colors.contentPrimary }]}>{profile.bio}</Text>
          </View>
        )}

        {/* Location */}
        {profile?.location && (
          <View style={[styles.detailRow, { borderTopColor: colors.borderSecondary }]}>
            <Ionicons name="location-outline" size={16} color={colors.contentTertiary} />
            <Text style={[styles.detailText, { color: colors.contentSecondary }]}>{profile.location}</Text>
          </View>
        )}

        {/* University */}
        {profile?.university_verified && profile?.university_name && profile?.show_university && (
          <View style={[styles.detailRow, { borderTopColor: colors.borderSecondary }]}>
            <Ionicons name="school-outline" size={16} color={colors.contentTertiary} />
            <Text style={[styles.detailText, { color: colors.contentSecondary }]}>{profile.university_name}</Text>
            <Ionicons name="checkmark-circle" size={13} color={colors.success} style={{ marginLeft: 4 }} />
          </View>
        )}

        {/* Interests */}
        {Array.isArray(profile?.interests) && profile.interests.length > 0 && (
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: colors.contentTertiary }]}>Interests</Text>
            <View style={styles.tagsRow}>
              {profile.interests.map((tag: string) => (
                <View key={tag} style={[styles.tag, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
                  <Text style={[styles.tagText, { color: colors.contentPrimary }]}>{tag}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Settings shortcut */}
        <Pressable
          onPress={() => router.push('/(tabs)/settings')}
          style={[styles.settingsRow, { borderColor: colors.borderSecondary }]}
        >
          <Ionicons name="settings-outline" size={18} color={colors.contentSecondary} />
          <Text style={[styles.settingsText, { color: colors.contentSecondary }]}>Settings</Text>
          <Ionicons name="chevron-forward" size={16} color={colors.contentTertiary} style={{ marginLeft: 'auto' }} />
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: {
    padding: Spacing.base,
    paddingBottom: 100,
    gap: Spacing.sm,
  },

  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: Spacing.sm,
  },
  screenTitle: { fontSize: Typography.headline, fontWeight: '700' },
  editButton: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  editText: { fontSize: Typography.callout, fontWeight: '500' },

  heroSection: { alignItems: 'center', paddingVertical: Spacing.lg, gap: Spacing.sm },
  avatarWrap: { marginBottom: Spacing.sm },
  avatar: { width: 88, height: 88, borderRadius: 44 },
  avatarFallback: { borderWidth: 1, justifyContent: 'center', alignItems: 'center' },
  avatarText: { fontSize: 34, fontWeight: '600' },
  name: { fontSize: Typography.title, fontWeight: '700', textAlign: 'center' },
  usernameRow: { flexDirection: 'row', alignItems: 'center' },
  username: { fontSize: Typography.body },

  badgesRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
  badgeText: { fontSize: Typography.caption },

  statsRow: {
    flexDirection: 'row',
    borderWidth: 1,
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
    marginVertical: Spacing.sm,
  },
  statItem: { flex: 1, alignItems: 'center', paddingVertical: Spacing.base },
  statValue: { fontSize: Typography.callout, fontWeight: '600' },
  statLabel: { fontSize: Typography.caption, marginTop: 2 },
  statDivider: { width: 1 },

  section: { paddingVertical: Spacing.base, gap: Spacing.sm },
  sectionTitle: {
    fontSize: Typography.caption,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
  },
  bioText: { fontSize: Typography.body, lineHeight: Typography.body * 1.5 },

  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.md,
    borderTopWidth: 1,
  },
  detailText: { fontSize: Typography.callout },

  tagsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  tag: {
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
  tagText: { fontSize: Typography.caption },

  settingsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    paddingVertical: Spacing.base,
    borderWidth: 1,
    borderRadius: BorderRadius.lg,
    paddingHorizontal: Spacing.base,
    marginTop: Spacing.base,
  },
  settingsText: { fontSize: Typography.callout },
})
