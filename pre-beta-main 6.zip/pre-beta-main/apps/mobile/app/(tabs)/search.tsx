import React, { useState, useCallback, useRef, useEffect } from 'react'
import {
  View,
  Text,
  FlatList,
  Pressable,
  StyleSheet,
  ActivityIndicator,
  Image,
  TextInput,
  SectionList,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

// ─── Types ────────────────────────────────────────────────────────────────────

interface PersonResult {
  id: string
  full_name: string | null
  username: string | null
  avatar_url: string | null
  bio: string | null
  is_verified: boolean
  early_supporter_number: number | null
  _type: 'person'
}

interface CircleResult {
  id: string
  name: string
  description: string | null
  category: string | null
  member_count: number
  _type: 'circle'
}

interface EventResult {
  id: string
  title: string
  description: string | null
  starts_at: string
  location_text: string | null
  location: string
  attendee_count: number
  _type: 'event'
}

type AnyResult = PersonResult | CircleResult | EventResult

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getInitials(name: string | null, username: string | null): string {
  if (name) return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
  if (username) return username[0].toUpperCase()
  return '?'
}

function formatEventDate(iso: string): string {
  const d = new Date(iso)
  const now = new Date()
  const tomorrow = new Date(now); tomorrow.setDate(now.getDate() + 1)
  const isToday = d.toDateString() === now.toDateString()
  const isTomorrow = d.toDateString() === tomorrow.toDateString()
  const time = d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
  if (isToday) return `Today · ${time}`
  if (isTomorrow) return `Tomorrow · ${time}`
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) + ` · ${time}`
}

// ─── Avatar ───────────────────────────────────────────────────────────────────

function Avatar({ uri, name, username, size = 40, colors }: {
  uri: string | null; name: string | null; username: string | null; size?: number; colors: any
}) {
  if (uri) return <Image source={{ uri }} style={{ width: size, height: size, borderRadius: size / 2 }} />
  return (
    <View style={{
      width: size, height: size, borderRadius: size / 2,
      backgroundColor: colors.surfaceElevated, borderWidth: 1, borderColor: colors.borderPrimary,
      justifyContent: 'center', alignItems: 'center',
    }}>
      <Text style={{ fontSize: size * 0.35, color: colors.contentPrimary, fontWeight: '600' }}>
        {getInitials(name, username)}
      </Text>
    </View>
  )
}

// ─── Trending / Suggested defaults ────────────────────────────────────────────

function useSuggested(user: any) {
  const [circles, setCircles] = useState<CircleResult[]>([])
  const [events, setEvents] = useState<EventResult[]>([])
  const [people, setPeople] = useState<PersonResult[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) return
    Promise.all([
      supabase.from('circles').select('id, name, description, category, member_count').eq('is_public', true).order('member_count', { ascending: false }).limit(5),
      supabase.from('events').select('id, title, description, starts_at, location, location_text, attendee_count').eq('is_public', true).gte('starts_at', new Date().toISOString()).order('starts_at', { ascending: true }).limit(4),
      supabase.from('profiles').select('id, full_name, username, avatar_url, bio, is_verified, early_supporter_number').neq('id', user.id).eq('onboarding_completed', true).order('total_points', { ascending: false }).limit(5),
    ]).then(([c, e, p]) => {
      setCircles((c.data ?? []).map(x => ({ ...x, _type: 'circle' as const })))
      setEvents((e.data ?? []).map(x => ({ ...x, _type: 'event' as const })))
      setPeople((p.data ?? []).map(x => ({ ...x, _type: 'person' as const })))
      setLoading(false)
    })
  }, [user])

  return { circles, events, people, loading }
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function SearchScreen() {
  const router = useRouter()
  const { colors } = useTheme()
  const { user } = useAuth()

  const [query, setQuery] = useState('')
  const [results, setResults] = useState<{ people: PersonResult[]; circles: CircleResult[]; events: EventResult[] }>({
    people: [], circles: [], events: [],
  })
  const [searching, setSearching] = useState(false)
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const inputRef = useRef<TextInput>(null)
  const { circles: sugCircles, events: sugEvents, people: sugPeople, loading: sugLoading } = useSuggested(user)

  const doSearch = useCallback(async (q: string) => {
    if (!user || !q.trim()) {
      setResults({ people: [], circles: [], events: [] })
      setSearching(false)
      return
    }
    setSearching(true)
    const term = q.trim()

    const [peopleRes, circlesRes, eventsRes] = await Promise.all([
      supabase
        .from('profiles')
        .select('id, full_name, username, avatar_url, bio, is_verified, early_supporter_number')
        .neq('id', user.id)
        .or(`full_name.ilike.%${term}%,username.ilike.%${term}%`)
        .eq('onboarding_completed', true)
        .limit(10),
      supabase
        .from('circles')
        .select('id, name, description, category, member_count')
        .eq('is_public', true)
        .or(`name.ilike.%${term}%,description.ilike.%${term}%,category.ilike.%${term}%`)
        .limit(8),
      supabase
        .from('events')
        .select('id, title, description, starts_at, location, location_text, attendee_count')
        .eq('is_public', true)
        .or(`title.ilike.%${term}%,description.ilike.%${term}%`)
        .limit(6),
    ])

    setResults({
      people: (peopleRes.data ?? []).map(x => ({ ...x, _type: 'person' })),
      circles: (circlesRes.data ?? []).map(x => ({ ...x, _type: 'circle' })),
      events: (eventsRes.data ?? []).map(x => ({ ...x, _type: 'event' })),
    })
    setSearching(false)
  }, [user])

  const handleQueryChange = (text: string) => {
    setQuery(text)
    if (debounceRef.current) clearTimeout(debounceRef.current)
    if (!text.trim()) {
      setResults({ people: [], circles: [], events: [] })
      setSearching(false)
      return
    }
    setSearching(true)
    debounceRef.current = setTimeout(() => doSearch(text), 300)
  }

  const clearSearch = () => {
    setQuery('')
    setResults({ people: [], circles: [], events: [] })
    inputRef.current?.focus()
  }

  const hasResults = query.trim().length > 0
  const totalResults = results.people.length + results.circles.length + results.events.length

  // ─── Result renderers ────────────────────────────────────────────────────────

  const renderPerson = (item: PersonResult) => (
    <Pressable
      key={item.id}
      onPress={() => { Haptics.selectionAsync(); router.push(`/user/${item.id}` as any) }}
      style={[styles.resultRow, { borderBottomColor: colors.borderSecondary }]}
    >
      <Avatar uri={item.avatar_url} name={item.full_name} username={item.username} size={42} colors={colors} />
      <View style={styles.resultInfo}>
        <View style={styles.nameRow}>
          <Text style={[styles.resultTitle, { color: colors.contentPrimary }]} numberOfLines={1}>
            {item.full_name || item.username}
          </Text>
          {item.is_verified && (
            <Ionicons name="checkmark-circle" size={13} color={colors.contentPrimary} style={{ marginLeft: 4 }} />
          )}
        </View>
        {item.username && (
          <Text style={[styles.resultSub, { color: colors.contentTertiary }]}>@{item.username}</Text>
        )}
        {item.bio && (
          <Text style={[styles.resultBody, { color: colors.contentSecondary }]} numberOfLines={1}>{item.bio}</Text>
        )}
      </View>
      <Ionicons name="chevron-forward" size={14} color={colors.contentTertiary} />
    </Pressable>
  )

  const renderCircle = (item: CircleResult) => (
    <Pressable
      key={item.id}
      onPress={() => { Haptics.selectionAsync(); router.push(`/circle/${item.id}` as any) }}
      style={[styles.resultRow, { borderBottomColor: colors.borderSecondary }]}
    >
      <View style={[styles.iconBox, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderSecondary }]}>
        <Ionicons name="people" size={18} color={colors.contentSecondary} />
      </View>
      <View style={styles.resultInfo}>
        <Text style={[styles.resultTitle, { color: colors.contentPrimary }]} numberOfLines={1}>{item.name}</Text>
        <Text style={[styles.resultSub, { color: colors.contentTertiary }]}>
          {item.member_count.toLocaleString()} members{item.category ? ` · ${item.category}` : ''}
        </Text>
        {item.description && (
          <Text style={[styles.resultBody, { color: colors.contentSecondary }]} numberOfLines={1}>{item.description}</Text>
        )}
      </View>
      <Ionicons name="chevron-forward" size={14} color={colors.contentTertiary} />
    </Pressable>
  )

  const renderEvent = (item: EventResult) => (
    <Pressable
      key={item.id}
      onPress={() => { Haptics.selectionAsync(); router.push(`/event/${item.id}` as any) }}
      style={[styles.resultRow, { borderBottomColor: colors.borderSecondary }]}
    >
      <View style={[styles.iconBox, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderSecondary }]}>
        <Ionicons name="calendar" size={18} color={colors.contentSecondary} />
      </View>
      <View style={styles.resultInfo}>
        <Text style={[styles.resultTitle, { color: colors.contentPrimary }]} numberOfLines={1}>{item.title}</Text>
        <Text style={[styles.resultSub, { color: colors.contentTertiary }]}>{formatEventDate(item.starts_at)}</Text>
        {(item.location_text || item.location) && (
          <Text style={[styles.resultBody, { color: colors.contentSecondary }]} numberOfLines={1}>
            {item.location_text || item.location}
          </Text>
        )}
      </View>
      <Ionicons name="chevron-forward" size={14} color={colors.contentTertiary} />
    </Pressable>
  )

  // ─── Section label ────────────────────────────────────────────────────────────

  const SectionHeader = ({ title, count }: { title: string; count: number }) => (
    <View style={[styles.sectionHeader, { backgroundColor: colors.surfacePrimary, borderBottomColor: colors.borderSecondary }]}>
      <Text style={[styles.sectionTitle, { color: colors.contentTertiary }]}>{title}</Text>
      <Text style={[styles.sectionCount, { color: colors.contentTertiary }]}>{count}</Text>
    </View>
  )

  // ─── Render ────────────────────────────────────────────────────────────────

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      {/* Search bar */}
      <View style={styles.searchWrap}>
        <View style={[styles.searchBar, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
          <Ionicons name="search" size={16} color={colors.contentTertiary} />
          <TextInput
            ref={inputRef}
            value={query}
            onChangeText={handleQueryChange}
            placeholder="Search people, circles, events…"
            placeholderTextColor={colors.contentTertiary}
            style={[styles.searchInput, { color: colors.contentPrimary }]}
            autoCapitalize="none"
            autoCorrect={false}
            returnKeyType="search"
          />
          {searching && <ActivityIndicator size="small" color={colors.contentTertiary} />}
          {!searching && query.length > 0 && (
            <Pressable onPress={clearSearch} hitSlop={8}>
              <Ionicons name="close-circle" size={16} color={colors.contentTertiary} />
            </Pressable>
          )}
        </View>
      </View>

      {/* Search results */}
      {hasResults ? (
        <FlatList
          data={[1]}
          keyExtractor={() => 'results'}
          renderItem={() => (
            <View>
              {results.people.length > 0 && (
                <>
                  <SectionHeader title="People" count={results.people.length} />
                  {results.people.map(renderPerson)}
                </>
              )}
              {results.circles.length > 0 && (
                <>
                  <SectionHeader title="Circles" count={results.circles.length} />
                  {results.circles.map(renderCircle)}
                </>
              )}
              {results.events.length > 0 && (
                <>
                  <SectionHeader title="Events" count={results.events.length} />
                  {results.events.map(renderEvent)}
                </>
              )}
              {!searching && totalResults === 0 && (
                <View style={styles.noResults}>
                  <Ionicons name="search-outline" size={40} color={colors.contentTertiary} />
                  <Text style={[styles.noResultsTitle, { color: colors.contentPrimary }]}>No results</Text>
                  <Text style={[styles.noResultsSub, { color: colors.contentSecondary }]}>
                    Try a different name or keyword
                  </Text>
                </View>
              )}
            </View>
          )}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={{ paddingBottom: 100 }}
        />
      ) : (
        /* Suggested / trending when no query */
        <FlatList
          data={[1]}
          keyExtractor={() => 'suggested'}
          renderItem={() => (
            <View>
              {sugLoading ? (
                <View style={styles.centered}>
                  <ActivityIndicator color={colors.contentTertiary} />
                </View>
              ) : (
                <>
                  {sugPeople.length > 0 && (
                    <>
                      <SectionHeader title="People to meet" count={sugPeople.length} />
                      {sugPeople.map(renderPerson)}
                    </>
                  )}
                  {sugCircles.length > 0 && (
                    <>
                      <SectionHeader title="Popular circles" count={sugCircles.length} />
                      {sugCircles.map(renderCircle)}
                    </>
                  )}
                  {sugEvents.length > 0 && (
                    <>
                      <SectionHeader title="Upcoming events" count={sugEvents.length} />
                      {sugEvents.map(renderEvent)}
                    </>
                  )}
                </>
              )}
            </View>
          )}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={{ paddingBottom: 100 }}
        />
      )}
    </SafeAreaView>
  )
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { padding: Spacing.xl, alignItems: 'center' },

  searchWrap: {
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.sm,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingHorizontal: Spacing.md,
    paddingVertical: 11,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
  },
  searchInput: { flex: 1, fontSize: Typography.callout, padding: 0 },

  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.sm,
    borderBottomWidth: 1,
  },
  sectionTitle: {
    fontSize: Typography.caption,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
  },
  sectionCount: { fontSize: Typography.caption },

  resultRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    gap: Spacing.md,
  },
  iconBox: {
    width: 42,
    height: 42,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  resultInfo: { flex: 1, gap: 2 },
  nameRow: { flexDirection: 'row', alignItems: 'center' },
  resultTitle: { fontSize: Typography.callout, fontWeight: '500' },
  resultSub: { fontSize: Typography.caption },
  resultBody: { fontSize: Typography.caption, marginTop: 1 },

  noResults: {
    alignItems: 'center',
    paddingTop: 60,
    paddingHorizontal: Spacing.xl,
    gap: Spacing.md,
  },
  noResultsTitle: { fontSize: Typography.headline, fontWeight: '600' },
  noResultsSub: { fontSize: Typography.callout, textAlign: 'center' },
})
