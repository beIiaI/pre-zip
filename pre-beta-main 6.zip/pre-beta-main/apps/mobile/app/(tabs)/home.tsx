import React, { useState, useCallback, useEffect, useRef } from 'react'
import {
  View,
  Text,
  FlatList,
  Pressable,
  StyleSheet,
  RefreshControl,
  ActivityIndicator,
  Image,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { PreWordmark } from '@/components/ui/PreWordmark'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

// ─── Notification badge hook ──────────────────────────────────────────────────

function useUnreadNotifCount(userId: string | undefined) {
  const [count, setCount] = useState(0)
  const fetch = useCallback(async () => {
    if (!userId) return
    const { count: c } = await supabase
      .from('notifications')
      .select('id', { count: 'exact', head: true })
      .eq('user_id', userId)
      .eq('read', false)
    setCount(Math.min(c ?? 0, 99))
  }, [userId])
  useEffect(() => { fetch() }, [fetch])
  useEffect(() => {
    if (!userId) return
    const ch = supabase
      .channel(`notif-badge:${userId}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${userId}` }, fetch)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'notifications', filter: `user_id=eq.${userId}` }, fetch)
      .subscribe()
    return () => { supabase.removeChannel(ch) }
  }, [userId, fetch])
  return count
}

// ─── Types ────────────────────────────────────────────────────────────────────

type TabId = 'circles' | 'events' | 'people'

interface Circle {
  id: string
  name: string
  description: string | null
  is_public: boolean
  category: string | null
  creator_id: string
  member_count: number
}

interface Event {
  id: string
  title: string
  description: string | null
  starts_at: string
  location: string
  location_text: string | null
  attendee_count: number
  is_public: boolean
  host_id: string | null
}

interface Person {
  id: string
  username: string | null
  full_name: string | null
  avatar_url: string | null
  bio: string | null
  location: string | null
  is_verified: boolean
  early_supporter_number: number | null
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getInitials(name: string | null, username: string | null): string {
  if (name) return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
  if (username) return username[0].toUpperCase()
  return '?'
}

function formatEventDate(iso: string): string {
  const d = new Date(iso)
  const now = new Date()
  const isToday = d.toDateString() === now.toDateString()
  const tomorrow = new Date(now); tomorrow.setDate(now.getDate() + 1)
  const isTomorrow = d.toDateString() === tomorrow.toDateString()

  const time = d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
  if (isToday) return `Today · ${time}`
  if (isTomorrow) return `Tomorrow · ${time}`
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) + ` · ${time}`
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function Avatar({
  uri,
  name,
  username,
  size = 40,
  colors,
}: {
  uri: string | null
  name: string | null
  username: string | null
  size?: number
  colors: any
}) {
  if (uri) {
    return (
      <Image
        source={{ uri }}
        style={{ width: size, height: size, borderRadius: size / 2 }}
      />
    )
  }
  return (
    <View
      style={[
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: colors.surfaceElevated,
          justifyContent: 'center',
          alignItems: 'center',
          borderWidth: 1,
          borderColor: colors.borderPrimary,
        },
      ]}
    >
      <Text style={{ fontSize: size * 0.35, color: colors.contentPrimary, fontWeight: '600' }}>
        {getInitials(name, username)}
      </Text>
    </View>
  )
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function HomeScreen() {
  const router = useRouter()
  const { colors } = useTheme()
  const { user, profile } = useAuth()
  const unreadNotifs = useUnreadNotifCount(user?.id)

  const [activeTab, setActiveTab] = useState<TabId>('circles')

  // Circles state
  const [circles, setCircles] = useState<Circle[]>([])
  const [joinedIds, setJoinedIds] = useState<Set<string>>(new Set())
  const [circlesLoading, setCirclesLoading] = useState(false)
  const [circlesRefreshing, setCirclesRefreshing] = useState(false)
  const circlesFetched = useRef(false)

  // Events state
  const [events, setEvents] = useState<Event[]>([])
  const [eventsLoading, setEventsLoading] = useState(false)
  const [eventsRefreshing, setEventsRefreshing] = useState(false)
  const eventsFetched = useRef(false)

  // People state
  const [people, setPeople] = useState<Person[]>([])
  const [peopleLoading, setPeopleLoading] = useState(false)
  const [peopleRefreshing, setPeopleRefreshing] = useState(false)
  const peopleFetched = useRef(false)

  // ─── Data fetchers ──────────────────────────────────────────────────────────

  const fetchCircles = useCallback(async (refresh = false) => {
    if (!user) return
    if (refresh) setCirclesRefreshing(true)
    else setCirclesLoading(true)

    const [circlesRes, membershipRes] = await Promise.all([
      supabase
        .from('circles')
        .select('id, name, description, is_public, category, creator_id, member_count')
        .eq('is_public', true)
        .order('member_count', { ascending: false })
        .limit(30),
      supabase
        .from('circle_members')
        .select('circle_id')
        .eq('user_id', user.id),
    ])

    if (circlesRes.data) setCircles(circlesRes.data)
    if (membershipRes.data) {
      setJoinedIds(new Set(membershipRes.data.map(m => m.circle_id)))
    }

    setCirclesLoading(false)
    setCirclesRefreshing(false)
    circlesFetched.current = true
  }, [user])

  const fetchEvents = useCallback(async (refresh = false) => {
    if (refresh) setEventsRefreshing(true)
    else setEventsLoading(true)

    const { data } = await supabase
      .from('events')
      .select('id, title, description, starts_at, location, location_text, attendee_count, is_public, host_id')
      .eq('is_public', true)
      .gte('starts_at', new Date().toISOString())
      .order('starts_at', { ascending: true })
      .limit(20)

    if (data) setEvents(data)
    setEventsLoading(false)
    setEventsRefreshing(false)
    eventsFetched.current = true
  }, [])

  const fetchPeople = useCallback(async (refresh = false) => {
    if (!user) return
    if (refresh) setPeopleRefreshing(true)
    else setPeopleLoading(true)

    const { data } = await supabase
      .from('profiles')
      .select('id, username, full_name, avatar_url, bio, location, is_verified, early_supporter_number')
      .neq('id', user.id)
      .not('username', 'is', null)
      .eq('onboarding_completed', true)
      .order('created_at', { ascending: false })
      .limit(30)

    if (data) setPeople(data)
    setPeopleLoading(false)
    setPeopleRefreshing(false)
    peopleFetched.current = true
  }, [user])

  // Lazy-load each tab on first visit
  useEffect(() => {
    if (activeTab === 'circles' && !circlesFetched.current) fetchCircles()
    if (activeTab === 'events' && !eventsFetched.current) fetchEvents()
    if (activeTab === 'people' && !peopleFetched.current) fetchPeople()
  }, [activeTab, fetchCircles, fetchEvents, fetchPeople])

  // ─── Circle join/leave ──────────────────────────────────────────────────────

  const handleJoinCircle = useCallback(async (circleId: string) => {
    if (!user) return
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)

    if (joinedIds.has(circleId)) {
      // Leave
      setJoinedIds(prev => { const n = new Set(prev); n.delete(circleId); return n })
      setCircles(prev => prev.map(c => c.id === circleId ? { ...c, member_count: Math.max(0, c.member_count - 1) } : c))
      await supabase.from('circle_members').delete().match({ circle_id: circleId, user_id: user.id })
    } else {
      // Join
      setJoinedIds(prev => new Set([...prev, circleId]))
      setCircles(prev => prev.map(c => c.id === circleId ? { ...c, member_count: c.member_count + 1 } : c))
      await supabase.from('circle_members').insert({ circle_id: circleId, user_id: user.id })
    }
  }, [user, joinedIds])

  // ─── Tab switch ─────────────────────────────────────────────────────────────

  const handleTabPress = (tab: TabId) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)
    setActiveTab(tab)
  }

  // ─── Render items ───────────────────────────────────────────────────────────

  const renderCircle = ({ item }: { item: Circle }) => {
    const joined = joinedIds.has(item.id)
    return (
      <Pressable
        onPress={() => {
          Haptics.selectionAsync()
          router.push(`/circle/${item.id}` as any)
        }}
        style={[styles.card, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}
      >
        <View style={styles.cardHeader}>
          <View style={[styles.circleIcon, { backgroundColor: colors.surfaceElevated }]}>
            <Ionicons name="people" size={18} color={colors.contentPrimary} />
          </View>
          <View style={styles.cardHeaderText}>
            <Text style={[styles.cardTitle, { color: colors.contentPrimary }]} numberOfLines={1}>
              {item.name}
            </Text>
            {item.category && (
              <Text style={[styles.cardCategory, { color: colors.contentTertiary }]}>
                {item.category}
              </Text>
            )}
          </View>
          <Pressable
            onPress={(e) => {
              e.stopPropagation()
              handleJoinCircle(item.id)
            }}
            style={[
              styles.joinButton,
              {
                backgroundColor: joined ? colors.surfaceElevated : colors.contentPrimary,
                borderColor: joined ? colors.borderPrimary : colors.contentPrimary,
              },
            ]}
          >
            <Text style={[styles.joinButtonText, { color: joined ? colors.contentPrimary : colors.contentInverse }]}>
              {joined ? 'Joined' : 'Join'}
            </Text>
          </Pressable>
        </View>

        {item.description && (
          <Text style={[styles.cardBody, { color: colors.contentSecondary }]} numberOfLines={2}>
            {item.description}
          </Text>
        )}

        <View style={styles.metaRow}>
          <Ionicons name="people-outline" size={13} color={colors.contentTertiary} />
          <Text style={[styles.cardMeta, { color: colors.contentTertiary, marginLeft: 4 }]}>
            {item.member_count.toLocaleString()} {item.member_count === 1 ? 'member' : 'members'}
          </Text>
          <Ionicons name="chevron-forward" size={13} color={colors.contentTertiary} style={{ marginLeft: 'auto' }} />
        </View>
      </Pressable>
    )
  }

  const renderEvent = ({ item }: { item: Event }) => (
    <Pressable
      onPress={() => {
        Haptics.selectionAsync()
        router.push(`/event/${item.id}` as any)
      }}
      style={[styles.card, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}
    >
      <View style={styles.cardHeader}>
        <View style={[styles.circleIcon, { backgroundColor: colors.surfaceElevated }]}>
          <Ionicons name="calendar" size={18} color={colors.contentPrimary} />
        </View>
        <View style={styles.cardHeaderText}>
          <Text style={[styles.cardTitle, { color: colors.contentPrimary }]} numberOfLines={1}>
            {item.title}
          </Text>
          <Text style={[styles.cardCategory, { color: colors.contentTertiary }]}>
            {formatEventDate(item.starts_at)}
          </Text>
        </View>
        <Ionicons name="chevron-forward" size={16} color={colors.contentTertiary} />
      </View>

      {item.description && (
        <Text style={[styles.cardBody, { color: colors.contentSecondary }]} numberOfLines={2}>
          {item.description}
        </Text>
      )}

      <View style={styles.eventMeta}>
        {(item.location_text || item.location) && (
          <View style={styles.metaRow}>
            <Ionicons name="location-outline" size={13} color={colors.contentTertiary} />
            <Text style={[styles.cardMeta, { color: colors.contentTertiary, marginLeft: 4 }]} numberOfLines={1}>
              {item.location_text || item.location}
            </Text>
          </View>
        )}
        <View style={styles.metaRow}>
          <Ionicons name="checkmark-circle-outline" size={13} color={colors.contentTertiary} />
          <Text style={[styles.cardMeta, { color: colors.contentTertiary, marginLeft: 4 }]}>
            {item.attendee_count} going
          </Text>
        </View>
      </View>
    </Pressable>
  )

  const renderPerson = ({ item }: { item: Person }) => (
    <Pressable
      onPress={() => {
        Haptics.selectionAsync()
        router.push(`/user/${item.id}` as any)
      }}
      style={[styles.card, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}
    >
      <View style={styles.personRow}>
        <Avatar uri={item.avatar_url} name={item.full_name} username={item.username} size={46} colors={colors} />
        <View style={styles.personInfo}>
          <View style={styles.personNameRow}>
            <Text style={[styles.cardTitle, { color: colors.contentPrimary }]} numberOfLines={1}>
              {item.full_name || item.username}
            </Text>
            {item.is_verified && (
              <Ionicons name="checkmark-circle" size={14} color={colors.contentPrimary} style={{ marginLeft: 4 }} />
            )}
            {item.early_supporter_number != null && (
              <View style={[styles.earlyBadge, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
                <Text style={[styles.earlyBadgeText, { color: colors.contentTertiary }]}>
                  #{item.early_supporter_number}
                </Text>
              </View>
            )}
          </View>
          {item.username && (
            <Text style={[styles.cardCategory, { color: colors.contentTertiary }]}>@{item.username}</Text>
          )}
          {item.bio && (
            <Text style={[styles.personBio, { color: colors.contentSecondary }]} numberOfLines={2}>
              {item.bio}
            </Text>
          )}
          {item.location && (
            <View style={[styles.metaRow, { marginTop: 4 }]}>
              <Ionicons name="location-outline" size={12} color={colors.contentTertiary} />
              <Text style={[styles.cardMeta, { color: colors.contentTertiary, marginLeft: 3 }]}>
                {item.location}
              </Text>
            </View>
          )}
        </View>
        <Ionicons name="chevron-forward" size={16} color={colors.contentTertiary} />
      </View>
    </Pressable>
  )

  // ─── Tab content ────────────────────────────────────────────────────────────

  const tabConfig = {
    circles: {
      data: circles,
      loading: circlesLoading,
      refreshing: circlesRefreshing,
      onRefresh: () => fetchCircles(true),
      renderItem: renderCircle,
      emptyIcon: 'people-outline' as const,
      emptyTitle: 'No circles yet',
      emptySubtitle: 'Circles will appear here when they\'re created.',
    },
    events: {
      data: events,
      loading: eventsLoading,
      refreshing: eventsRefreshing,
      onRefresh: () => fetchEvents(true),
      renderItem: renderEvent,
      emptyIcon: 'calendar-outline' as const,
      emptyTitle: 'No upcoming events',
      emptySubtitle: 'Events will appear here when they\'re created.',
    },
    people: {
      data: people,
      loading: peopleLoading,
      refreshing: peopleRefreshing,
      onRefresh: () => fetchPeople(true),
      renderItem: renderPerson as any,
      emptyIcon: 'person-add-outline' as const,
      emptyTitle: 'No people yet',
      emptySubtitle: 'Other members will appear here.',
    },
  }

  const current = tabConfig[activeTab]

  // ─── Render ─────────────────────────────────────────────────────────────────

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>

      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
        <PreWordmark size="small" color={colors.contentPrimary} />
        <View style={styles.headerRight}>
          {activeTab !== 'people' && (
            <Pressable
              onPress={() => {
                Haptics.selectionAsync()
                router.push(activeTab === 'circles' ? '/create-circle' : '/create-event' as any)
              }}
              style={styles.headerIcon}
            >
              <Ionicons name="add-circle-outline" size={24} color={colors.contentPrimary} />
            </Pressable>
          )}
          <Pressable onPress={() => router.push('/notifications' as any)} style={styles.headerIcon}>
            <Ionicons name="notifications-outline" size={22} color={colors.contentPrimary} />
            {unreadNotifs > 0 && (
              <View style={[styles.notifBadge, { backgroundColor: colors.contentPrimary }]}>
                <Text style={[styles.notifBadgeText, { color: colors.contentInverse }]}>
                  {unreadNotifs > 9 ? '9+' : unreadNotifs}
                </Text>
              </View>
            )}
          </Pressable>
        </View>
      </View>

      {/* Tab bar */}
      <View style={[styles.tabBar, { borderBottomColor: colors.borderSecondary }]}>
        {(['circles', 'events', 'people'] as TabId[]).map(tab => (
          <Pressable
            key={tab}
            onPress={() => handleTabPress(tab)}
            style={styles.tabItem}
          >
            <Text style={[
              styles.tabLabel,
              {
                color: activeTab === tab ? colors.contentPrimary : colors.contentTertiary,
                fontWeight: activeTab === tab ? '600' : '400',
              },
            ]}>
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </Text>
            {activeTab === tab && (
              <View style={[styles.tabIndicator, { backgroundColor: colors.contentPrimary }]} />
            )}
          </Pressable>
        ))}
      </View>

      {/* Content */}
      {current.loading ? (
        <View style={styles.centered}>
          <ActivityIndicator color={colors.contentTertiary} />
          <Text style={[styles.loadingText, { color: colors.contentTertiary }]}>
            Loading {activeTab}…
          </Text>
        </View>
      ) : (
        <FlatList
          data={current.data}
          keyExtractor={item => item.id}
          renderItem={current.renderItem}
          contentContainerStyle={[
            styles.listContent,
            current.data.length === 0 && styles.listContentEmpty,
          ]}
          refreshControl={
            <RefreshControl
              refreshing={current.refreshing}
              onRefresh={current.onRefresh}
              tintColor={colors.contentTertiary}
            />
          }
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <Ionicons name={current.emptyIcon} size={40} color={colors.contentTertiary} />
              <Text style={[styles.emptyTitle, { color: colors.contentPrimary }]}>
                {current.emptyTitle}
              </Text>
              <Text style={[styles.emptySubtitle, { color: colors.contentSecondary }]}>
                {current.emptySubtitle}
              </Text>
            </View>
          }
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  )
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1 },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
  },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  headerIcon: {
    width: 36,
    height: 36,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  notifBadge: {
    position: 'absolute',
    top: 2,
    right: 2,
    minWidth: 16,
    height: 16,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 3,
  },
  notifBadgeText: { fontSize: 9, fontWeight: '700' },

  tabBar: {
    flexDirection: 'row',
    borderBottomWidth: 1,
  },
  tabItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: Spacing.md,
    position: 'relative',
  },
  tabLabel: { fontSize: Typography.callout },
  tabIndicator: {
    position: 'absolute',
    bottom: 0,
    left: '20%',
    right: '20%',
    height: 2,
    borderRadius: BorderRadius.full,
  },

  listContent: {
    padding: Spacing.base,
    gap: Spacing.sm,
    paddingBottom: 100, // clear iOS tab bar
  },
  listContentEmpty: { flex: 1 },

  centered: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: Spacing.sm },
  loadingText: { fontSize: Typography.callout, marginTop: Spacing.sm },

  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingHorizontal: Spacing.xl,
  },
  emptyTitle: { fontSize: Typography.headline, fontWeight: '600', textAlign: 'center' },
  emptySubtitle: { fontSize: Typography.callout, textAlign: 'center', lineHeight: Typography.callout * 1.5 },

  // Card
  card: {
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    padding: Spacing.base,
    gap: Spacing.sm,
  },
  cardHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  cardHeaderText: { flex: 1 },
  cardTitle: { fontSize: Typography.callout, fontWeight: '600' },
  cardCategory: { fontSize: Typography.caption, marginTop: 2 },
  cardBody: { fontSize: Typography.callout, lineHeight: Typography.callout * 1.5 },
  cardMeta: { fontSize: Typography.caption },

  circleIcon: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.md,
    justifyContent: 'center',
    alignItems: 'center',
  },

  joinButton: {
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
  joinButtonText: { fontSize: Typography.caption, fontWeight: '600' },

  eventMeta: { gap: 4 },
  metaRow: { flexDirection: 'row', alignItems: 'center' },

  personRow: { flexDirection: 'row', gap: Spacing.md },
  personInfo: { flex: 1, gap: 2 },
  personNameRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap' },
  personBio: { fontSize: Typography.caption, lineHeight: Typography.caption * 1.5, marginTop: 4 },
  earlyBadge: {
    marginLeft: 6,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: BorderRadius.sm,
    borderWidth: 1,
  },
  earlyBadgeText: { fontSize: 10 },
})
