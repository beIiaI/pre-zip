import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { Button } from '@/components/ui/Button'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

type ThemeMode = 'light' | 'dark' | 'amoled' | 'system'

const THEME_OPTIONS: { value: ThemeMode; label: string; icon: string; sub?: string }[] = [
  { value: 'system', label: 'System', icon: 'phone-portrait-outline', sub: 'Follows device setting' },
  { value: 'light', label: 'Light', icon: 'sunny-outline' },
  { value: 'dark', label: 'Dark', icon: 'moon-outline' },
  { value: 'amoled', label: 'AMOLED', icon: 'contrast-outline', sub: 'Pure black' },
]

export default function SettingsScreen() {
  const { colors, theme, setTheme } = useTheme()
  const { signOut, profile } = useAuth()
  const router = useRouter()

  const handleSignOut = async () => {
    await signOut()
    router.replace('/auth/splash')
  }

  const handleTheme = (mode: ThemeMode) => {
    Haptics.selectionAsync()
    setTheme(mode)
  }

  const navSections = [
    {
      title: 'Safety & Verification',
      items: [
        { label: 'University Verification', icon: 'school-outline', route: '/settings/verification' },
        { label: 'Emergency Contacts', icon: 'call-outline', route: '/settings/emergency' },
        { label: 'Privacy Settings', icon: 'lock-closed-outline', route: '/settings/privacy' },
      ],
    },
    {
      title: 'Account',
      items: [
        { label: 'Edit Profile', icon: 'create-outline', route: '/profile/edit' },
        { label: 'Change Password', icon: 'key-outline', route: '/settings/password' },
        { label: 'Invites', icon: 'person-add-outline', route: '/settings/invites' },
      ],
    },
    {
      title: 'Support',
      items: [
        { label: 'Help & Support', icon: 'help-circle-outline', route: '/settings/help' },
        { label: 'Report a Problem', icon: 'flag-outline', route: '/settings/report' },
      ],
    },
  ]

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <Text style={[styles.header, { color: colors.contentPrimary }]}>Settings</Text>

        {/* Appearance */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.contentSecondary }]}>Appearance</Text>
          <View style={[styles.card, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
            {THEME_OPTIONS.map((opt, idx) => {
              const active = theme === opt.value
              return (
                <Pressable
                  key={opt.value}
                  onPress={() => handleTheme(opt.value)}
                  style={[
                    styles.themeRow,
                    idx > 0 && { borderTopWidth: 1, borderTopColor: colors.borderSecondary },
                  ]}
                >
                  <View style={[
                    styles.themeIconWrap,
                    { backgroundColor: active ? colors.contentPrimary : colors.surfaceElevated },
                  ]}>
                    <Ionicons
                      name={opt.icon as any}
                      size={16}
                      color={active ? colors.contentInverse : colors.contentSecondary}
                    />
                  </View>
                  <View style={styles.themeLabelWrap}>
                    <Text style={[styles.themeLabel, {
                      color: colors.contentPrimary,
                      fontWeight: active ? '600' : '400',
                    }]}>
                      {opt.label}
                    </Text>
                    {opt.sub && (
                      <Text style={[styles.themeSub, { color: colors.contentTertiary }]}>{opt.sub}</Text>
                    )}
                  </View>
                  {active && (
                    <Ionicons name="checkmark" size={18} color={colors.contentPrimary} />
                  )}
                </Pressable>
              )
            })}
          </View>
        </View>

        {/* Nav sections */}
        {navSections.map((section, sIdx) => (
          <View key={sIdx} style={styles.section}>
            <Text style={[styles.sectionTitle, { color: colors.contentSecondary }]}>
              {section.title}
            </Text>
            <View style={[styles.card, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
              {section.items.map((item, iIdx) => (
                <Pressable
                  key={iIdx}
                  onPress={() => router.push(item.route as any)}
                  style={[
                    styles.navItem,
                    iIdx > 0 && { borderTopWidth: 1, borderTopColor: colors.borderSecondary },
                  ]}
                >
                  <View style={[styles.navIconWrap, { backgroundColor: colors.surfaceElevated }]}>
                    <Ionicons name={item.icon as any} size={16} color={colors.contentSecondary} />
                  </View>
                  <Text style={[styles.navLabel, { color: colors.contentPrimary }]}>{item.label}</Text>
                  <Ionicons name="chevron-forward" size={16} color={colors.contentTertiary} />
                </Pressable>
              ))}
            </View>
          </View>
        ))}

        {/* Account card */}
        {profile && (
          <View style={[styles.profileCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
            <Text style={[styles.profileName, { color: colors.contentPrimary }]}>
              {profile.full_name || profile.username || '—'}
            </Text>
            <Text style={[styles.profileEmail, { color: colors.contentTertiary }]}>{profile.email}</Text>
            {profile.early_supporter_number != null && (
              <Text style={[styles.profileBadge, { color: colors.contentTertiary }]}>
                Early Supporter #{profile.early_supporter_number}
              </Text>
            )}
          </View>
        )}

        {/* Sign out */}
        <View style={styles.signOutSection}>
          <Button onPress={handleSignOut} variant="secondary" fullWidth>
            Sign Out
          </Button>
        </View>

        <Text style={[styles.version, { color: colors.contentTertiary }]}>pre · pre-beta</Text>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: {
    padding: Spacing.base,
    paddingBottom: 100,
    gap: Spacing.md,
  },
  header: {
    fontSize: Typography.display,
    fontWeight: '700',
    marginBottom: Spacing.sm,
    marginTop: Spacing.sm,
  },

  section: { gap: Spacing.sm },
  sectionTitle: {
    fontSize: Typography.caption,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 1,
    paddingHorizontal: Spacing.xs,
  },

  card: {
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    overflow: 'hidden',
  },

  themeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
  },
  themeIconWrap: {
    width: 32,
    height: 32,
    borderRadius: BorderRadius.sm,
    justifyContent: 'center',
    alignItems: 'center',
  },
  themeLabelWrap: { flex: 1 },
  themeLabel: { fontSize: Typography.callout },
  themeSub: { fontSize: Typography.caption, marginTop: 1 },

  navItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
  },
  navIconWrap: {
    width: 32,
    height: 32,
    borderRadius: BorderRadius.sm,
    justifyContent: 'center',
    alignItems: 'center',
  },
  navLabel: { flex: 1, fontSize: Typography.body },

  profileCard: {
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    padding: Spacing.base,
    gap: 4,
    marginTop: Spacing.sm,
  },
  profileName: { fontSize: Typography.callout, fontWeight: '600' },
  profileEmail: { fontSize: Typography.caption },
  profileBadge: { fontSize: Typography.caption },

  signOutSection: { marginTop: Spacing.sm },
  version: { fontSize: Typography.caption, textAlign: 'center', marginTop: Spacing.sm },
})
