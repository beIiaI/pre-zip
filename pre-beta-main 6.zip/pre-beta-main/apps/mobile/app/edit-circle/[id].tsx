import React, { useState, useEffect, useCallback } from 'react'
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Switch,
  Alert,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useLocalSearchParams, useRouter } from 'expo-router'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

const CATEGORIES = [
  'Social', 'Academic', 'Sports', 'Arts', 'Technology',
  'Gaming', 'Music', 'Food', 'Wellness', 'Career', 'Other',
]

export default function EditCircleScreen() {
  const { id: circleId } = useLocalSearchParams<{ id: string }>()
  const router = useRouter()
  const { colors } = useTheme()
  const { user } = useAuth()

  const [loading, setLoading] = useState(true)
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [category, setCategory] = useState<string | null>(null)
  const [isPublic, setIsPublic] = useState(true)
  const [saving, setSaving] = useState(false)
  const [deleting, setDeleting] = useState(false)

  const load = useCallback(async () => {
    if (!circleId) return
    const { data } = await supabase
      .from('circles')
      .select('name, description, category, is_public, creator_id')
      .eq('id', circleId)
      .single()

    if (!data) { router.back(); return }
    // Guard: only creator can edit
    if (data.creator_id !== user?.id) { router.back(); return }

    setName(data.name)
    setDescription(data.description ?? '')
    setCategory(data.category)
    setIsPublic(data.is_public)
    setLoading(false)
  }, [circleId, user])

  useEffect(() => { load() }, [load])

  const canSave = name.trim().length >= 2 && !saving && !deleting

  const handleSave = async () => {
    if (!canSave || !circleId) return
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)
    setSaving(true)

    const { error } = await supabase
      .from('circles')
      .update({
        name: name.trim(),
        description: description.trim() || null,
        category,
        is_public: isPublic,
      })
      .eq('id', circleId)

    setSaving(false)
    if (error) {
      Alert.alert('Error', 'Could not save changes. Please try again.')
      return
    }
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success)
    router.back()
  }

  const handleDelete = () => {
    Alert.alert(
      'Delete circle?',
      'This will permanently delete the circle and all its messages. This cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy)
            setDeleting(true)
            await supabase.from('circles').delete().eq('id', circleId)
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success)
            router.dismissAll()
          },
        },
      ],
    )
  }

  if (loading) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
        <View style={styles.centered}><ActivityIndicator color={colors.contentTertiary} /></View>
      </SafeAreaView>
    )
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        {/* Header */}
        <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
          <Pressable onPress={() => router.back()} style={styles.headerButton}>
            <Text style={[styles.headerCancel, { color: colors.contentSecondary }]}>Cancel</Text>
          </Pressable>
          <Text style={[styles.headerTitle, { color: colors.contentPrimary }]}>Edit Circle</Text>
          <Pressable onPress={handleSave} style={styles.headerButton} disabled={!canSave}>
            {saving ? (
              <ActivityIndicator size="small" color={colors.contentPrimary} />
            ) : (
              <Text style={[styles.headerSave, { color: canSave ? colors.contentPrimary : colors.contentTertiary, fontWeight: '600' }]}>
                Save
              </Text>
            )}
          </Pressable>
        </View>

        <ScrollView contentContainerStyle={styles.body} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          {/* Name */}
          <View style={styles.fieldGroup}>
            <Text style={[styles.label, { color: colors.contentSecondary }]}>CIRCLE NAME *</Text>
            <View style={[styles.inputWrap, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
              <TextInput
                value={name}
                onChangeText={setName}
                placeholder="Circle name"
                placeholderTextColor={colors.contentTertiary}
                style={[styles.input, { color: colors.contentPrimary }]}
                maxLength={50}
                autoFocus
              />
            </View>
            <Text style={[styles.hint, { color: colors.contentTertiary }]}>{name.length}/50</Text>
          </View>

          {/* Description */}
          <View style={styles.fieldGroup}>
            <Text style={[styles.label, { color: colors.contentSecondary }]}>DESCRIPTION</Text>
            <View style={[styles.inputWrap, styles.textareaWrap, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
              <TextInput
                value={description}
                onChangeText={setDescription}
                placeholder="What's this circle about?"
                placeholderTextColor={colors.contentTertiary}
                style={[styles.input, styles.textarea, { color: colors.contentPrimary }]}
                multiline
                maxLength={300}
                textAlignVertical="top"
              />
            </View>
            <Text style={[styles.hint, { color: colors.contentTertiary }]}>{description.length}/300</Text>
          </View>

          {/* Category */}
          <View style={styles.fieldGroup}>
            <Text style={[styles.label, { color: colors.contentSecondary }]}>CATEGORY</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.pillScroll}>
              {CATEGORIES.map(cat => {
                const selected = category === cat
                return (
                  <Pressable
                    key={cat}
                    onPress={() => { import('expo-haptics').then(h => h.selectionAsync()); setCategory(selected ? null : cat) }}
                    style={[styles.pill, { backgroundColor: selected ? colors.contentPrimary : colors.surfaceSecondary, borderColor: selected ? colors.contentPrimary : colors.borderSecondary }]}
                  >
                    <Text style={[styles.pillText, { color: selected ? colors.contentInverse : colors.contentSecondary }]}>{cat}</Text>
                  </Pressable>
                )
              })}
            </ScrollView>
          </View>

          {/* Public toggle */}
          <View style={[styles.toggleRow, { borderColor: colors.borderSecondary, backgroundColor: colors.surfaceSecondary }]}>
            <View style={styles.toggleInfo}>
              <Text style={[styles.toggleLabel, { color: colors.contentPrimary }]}>Public circle</Text>
              <Text style={[styles.toggleSub, { color: colors.contentTertiary }]}>
                {isPublic ? 'Anyone can find and join' : 'Only invited people can join'}
              </Text>
            </View>
            <Switch
              value={isPublic}
              onValueChange={v => { import('expo-haptics').then(h => h.selectionAsync()); setIsPublic(v) }}
              trackColor={{ false: colors.borderSecondary, true: colors.contentPrimary }}
              thumbColor={colors.contentInverse}
            />
          </View>

          {/* Save button */}
          <Pressable
            onPress={handleSave}
            disabled={!canSave}
            style={[styles.saveBtn, { backgroundColor: canSave ? colors.contentPrimary : colors.surfaceElevated }]}
          >
            {saving ? (
              <ActivityIndicator color={colors.contentInverse} />
            ) : (
              <Text style={[styles.saveBtnText, { color: canSave ? colors.contentInverse : colors.contentTertiary }]}>Save Changes</Text>
            )}
          </Pressable>

          {/* Delete — danger zone */}
          <View style={[styles.dangerZone, { borderColor: colors.borderSecondary }]}>
            <Text style={[styles.dangerTitle, { color: colors.contentTertiary }]}>Danger zone</Text>
            <Pressable
              onPress={handleDelete}
              disabled={deleting}
              style={[styles.deleteBtn, { borderColor: colors.contentTertiary }]}
            >
              {deleting ? (
                <ActivityIndicator color={colors.contentTertiary} />
              ) : (
                <Text style={[styles.deleteBtnText, { color: colors.contentTertiary }]}>Delete Circle</Text>
              )}
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },

  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.md, borderBottomWidth: 1,
  },
  headerButton: { minWidth: 60 },
  headerTitle: { fontSize: Typography.callout, fontWeight: '600' },
  headerCancel: { fontSize: Typography.callout },
  headerSave: { fontSize: Typography.callout, textAlign: 'right' },

  body: { padding: Spacing.base, gap: Spacing.lg, paddingBottom: 60 },

  fieldGroup: { gap: Spacing.xs },
  label: { fontSize: 11, fontWeight: '600', letterSpacing: 0.8, textTransform: 'uppercase' },
  inputWrap: { borderRadius: BorderRadius.md, borderWidth: 1, paddingHorizontal: Spacing.md, paddingVertical: 12 },
  textareaWrap: { paddingVertical: Spacing.md },
  input: { fontSize: Typography.callout, padding: 0 },
  textarea: { minHeight: 80 },
  hint: { fontSize: Typography.caption, textAlign: 'right' },

  pillScroll: { gap: Spacing.sm, paddingVertical: 4 },
  pill: { paddingHorizontal: Spacing.md, paddingVertical: 7, borderRadius: BorderRadius.full, borderWidth: 1 },
  pillText: { fontSize: Typography.caption, fontWeight: '500' },

  toggleRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    borderRadius: BorderRadius.md, borderWidth: 1, padding: Spacing.md, gap: Spacing.base,
  },
  toggleInfo: { flex: 1, gap: 2 },
  toggleLabel: { fontSize: Typography.callout, fontWeight: '500' },
  toggleSub: { fontSize: Typography.caption },

  saveBtn: { borderRadius: BorderRadius.md, paddingVertical: 15, alignItems: 'center', marginTop: Spacing.md },
  saveBtnText: { fontSize: Typography.callout, fontWeight: '600' },

  dangerZone: {
    borderWidth: 1, borderRadius: BorderRadius.lg,
    padding: Spacing.base, gap: Spacing.md, marginTop: Spacing.base,
  },
  dangerTitle: { fontSize: Typography.caption, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.8 },
  deleteBtn: {
    borderWidth: 1, borderRadius: BorderRadius.md,
    paddingVertical: 13, alignItems: 'center',
  },
  deleteBtnText: { fontSize: Typography.callout, fontWeight: '600' },
})
