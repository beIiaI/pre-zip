import { Slot, SplashScreen } from 'expo-router'
import { StatusBar } from 'expo-status-bar'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { AuthProvider } from '@/contexts/AuthContext'
import { ThemeProvider, useTheme } from '@/contexts/ThemeContext'
import { useEffect } from 'react'
import { View } from 'react-native'
import { GestureHandlerRootView } from 'react-native-gesture-handler'
import * as SystemUI from 'expo-system-ui'
import { validateApiConfig, getApiBaseUrl } from '@/lib/api'
import { ConfigErrorScreen } from '@/components/ui/ConfigErrorScreen'

// Prevent splash screen from auto-hiding
SplashScreen.preventAutoHideAsync()

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 5 * 60 * 1000, // 5 minutes
    },
  },
})

function RootLayoutContent() {
  const { colors, isDark } = useTheme()

  // Check for configuration errors
  const configValidation = validateApiConfig()

  useEffect(() => {
    // Set system UI colors
    SystemUI.setBackgroundColorAsync(colors.surfacePrimary)
  }, [colors.surfacePrimary])

  useEffect(() => {
    // Hide splash screen once layout is ready
    const timer = setTimeout(() => {
      SplashScreen.hideAsync()
    }, 100)
    return () => clearTimeout(timer)
  }, [])

  // Show config error screen if validation fails
  if (!configValidation.valid) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.surfacePrimary }}>
        <StatusBar style={isDark ? 'light' : 'dark'} />
        <ConfigErrorScreen error={configValidation.error!} apiUrl={getApiBaseUrl()} />
      </View>
    )
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.surfacePrimary }}>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <Slot />
    </View>
  )
}

export default function RootLayout() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <QueryClientProvider client={queryClient}>
        <ThemeProvider>
          <AuthProvider>
            <RootLayoutContent />
          </AuthProvider>
        </ThemeProvider>
      </QueryClientProvider>
    </GestureHandlerRootView>
  )
}
