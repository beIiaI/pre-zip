import React, { useState } from 'react'
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Switch,
  Alert,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import DateTimePicker from '@react-native-community/datetimepicker'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

const CATEGORIES = [
  'Social', 'Academic', 'Sports', 'Arts', 'Technology',
  'Gaming', 'Music', 'Food', 'Wellness', 'Career', 'Other',
]

function formatDate(d: Date): string {
  return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })
}

function formatTime(d: Date): string {
  return d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
}

// Default start = next round hour, end = +2h
function defaultStart(): Date {
  const d = new Date()
  d.setHours(d.getHours() + 1, 0, 0, 0)
  return d
}
function defaultEnd(start: Date): Date {
  return new Date(start.getTime() + 2 * 60 * 60 * 1000)
}

export default function CreateEventScreen() {
  const router = useRouter()
  const { colors } = useTheme()
  const { user } = useAuth()

  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [location, setLocation] = useState('')
  const [category, setCategory] = useState<string | null>(null)
  const [isPublic, setIsPublic] = useState(true)
  const [submitting, setSubmitting] = useState(false)

  const [startDate, setStartDate] = useState<Date>(defaultStart)
  const [endDate, setEndDate] = useState<Date>(() => defaultEnd(defaultStart()))

  // Picker visibility (Android needs explicit open/close)
  const [picker, setPicker] = useState<null | 'startDate' | 'startTime' | 'endDate' | 'endTime'>(null)

  const isAndroid = Platform.OS === 'android'
  const isIOS = Platform.OS === 'ios'

  const canSubmit = title.trim().length >= 2 && location.trim().length >= 2 && !submitting && startDate > new Date()

  const handleStartChange = (_: any, selected?: Date) => {
    if (isAndroid) setPicker(null)
    if (!selected) return
    setStartDate(selected)
    // Push end date forward if it would be before start
    if (endDate <= selected) setEndDate(new Date(selected.getTime() + 2 * 60 * 60 * 1000))
  }

  const handleEndChange = (_: any, selected?: Date) => {
    if (isAndroid) setPicker(null)
    if (selected) setEndDate(selected)
  }

  const handleCreate = async () => {
    if (!canSubmit || !user) return
    if (endDate <= startDate) {
      Alert.alert('Invalid time', 'End time must be after start time.')
      return
    }
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)
    setSubmitting(true)

    const { data: event, error } = await supabase
      .from('events')
      .insert({
        title: title.trim(),
        description: description.trim() || null,
        location: location.trim(),
        location_text: location.trim(),
        starts_at: startDate.toISOString(),
        ends_at: endDate.toISOString(),
        category,
        is_public: isPublic,
        creator_id: user.id,
        attendee_count: 1,
      })
      .select('id')
      .single()

    if (error || !event) {
      setSubmitting(false)
      Alert.alert('Error', 'Could not create event. Please try again.')
      return
    }

    // Add creator as going
    await supabase.from('event_attendees').insert({
      event_id: event.id,
      user_id: user.id,
      status: 'going',
    })

    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success)
    router.replace(`/event/${event.id}` as any)
  }

  // ─── Date/time row component ───────────────────────────────────────────────

  const DateRow = ({
    label,
    value,
    onPressDate,
    onPressTime,
    pickerKeyDate,
    pickerKeyTime,
  }: {
    label: string
    value: Date
    onPressDate: () => void
    onPressTime: () => void
    pickerKeyDate: typeof picker
    pickerKeyTime: typeof picker
  }) => (
    <View style={styles.fieldGroup}>
      <Text style={[styles.label, { color: colors.contentSecondary }]}>{label}</Text>
      <View style={styles.dateRow}>
        <Pressable
          onPress={onPressDate}
          style={[styles.dateChip, { backgroundColor: colors.surfaceSecondary, borderColor: picker === pickerKeyDate ? colors.contentPrimary : colors.borderSecondary }]}
        >
          <Ionicons name="calendar-outline" size={14} color={colors.contentSecondary} />
          <Text style={[styles.dateChipText, { color: colors.contentPrimary }]}>{formatDate(value)}</Text>
        </Pressable>
        <Pressable
          onPress={onPressTime}
          style={[styles.timeChip, { backgroundColor: colors.surfaceSecondary, borderColor: picker === pickerKeyTime ? colors.contentPrimary : colors.borderSecondary }]}
        >
          <Ionicons name="time-outline" size={14} color={colors.contentSecondary} />
          <Text style={[styles.dateChipText, { color: colors.contentPrimary }]}>{formatTime(value)}</Text>
        </Pressable>
      </View>

      {/* iOS inline picker */}
      {isIOS && (picker === pickerKeyDate || picker === pickerKeyTime) && (
        <View style={[styles.pickerContainer, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
          <DateTimePicker
            value={value}
            mode={picker === pickerKeyDate ? 'date' : 'time'}
            display="spinner"
            onChange={label.startsWith('START') ? handleStartChange : handleEndChange}
            minimumDate={label.startsWith('START') ? new Date() : startDate}
            textColor={colors.contentPrimary}
            themeVariant={colors.contentPrimary === '#FFFFFF' ? 'dark' : 'light'}
          />
          <Pressable onPress={() => setPicker(null)} style={[styles.pickerDone, { borderTopColor: colors.borderSecondary }]}>
            <Text style={[styles.pickerDoneText, { color: colors.contentPrimary }]}>Done</Text>
          </Pressable>
        </View>
      )}
      {/* Android dialog picker */}
      {isAndroid && (picker === pickerKeyDate || picker === pickerKeyTime) && (
        <DateTimePicker
          value={value}
          mode={picker === pickerKeyDate ? 'date' : 'time'}
          display="default"
          onChange={label.startsWith('START') ? handleStartChange : handleEndChange}
          minimumDate={label.startsWith('START') ? new Date() : startDate}
        />
      )}
    </View>
  )

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>

        {/* Header */}
        <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
          <Pressable onPress={() => router.back()} style={styles.headerButton}>
            <Text style={[styles.headerCancel, { color: colors.contentSecondary }]}>Cancel</Text>
          </Pressable>
          <Text style={[styles.headerTitle, { color: colors.contentPrimary }]}>New Event</Text>
          <Pressable onPress={handleCreate} style={styles.headerButton} disabled={!canSubmit}>
            {submitting ? (
              <ActivityIndicator size="small" color={colors.contentPrimary} />
            ) : (
              <Text style={[styles.headerCreate, { color: canSubmit ? colors.contentPrimary : colors.contentTertiary, fontWeight: '600' }]}>
                Create
              </Text>
            )}
          </Pressable>
        </View>

        <ScrollView
          contentContainerStyle={styles.body}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Title */}
          <View style={styles.fieldGroup}>
            <Text style={[styles.label, { color: colors.contentSecondary }]}>EVENT TITLE *</Text>
            <View style={[styles.inputWrap, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
              <TextInput
                value={title}
                onChangeText={setTitle}
                placeholder="e.g. Study Session at the Library"
                placeholderTextColor={colors.contentTertiary}
                style={[styles.input, { color: colors.contentPrimary }]}
                maxLength={100}
                autoFocus
                returnKeyType="next"
              />
            </View>
            <Text style={[styles.hint, { color: colors.contentTertiary }]}>{title.length}/100</Text>
          </View>

          {/* Description */}
          <View style={styles.fieldGroup}>
            <Text style={[styles.label, { color: colors.contentSecondary }]}>DESCRIPTION</Text>
            <View style={[styles.inputWrap, styles.textareaWrap, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
              <TextInput
                value={description}
                onChangeText={setDescription}
                placeholder="Tell people what to expect…"
                placeholderTextColor={colors.contentTertiary}
                style={[styles.input, styles.textarea, { color: colors.contentPrimary }]}
                multiline
                maxLength={500}
                textAlignVertical="top"
              />
            </View>
            <Text style={[styles.hint, { color: colors.contentTertiary }]}>{description.length}/500</Text>
          </View>

          {/* Start date/time */}
          <DateRow
            label="STARTS *"
            value={startDate}
            onPressDate={() => setPicker(picker === 'startDate' ? null : 'startDate')}
            onPressTime={() => setPicker(picker === 'startTime' ? null : 'startTime')}
            pickerKeyDate="startDate"
            pickerKeyTime="startTime"
          />

          {/* End date/time */}
          <DateRow
            label="ENDS"
            value={endDate}
            onPressDate={() => setPicker(picker === 'endDate' ? null : 'endDate')}
            onPressTime={() => setPicker(picker === 'endTime' ? null : 'endTime')}
            pickerKeyDate="endDate"
            pickerKeyTime="endTime"
          />

          {/* Location */}
          <View style={styles.fieldGroup}>
            <Text style={[styles.label, { color: colors.contentSecondary }]}>LOCATION *</Text>
            <View style={[styles.inputWrap, styles.locationWrap, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
              <Ionicons name="location-outline" size={16} color={colors.contentTertiary} />
              <TextInput
                value={location}
                onChangeText={setLocation}
                placeholder="Venue name or address"
                placeholderTextColor={colors.contentTertiary}
                style={[styles.input, { color: colors.contentPrimary, flex: 1 }]}
                maxLength={200}
                returnKeyType="next"
              />
            </View>
          </View>

          {/* Category */}
          <View style={styles.fieldGroup}>
            <Text style={[styles.label, { color: colors.contentSecondary }]}>CATEGORY</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.pillScroll}>
              {CATEGORIES.map(cat => {
                const selected = category === cat
                return (
                  <Pressable
                    key={cat}
                    onPress={() => { Haptics.selectionAsync(); setCategory(selected ? null : cat) }}
                    style={[styles.pill, { backgroundColor: selected ? colors.contentPrimary : colors.surfaceSecondary, borderColor: selected ? colors.contentPrimary : colors.borderSecondary }]}
                  >
                    <Text style={[styles.pillText, { color: selected ? colors.contentInverse : colors.contentSecondary }]}>{cat}</Text>
                  </Pressable>
                )
              })}
            </ScrollView>
          </View>

          {/* Public toggle */}
          <View style={[styles.toggleRow, { borderColor: colors.borderSecondary, backgroundColor: colors.surfaceSecondary }]}>
            <View style={styles.toggleInfo}>
              <Text style={[styles.toggleLabel, { color: colors.contentPrimary }]}>Public event</Text>
              <Text style={[styles.toggleSub, { color: colors.contentTertiary }]}>
                {isPublic ? 'Anyone can find and RSVP' : 'Only invited people can see this'}
              </Text>
            </View>
            <Switch
              value={isPublic}
              onValueChange={v => { Haptics.selectionAsync(); setIsPublic(v) }}
              trackColor={{ false: colors.borderSecondary, true: colors.contentPrimary }}
              thumbColor={colors.contentInverse}
            />
          </View>

          {/* Create button */}
          <Pressable
            onPress={handleCreate}
            disabled={!canSubmit}
            style={[styles.createBtn, { backgroundColor: canSubmit ? colors.contentPrimary : colors.surfaceElevated }]}
          >
            {submitting ? (
              <ActivityIndicator color={colors.contentInverse} />
            ) : (
              <Text style={[styles.createBtnText, { color: canSubmit ? colors.contentInverse : colors.contentTertiary }]}>
                Create Event
              </Text>
            )}
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1 },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
  },
  headerButton: { minWidth: 60 },
  headerTitle: { fontSize: Typography.callout, fontWeight: '600' },
  headerCancel: { fontSize: Typography.callout },
  headerCreate: { fontSize: Typography.callout },

  body: {
    padding: Spacing.base,
    gap: Spacing.lg,
    paddingBottom: 60,
  },

  fieldGroup: { gap: Spacing.xs },
  label: { fontSize: 11, fontWeight: '600', letterSpacing: 0.8, textTransform: 'uppercase' },
  inputWrap: { borderRadius: BorderRadius.md, borderWidth: 1, paddingHorizontal: Spacing.md, paddingVertical: 12 },
  textareaWrap: { paddingVertical: Spacing.md },
  locationWrap: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  input: { fontSize: Typography.callout, padding: 0 },
  textarea: { minHeight: 80 },
  hint: { fontSize: Typography.caption, textAlign: 'right' },

  dateRow: { flexDirection: 'row', gap: Spacing.sm },
  dateChip: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    paddingHorizontal: Spacing.md,
    paddingVertical: 10,
  },
  timeChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    paddingHorizontal: Spacing.md,
    paddingVertical: 10,
  },
  dateChipText: { fontSize: Typography.caption, fontWeight: '500' },

  pickerContainer: {
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    overflow: 'hidden',
    marginTop: 4,
  },
  pickerDone: {
    paddingVertical: Spacing.md,
    alignItems: 'center',
    borderTopWidth: 1,
  },
  pickerDoneText: { fontSize: Typography.callout, fontWeight: '600' },

  pillScroll: { gap: Spacing.sm, paddingVertical: 4 },
  pill: { paddingHorizontal: Spacing.md, paddingVertical: 7, borderRadius: BorderRadius.full, borderWidth: 1 },
  pillText: { fontSize: Typography.caption, fontWeight: '500' },

  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    padding: Spacing.md,
    gap: Spacing.base,
  },
  toggleInfo: { flex: 1, gap: 2 },
  toggleLabel: { fontSize: Typography.callout, fontWeight: '500' },
  toggleSub: { fontSize: Typography.caption },

  createBtn: { borderRadius: BorderRadius.md, paddingVertical: 15, alignItems: 'center', marginTop: Spacing.md },
  createBtnText: { fontSize: Typography.callout, fontWeight: '600' },
})
