'use client'
import React, { useState, useRef, useCallback } from 'react'
import {
  View,
  Text,
  TextInput,
  ScrollView,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  Switch,
  Pressable,
  FlatList,
  ActivityIndicator,
  Alert,
  Image,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import DateTimePicker from '@react-native-community/datetimepicker'
import * as ImagePicker from 'expo-image-picker'
import * as Haptics from 'expo-haptics'
import { Ionicons } from '@expo/vector-icons'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { apiRequest } from '@/lib/api'
import { Button } from '@/components/ui/Button'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

// ─── Constants ────────────────────────────────────────────────────────────────

const TOTAL_STEPS = 9

const USER_INTENT_OPTIONS = [
  'Make new friends',
  'Find local events',
  'Join group activities',
  'Meet people with similar interests',
  'Network professionally',
  'Explore my city',
  'Find workout buddies',
  'Join study groups',
]

const INTEREST_OPTIONS = [
  'Sports & Fitness', 'Music', 'Art & Design', 'Technology',
  'Food & Dining', 'Travel', 'Gaming', 'Photography',
  'Books & Reading', 'Movies & TV', 'Outdoor Activities', 'Yoga & Wellness',
  'Dancing', 'Cooking', 'Fashion', 'Business & Startups',
  'Volunteering', 'Languages', 'Pets & Animals', 'Board Games',
]

// ─── Types ────────────────────────────────────────────────────────────────────

type ThemeSelection = 'light' | 'dark' | 'system'

interface FormData {
  fullName: string
  username: string
  userIntent: string[]
  interests: string[]
  dateOfBirth: Date | null
  location: string
  locationLat: number | null
  locationLng: number | null
  themeMode: ThemeSelection
  amoledEnabled: boolean
  bio: string
  avatarUri: string | null
}

interface LocationResult {
  id: string
  city?: string
  state?: string
  country?: string
  lat: number
  lon: number
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatDate(date: Date): string {
  return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function OnboardingScreen() {
  const router = useRouter()
  const { colors, isDark, setTheme } = useTheme()
  const { user, refreshProfile } = useAuth()

  const [step, setStep] = useState(1)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [data, setData] = useState<FormData>({
    fullName: '',
    username: '',
    userIntent: [],
    interests: [],
    dateOfBirth: null,
    location: '',
    locationLat: null,
    locationLng: null,
    themeMode: 'system',
    amoledEnabled: false,
    bio: '',
    avatarUri: null,
  })

  // Username check state
  const [usernameChecking, setUsernameChecking] = useState(false)
  const [usernameAvailable, setUsernameAvailable] = useState<boolean | null>(null)
  const usernameDebounce = useRef<ReturnType<typeof setTimeout> | null>(null)

  // Location state
  const [locationResults, setLocationResults] = useState<LocationResult[]>([])
  const [locationSearching, setLocationSearching] = useState(false)
  const [locationDropdownOpen, setLocationDropdownOpen] = useState(false)
  const locationDebounce = useRef<ReturnType<typeof setTimeout> | null>(null)

  // Android date picker visibility
  const [showAndroidDatePicker, setShowAndroidDatePicker] = useState(false)

  // ─── Navigation ────────────────────────────────────────────────────────────

  const goBack = () => {
    if (step === 1) return
    setError(null)
    setStep(s => s - 1)
  }

  const goNext = () => {
    setError(null)
    setStep(s => s + 1)
  }

  const canProceed = (): boolean => {
    switch (step) {
      case 1: return true
      case 2: return data.fullName.trim().length >= 2
      case 3: return usernameAvailable === true && data.username.length >= 2
      case 4: return data.userIntent.length >= 1
      case 5: return data.interests.length >= 3
      case 6: return true  // skippable
      case 7: return true  // skippable
      case 8: return true
      case 9: return true
      default: return false
    }
  }

  // ─── Username check ─────────────────────────────────────────────────────────

  const handleUsernameChange = useCallback((text: string) => {
    const normalized = text.toLowerCase().replace(/[^a-z0-9_]/g, '')
    setData(prev => ({ ...prev, username: normalized }))
    setUsernameAvailable(null)

    if (usernameDebounce.current) clearTimeout(usernameDebounce.current)
    if (normalized.length < 2) return

    setUsernameChecking(true)
    usernameDebounce.current = setTimeout(async () => {
      const { data: existing } = await supabase
        .from('profiles')
        .select('id')
        .eq('username', normalized)
        .neq('id', user?.id ?? '')
        .maybeSingle()
      setUsernameAvailable(existing === null)
      setUsernameChecking(false)
    }, 450)
  }, [user?.id])

  // ─── Location autocomplete ──────────────────────────────────────────────────

  const handleLocationChange = useCallback((text: string) => {
    setData(prev => ({ ...prev, location: text, locationLat: null, locationLng: null }))
    setLocationDropdownOpen(false)

    if (locationDebounce.current) clearTimeout(locationDebounce.current)
    if (text.length < 2) { setLocationResults([]); return }

    setLocationSearching(true)
    locationDebounce.current = setTimeout(async () => {
      const result = await apiRequest<{ results: LocationResult[] }>(
        `/api/location/autocomplete?text=${encodeURIComponent(text)}`
      )
      setLocationResults(result.data?.results ?? [])
      setLocationDropdownOpen(true)
      setLocationSearching(false)
    }, 300)
  }, [])

  const selectLocation = useCallback((result: LocationResult) => {
    const label = result.city && result.country
      ? `${result.city}, ${result.country}`
      : result.city || result.country || ''
    setData(prev => ({
      ...prev,
      location: label,
      locationLat: result.lat,
      locationLng: result.lon,
    }))
    setLocationResults([])
    setLocationDropdownOpen(false)
  }, [])

  // ─── Theme selection ────────────────────────────────────────────────────────

  const handleThemeSelect = useCallback((mode: ThemeSelection) => {
    setData(prev => {
      const next = { ...prev, themeMode: mode }
      if (mode !== 'dark') next.amoledEnabled = false
      // Live preview: apply to app immediately
      if (mode === 'dark' && prev.amoledEnabled) setTheme('amoled')
      else setTheme(mode)
      return next
    })
  }, [setTheme])

  const handleAmoledToggle = useCallback((value: boolean) => {
    setData(prev => ({ ...prev, amoledEnabled: value }))
    setTheme(value ? 'amoled' : 'dark')
  }, [setTheme])

  // ─── Avatar picker ──────────────────────────────────────────────────────────

  const handlePickAvatar = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync()
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Please allow access to your photo library.')
      return
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    })
    if (!result.canceled && result.assets[0]) {
      setData(prev => ({ ...prev, avatarUri: result.assets[0].uri }))
    }
  }

  // ─── Submit ─────────────────────────────────────────────────────────────────

  const handleComplete = async () => {
    if (!user) return
    setSubmitting(true)
    setError(null)

    try {
      let avatarUrl: string | null = null

      // Upload avatar if selected
      if (data.avatarUri) {
        try {
          const ext = data.avatarUri.split('.').pop() ?? 'jpg'
          const path = `${user.id}/avatar.${ext}`
          const response = await fetch(data.avatarUri)
          const blob = await response.blob()
          const arrayBuffer = await blob.arrayBuffer()
          const { data: uploadData, error: uploadError } = await supabase.storage
            .from('avatars')
            .upload(path, arrayBuffer, { contentType: `image/${ext}`, upsert: true })
          if (!uploadError && uploadData) {
            const { data: { publicUrl } } = supabase.storage.from('avatars').getPublicUrl(path)
            avatarUrl = publicUrl
          }
        } catch {
          // Non-fatal: avatar upload failure doesn't block onboarding
        }
      }

      const dbThemeMode = (data.themeMode === 'dark' || data.themeMode === 'light' || data.themeMode === 'system')
        ? data.themeMode
        : 'system'

      const { error: dbError } = await supabase
        .from('profiles')
        .update({
          full_name: data.fullName.trim(),
          username: data.username.toLowerCase().trim(),
          user_intent: data.userIntent,
          interests: data.interests,
          date_of_birth: data.dateOfBirth
            ? data.dateOfBirth.toISOString().split('T')[0]
            : null,
          location: data.location || null,
          location_lat: data.locationLat,
          location_lng: data.locationLng,
          theme_mode: dbThemeMode,
          amoled_enabled: data.amoledEnabled,
          bio: data.bio.trim() || null,
          ...(avatarUrl ? { avatar_url: avatarUrl } : {}),
          onboarding_completed: true,
          onboarding_step: 9,
        })
        .eq('id', user.id)

      if (dbError) throw new Error(dbError.message)

      await refreshProfile()
      router.replace('/(tabs)/home')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  // ─── Step renders ───────────────────────────────────────────────────────────

  const renderStep = () => {
    switch (step) {

      // Step 1: Intro
      case 1:
        return (
          <View style={styles.stepContent}>
            <View style={styles.featureGrid}>
              {[
                { icon: 'people', title: 'Join Circles', desc: 'Find your people in groups built around shared interests' },
                { icon: 'calendar', title: 'Discover Events', desc: 'Explore and host local experiences near you' },
                { icon: 'chatbubbles', title: 'Group Chats', desc: 'Stay connected with everyone in your circles' },
                { icon: 'shield-checkmark', title: 'Safe Community', desc: 'Verified members and trusted connections only' },
              ].map(card => (
                <View
                  key={card.title}
                  style={[styles.featureCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}
                >
                  <Ionicons name={card.icon as any} size={24} color={colors.contentPrimary} />
                  <Text style={[styles.featureTitle, { color: colors.contentPrimary }]}>{card.title}</Text>
                  <Text style={[styles.featureDesc, { color: colors.contentSecondary }]}>{card.desc}</Text>
                </View>
              ))}
            </View>
          </View>
        )

      // Step 2: Full name
      case 2:
        return (
          <View style={styles.stepContent}>
            <TextInput
              style={[styles.textInput, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderPrimary, color: colors.contentPrimary }]}
              placeholder="Your full name"
              placeholderTextColor={colors.contentTertiary}
              value={data.fullName}
              onChangeText={text => setData(prev => ({ ...prev, fullName: text }))}
              autoCapitalize="words"
              autoFocus
              returnKeyType="next"
              onSubmitEditing={canProceed() ? goNext : undefined}
            />
          </View>
        )

      // Step 3: Username
      case 3:
        return (
          <View style={styles.stepContent}>
            <View style={styles.inputRow}>
              <View style={styles.inputPrefix}>
                <Text style={[styles.inputPrefixText, { color: colors.contentTertiary }]}>@</Text>
              </View>
              <TextInput
                style={[styles.textInputSuffixed, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderPrimary, color: colors.contentPrimary }]}
                placeholder="username"
                placeholderTextColor={colors.contentTertiary}
                value={data.username}
                onChangeText={handleUsernameChange}
                autoCapitalize="none"
                autoCorrect={false}
                autoFocus
              />
              <View style={styles.inputSuffix}>
                {usernameChecking
                  ? <ActivityIndicator size="small" color={colors.contentTertiary} />
                  : usernameAvailable === true
                    ? <Ionicons name="checkmark-circle" size={20} color={colors.success} />
                    : usernameAvailable === false
                      ? <Ionicons name="close-circle" size={20} color={colors.error} />
                      : null
                }
              </View>
            </View>
            {usernameAvailable === false && (
              <Text style={[styles.helperText, { color: colors.error }]}>That username is taken</Text>
            )}
            {usernameAvailable === true && (
              <Text style={[styles.helperText, { color: colors.success }]}>Username available</Text>
            )}
          </View>
        )

      // Step 4: User intent
      case 4:
        return (
          <View style={styles.stepContent}>
            <View style={styles.chipGrid}>
              {USER_INTENT_OPTIONS.map(opt => {
                const selected = data.userIntent.includes(opt)
                return (
                  <Pressable
                    key={opt}
                    onPress={() => {
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)
                      setData(prev => ({
                        ...prev,
                        userIntent: selected
                          ? prev.userIntent.filter(i => i !== opt)
                          : [...prev.userIntent, opt],
                      }))
                    }}
                    style={[
                      styles.chip,
                      {
                        backgroundColor: selected ? colors.contentPrimary : colors.surfaceSecondary,
                        borderColor: selected ? colors.contentPrimary : colors.borderPrimary,
                      },
                    ]}
                  >
                    <Text style={[styles.chipText, { color: selected ? colors.contentInverse : colors.contentPrimary }]}>
                      {opt}
                    </Text>
                  </Pressable>
                )
              })}
            </View>
            {data.userIntent.length > 0 && (
              <Text style={[styles.selectionCount, { color: colors.contentSecondary }]}>
                {data.userIntent.length} selected
              </Text>
            )}
          </View>
        )

      // Step 5: Interests
      case 5:
        return (
          <View style={styles.stepContent}>
            <View style={styles.chipGrid}>
              {INTEREST_OPTIONS.map(opt => {
                const selected = data.interests.includes(opt)
                return (
                  <Pressable
                    key={opt}
                    onPress={() => {
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)
                      setData(prev => ({
                        ...prev,
                        interests: selected
                          ? prev.interests.filter(i => i !== opt)
                          : [...prev.interests, opt],
                      }))
                    }}
                    style={[
                      styles.chip,
                      {
                        backgroundColor: selected ? colors.contentPrimary : colors.surfaceSecondary,
                        borderColor: selected ? colors.contentPrimary : colors.borderPrimary,
                      },
                    ]}
                  >
                    <Text style={[styles.chipText, { color: selected ? colors.contentInverse : colors.contentPrimary }]}>
                      {opt}
                    </Text>
                  </Pressable>
                )
              })}
            </View>
            <Text style={[styles.selectionCount, { color: data.interests.length >= 3 ? colors.contentSecondary : colors.error }]}>
              {data.interests.length}/3 minimum selected
            </Text>
          </View>
        )

      // Step 6: Date of birth
      case 6:
        return (
          <View style={styles.stepContent}>
            {Platform.OS === 'ios' ? (
              <DateTimePicker
                value={data.dateOfBirth ?? new Date(2000, 0, 1)}
                mode="date"
                display="spinner"
                maximumDate={new Date()}
                themeVariant={isDark ? 'dark' : 'light'}
                onChange={(_, date) => {
                  if (date) setData(prev => ({ ...prev, dateOfBirth: date }))
                }}
                style={styles.datePicker}
              />
            ) : (
              <>
                <Pressable
                  onPress={() => setShowAndroidDatePicker(true)}
                  style={[styles.dateButton, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderPrimary }]}
                >
                  <Ionicons name="calendar-outline" size={20} color={colors.contentSecondary} />
                  <Text style={[styles.dateButtonText, { color: data.dateOfBirth ? colors.contentPrimary : colors.contentTertiary }]}>
                    {data.dateOfBirth ? formatDate(data.dateOfBirth) : 'Select your date of birth'}
                  </Text>
                </Pressable>
                {showAndroidDatePicker && (
                  <DateTimePicker
                    value={data.dateOfBirth ?? new Date(2000, 0, 1)}
                    mode="date"
                    display="default"
                    maximumDate={new Date()}
                    onChange={(_, date) => {
                      setShowAndroidDatePicker(false)
                      if (date) setData(prev => ({ ...prev, dateOfBirth: date }))
                    }}
                  />
                )}
              </>
            )}
            {data.dateOfBirth && Platform.OS === 'ios' && (
              <Text style={[styles.helperText, { color: colors.contentSecondary, textAlign: 'center' }]}>
                {formatDate(data.dateOfBirth)}
              </Text>
            )}
          </View>
        )

      // Step 7: Location
      case 7:
        return (
          <View style={styles.stepContent}>
            <View style={styles.locationWrapper}>
              <View style={[styles.locationInputRow, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderPrimary }]}>
                <Ionicons name="location-outline" size={18} color={colors.contentTertiary} style={{ marginRight: 8 }} />
                <TextInput
                  style={[styles.locationInput, { color: colors.contentPrimary }]}
                  placeholder="Start typing a city..."
                  placeholderTextColor={colors.contentTertiary}
                  value={data.location}
                  onChangeText={handleLocationChange}
                  autoCapitalize="words"
                  autoCorrect={false}
                />
                {locationSearching && (
                  <ActivityIndicator size="small" color={colors.contentTertiary} />
                )}
                {data.location.length > 0 && !locationSearching && (
                  <Pressable onPress={() => {
                    setData(prev => ({ ...prev, location: '', locationLat: null, locationLng: null }))
                    setLocationResults([])
                    setLocationDropdownOpen(false)
                  }}>
                    <Ionicons name="close-circle" size={18} color={colors.contentTertiary} />
                  </Pressable>
                )}
              </View>
              {locationDropdownOpen && locationResults.length > 0 && (
                <View style={[styles.locationDropdown, { backgroundColor: colors.surfacePrimary, borderColor: colors.borderPrimary }]}>
                  {locationResults.map(result => (
                    <Pressable
                      key={result.id}
                      onPress={() => {
                        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)
                        selectLocation(result)
                      }}
                      style={[styles.locationResult, { borderBottomColor: colors.borderSecondary }]}
                    >
                      <Ionicons name="location-outline" size={16} color={colors.contentTertiary} />
                      <View style={{ marginLeft: 8, flex: 1 }}>
                        <Text style={[styles.locationResultCity, { color: colors.contentPrimary }]}>
                          {result.city}
                        </Text>
                        {(result.state || result.country) && (
                          <Text style={[styles.locationResultRegion, { color: colors.contentSecondary }]}>
                            {[result.state, result.country].filter(Boolean).join(', ')}
                          </Text>
                        )}
                      </View>
                    </Pressable>
                  ))}
                </View>
              )}
            </View>
          </View>
        )

      // Step 8: Theme
      case 8:
        return (
          <View style={styles.stepContent}>
            <View style={[styles.segmentedControl, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
              {(['light', 'dark', 'system'] as ThemeSelection[]).map(mode => (
                <Pressable
                  key={mode}
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)
                    handleThemeSelect(mode)
                  }}
                  style={[
                    styles.segmentedOption,
                    data.themeMode === mode && { backgroundColor: colors.surfacePrimary, ...styles.segmentedOptionSelected },
                  ]}
                >
                  <Text style={[
                    styles.segmentedOptionText,
                    { color: data.themeMode === mode ? colors.contentPrimary : colors.contentTertiary },
                  ]}>
                    {mode.charAt(0).toUpperCase() + mode.slice(1)}
                  </Text>
                </Pressable>
              ))}
            </View>

            {(data.themeMode === 'dark') && (
              <View style={[styles.toggleRow, { borderColor: colors.borderSecondary }]}>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.toggleLabel, { color: colors.contentPrimary }]}>AMOLED Dark Mode</Text>
                  <Text style={[styles.toggleDesc, { color: colors.contentSecondary }]}>
                    Pure black backgrounds for OLED displays
                  </Text>
                </View>
                <Switch
                  value={data.amoledEnabled}
                  onValueChange={handleAmoledToggle}
                  trackColor={{ false: colors.borderPrimary, true: colors.contentPrimary }}
                  thumbColor={colors.contentInverse}
                />
              </View>
            )}

            {/* Live preview */}
            <View style={[styles.themePreview, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
              <View style={[styles.previewCard, { backgroundColor: colors.surfacePrimary, borderColor: colors.borderPrimary }]}>
                <View style={[styles.previewAvatar, { backgroundColor: colors.surfaceElevated }]} />
                <View style={{ flex: 1, gap: 6 }}>
                  <View style={[styles.previewLine, { backgroundColor: colors.contentPrimary, width: '60%' }]} />
                  <View style={[styles.previewLine, { backgroundColor: colors.contentTertiary, width: '40%' }]} />
                </View>
              </View>
              <Text style={[styles.previewLabel, { color: colors.contentTertiary }]}>Preview</Text>
            </View>
          </View>
        )

      // Step 9: Bio + avatar
      case 9:
        return (
          <View style={styles.stepContent}>
            {/* Avatar */}
            <Pressable
              onPress={handlePickAvatar}
              style={[styles.avatarPicker, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderPrimary }]}
            >
              {data.avatarUri ? (
                <Image source={{ uri: data.avatarUri }} style={styles.avatarImage} />
              ) : (
                <View style={styles.avatarPlaceholder}>
                  <Text style={[styles.avatarInitial, { color: colors.contentPrimary }]}>
                    {data.fullName?.charAt(0)?.toUpperCase() || '?'}
                  </Text>
                </View>
              )}
              <View style={[styles.avatarEditBadge, { backgroundColor: colors.contentPrimary }]}>
                <Ionicons name="camera" size={12} color={colors.contentInverse} />
              </View>
            </Pressable>

            {/* Bio */}
            <View>
              <TextInput
                style={[
                  styles.bioInput,
                  { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderPrimary, color: colors.contentPrimary },
                ]}
                placeholder="Write a short bio... (optional)"
                placeholderTextColor={colors.contentTertiary}
                value={data.bio}
                onChangeText={text => setData(prev => ({ ...prev, bio: text.slice(0, 150) }))}
                multiline
                numberOfLines={4}
                textAlignVertical="top"
              />
              <Text style={[styles.bioCount, { color: data.bio.length >= 140 ? colors.error : colors.contentTertiary }]}>
                {data.bio.length}/150
              </Text>
            </View>

            {error && (
              <Text style={[styles.errorText, { color: colors.error }]}>{error}</Text>
            )}
          </View>
        )

      default:
        return null
    }
  }

  // ─── Step metadata ──────────────────────────────────────────────────────────

  const stepMeta: Record<number, { title: string; subtitle?: string; skippable?: boolean }> = {
    1: { title: 'Welcome to pre', subtitle: 'A community built on real connections.' },
    2: { title: 'What\'s your name?', subtitle: 'This is how you\'ll appear to others.' },
    3: { title: 'Choose a username', subtitle: 'Lowercase letters, numbers, and underscores.' },
    4: { title: 'What brings you here?', subtitle: 'Select all that apply.' },
    5: { title: 'What are you into?', subtitle: 'Pick at least 3 interests.' },
    6: { title: 'When\'s your birthday?', subtitle: 'Optional — used to gate 18+ features. Not shown publicly.', skippable: true },
    7: { title: 'Where are you based?', subtitle: 'Optional — helps us show local circles and events.', skippable: true },
    8: { title: 'Choose your theme', subtitle: 'You can change this later in settings.' },
    9: { title: 'Almost done!', subtitle: 'Add a photo and bio to complete your profile.' },
  }

  const meta = stepMeta[step]
  const isLastStep = step === TOTAL_STEPS

  // ─── Render ─────────────────────────────────────────────────────────────────

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top', 'bottom']}>

      {/* Header */}
      <View style={styles.header}>
        <Pressable
          onPress={goBack}
          style={[styles.backButton, { opacity: step === 1 ? 0 : 1 }]}
          disabled={step === 1}
        >
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
        </Pressable>
        <Text style={[styles.stepLabel, { color: colors.contentTertiary }]}>
          Step {step} of {TOTAL_STEPS}
        </Text>
        <View style={styles.backButton} />
      </View>

      {/* Progress bar */}
      <View style={[styles.progressTrack, { backgroundColor: colors.surfaceSecondary }]}>
        <View
          style={[
            styles.progressFill,
            { backgroundColor: colors.contentPrimary, width: `${(step / TOTAL_STEPS) * 100}%` },
          ]}
        />
      </View>

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={8}
      >
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Title */}
          <Text style={[styles.stepTitle, { color: colors.contentPrimary }]}>{meta.title}</Text>
          {meta.subtitle && (
            <Text style={[styles.stepSubtitle, { color: colors.contentSecondary }]}>{meta.subtitle}</Text>
          )}

          {renderStep()}
        </ScrollView>
      </KeyboardAvoidingView>

      {/* Footer buttons */}
      <View style={[styles.footer, { borderTopColor: colors.borderSecondary }]}>
        {meta.skippable ? (
          <View style={styles.footerRow}>
            <Button variant="secondary" onPress={goNext} style={{ flex: 1 }}>
              Skip
            </Button>
            <Button
              onPress={goNext}
              disabled={!canProceed()}
              style={{ flex: 1 }}
            >
              Continue
            </Button>
          </View>
        ) : isLastStep ? (
          <Button onPress={handleComplete} loading={submitting} fullWidth>
            {submitting ? 'Setting up your profile…' : 'Complete Profile'}
          </Button>
        ) : (
          <Button onPress={goNext} disabled={!canProceed()} fullWidth>
            Continue
          </Button>
        )}
      </View>

    </SafeAreaView>
  )
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1 },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.sm,
  },
  backButton: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  stepLabel: { fontSize: Typography.callout },

  progressTrack: {
    height: 3,
    marginHorizontal: Spacing.base,
    borderRadius: BorderRadius.full,
    overflow: 'hidden',
  },
  progressFill: {
    height: 3,
    borderRadius: BorderRadius.full,
  },

  scrollContent: {
    padding: Spacing.lg,
    paddingTop: Spacing.xl,
    paddingBottom: Spacing.xl,
  },

  stepTitle: {
    fontSize: Typography.title,
    fontWeight: '600',
    marginBottom: Spacing.xs,
  },
  stepSubtitle: {
    fontSize: Typography.callout,
    marginBottom: Spacing.xl,
    lineHeight: Typography.callout * 1.5,
  },

  stepContent: { gap: Spacing.md },

  footer: {
    padding: Spacing.base,
    paddingBottom: Spacing.sm,
    borderTopWidth: 1,
  },
  footerRow: { flexDirection: 'row', gap: Spacing.sm },

  // Text inputs
  textInput: {
    borderWidth: 1,
    borderRadius: BorderRadius.lg,
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    fontSize: Typography.body,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
  },
  inputPrefix: {
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
  },
  inputPrefixText: { fontSize: Typography.body },
  textInputSuffixed: {
    flex: 1,
    paddingVertical: Spacing.md,
    fontSize: Typography.body,
    borderWidth: 0,
  },
  inputSuffix: { paddingHorizontal: Spacing.base },

  helperText: { fontSize: Typography.caption, marginTop: 4 },

  // Chips
  chipGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  chip: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
  chipText: { fontSize: Typography.callout },
  selectionCount: { fontSize: Typography.caption, marginTop: Spacing.sm },

  // Date picker
  datePicker: { height: 200 },
  dateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    borderWidth: 1,
    borderRadius: BorderRadius.lg,
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
  },
  dateButtonText: { fontSize: Typography.body },

  // Location
  locationWrapper: { position: 'relative', zIndex: 10 },
  locationInputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: BorderRadius.lg,
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
  },
  locationInput: { flex: 1, fontSize: Typography.body },
  locationDropdown: {
    position: 'absolute',
    top: '100%',
    left: 0,
    right: 0,
    borderWidth: 1,
    borderRadius: BorderRadius.md,
    marginTop: 4,
    overflow: 'hidden',
    zIndex: 20,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 8,
  },
  locationResult: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
  },
  locationResultCity: { fontSize: Typography.body, fontWeight: '500' },
  locationResultRegion: { fontSize: Typography.caption, marginTop: 2 },

  // Theme
  segmentedControl: {
    flexDirection: 'row',
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    padding: 4,
    gap: 4,
  },
  segmentedOption: {
    flex: 1,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
  },
  segmentedOptionSelected: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  segmentedOptionText: { fontSize: Typography.callout, fontWeight: '500' },

  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.base,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    gap: Spacing.base,
  },
  toggleLabel: { fontSize: Typography.body, fontWeight: '500' },
  toggleDesc: { fontSize: Typography.caption, marginTop: 2 },

  themePreview: {
    padding: Spacing.base,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    gap: Spacing.sm,
    marginTop: Spacing.md,
  },
  previewCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
  },
  previewAvatar: { width: 36, height: 36, borderRadius: 18 },
  previewLine: { height: 10, borderRadius: BorderRadius.sm },
  previewLabel: { fontSize: Typography.caption, textAlign: 'center' },

  // Avatar
  avatarPicker: {
    width: 96,
    height: 96,
    borderRadius: 48,
    alignSelf: 'center',
    borderWidth: 2,
    overflow: 'visible',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarImage: { width: 96, height: 96, borderRadius: 48 },
  avatarPlaceholder: { width: 96, height: 96, borderRadius: 48, justifyContent: 'center', alignItems: 'center' },
  avatarInitial: { fontSize: 36, fontWeight: '600' },
  avatarEditBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 26,
    height: 26,
    borderRadius: 13,
    justifyContent: 'center',
    alignItems: 'center',
  },

  // Bio
  bioInput: {
    borderWidth: 1,
    borderRadius: BorderRadius.lg,
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    fontSize: Typography.body,
    minHeight: 100,
  },
  bioCount: { fontSize: Typography.caption, textAlign: 'right', marginTop: 4 },

  errorText: { fontSize: Typography.callout, textAlign: 'center', marginTop: Spacing.sm },

  // Feature cards (step 1)
  featureGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  featureCard: {
    width: '47%',
    padding: Spacing.base,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    gap: Spacing.xs,
  },
  featureTitle: { fontSize: Typography.callout, fontWeight: '600', marginTop: Spacing.xs },
  featureDesc: { fontSize: Typography.caption, lineHeight: Typography.caption * 1.5 },
})
