import { useState } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
  Alert,
} from 'react-native'
import { useRouter } from 'expo-router'
import { SafeAreaView } from 'react-native-safe-area-context'
import * as AppleAuthentication from 'expo-apple-authentication'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { PreWordmark } from '@/components/ui/PreWordmark'
import { validateEmail } from '@/utils/validation'
import { requestPasswordReset, checkApiHealth, getApiBaseUrl } from '@/lib/api'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

/**
 * Sign In screen
 * Matches pre-beta /auth with mode=signin
 */
export default function SignInScreen() {
  const router = useRouter()
  const { colors } = useTheme()
  const { signIn, signInWithApple } = useAuth()

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [forgotLoading, setForgotLoading] = useState(false)
  const [appleLoading, setAppleLoading] = useState(false)

  const handleSignIn = async () => {
    setError(null)
    setSuccess(null)

    const normalizedEmail = email.trim().toLowerCase()

    if (!validateEmail(normalizedEmail)) {
      setError('Please enter a valid email address')
      return
    }

    if (!password) {
      setError('Please enter your password')
      return
    }

    setLoading(true)
    const result = await signIn(normalizedEmail, password)

    if (result.error) {
      // Check if it's a network error
      if (result.error.message?.includes('fetch')) {
        setError(
          `Cannot reach authentication server.\n\nAPI URL: ${getApiBaseUrl()}\n\nCheck your internet connection or contact support.`
        )
      } else {
        setError(result.error.message)
      }
      setLoading(false)
    } else {
      // Auth context will handle redirect via index.tsx
      setLoading(false)
    }
  }

  const handleForgotPassword = async () => {
    setError(null)
    setSuccess(null)

    const normalizedEmail = email.trim().toLowerCase()

    if (!validateEmail(normalizedEmail)) {
      setError('Enter your email to reset your password')
      return
    }

    setForgotLoading(true)
    const result = await requestPasswordReset(normalizedEmail)
    setForgotLoading(false)

    if (result.error) {
      // Show detailed error with API info
      if (result.apiError?.code === 'NETWORK_ERROR' || result.apiError?.code === 'TIMEOUT') {
        setError(
          `${result.error}\n\nAPI URL: ${getApiBaseUrl()}\n\nIf you're testing locally, ensure EXPO_PUBLIC_API_URL is set correctly in .env`
        )
      } else {
        setError(result.error)
      }
    } else {
      setSuccess(
        'If an account exists for that email, password reset instructions have been sent.'
      )
    }
  }

  const handleAppleSignIn = async () => {
    setError(null)
    setAppleLoading(true)
    const result = await signInWithApple()
    setAppleLoading(false)
    if (result.error && result.error.message !== 'cancelled') {
      setError(result.error.message)
    }
    // Success: AuthContext fires onAuthStateChange → index.tsx handles routing
  }

  const handleCheckApiHealth = async () => {
    const health = await checkApiHealth()
    Alert.alert(
      health.reachable ? 'API Reachable ✅' : 'API Unreachable ❌',
      `${health.message}\n\nAPI URL: ${getApiBaseUrl()}`,
      [{ text: 'OK' }]
    )
  }

  return (
    <SafeAreaView
      style={[styles.container, { backgroundColor: colors.surfacePrimary }]}
      edges={['top', 'bottom']}
    >
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.header}>
            <PreWordmark size="medium" color={colors.contentPrimary} />
            <TouchableOpacity
              onPress={handleCheckApiHealth}
              style={styles.apiStatusButton}
            >
              <Text style={[styles.apiStatusText, { color: colors.contentTertiary }]}>
                API Health Check
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.content}>
            <View style={styles.titleSection}>
              <Text style={[styles.title, { color: colors.contentPrimary }]}>
                Sign in
              </Text>
              <Text style={[styles.subtitle, { color: colors.contentSecondary }]}>
                Connect with people who share your interests
              </Text>
            </View>

            {error && (
              <View style={[styles.alert, { backgroundColor: colors.error + '15', borderColor: colors.error }]}>
                <Text style={[styles.alertText, { color: colors.error }]}>
                  {error}
                </Text>
              </View>
            )}

            {success && (
              <View style={[styles.alert, { backgroundColor: colors.success + '15', borderColor: colors.success }]}>
                <Text style={[styles.alertText, { color: colors.success }]}>
                  {success}
                </Text>
              </View>
            )}

            <View style={styles.form}>
              <Input
                label="Email"
                placeholder="Email address"
                value={email}
                onChangeText={setEmail}
                autoCapitalize="none"
                autoCorrect={false}
                keyboardType="email-address"
                textContentType="emailAddress"
                testID="signin-email-input"
              />

              <Input
                label="Password"
                placeholder="••••••••"
                value={password}
                onChangeText={setPassword}
                secureTextEntry
                showPasswordToggle
                textContentType="password"
                testID="signin-password-input"
              />

              <TouchableOpacity
                onPress={handleForgotPassword}
                disabled={forgotLoading}
                style={styles.forgotButton}
              >
                <Text style={[styles.forgotText, { color: colors.contentPrimary }]}>
                  {forgotLoading ? 'Sending reset email…' : 'Forgot password?'}
                </Text>
              </TouchableOpacity>

              <Button
                onPress={handleSignIn}
                loading={loading}
                disabled={loading}
                fullWidth
                testID="signin-submit-button"
              >
                Sign In
              </Button>

              {Platform.OS === 'ios' && (
                <View style={styles.dividerRow}>
                  <View style={[styles.dividerLine, { backgroundColor: colors.borderPrimary }]} />
                  <Text style={[styles.dividerText, { color: colors.contentTertiary }]}>or</Text>
                  <View style={[styles.dividerLine, { backgroundColor: colors.borderPrimary }]} />
                </View>
              )}

              {Platform.OS === 'ios' && (
                <AppleAuthentication.AppleAuthenticationButton
                  buttonType={AppleAuthentication.AppleAuthenticationButtonType.SIGN_IN}
                  buttonStyle={AppleAuthentication.AppleAuthenticationButtonStyle.BLACK}
                  cornerRadius={BorderRadius.lg}
                  style={styles.appleButton}
                  onPress={handleAppleSignIn}
                />
              )}

              <TouchableOpacity
                onPress={() => router.push('/auth/signup')}
                style={styles.switchButton}
              >
                <Text style={[styles.switchText, { color: colors.contentSecondary }]}>
                  Don't have an account?{' '}
                  <Text style={{ color: colors.contentPrimary, fontWeight: '600' }}>
                    Sign Up
                  </Text>
                </Text>
              </TouchableOpacity>
            </View>

            <Text style={[styles.disclaimer, { color: colors.contentTertiary }]}>
              By continuing, you agree to our Terms of Service and Privacy Policy
            </Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: Spacing.lg,
  },
  header: {
    paddingTop: Spacing.lg,
    paddingBottom: Spacing.xl,
    alignItems: 'center',
  },
  apiStatusButton: {
    marginTop: Spacing.sm,
    padding: Spacing.xs,
  },
  apiStatusText: {
    fontSize: Typography.caption,
    textDecorationLine: 'underline',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
  },
  titleSection: {
    marginBottom: Spacing.xl,
  },
  title: {
    fontSize: Typography.display,
    fontWeight: Typography.medium,
    marginBottom: Spacing.sm,
  },
  subtitle: {
    fontSize: Typography.body,
  },
  alert: {
    padding: Spacing.md,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: Spacing.md,
  },
  alertText: {
    fontSize: Typography.callout,
  },
  form: {
    gap: Spacing.md,
  },
  forgotButton: {
    alignSelf: 'flex-start',
    marginTop: -Spacing.sm,
  },
  forgotText: {
    fontSize: Typography.callout,
    textDecorationLine: 'underline',
  },
  switchButton: {
    marginTop: Spacing.md,
    alignItems: 'center',
  },
  switchText: {
    fontSize: Typography.callout,
  },
  disclaimer: {
    fontSize: Typography.caption,
    textAlign: 'center',
    marginTop: Spacing.xl,
  },
  dividerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginVertical: Spacing.xs,
  },
  dividerLine: { flex: 1, height: 1 },
  dividerText: { fontSize: Typography.caption },
  appleButton: { height: 50, width: '100%' },
})
