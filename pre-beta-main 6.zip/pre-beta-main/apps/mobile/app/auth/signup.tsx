import { useState } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
} from 'react-native'
import { useRouter } from 'expo-router'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { PreWordmark } from '@/components/ui/PreWordmark'
import { validateEmail, validatePassword, normalizeInviteCode } from '@/utils/validation'
import { validateInvite, claimInvite, requestAccess } from '@/lib/api'
import { supabase } from '@/lib/supabase'
import { Spacing, Typography } from '@/constants/theme'

/**
 * Sign Up screen with invite code requirement
 * Matches pre-beta /auth with mode=signup
 */
export default function SignUpScreen() {
  const router = useRouter()
  const { colors } = useTheme()
  const { signUp } = useAuth()

  const [step, setStep] = useState<'email' | 'otp'>('email')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [inviteCode, setInviteCode] = useState('')
  const [otp, setOtp] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [otpLoading, setOtpLoading] = useState(false)
  const [inviteValidating, setInviteValidating] = useState(false)
  const [inviteDetails, setInviteDetails] = useState<any>(null)

  const validateInviteForSignup = async (targetEmail: string) => {
    const normalizedCode = normalizeInviteCode(inviteCode)
    if (!normalizedCode) {
      setError('An invite code is required to create an account.')
      return false
    }
    if (!validateEmail(targetEmail)) {
      setError('Please enter a valid email before validating your invite.')
      return false
    }

    setInviteValidating(true)
    const result = await validateInvite(normalizedCode, targetEmail)
    setInviteValidating(false)

    if (result.error) {
      setInviteDetails(null)
      setError(result.error)
      return false
    }

    const invite = result.data?.invite
    if (!invite?.code) {
      setInviteDetails(null)
      setError('Invite validation returned an invalid response.')
      return false
    }

    setInviteCode(invite.code)
    setInviteDetails(invite)
    return true
  }

  const handleSignUp = async () => {
    setError(null)
    setSuccess(null)

    const normalizedEmail = email.trim().toLowerCase()

    if (!validateEmail(normalizedEmail)) {
      setError('Please enter a valid email address')
      return
    }

    const passwordValidation = validatePassword(password)
    if (!passwordValidation.valid) {
      setError(passwordValidation.error || 'Invalid password')
      return
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match')
      return
    }

    const inviteValid = await validateInviteForSignup(normalizedEmail)
    if (!inviteValid) {
      return
    }

    setLoading(true)
    const result = await signUp(normalizedEmail, password)

    if (result.error) {
      const message = result.error.message || 'Unable to create account'
      if (
        message.toLowerCase().includes('already exists') ||
        message.toLowerCase().includes('already registered')
      ) {
        setError('Account already exists — please sign in')
      } else {
        setError(message)
      }
      setLoading(false)
    } else {
      setSuccess('We sent an 8-digit code to your email. Enter it to finish signing up.')
      setOtp('')
      setStep('otp')
      setLoading(false)
    }
  }

  const handleVerifyOtp = async () => {
    setError(null)
    setSuccess(null)

    const token = otp.replace(/\D/g, '').slice(0, 8)
    const normalizedEmail = email.trim().toLowerCase()

    if (token.length !== 8) {
      setError('Enter the 8-digit verification code.')
      return
    }

    if (!validateEmail(normalizedEmail)) {
      setError('Missing email for verification.')
      return
    }

    setOtpLoading(true)

    try {
      const { error: verifyError } = await supabase.auth.verifyOtp({
        email: normalizedEmail,
        token,
        type: 'signup',
      })

      if (verifyError) {
        throw new Error(verifyError.message || 'Unable to verify code')
      }

      // Claim invite after OTP verification
      const code = normalizeInviteCode(inviteCode)
      if (!code) {
        throw new Error('Missing invite code. Please return and try again.')
      }

      const claimResult = await claimInvite(code, normalizedEmail)
      if (claimResult.error) {
        throw new Error(claimResult.error)
      }

      // Success - will redirect via index.tsx
      setOtpLoading(false)
      router.replace('/auth/onboarding')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to verify code.')
      setOtpLoading(false)
    }
  }

  const handleResendOtp = async () => {
    setError(null)
    setSuccess(null)

    const normalizedEmail = email.trim().toLowerCase()
    if (!validateEmail(normalizedEmail)) {
      setError('Enter your email to resend the code.')
      return
    }

    try {
      const { error: resendError } = await supabase.auth.resend({
        type: 'signup',
        email: normalizedEmail,
      })

      if (resendError) {
        throw new Error(resendError.message || 'Unable to resend code.')
      }

      setSuccess('Verification code resent.')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to resend code.')
    }
  }

  const passwordChecks = {
    length: password.length >= 8,
    lower: /[a-z]/.test(password),
    upper: /[A-Z]/.test(password),
    number: /[0-9]/.test(password),
    symbol: /[^A-Za-z0-9]/.test(password),
  }

  if (step === 'otp') {
    return (
      <SafeAreaView
        style={[styles.container, { backgroundColor: colors.surfacePrimary }]}
        edges={['top', 'bottom']}
      >
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.keyboardView}
        >
          <ScrollView
            contentContainerStyle={styles.scrollContent}
            keyboardShouldPersistTaps="handled"
          >
            <View style={styles.header}>
              <PreWordmark size="medium" color={colors.contentPrimary} />
            </View>

            <View style={styles.content}>
              <TouchableOpacity
                onPress={() => setStep('email')}
                style={styles.backButton}
              >
                <Text style={[styles.backText, { color: colors.contentPrimary }]}>
                  ← Back
                </Text>
              </TouchableOpacity>

              <View style={styles.titleSection}>
                <Text style={[styles.title, { color: colors.contentPrimary }]}>
                  Verify your email
                </Text>
                <Text style={[styles.subtitle, { color: colors.contentSecondary }]}>
                  Enter the code to finish setting up your account.
                </Text>
              </View>

              {error && (
                <View style={[styles.alert, { backgroundColor: colors.error + '15', borderColor: colors.error }]}>
                  <Text style={[styles.alertText, { color: colors.error }]}>{error}</Text>
                </View>
              )}

              {success && (
                <View style={[styles.alert, { backgroundColor: colors.success + '15', borderColor: colors.success }]}>
                  <Text style={[styles.alertText, { color: colors.success }]}>{success}</Text>
                </View>
              )}

              <View style={[styles.otpInfo, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
                <Text style={[styles.otpInfoText, { color: colors.contentSecondary }]}>
                  We sent a verification code to {email}. It expires in 15 minutes.
                </Text>
              </View>

              <View style={styles.form}>
                <Input
                  label="Verification code"
                  placeholder="12345678"
                  value={otp}
                  onChangeText={(text) => setOtp(text.replace(/\D/g, '').slice(0, 8))}
                  maxLength={8}
                  keyboardType="number-pad"
                  textContentType="oneTimeCode"
                  testID="signup-otp-input"
                />

                <Button
                  onPress={handleVerifyOtp}
                  loading={otpLoading}
                  disabled={otpLoading}
                  fullWidth
                >
                  Verify Code
                </Button>

                <Button
                  onPress={handleResendOtp}
                  variant="secondary"
                  fullWidth
                >
                  Resend Code
                </Button>
              </View>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    )
  }

  return (
    <SafeAreaView
      style={[styles.container, { backgroundColor: colors.surfacePrimary }]}
      edges={['top', 'bottom']}
    >
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.header}>
            <PreWordmark size="medium" color={colors.contentPrimary} />
          </View>

          <View style={styles.content}>
            <View style={styles.titleSection}>
              <Text style={[styles.title, { color: colors.contentPrimary }]}>
                Private Sign Up
              </Text>
              <Text style={[styles.subtitle, { color: colors.contentSecondary }]}>
                pre is invite-only. Existing members can nominate up to 5 people.
              </Text>
            </View>

            {error && (
              <View style={[styles.alert, { backgroundColor: colors.error + '15', borderColor: colors.error }]}>
                <Text style={[styles.alertText, { color: colors.error }]}>{error}</Text>
              </View>
            )}

            {success && (
              <View style={[styles.alert, { backgroundColor: colors.success + '15', borderColor: colors.success }]}>
                <Text style={[styles.alertText, { color: colors.success }]}>{success}</Text>
              </View>
            )}

            <View style={styles.form}>
              <Input
                label="Email"
                placeholder="Email address"
                value={email}
                onChangeText={setEmail}
                autoCapitalize="none"
                autoCorrect={false}
                keyboardType="email-address"
                textContentType="emailAddress"
                testID="signup-email-input"
              />

              <Input
                label="Invite Code"
                placeholder="Invitation code"
                value={inviteCode}
                onChangeText={(text) => {
                  setInviteCode(normalizeInviteCode(text))
                  setInviteDetails(null)
                }}
                autoCapitalize="characters"
                autoCorrect={false}
                testID="signup-invite-input"
              />

              {inviteDetails && (
                <Text style={[styles.inviteSuccess, { color: colors.success }]}>
                  {inviteDetails.inviteeEmail
                    ? `Reserved by ${inviteDetails.inviterName} for ${inviteDetails.inviteeEmail}`
                    : `Invite shared by ${inviteDetails.inviterName}. This link can be claimed by any new member.`}
                </Text>
              )}

              {inviteValidating && (
                <Text style={[styles.inviteValidating, { color: colors.contentTertiary }]}>
                  Checking invite code...
                </Text>
              )}

              <Input
                label="Password"
                placeholder="••••••••"
                value={password}
                onChangeText={setPassword}
                secureTextEntry
                showPasswordToggle
                textContentType="newPassword"
                testID="signup-password-input"
              />

              <Input
                label="Confirm Password"
                placeholder="••••••••"
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                secureTextEntry
                showPasswordToggle
                textContentType="newPassword"
                testID="signup-confirm-password-input"
              />

              <View style={[styles.passwordChecks, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
                <Text style={[styles.passwordChecksTitle, { color: colors.contentSecondary }]}>
                  Password must include:
                </Text>
                {[
                  { label: 'At least 8 characters', ok: passwordChecks.length },
                  { label: 'One lowercase letter', ok: passwordChecks.lower },
                  { label: 'One uppercase letter', ok: passwordChecks.upper },
                  { label: 'One number', ok: passwordChecks.number },
                  { label: 'One symbol', ok: passwordChecks.symbol },
                ].map((rule) => (
                  <View key={rule.label} style={styles.passwordCheck}>
                    <Text
                      style={[
                        styles.passwordCheckText,
                        { color: rule.ok ? colors.success : colors.contentTertiary },
                      ]}
                    >
                      {rule.ok ? '✓' : '○'} {rule.label}
                    </Text>
                  </View>
                ))}
              </View>

              <Button
                onPress={handleSignUp}
                loading={loading}
                disabled={loading || inviteValidating}
                fullWidth
                testID="signup-submit-button"
              >
                Create Account
              </Button>

              <TouchableOpacity
                onPress={() => router.push('/auth/signin')}
                style={styles.switchButton}
              >
                <Text style={[styles.switchText, { color: colors.contentSecondary }]}>
                  Already have an account?{' '}
                  <Text style={{ color: colors.contentPrimary, fontWeight: '600' }}>
                    Sign In
                  </Text>
                </Text>
              </TouchableOpacity>
            </View>

            <Text style={[styles.disclaimer, { color: colors.contentTertiary }]}>
              By continuing, you agree to our Terms of Service and Privacy Policy
            </Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: Spacing.lg,
  },
  header: {
    paddingTop: Spacing.lg,
    paddingBottom: Spacing.xl,
    alignItems: 'center',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
  },
  backButton: {
    marginBottom: Spacing.md,
  },
  backText: {
    fontSize: Typography.body,
  },
  titleSection: {
    marginBottom: Spacing.xl,
  },
  title: {
    fontSize: Typography.display,
    fontWeight: Typography.medium,
    marginBottom: Spacing.sm,
  },
  subtitle: {
    fontSize: Typography.body,
  },
  alert: {
    padding: Spacing.md,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: Spacing.md,
  },
  alertText: {
    fontSize: Typography.callout,
  },
  form: {
    gap: Spacing.md,
  },
  inviteSuccess: {
    fontSize: Typography.caption,
    marginTop: -Spacing.sm,
  },
  inviteValidating: {
    fontSize: Typography.caption,
    marginTop: -Spacing.sm,
  },
  passwordChecks: {
    padding: Spacing.md,
    borderRadius: 12,
    borderWidth: 1,
    gap: Spacing.xs,
  },
  passwordChecksTitle: {
    fontSize: Typography.caption,
    marginBottom: Spacing.xs,
  },
  passwordCheck: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  passwordCheckText: {
    fontSize: Typography.caption,
  },
  otpInfo: {
    padding: Spacing.md,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: Spacing.md,
  },
  otpInfoText: {
    fontSize: Typography.callout,
    textAlign: 'center',
  },
  switchButton: {
    marginTop: Spacing.md,
    alignItems: 'center',
  },
  switchText: {
    fontSize: Typography.callout,
  },
  disclaimer: {
    fontSize: Typography.caption,
    textAlign: 'center',
    marginTop: Spacing.xl,
  },
})
