import { useEffect } from 'react'
import { useRouter, useLocalSearchParams } from 'expo-router'
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useTheme } from '@/contexts/ThemeContext'
import { supabase } from '@/lib/supabase'
import { Spacing, Typography } from '@/constants/theme'

/**
 * Auth callback handler
 * Handles OAuth callbacks and password reset deep links
 * Matches pre-beta /auth/callback
 */
export default function AuthCallbackScreen() {
  const router = useRouter()
  const params = useLocalSearchParams()
  const { colors } = useTheme()

  useEffect(() => {
    const handleCallback = async () => {
      // Check for password recovery
      if (params.type === 'recovery') {
        // Token will be handled automatically by Supabase
        // Redirect to reset password screen
        router.replace('/auth/reset')
        return
      }

      // Check for session
      const { data: { session } } = await supabase.auth.getSession()

      if (session) {
        // User authenticated, check where to redirect
        const next = Array.isArray(params.next) ? params.next[0] : params.next
        if (next) {
          router.replace(next as any)
        } else {
          router.replace('/(tabs)/home')
        }
      } else {
        // No session, redirect to signin
        router.replace('/auth/signin')
      }
    }

    handleCallback()
  }, [params, router])

  return (
    <SafeAreaView
      style={[styles.container, { backgroundColor: colors.surfacePrimary }]}
      edges={['top', 'bottom']}
    >
      <View style={styles.content}>
        <ActivityIndicator size="large" color={colors.contentPrimary} />
        <Text style={[styles.text, { color: colors.contentSecondary }]}>
          Loading...
        </Text>
      </View>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: Spacing.base,
  },
  text: {
    fontSize: Typography.body,
  },
})
