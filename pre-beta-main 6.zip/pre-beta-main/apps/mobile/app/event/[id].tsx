import React, { useState, useCallback, useEffect } from 'react'
import {
  View,
  Text,
  ScrollView,
  Pressable,
  StyleSheet,
  ActivityIndicator,
  Image,
  Alert,
  Linking,
  Platform,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useLocalSearchParams, useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

// ─── Types ────────────────────────────────────────────────────────────────────

interface EventDetail {
  id: string
  title: string
  description: string | null
  starts_at: string
  ends_at: string | null
  location: string
  location_text: string | null
  location_lat: number | null
  location_lng: number | null
  attendee_count: number
  max_attendees: number | null
  is_public: boolean
  is_campus_only: boolean
  category: string | null
  hero_image_url: string | null
  image_url: string | null
  creator_id: string
  circle_id: string | null
}

interface Attendee {
  user_id: string
  status: 'going' | 'maybe' | 'not_going'
  profiles: {
    full_name: string | null
    username: string | null
    avatar_url: string | null
    is_verified: boolean
  } | null
}

type RsvpStatus = 'going' | 'maybe' | 'not_going' | null

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getInitials(name: string | null, username: string | null): string {
  if (name) return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
  if (username) return username[0].toUpperCase()
  return '?'
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('en-US', {
    weekday: 'long', month: 'long', day: 'numeric', year: 'numeric',
  })
}

function formatTime(iso: string): string {
  return new Date(iso).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
}

function Avatar({
  uri, name, username, size = 36, colors,
}: { uri: string | null; name: string | null; username: string | null; size?: number; colors: any }) {
  if (uri) return <Image source={{ uri }} style={{ width: size, height: size, borderRadius: size / 2 }} />
  return (
    <View style={{
      width: size, height: size, borderRadius: size / 2,
      backgroundColor: colors.surfaceElevated,
      borderWidth: 1, borderColor: colors.borderPrimary,
      justifyContent: 'center', alignItems: 'center',
    }}>
      <Text style={{ fontSize: size * 0.35, color: colors.contentPrimary, fontWeight: '600' }}>
        {getInitials(name, username)}
      </Text>
    </View>
  )
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function EventDetailScreen() {
  const { id: eventId } = useLocalSearchParams<{ id: string }>()
  const router = useRouter()
  const { colors } = useTheme()
  const { user } = useAuth()

  const [event, setEvent] = useState<EventDetail | null>(null)
  const [attendees, setAttendees] = useState<Attendee[]>([])
  const [myRsvp, setMyRsvp] = useState<RsvpStatus>(null)
  const [loading, setLoading] = useState(true)
  const [rsvping, setRsvping] = useState(false)

  const loadEvent = useCallback(async () => {
    if (!eventId || !user) return
    setLoading(true)

    const [eventRes, attendeesRes, myRsvpRes] = await Promise.all([
      supabase
        .from('events')
        .select('id, title, description, starts_at, ends_at, location, location_text, location_lat, location_lng, attendee_count, max_attendees, is_public, is_campus_only, category, hero_image_url, image_url, creator_id, circle_id')
        .eq('id', eventId)
        .single(),
      supabase
        .from('event_attendees')
        .select('user_id, status, profiles(full_name, username, avatar_url, is_verified)')
        .eq('event_id', eventId)
        .eq('status', 'going')
        .limit(20),
      supabase
        .from('event_attendees')
        .select('status')
        .eq('event_id', eventId)
        .eq('user_id', user.id)
        .maybeSingle(),
    ])

    if (eventRes.data) setEvent(eventRes.data)
    if (attendeesRes.data) setAttendees(attendeesRes.data as Attendee[])
    if (myRsvpRes.data) setMyRsvp(myRsvpRes.data.status as RsvpStatus)
    setLoading(false)
  }, [eventId, user])

  useEffect(() => { loadEvent() }, [loadEvent])

  // ─── RSVP ──────────────────────────────────────────────────────────────────

  const handleRsvp = async (status: 'going' | 'maybe' | 'not_going') => {
    if (!user || !eventId || rsvping) return
    setRsvping(true)
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)

    const prev = myRsvp

    if (myRsvp === status) {
      // Toggle off
      setMyRsvp(null)
      if (status === 'going') {
        setEvent(e => e ? { ...e, attendee_count: Math.max(0, e.attendee_count - 1) } : e)
      }
      await supabase.from('event_attendees').delete().match({ event_id: eventId, user_id: user.id })
    } else {
      const wasGoing = myRsvp === 'going'
      const nowGoing = status === 'going'
      setMyRsvp(status)
      if (wasGoing && !nowGoing) {
        setEvent(e => e ? { ...e, attendee_count: Math.max(0, e.attendee_count - 1) } : e)
      } else if (!wasGoing && nowGoing) {
        setEvent(e => e ? { ...e, attendee_count: e.attendee_count + 1 } : e)
      }

      const { error } = await supabase
        .from('event_attendees')
        .upsert({ event_id: eventId, user_id: user.id, status }, { onConflict: 'event_id,user_id' })

      if (error) {
        setMyRsvp(prev)
        setEvent(e => e ? { ...e, attendee_count: e.attendee_count } : e)
        Alert.alert('Error', 'Could not update your RSVP. Please try again.')
      }
    }
    setRsvping(false)
  }

  // ─── Open maps ─────────────────────────────────────────────────────────────

  const openMaps = () => {
    if (!event) return
    const query = encodeURIComponent(event.location_text || event.location)
    const url = Platform.OS === 'ios'
      ? `maps://?q=${query}`
      : `geo:0,0?q=${query}`
    Linking.openURL(url).catch(() => {
      Linking.openURL(`https://maps.google.com/?q=${query}`)
    })
  }

  // ─── Render ────────────────────────────────────────────────────────────────

  if (loading) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
        <Pressable onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
        </Pressable>
        <View style={styles.centered}><ActivityIndicator color={colors.contentTertiary} /></View>
      </SafeAreaView>
    )
  }

  if (!event) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
        <Pressable onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
        </Pressable>
        <View style={styles.centered}>
          <Ionicons name="alert-circle-outline" size={40} color={colors.contentTertiary} />
          <Text style={[styles.errorText, { color: colors.contentPrimary }]}>Event not found</Text>
        </View>
      </SafeAreaView>
    )
  }

  const heroImage = event.hero_image_url || event.image_url
  const isPast = new Date(event.starts_at) < new Date()
  const isFull = event.max_attendees != null && event.attendee_count >= event.max_attendees && myRsvp !== 'going'

  const rsvpOptions: { status: 'going' | 'maybe' | 'not_going'; label: string; icon: string }[] = [
    { status: 'going', label: 'Going', icon: 'checkmark-circle' },
    { status: 'maybe', label: 'Interested', icon: 'star' },
    { status: 'not_going', label: "Can't go", icon: 'close-circle' },
  ]

  const isCreator = event.creator_id === user?.id

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      {/* Back button (floats over hero) */}
      <Pressable
        onPress={() => router.back()}
        style={[styles.backButton, heroImage ? styles.backButtonHero : null]}
      >
        <Ionicons name="chevron-back" size={24} color={heroImage ? '#fff' : colors.contentPrimary} />
      </Pressable>

      {/* Edit button for creator */}
      {isCreator && (
        <Pressable
          onPress={() => router.push(`/edit-event/${eventId}` as any)}
          style={[styles.moreButton, heroImage ? styles.moreButtonHero : null]}
        >
          <Ionicons name="ellipsis-horizontal" size={20} color={heroImage ? '#fff' : colors.contentPrimary} />
        </Pressable>
      )}

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 100 }}>
        {/* Hero image */}
        {heroImage && (
          <Image source={{ uri: heroImage }} style={styles.heroImage} resizeMode="cover" />
        )}

        <View style={styles.body}>
          {/* Title + meta */}
          <View style={styles.titleSection}>
            {event.category && (
              <View style={[styles.categoryTag, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
                <Text style={[styles.categoryTagText, { color: colors.contentSecondary }]}>{event.category}</Text>
              </View>
            )}
            <Text style={[styles.title, { color: colors.contentPrimary }]}>{event.title}</Text>

            {event.is_campus_only && (
              <View style={styles.campusRow}>
                <Ionicons name="school-outline" size={14} color={colors.contentTertiary} />
                <Text style={[styles.campusText, { color: colors.contentTertiary }]}>Campus only</Text>
              </View>
            )}
          </View>

          {/* Date & time */}
          <View style={[styles.infoCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
            <View style={styles.infoRow}>
              <View style={[styles.infoIcon, { backgroundColor: colors.surfaceElevated }]}>
                <Ionicons name="calendar" size={18} color={colors.contentPrimary} />
              </View>
              <View style={styles.infoText}>
                <Text style={[styles.infoLabel, { color: colors.contentTertiary }]}>Date</Text>
                <Text style={[styles.infoValue, { color: colors.contentPrimary }]}>{formatDate(event.starts_at)}</Text>
              </View>
            </View>
            <View style={[styles.infoDivider, { backgroundColor: colors.borderSecondary }]} />
            <View style={styles.infoRow}>
              <View style={[styles.infoIcon, { backgroundColor: colors.surfaceElevated }]}>
                <Ionicons name="time" size={18} color={colors.contentPrimary} />
              </View>
              <View style={styles.infoText}>
                <Text style={[styles.infoLabel, { color: colors.contentTertiary }]}>Time</Text>
                <Text style={[styles.infoValue, { color: colors.contentPrimary }]}>
                  {formatTime(event.starts_at)}{event.ends_at ? ` — ${formatTime(event.ends_at)}` : ''}
                </Text>
              </View>
            </View>
          </View>

          {/* Location */}
          <Pressable
            onPress={openMaps}
            style={[styles.infoCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}
          >
            <View style={styles.infoRow}>
              <View style={[styles.infoIcon, { backgroundColor: colors.surfaceElevated }]}>
                <Ionicons name="location" size={18} color={colors.contentPrimary} />
              </View>
              <View style={styles.infoText}>
                <Text style={[styles.infoLabel, { color: colors.contentTertiary }]}>Location</Text>
                <Text style={[styles.infoValue, { color: colors.contentPrimary }]}>
                  {event.location_text || event.location}
                </Text>
              </View>
              <Ionicons name="open-outline" size={16} color={colors.contentTertiary} />
            </View>
          </Pressable>

          {/* Description */}
          {event.description && (
            <View style={[styles.infoCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
              <Text style={[styles.sectionLabel, { color: colors.contentTertiary }]}>About</Text>
              <Text style={[styles.description, { color: colors.contentPrimary }]}>{event.description}</Text>
            </View>
          )}

          {/* RSVP */}
          {!isPast && (
            <View style={styles.rsvpSection}>
              <Text style={[styles.sectionLabel, { color: colors.contentTertiary }]}>RSVP</Text>
              <View style={styles.rsvpRow}>
                {rsvpOptions.map(opt => {
                  const active = myRsvp === opt.status
                  const disabled = rsvping || (isFull && opt.status === 'going' && !active)
                  return (
                    <Pressable
                      key={opt.status}
                      onPress={() => !disabled && handleRsvp(opt.status)}
                      style={[
                        styles.rsvpBtn,
                        {
                          backgroundColor: active ? colors.contentPrimary : colors.surfaceSecondary,
                          borderColor: active ? colors.contentPrimary : colors.borderSecondary,
                          opacity: disabled ? 0.4 : 1,
                        },
                      ]}
                    >
                      <Ionicons
                        name={opt.icon as any}
                        size={16}
                        color={active ? colors.contentInverse : colors.contentSecondary}
                      />
                      <Text style={[styles.rsvpBtnText, { color: active ? colors.contentInverse : colors.contentSecondary }]}>
                        {opt.label}
                      </Text>
                    </Pressable>
                  )
                })}
              </View>
              {isFull && (
                <Text style={[styles.fullText, { color: colors.warning }]}>Event is full</Text>
              )}
            </View>
          )}

          {isPast && (
            <View style={[styles.pastBanner, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
              <Ionicons name="time-outline" size={16} color={colors.contentTertiary} />
              <Text style={[styles.pastText, { color: colors.contentTertiary }]}>This event has already passed</Text>
            </View>
          )}

          {/* Attendees */}
          <View style={styles.attendeesSection}>
            <Text style={[styles.sectionLabel, { color: colors.contentTertiary }]}>
              {event.attendee_count > 0
                ? `${event.attendee_count.toLocaleString()} going${event.max_attendees ? ` · ${event.max_attendees} max` : ''}`
                : 'No attendees yet'}
            </Text>
            {attendees.length > 0 && (
              <View style={styles.avatarRow}>
                {attendees.slice(0, 10).map(a => (
                  <Pressable
                    key={a.user_id}
                    onPress={() => router.push(`/user/${a.user_id}` as any)}
                  >
                    <Avatar
                      uri={a.profiles?.avatar_url ?? null}
                      name={a.profiles?.full_name ?? null}
                      username={a.profiles?.username ?? null}
                      size={40}
                      colors={colors}
                    />
                  </Pressable>
                ))}
                {event.attendee_count > 10 && (
                  <View style={[styles.moreAvatars, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
                    <Text style={[styles.moreText, { color: colors.contentSecondary }]}>
                      +{event.attendee_count - 10}
                    </Text>
                  </View>
                )}
              </View>
            )}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: Spacing.md },
  errorText: { fontSize: Typography.headline, fontWeight: '600' },

  backButton: {
    position: 'absolute',
    top: 56,
    left: Spacing.sm,
    zIndex: 10,
    width: 36,
    height: 36,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonHero: {
    top: 56,
    backgroundColor: 'rgba(0,0,0,0.35)',
    borderRadius: 18,
  },
  moreButton: {
    position: 'absolute',
    top: 56,
    right: Spacing.sm,
    zIndex: 10,
    width: 36,
    height: 36,
    justifyContent: 'center',
    alignItems: 'center',
  },
  moreButtonHero: {
    backgroundColor: 'rgba(0,0,0,0.35)',
    borderRadius: 18,
  },

  heroImage: {
    width: '100%',
    height: 220,
  },

  body: {
    padding: Spacing.base,
    gap: Spacing.md,
  },

  titleSection: { gap: Spacing.sm, paddingTop: Spacing.md },
  title: { fontSize: Typography.title, fontWeight: '700', lineHeight: Typography.title * 1.2 },

  categoryTag: {
    alignSelf: 'flex-start',
    paddingHorizontal: Spacing.md,
    paddingVertical: 4,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
  categoryTagText: { fontSize: Typography.caption, fontWeight: '500' },

  campusRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  campusText: { fontSize: Typography.caption },

  infoCard: {
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    overflow: 'hidden',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    padding: Spacing.base,
  },
  infoIcon: {
    width: 36,
    height: 36,
    borderRadius: BorderRadius.md,
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoText: { flex: 1 },
  infoLabel: { fontSize: Typography.caption, marginBottom: 2 },
  infoValue: { fontSize: Typography.callout, fontWeight: '500' },
  infoDivider: { height: 1, marginHorizontal: Spacing.base },

  sectionLabel: {
    fontSize: Typography.caption,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
  },
  description: { fontSize: Typography.body, lineHeight: Typography.body * 1.55 },

  rsvpSection: { gap: Spacing.md },
  rsvpRow: { flexDirection: 'row', gap: Spacing.sm },
  rsvpBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
  },
  rsvpBtnText: { fontSize: Typography.caption, fontWeight: '600' },
  fullText: { fontSize: Typography.caption, textAlign: 'center' },

  pastBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    padding: Spacing.base,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
  },
  pastText: { fontSize: Typography.callout },

  attendeesSection: { gap: Spacing.md },
  avatarRow: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  moreAvatars: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  moreText: { fontSize: Typography.caption, fontWeight: '600' },
})
