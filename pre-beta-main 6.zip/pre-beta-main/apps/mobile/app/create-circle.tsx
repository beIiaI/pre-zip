import React, { useState } from 'react'
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Switch,
  Alert,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

const CATEGORIES = [
  'Social', 'Academic', 'Sports', 'Arts', 'Technology',
  'Gaming', 'Music', 'Food', 'Wellness', 'Career', 'Other',
]

export default function CreateCircleScreen() {
  const router = useRouter()
  const { colors } = useTheme()
  const { user } = useAuth()

  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [category, setCategory] = useState<string | null>(null)
  const [isPublic, setIsPublic] = useState(true)
  const [submitting, setSubmitting] = useState(false)

  const canSubmit = name.trim().length >= 2 && !submitting

  const handleCreate = async () => {
    if (!canSubmit || !user) return
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)
    setSubmitting(true)

    const { data: circle, error } = await supabase
      .from('circles')
      .insert({
        name: name.trim(),
        description: description.trim() || null,
        category,
        is_public: isPublic,
        creator_id: user.id,
        member_count: 1,
      })
      .select('id')
      .single()

    if (error || !circle) {
      setSubmitting(false)
      Alert.alert('Error', 'Could not create circle. Please try again.')
      return
    }

    // Add creator as admin
    await supabase.from('circle_members').insert({
      circle_id: circle.id,
      user_id: user.id,
      role: 'admin',
    })

    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success)
    router.replace(`/circle/${circle.id}` as any)
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>

        {/* Header */}
        <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
          <Pressable onPress={() => router.back()} style={styles.headerButton}>
            <Text style={[styles.headerCancel, { color: colors.contentSecondary }]}>Cancel</Text>
          </Pressable>
          <Text style={[styles.headerTitle, { color: colors.contentPrimary }]}>New Circle</Text>
          <Pressable
            onPress={handleCreate}
            style={styles.headerButton}
            disabled={!canSubmit}
          >
            {submitting ? (
              <ActivityIndicator size="small" color={colors.contentPrimary} />
            ) : (
              <Text style={[styles.headerCreate, { color: canSubmit ? colors.contentPrimary : colors.contentTertiary, fontWeight: '600' }]}>
                Create
              </Text>
            )}
          </Pressable>
        </View>

        <ScrollView
          contentContainerStyle={styles.body}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Name */}
          <View style={styles.fieldGroup}>
            <Text style={[styles.label, { color: colors.contentSecondary }]}>CIRCLE NAME *</Text>
            <View style={[styles.inputWrap, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
              <TextInput
                value={name}
                onChangeText={setName}
                placeholder="e.g. Coffee Lovers Club"
                placeholderTextColor={colors.contentTertiary}
                style={[styles.input, { color: colors.contentPrimary }]}
                maxLength={50}
                autoFocus
                returnKeyType="next"
              />
            </View>
            <Text style={[styles.hint, { color: colors.contentTertiary }]}>{name.length}/50</Text>
          </View>

          {/* Description */}
          <View style={styles.fieldGroup}>
            <Text style={[styles.label, { color: colors.contentSecondary }]}>DESCRIPTION</Text>
            <View style={[styles.inputWrap, styles.textareaWrap, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
              <TextInput
                value={description}
                onChangeText={setDescription}
                placeholder="What's this circle about?"
                placeholderTextColor={colors.contentTertiary}
                style={[styles.input, styles.textarea, { color: colors.contentPrimary }]}
                multiline
                maxLength={300}
                textAlignVertical="top"
              />
            </View>
            <Text style={[styles.hint, { color: colors.contentTertiary }]}>{description.length}/300</Text>
          </View>

          {/* Category */}
          <View style={styles.fieldGroup}>
            <Text style={[styles.label, { color: colors.contentSecondary }]}>CATEGORY</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.pillScroll}>
              {CATEGORIES.map(cat => {
                const selected = category === cat
                return (
                  <Pressable
                    key={cat}
                    onPress={() => { Haptics.selectionAsync(); setCategory(selected ? null : cat) }}
                    style={[
                      styles.pill,
                      {
                        backgroundColor: selected ? colors.contentPrimary : colors.surfaceSecondary,
                        borderColor: selected ? colors.contentPrimary : colors.borderSecondary,
                      },
                    ]}
                  >
                    <Text style={[styles.pillText, { color: selected ? colors.contentInverse : colors.contentSecondary }]}>
                      {cat}
                    </Text>
                  </Pressable>
                )
              })}
            </ScrollView>
          </View>

          {/* Public toggle */}
          <View style={[styles.toggleRow, { borderColor: colors.borderSecondary, backgroundColor: colors.surfaceSecondary }]}>
            <View style={styles.toggleInfo}>
              <Text style={[styles.toggleLabel, { color: colors.contentPrimary }]}>Public circle</Text>
              <Text style={[styles.toggleSub, { color: colors.contentTertiary }]}>
                {isPublic ? 'Anyone can find and join' : 'Only people you invite can join'}
              </Text>
            </View>
            <Switch
              value={isPublic}
              onValueChange={v => { Haptics.selectionAsync(); setIsPublic(v) }}
              trackColor={{ false: colors.borderSecondary, true: colors.contentPrimary }}
              thumbColor={colors.contentInverse}
            />
          </View>

          {/* Create button (bottom) */}
          <Pressable
            onPress={handleCreate}
            disabled={!canSubmit}
            style={[
              styles.createBtn,
              { backgroundColor: canSubmit ? colors.contentPrimary : colors.surfaceElevated },
            ]}
          >
            {submitting ? (
              <ActivityIndicator color={colors.contentInverse} />
            ) : (
              <Text style={[styles.createBtnText, { color: canSubmit ? colors.contentInverse : colors.contentTertiary }]}>
                Create Circle
              </Text>
            )}
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1 },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
  },
  headerButton: { minWidth: 60 },
  headerTitle: { fontSize: Typography.callout, fontWeight: '600' },
  headerCancel: { fontSize: Typography.callout },
  headerCreate: { fontSize: Typography.callout },

  body: {
    padding: Spacing.base,
    gap: Spacing.lg,
    paddingBottom: 60,
  },

  fieldGroup: { gap: Spacing.xs },
  label: {
    fontSize: 11,
    fontWeight: '600',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
  },
  inputWrap: {
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    paddingHorizontal: Spacing.md,
    paddingVertical: 12,
  },
  textareaWrap: { paddingVertical: Spacing.md },
  input: { fontSize: Typography.callout, padding: 0 },
  textarea: { minHeight: 80 },
  hint: { fontSize: Typography.caption, textAlign: 'right' },

  pillScroll: { gap: Spacing.sm, paddingVertical: 4 },
  pill: {
    paddingHorizontal: Spacing.md,
    paddingVertical: 7,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
  pillText: { fontSize: Typography.caption, fontWeight: '500' },

  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    padding: Spacing.md,
    gap: Spacing.base,
  },
  toggleInfo: { flex: 1, gap: 2 },
  toggleLabel: { fontSize: Typography.callout, fontWeight: '500' },
  toggleSub: { fontSize: Typography.caption },

  createBtn: {
    borderRadius: BorderRadius.md,
    paddingVertical: 15,
    alignItems: 'center',
    marginTop: Spacing.md,
  },
  createBtnText: { fontSize: Typography.callout, fontWeight: '600' },
})
