import React, { useState, useCallback, useRef } from 'react'
import {
  View,
  Text,
  FlatList,
  Pressable,
  StyleSheet,
  ActivityIndicator,
  Image,
  TextInput,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

interface UserResult {
  id: string
  full_name: string | null
  username: string | null
  avatar_url: string | null
  bio: string | null
}

function getInitials(name: string | null, username: string | null): string {
  if (name) return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
  if (username) return username[0].toUpperCase()
  return '?'
}

export default function NewMessageScreen() {
  const router = useRouter()
  const { colors } = useTheme()
  const { user } = useAuth()

  const [query, setQuery] = useState('')
  const [results, setResults] = useState<UserResult[]>([])
  const [searching, setSearching] = useState(false)
  const [starting, setStarting] = useState<string | null>(null)
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const doSearch = useCallback(async (q: string) => {
    if (!q.trim() || !user) { setResults([]); setSearching(false); return }

    const { data } = await supabase
      .from('profiles')
      .select('id, full_name, username, avatar_url, bio')
      .neq('id', user.id)
      .or(`full_name.ilike.%${q}%,username.ilike.%${q}%`)
      .eq('onboarding_completed', true)
      .limit(20)

    setResults(data ?? [])
    setSearching(false)
  }, [user])

  const handleQueryChange = (text: string) => {
    setQuery(text)
    if (debounceRef.current) clearTimeout(debounceRef.current)
    if (!text.trim()) { setResults([]); setSearching(false); return }
    setSearching(true)
    debounceRef.current = setTimeout(() => doSearch(text), 300)
  }

  const startConversation = async (otherId: string) => {
    if (!user || starting) return
    setStarting(otherId)

    // Check if thread already exists (either direction)
    const { data: existing } = await supabase
      .from('dm_threads')
      .select('id')
      .or(`and(user_a.eq.${user.id},user_b.eq.${otherId}),and(user_a.eq.${otherId},user_b.eq.${user.id})`)
      .maybeSingle()

    if (existing) {
      router.replace(`/conversation/${existing.id}` as any)
      return
    }

    // Create new thread
    const { data: newThread, error } = await supabase
      .from('dm_threads')
      .insert({ user_a: user.id, user_b: otherId })
      .select('id')
      .single()

    if (error || !newThread) { setStarting(null); return }

    // Add both participants
    await supabase.from('dm_participants').insert([
      { thread_id: newThread.id, user_id: user.id },
      { thread_id: newThread.id, user_id: otherId },
    ])

    router.replace(`/conversation/${newThread.id}` as any)
  }

  const renderUser = ({ item }: { item: UserResult }) => {
    const initials = getInitials(item.full_name, item.username)
    const isStarting = starting === item.id

    return (
      <Pressable
        style={({ pressed }) => [
          styles.userRow,
          { borderBottomColor: colors.borderSecondary, opacity: pressed ? 0.7 : 1 },
        ]}
        onPress={() => startConversation(item.id)}
        disabled={!!starting}
      >
        {item.avatar_url ? (
          <Image source={{ uri: item.avatar_url }} style={styles.avatar} />
        ) : (
          <View style={[styles.avatar, styles.avatarFallback, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
            <Text style={[styles.avatarInitials, { color: colors.contentPrimary }]}>{initials}</Text>
          </View>
        )}

        <View style={styles.userInfo}>
          <Text style={[styles.userName, { color: colors.contentPrimary }]} numberOfLines={1}>
            {item.full_name || item.username}
          </Text>
          {item.username && (
            <Text style={[styles.userHandle, { color: colors.contentSecondary }]}>@{item.username}</Text>
          )}
        </View>

        {isStarting ? (
          <ActivityIndicator size="small" color={colors.contentTertiary} />
        ) : (
          <Ionicons name="chevron-forward" size={16} color={colors.contentTertiary} />
        )}
      </Pressable>
    )
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
        <Pressable onPress={() => router.back()} style={styles.cancelButton}>
          <Text style={[styles.cancelText, { color: colors.contentPrimary }]}>Cancel</Text>
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.contentPrimary }]}>New Message</Text>
        <View style={styles.cancelButton} />
      </View>

      <View style={[styles.searchBar, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
        <Ionicons name="search" size={16} color={colors.contentTertiary} />
        <TextInput
          value={query}
          onChangeText={handleQueryChange}
          placeholder="Search by name or username…"
          placeholderTextColor={colors.contentTertiary}
          style={[styles.searchInput, { color: colors.contentPrimary }]}
          autoFocus
          autoCapitalize="none"
          autoCorrect={false}
        />
        {searching && <ActivityIndicator size="small" color={colors.contentTertiary} />}
      </View>

      <FlatList
        data={results}
        keyExtractor={item => item.id}
        renderItem={renderUser}
        ListEmptyComponent={
          query.length > 0 && !searching ? (
            <View style={styles.emptyState}>
              <Text style={[styles.emptyText, { color: colors.contentTertiary }]}>No members found</Text>
            </View>
          ) : query.length === 0 ? (
            <View style={styles.emptyState}>
              <Ionicons name="search-outline" size={36} color={colors.contentTertiary} />
              <Text style={[styles.emptyText, { color: colors.contentTertiary }]}>Search for a member to message</Text>
            </View>
          ) : null
        }
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1 },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
  },
  headerTitle: { flex: 1, textAlign: 'center', fontSize: Typography.callout, fontWeight: '600' },
  cancelButton: { width: 60 },
  cancelText: { fontSize: Typography.callout },

  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginHorizontal: Spacing.base,
    marginVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    paddingVertical: 10,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
  },
  searchInput: { flex: 1, fontSize: Typography.callout, padding: 0 },

  userRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    gap: Spacing.md,
  },
  avatar: { width: 44, height: 44, borderRadius: 22 },
  avatarFallback: { borderWidth: 1, justifyContent: 'center', alignItems: 'center' },
  avatarInitials: { fontSize: 16, fontWeight: '600' },
  userInfo: { flex: 1 },
  userName: { fontSize: Typography.callout, fontWeight: '500' },
  userHandle: { fontSize: Typography.caption, marginTop: 2 },

  emptyState: { alignItems: 'center', paddingTop: 60, gap: Spacing.md },
  emptyText: { fontSize: Typography.callout, textAlign: 'center' },
})
