import React, { useState, useCallback, useEffect } from 'react'
import {
  View,
  Text,
  FlatList,
  Pressable,
  StyleSheet,
  ActivityIndicator,
  RefreshControl,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

// ─── Types ────────────────────────────────────────────────────────────────────

interface AppNotification {
  id: string
  type: string
  title: string
  body: string | null
  data: any
  read: boolean
  created_at: string
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatTime(iso: string): string {
  const d = new Date(iso)
  const now = new Date()
  const diffMs = now.getTime() - d.getTime()
  const diffMins = Math.floor(diffMs / 60_000)
  const diffHrs = Math.floor(diffMins / 60)
  const diffDays = Math.floor(diffHrs / 24)

  if (diffMins < 1) return 'Just now'
  if (diffMins < 60) return `${diffMins}m ago`
  if (diffHrs < 24) return `${diffHrs}h ago`
  if (diffDays < 7) return `${diffDays}d ago`
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
}

function getNotificationIcon(type: string): { name: string; color: string } {
  const map: Record<string, { name: string; color: string }> = {
    message: { name: 'chatbubble', color: '#0A84FF' },
    circle_invite: { name: 'people', color: '#30D158' },
    circle_join: { name: 'person-add', color: '#30D158' },
    event: { name: 'calendar', color: '#FF9F0A' },
    event_reminder: { name: 'alarm', color: '#FF9F0A' },
    mention: { name: 'at', color: '#BF5AF2' },
    follow: { name: 'person-add', color: '#0A84FF' },
    badge: { name: 'ribbon', color: '#FFD60A' },
    system: { name: 'information-circle', color: '#636366' },
  }
  return map[type] ?? { name: 'notifications', color: '#636366' }
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function NotificationsScreen() {
  const router = useRouter()
  const { colors } = useTheme()
  const { user } = useAuth()

  const [notifications, setNotifications] = useState<AppNotification[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [unreadCount, setUnreadCount] = useState(0)

  const fetchNotifications = useCallback(async (refresh = false) => {
    if (!user) return
    if (refresh) setRefreshing(true)
    else setLoading(true)

    const { data } = await supabase
      .from('notifications')
      .select('id, type, title, body, data, read, created_at')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(50)

    if (data) {
      setNotifications(data)
      setUnreadCount(data.filter(n => !n.read).length)
    }
    setLoading(false)
    setRefreshing(false)
  }, [user])

  useEffect(() => { fetchNotifications() }, [fetchNotifications])

  // ─── Mark all read ─────────────────────────────────────────────────────────

  const markAllRead = async () => {
    if (!user || unreadCount === 0) return
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)

    const unreadIds = notifications.filter(n => !n.read).map(n => n.id)
    setNotifications(prev => prev.map(n => ({ ...n, read: true })))
    setUnreadCount(0)

    await supabase
      .from('notifications')
      .update({ read: true, read_at: new Date().toISOString() })
      .in('id', unreadIds)
  }

  // ─── Tap notification ──────────────────────────────────────────────────────

  const handleTap = async (item: AppNotification) => {
    Haptics.selectionAsync()

    // Mark as read
    if (!item.read) {
      setNotifications(prev => prev.map(n => n.id === item.id ? { ...n, read: true } : n))
      setUnreadCount(prev => Math.max(0, prev - 1))
      await supabase
        .from('notifications')
        .update({ read: true, read_at: new Date().toISOString() })
        .eq('id', item.id)
    }

    // Navigate based on type + data
    const d = item.data || {}
    if (d.thread_id) router.push(`/conversation/${d.thread_id}` as any)
    else if (d.circle_id) router.push(`/circle/${d.circle_id}` as any)
    else if (d.event_id) router.push(`/event/${d.event_id}` as any)
    else if (d.user_id) router.push(`/user/${d.user_id}` as any)
  }

  // ─── Render ────────────────────────────────────────────────────────────────

  const renderItem = ({ item }: { item: AppNotification }) => {
    const icon = getNotificationIcon(item.type)
    return (
      <Pressable
        onPress={() => handleTap(item)}
        style={[
          styles.notifItem,
          {
            backgroundColor: item.read ? colors.surfacePrimary : colors.surfaceSecondary,
            borderBottomColor: colors.borderSecondary,
          },
        ]}
      >
        {/* Unread dot */}
        {!item.read && (
          <View style={[styles.unreadDot, { backgroundColor: colors.contentPrimary }]} />
        )}

        {/* Icon */}
        <View style={[styles.iconWrap, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderSecondary }]}>
          <Ionicons name={icon.name as any} size={20} color={icon.color} />
        </View>

        {/* Content */}
        <View style={styles.notifContent}>
          <Text style={[styles.notifTitle, { color: colors.contentPrimary, fontWeight: item.read ? '400' : '600' }]}>
            {item.title}
          </Text>
          {item.body && (
            <Text style={[styles.notifBody, { color: colors.contentSecondary }]} numberOfLines={2}>
              {item.body}
            </Text>
          )}
          <Text style={[styles.notifTime, { color: colors.contentTertiary }]}>
            {formatTime(item.created_at)}
          </Text>
        </View>

        <Ionicons name="chevron-forward" size={14} color={colors.contentTertiary} />
      </Pressable>
    )
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
        <Pressable onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.contentPrimary }]}>Notifications</Text>
        {unreadCount > 0 && (
          <Pressable onPress={markAllRead} style={styles.markReadBtn}>
            <Text style={[styles.markReadText, { color: colors.contentPrimary }]}>Mark all read</Text>
          </Pressable>
        )}
        {unreadCount === 0 && <View style={styles.markReadBtn} />}
      </View>

      {loading ? (
        <View style={styles.centered}>
          <ActivityIndicator color={colors.contentTertiary} />
        </View>
      ) : (
        <FlatList
          data={notifications}
          keyExtractor={item => item.id}
          renderItem={renderItem}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => fetchNotifications(true)}
              tintColor={colors.contentTertiary}
            />
          }
          ListEmptyComponent={
            <View style={styles.empty}>
              <Ionicons name="notifications-off-outline" size={48} color={colors.contentTertiary} />
              <Text style={[styles.emptyTitle, { color: colors.contentPrimary }]}>No notifications</Text>
              <Text style={[styles.emptySub, { color: colors.contentSecondary }]}>
                You're all caught up! We'll notify you when something happens.
              </Text>
            </View>
          }
          contentContainerStyle={notifications.length === 0 ? styles.emptyContainer : undefined}
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  )
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.sm,
    borderBottomWidth: 1,
  },
  backButton: { width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },
  headerTitle: { flex: 1, fontSize: Typography.headline, fontWeight: '700', marginLeft: Spacing.sm },
  markReadBtn: { minWidth: 80, alignItems: 'flex-end' },
  markReadText: { fontSize: Typography.caption, fontWeight: '600' },

  notifItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    gap: Spacing.md,
    position: 'relative',
  },
  unreadDot: {
    position: 'absolute',
    left: Spacing.sm - 3,
    top: '50%',
    width: 6,
    height: 6,
    borderRadius: 3,
    marginTop: -3,
  },
  iconWrap: {
    width: 42,
    height: 42,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  notifContent: { flex: 1, gap: 2 },
  notifTitle: { fontSize: Typography.callout },
  notifBody: { fontSize: Typography.caption, lineHeight: Typography.caption * 1.5 },
  notifTime: { fontSize: Typography.caption, marginTop: 2 },

  empty: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: Spacing.md,
    padding: Spacing.xl,
  },
  emptyContainer: { flex: 1 },
  emptyTitle: { fontSize: Typography.headline, fontWeight: '600' },
  emptySub: { fontSize: Typography.callout, textAlign: 'center', lineHeight: Typography.callout * 1.5 },
})
