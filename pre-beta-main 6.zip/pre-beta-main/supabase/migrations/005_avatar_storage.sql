-- ============================================
-- Avatars storage bucket + policies
-- ============================================

DO $$
BEGIN
  BEGIN
    INSERT INTO storage.buckets (id, name, public)
    VALUES ('avatars', 'avatars', true)
    ON CONFLICT (id) DO UPDATE SET public = true;
  EXCEPTION WHEN insufficient_privilege THEN
    RAISE NOTICE 'Insufficient privilege to create/update storage bucket avatars. Create bucket via Supabase dashboard.';
  END;
END $$;

-- Note: storage.objects policies must be created by the storage owner.
-- Configure read/write policies for the avatars bucket in the Supabase dashboard.
