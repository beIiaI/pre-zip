-- Allow participants to update their own row (e.g. last_read_at)

DROP POLICY IF EXISTS dm_participants_update_self ON public.dm_participants;
CREATE POLICY dm_participants_update_self ON public.dm_participants
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());
