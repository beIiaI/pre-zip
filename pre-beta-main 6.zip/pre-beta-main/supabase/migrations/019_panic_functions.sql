-- ============================================
-- Panic event helper (creates notifications for contacts)
-- ============================================

CREATE OR REPLACE FUNCTION public.create_panic_event(lat double precision, lng double precision)
RETURNS TABLE(event_id uuid, notified_count integer)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
SET row_security = off
AS $$
DECLARE
  v_owner uuid;
  v_event_id uuid;
  v_count integer := 0;
BEGIN
  v_owner := auth.uid();
  IF v_owner IS NULL THEN
    RETURN;
  END IF;

  INSERT INTO public.panic_events (owner_id, lat, lng)
  VALUES (v_owner, lat, lng)
  RETURNING id INTO v_event_id;

  INSERT INTO public.notifications (user_id, type, title, body, data)
  SELECT
    c.contact_user_id,
    'panic_alert',
    'Emergency alert',
    'A contact triggered an alert. Tap to view location.',
    jsonb_build_object(
      'event_id', v_event_id,
      'owner_id', v_owner,
      'lat', lat,
      'lng', lng
    )
  FROM public.emergency_contacts c
  WHERE c.owner_id = v_owner;

  GET DIAGNOSTICS v_count = ROW_COUNT;

  RETURN QUERY SELECT v_event_id, v_count;
END;
$$;
