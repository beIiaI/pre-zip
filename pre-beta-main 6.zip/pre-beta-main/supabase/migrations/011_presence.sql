-- ============================================
-- Presence (last active)
-- ============================================

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS last_active_at timestamptz DEFAULT now();

UPDATE public.profiles
SET last_active_at = COALESCE(last_active_at, now())
WHERE last_active_at IS NULL;
