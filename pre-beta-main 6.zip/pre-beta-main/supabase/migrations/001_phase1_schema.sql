-- ============================================
-- PRE APP - PHASE 1 DATABASE SCHEMA
-- ============================================
-- Safe to re-run (idempotent)
-- Run in Supabase SQL Editor
-- ============================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ============================================
-- 1. PROFILES TABLE
-- ============================================

CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  email TEXT NOT NULL,
  full_name TEXT,
  username TEXT UNIQUE,
  bio TEXT,
  avatar_url TEXT,
  date_of_birth DATE,
  location TEXT,
  location_lat DOUBLE PRECISION,
  location_lng DOUBLE PRECISION,
  interests TEXT[] DEFAULT '{}',
  user_intent TEXT[] DEFAULT '{}',
  theme_mode TEXT DEFAULT 'system' CHECK (theme_mode IN ('light', 'dark', 'system')),
  amoled_enabled BOOLEAN DEFAULT FALSE,
  onboarding_completed BOOLEAN DEFAULT FALSE,
  onboarding_step INTEGER DEFAULT 1,
  early_supporter_number INTEGER UNIQUE,
  total_points INTEGER DEFAULT 0,
  is_verified BOOLEAN DEFAULT FALSE,
  verification_type TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::TEXT, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::TEXT, NOW()) NOT NULL
);

-- Index for username lookups
CREATE INDEX IF NOT EXISTS profiles_username_idx ON public.profiles (username);
CREATE UNIQUE INDEX IF NOT EXISTS profiles_username_lower_idx ON public.profiles (LOWER(username));

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'profiles_username_format'
  ) THEN
    ALTER TABLE public.profiles
      ADD CONSTRAINT profiles_username_format
      CHECK (username IS NULL OR username ~ '^[a-z][a-z0-9_]{2,19}$');
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'profiles_early_supporter_range'
  ) THEN
    ALTER TABLE public.profiles
      ADD CONSTRAINT profiles_early_supporter_range
      CHECK (early_supporter_number IS NULL OR (early_supporter_number BETWEEN 0 AND 250));
  END IF;
END $$;

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist (for re-run safety)
DROP POLICY IF EXISTS "Users can view all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Users can insert their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;

-- Create policies (require authentication for reads)
CREATE POLICY "Users can view all profiles" ON public.profiles
  FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "Users can insert their own profile" ON public.profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update their own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- Sequence for early supporter numbering
CREATE SEQUENCE IF NOT EXISTS public.early_supporter_seq
  START 1
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 250
  CACHE 1;

DO $$
DECLARE m int;
BEGIN
  SELECT MAX(early_supporter_number) INTO m
  FROM public.profiles
  WHERE early_supporter_number BETWEEN 1 AND 250;

  IF m IS NULL THEN
    PERFORM setval('public.early_supporter_seq', 1, false);
  ELSE
    PERFORM setval('public.early_supporter_seq', m, true);
  END IF;
END $$;

-- Optional backfill: if no early supporters assigned yet, assign earliest 250
DO $$
BEGIN
  IF (SELECT count(*) FROM public.profiles WHERE early_supporter_number IS NOT NULL) = 0 THEN
    UPDATE public.profiles
    SET early_supporter_number = 0
    WHERE id = 'fb04c13f-9c1d-4584-ad01-778f9874908b';

    WITH ranked AS (
      SELECT id, row_number() OVER (ORDER BY created_at ASC) AS rn
      FROM public.profiles
      WHERE early_supporter_number IS NULL
        AND id <> 'fb04c13f-9c1d-4584-ad01-778f9874908b'
    )
    UPDATE public.profiles p
    SET early_supporter_number = ranked.rn
    FROM ranked
    WHERE p.id = ranked.id AND ranked.rn <= 250;

    PERFORM (
      SELECT CASE
        WHEN MAX(early_supporter_number) FILTER (WHERE early_supporter_number BETWEEN 1 AND 250) IS NULL
          THEN setval('public.early_supporter_seq', 1, false)
        ELSE
          setval('public.early_supporter_seq',
                 MAX(early_supporter_number) FILTER (WHERE early_supporter_number BETWEEN 1 AND 250),
                 true)
      END
      FROM public.profiles
    );
  END IF;
END $$;

-- ============================================
-- 2. FUNCTION: Create profile on signup
-- ============================================

CREATE OR REPLACE FUNCTION public.assign_early_supporter_number()
RETURNS TRIGGER AS $$
DECLARE
  new_supporter_number INTEGER;
BEGIN
  IF NEW.early_supporter_number IS NOT NULL THEN
    RETURN NEW;
  END IF;

  BEGIN
    new_supporter_number := nextval('public.early_supporter_seq');
  EXCEPTION WHEN others THEN
    RETURN NEW;
  END;

  NEW.early_supporter_number := new_supporter_number;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS profiles_assign_early_supporter ON public.profiles;
CREATE TRIGGER profiles_assign_early_supporter
  BEFORE INSERT ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.assign_early_supporter_number();

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email)
  VALUES (NEW.id, NEW.email)
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop and recreate trigger (for re-run safety)
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================
-- 3. CIRCLES TABLE (structure only for Phase 1)
-- ============================================

CREATE TABLE IF NOT EXISTS public.circles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  cover_image_url TEXT,
  creator_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  is_public BOOLEAN DEFAULT TRUE,
  member_count INTEGER DEFAULT 0,
  category TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::TEXT, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::TEXT, NOW()) NOT NULL
);

ALTER TABLE public.circles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Authenticated users can view public circles" ON public.circles;
CREATE POLICY "Authenticated users can view public circles" ON public.circles
  FOR SELECT USING (auth.uid() IS NOT NULL AND (is_public = TRUE OR auth.uid() = creator_id));

-- ============================================
-- 4. CIRCLE MEMBERS TABLE (structure only)
-- ============================================

CREATE TABLE IF NOT EXISTS public.circle_members (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  circle_id UUID REFERENCES public.circles(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  role TEXT DEFAULT 'member' CHECK (role IN ('admin', 'moderator', 'member')),
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::TEXT, NOW()) NOT NULL,
  UNIQUE(circle_id, user_id)
);

ALTER TABLE public.circle_members ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Authenticated users can view circle members" ON public.circle_members;
CREATE POLICY "Authenticated users can view circle members" ON public.circle_members
  FOR SELECT USING (auth.uid() IS NOT NULL);

-- ============================================
-- 5. EVENTS TABLE (structure only)
-- ============================================

CREATE TABLE IF NOT EXISTS public.events (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  hero_image_url TEXT,
  creator_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  circle_id UUID REFERENCES public.circles(id) ON DELETE SET NULL,
  location TEXT NOT NULL,
  location_lat DOUBLE PRECISION,
  location_lng DOUBLE PRECISION,
  starts_at TIMESTAMP WITH TIME ZONE NOT NULL,
  ends_at TIMESTAMP WITH TIME ZONE,
  max_attendees INTEGER,
  attendee_count INTEGER DEFAULT 0,
  is_public BOOLEAN DEFAULT TRUE,
  category TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::TEXT, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::TEXT, NOW()) NOT NULL
);

ALTER TABLE public.events ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Authenticated users can view public events" ON public.events;
CREATE POLICY "Authenticated users can view public events" ON public.events
  FOR SELECT USING (auth.uid() IS NOT NULL AND (is_public = TRUE OR auth.uid() = creator_id));

-- ============================================
-- 6. EVENT ATTENDEES TABLE (structure only)
-- ============================================

CREATE TABLE IF NOT EXISTS public.event_attendees (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  event_id UUID REFERENCES public.events(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  status TEXT DEFAULT 'going' CHECK (status IN ('going', 'maybe', 'not_going')),
  rsvp_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::TEXT, NOW()) NOT NULL,
  UNIQUE(event_id, user_id)
);

ALTER TABLE public.event_attendees ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Authenticated users can view event attendees" ON public.event_attendees;
CREATE POLICY "Authenticated users can view event attendees" ON public.event_attendees
  FOR SELECT USING (auth.uid() IS NOT NULL);

-- ============================================
-- 7. BADGES TABLE (structure only)
-- ============================================

CREATE TABLE IF NOT EXISTS public.badges (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL,
  icon TEXT NOT NULL,
  category TEXT NOT NULL,
  points_required INTEGER,
  criteria JSONB,
  is_earnable BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::TEXT, NOW()) NOT NULL
);

ALTER TABLE public.badges ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Authenticated users can view badges" ON public.badges;
CREATE POLICY "Authenticated users can view badges" ON public.badges
  FOR SELECT USING (auth.uid() IS NOT NULL);

-- ============================================
-- 8. USER BADGES TABLE (structure only)
-- ============================================

CREATE TABLE IF NOT EXISTS public.user_badges (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  badge_id UUID REFERENCES public.badges(id) ON DELETE CASCADE NOT NULL,
  earned_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::TEXT, NOW()) NOT NULL,
  progress INTEGER DEFAULT 0,
  UNIQUE(user_id, badge_id)
);

ALTER TABLE public.user_badges ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view their badges" ON public.user_badges;
CREATE POLICY "Users can view their badges" ON public.user_badges
  FOR SELECT USING (auth.uid() = user_id);

-- ============================================
-- 9. NOTIFICATIONS TABLE (structure only)
-- ============================================

CREATE TABLE IF NOT EXISTS public.notifications (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT,
  data JSONB,
  read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::TEXT, NOW()) NOT NULL
);

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view their notifications" ON public.notifications;
CREATE POLICY "Users can view their notifications" ON public.notifications
  FOR SELECT USING (auth.uid() = user_id);

-- ============================================
-- 10. REPORTS TABLE (structure only)
-- ============================================

CREATE TABLE IF NOT EXISTS public.reports (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  reporter_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL NOT NULL,
  reported_user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  reported_content_id UUID,
  content_type TEXT,
  reason TEXT NOT NULL,
  description TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'reviewed', 'resolved', 'dismissed')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::TEXT, NOW()) NOT NULL
);

ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can create reports" ON public.reports;
CREATE POLICY "Users can create reports" ON public.reports
  FOR INSERT WITH CHECK (auth.uid() = reporter_id);

-- ============================================
-- 11. BLOCKS TABLE (structure only)
-- ============================================

CREATE TABLE IF NOT EXISTS public.blocks (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  blocker_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  blocked_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::TEXT, NOW()) NOT NULL,
  UNIQUE(blocker_id, blocked_id)
);

ALTER TABLE public.blocks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view their blocks" ON public.blocks;
DROP POLICY IF EXISTS "Users can create blocks" ON public.blocks;
DROP POLICY IF EXISTS "Users can remove blocks" ON public.blocks;

CREATE POLICY "Users can view their blocks" ON public.blocks
  FOR SELECT USING (auth.uid() = blocker_id);

CREATE POLICY "Users can create blocks" ON public.blocks
  FOR INSERT WITH CHECK (auth.uid() = blocker_id);

CREATE POLICY "Users can remove blocks" ON public.blocks
  FOR DELETE USING (auth.uid() = blocker_id);

-- ============================================
-- 12. REFERRALS TABLE (structure only)
-- ============================================

CREATE TABLE IF NOT EXISTS public.referrals (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  referrer_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL NOT NULL,
  referred_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  code TEXT NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'completed')),
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::TEXT, NOW()) NOT NULL
);

ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view their referrals" ON public.referrals;
CREATE POLICY "Users can view their referrals" ON public.referrals
  FOR SELECT USING (auth.uid() = referrer_id OR auth.uid() = referred_id);

-- ============================================
-- 13. POINTS LEDGER TABLE (structure only)
-- ============================================

CREATE TABLE IF NOT EXISTS public.points_ledger (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  amount INTEGER NOT NULL,
  reason TEXT NOT NULL,
  reference_type TEXT,
  reference_id UUID,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::TEXT, NOW()) NOT NULL
);

ALTER TABLE public.points_ledger ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view their points" ON public.points_ledger;
CREATE POLICY "Users can view their points" ON public.points_ledger
  FOR SELECT USING (auth.uid() = user_id);

-- ============================================
-- PHASE 1 COMPLETE
-- ============================================
