-- ============================================
-- Public profile college display preference
-- ============================================

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS show_college boolean NOT NULL DEFAULT false;
