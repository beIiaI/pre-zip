-- =========================================================
-- Fix circles RLS recursion
-- Root cause:
-- - circles SELECT policy queried circle_members
-- - circle_members SELECT policy queried circles
-- This mutual dependency can recurse during policy evaluation.
-- =========================================================

ALTER TABLE public.circles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.circle_members ENABLE ROW LEVEL SECURITY;

ALTER TABLE public.circles FORCE ROW LEVEL SECURITY;
ALTER TABLE public.circle_members FORCE ROW LEVEL SECURITY;

REVOKE ALL ON TABLE public.circles FROM anon;
REVOKE ALL ON TABLE public.circle_members FROM anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.circles TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.circle_members TO authenticated;

DO $$
DECLARE
  circles_policy RECORD;
  members_policy RECORD;
BEGIN
  FOR circles_policy IN
    SELECT policyname
    FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'circles'
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.circles', circles_policy.policyname);
  END LOOP;

  FOR members_policy IN
    SELECT policyname
    FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'circle_members'
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.circle_members', members_policy.policyname);
  END LOOP;
END $$;

-- circles: public circles + creator + joined circles
CREATE POLICY circles_select_authenticated ON public.circles
  FOR SELECT TO authenticated
  USING (
    is_public = TRUE
    OR creator_id = auth.uid()
    OR EXISTS (
      SELECT 1
      FROM public.circle_members cm
      WHERE cm.circle_id = circles.id
        AND cm.user_id = auth.uid()
    )
  );

CREATE POLICY circles_insert_authenticated ON public.circles
  FOR INSERT TO authenticated
  WITH CHECK (creator_id = auth.uid());

CREATE POLICY circles_update_authenticated ON public.circles
  FOR UPDATE TO authenticated
  USING (creator_id = auth.uid())
  WITH CHECK (creator_id = auth.uid());

CREATE POLICY circles_delete_authenticated ON public.circles
  FOR DELETE TO authenticated
  USING (creator_id = auth.uid());

-- circle_members:
-- Keep SELECT non-recursive: no lookup back into circles here.
CREATE POLICY circle_members_select_authenticated ON public.circle_members
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY circle_members_insert_authenticated ON public.circle_members
  FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    AND EXISTS (
      SELECT 1
      FROM public.circles c
      WHERE c.id = circle_members.circle_id
        AND (c.is_public = TRUE OR c.creator_id = auth.uid())
    )
  );

CREATE POLICY circle_members_delete_authenticated ON public.circle_members
  FOR DELETE TO authenticated
  USING (
    user_id = auth.uid()
    OR EXISTS (
      SELECT 1
      FROM public.circles c
      WHERE c.id = circle_members.circle_id
        AND c.creator_id = auth.uid()
    )
  );

CREATE INDEX IF NOT EXISTS circle_members_user_circle_lookup_idx
  ON public.circle_members (user_id, circle_id);

