-- ============================================
-- University verification fields + campus event policies
-- ============================================

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS university_verified boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS university_domain text,
  ADD COLUMN IF NOT EXISTS university_verified_at timestamptz;

UPDATE public.profiles
SET university_verified = true,
    university_domain = COALESCE(university_domain, NULLIF(split_part(email, '@', 2), '')),
    university_verified_at = COALESCE(university_verified_at, now())
WHERE is_verified = true
  AND verification_type = 'university_email';

CREATE INDEX IF NOT EXISTS profiles_university_domain_idx
  ON public.profiles (university_domain);

ALTER TABLE public.events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.event_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS events_select ON public.events;
CREATE POLICY events_select ON public.events
  FOR SELECT TO authenticated
  USING (
    is_public
    OR host_id = auth.uid()
    OR (
      is_campus_only AND EXISTS (
        SELECT 1 FROM public.profiles p
        WHERE p.id = auth.uid()
          AND p.university_verified = true
      )
    )
  );

DROP POLICY IF EXISTS events_insert ON public.events;
CREATE POLICY events_insert ON public.events
  FOR INSERT TO authenticated
  WITH CHECK (
    host_id = auth.uid()
    AND (
      NOT is_campus_only OR EXISTS (
        SELECT 1 FROM public.profiles p
        WHERE p.id = auth.uid()
          AND p.university_verified = true
      )
    )
  );

DROP POLICY IF EXISTS events_update ON public.events;
CREATE POLICY events_update ON public.events
  FOR UPDATE TO authenticated
  USING (host_id = auth.uid())
  WITH CHECK (
    host_id = auth.uid()
    AND (
      NOT is_campus_only OR EXISTS (
        SELECT 1 FROM public.profiles p
        WHERE p.id = auth.uid()
          AND p.university_verified = true
      )
    )
  );

DROP POLICY IF EXISTS event_messages_select ON public.event_messages;
CREATE POLICY event_messages_select ON public.event_messages
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.events e
      WHERE e.id = event_id
        AND (
          e.is_public
          OR e.host_id = auth.uid()
          OR (
            e.is_campus_only AND EXISTS (
              SELECT 1 FROM public.profiles p
              WHERE p.id = auth.uid()
                AND p.university_verified = true
            )
          )
        )
    )
  );

DROP POLICY IF EXISTS event_messages_insert ON public.event_messages;
CREATE POLICY event_messages_insert ON public.event_messages
  FOR INSERT TO authenticated
  WITH CHECK (
    sender_id = auth.uid()
    AND EXISTS (
      SELECT 1 FROM public.events e
      WHERE e.id = event_id
        AND (
          e.is_public
          OR e.host_id = auth.uid()
          OR (
            e.is_campus_only AND EXISTS (
              SELECT 1 FROM public.profiles p
              WHERE p.id = auth.uid()
                AND p.university_verified = true
            )
          )
        )
    )
  );
