-- ============================================
-- Exclusive invite limits + safety hardening
-- ============================================

CREATE OR REPLACE FUNCTION public.enforce_access_invite_limit()
RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  existing_count integer;
BEGIN
  SELECT count(*)
    INTO existing_count
  FROM public.access_invites
  WHERE inviter_id = NEW.inviter_id;

  IF existing_count >= 5 THEN
    RAISE EXCEPTION 'invite_limit_reached';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS access_invites_limit_trigger ON public.access_invites;
CREATE TRIGGER access_invites_limit_trigger
  BEFORE INSERT ON public.access_invites
  FOR EACH ROW
  EXECUTE FUNCTION public.enforce_access_invite_limit();

CREATE OR REPLACE FUNCTION public.touch_access_invites_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS access_invites_updated_at_trigger ON public.access_invites;
CREATE TRIGGER access_invites_updated_at_trigger
  BEFORE UPDATE ON public.access_invites
  FOR EACH ROW
  EXECUTE FUNCTION public.touch_access_invites_updated_at();

CREATE UNIQUE INDEX IF NOT EXISTS access_invites_pending_unique_per_email_idx
  ON public.access_invites (inviter_id, lower(invitee_email))
  WHERE status = 'pending';

CREATE UNIQUE INDEX IF NOT EXISTS access_applications_pending_unique_email_idx
  ON public.access_applications (lower(email))
  WHERE status = 'pending';
