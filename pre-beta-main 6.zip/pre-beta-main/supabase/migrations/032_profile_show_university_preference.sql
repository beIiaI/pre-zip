-- Public profile university display preference

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS show_university boolean NOT NULL DEFAULT true;

