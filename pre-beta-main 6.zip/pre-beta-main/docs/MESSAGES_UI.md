# Messages UI + Behavior

## Inbox UI
- The oversized top card has been removed.
- Privacy guidance is now a subtle inline helper above search:
  - `Private by design: only thread participants can read messages.`
- The helper does not act like a card and does not dominate thread list layout.

## Composer Behavior
- Composer uses a multiline `textarea` that auto-grows up to `160px`.
- Long text now wraps and remains visible with:
  - `min-w-0` flex containment
  - `overflow-wrap: anywhere`
  - `word-break: break-word`
  - vertical scroll after max height
- Expected behavior:
  - Works with long continuous text, pasted paragraphs, emojis, and backspacing.
  - Cursor remains visible on Safari (desktop + iOS).

## Unsend Rule (Product Requirement)
- Message editing is disabled (no edit action in UI, no edit API route).
- Unsend is available only for the sender and only within 5 minutes of send time.
- After 5 minutes:
  - Unsend action is hidden in UI.
  - Server rejects unsend attempts.

## Enforcement Location
- Server enforcement:
  - `src/app/api/dms/[id]/messages/route.ts` (`DELETE` handler)
  - checks `Date.now() - created_at <= 5 minutes`
  - update query additionally guards by `created_at >= now() - 5 minutes`
- Database enforcement:
  - `supabase/migrations/035_dm_unsend_window.sql`
  - RLS `dm_messages_update` policy allows only:
    - sender-owned rows
    - not already deleted
    - created within last 5 minutes
    - update shape corresponding to unsend (`deleted_at` set, `body=''`, `edited_at IS NULL`)

## QA Checklist
1. Inbox screen
- Open `/messages`.
- Confirm no large “Private by design” card appears.
- Confirm inline helper text renders above search.

2. Thread layout
- Open `/messages/:id`.
- Confirm spacing is stable for sent/received messages.

3. Composer long-text behavior
- Type a long sentence (>300 chars), include emojis and paste content.
- Confirm earlier text stays visible (no clipping) and cursor tracks correctly.
- Backspace through long content and confirm input remains stable.

4. Unsend under 5 minutes
- Send a message.
- Open message menu within 5 minutes.
- Confirm `Unsend` appears and works.
- Confirm message renders as `Message unsent`.

5. Unsend over 5 minutes
- Wait until message is older than 5 minutes (or seed old message in DB).
- Confirm `Unsend` no longer appears in UI.
- Attempt API unsend manually and confirm rejection.

6. No edit capability
- Confirm no Edit action in any message menu.
- Confirm no message edit endpoint exists in API route.
