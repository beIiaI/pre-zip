# Email System (Pre Web)

This document defines the production email flow for the Next.js app at `https://app.presocial.app`.

## Provider Ownership

## Supabase Auth SMTP (authentication emails)
- Signup verification / OTP send
- OTP resend
- Password recovery
- Magic link / email link callbacks (supported by callback route; currently no dedicated send UI in web)

## Resend API (app transactional emails)
- University verification request email
- Vetted access review queue notifications

Do not send the same event through both providers.

## Email Inventory

| Email type | Provider | Trigger path | Code location | Template source | Redirect target |
| --- | --- | --- | --- | --- | --- |
| Signup verification (initial OTP) | Supabase Auth SMTP | `POST /api/auth/sign-up` | `src/app/api/auth/sign-up/route.ts` | Supabase Auth template | `.../auth/callback?next=/onboarding` |
| Signup verification resend | Supabase Auth SMTP | `POST /api/auth/otp/resend` | `src/app/api/auth/otp/resend/route.ts` | Supabase Auth template | `.../auth/callback?next=/onboarding` |
| Password recovery | Supabase Auth SMTP | `POST /api/auth/password/forgot` | `src/app/api/auth/password/forgot/route.ts` | Supabase recovery template | `.../auth/callback?next=/auth/reset` |
| Email callback handler (signup/recovery/magiclink/invite/email_change) | Supabase Auth verify | `GET /auth/callback` | `src/app/auth/callback/route.ts` | N/A | Resolves to `/`, `/onboarding`, or `/auth/reset` |
| University verification request | Resend | `POST /api/verification/university/request` | `src/app/api/verification/university/request/route.ts` + `src/lib/email.ts` | Shared Resend layout | Verification confirm link |
| Vetted access application notification | Resend | `POST /api/access/apply` | `src/app/api/access/apply/route.ts` + `src/lib/email.ts` | Shared Resend layout | No user redirect |

## Shared Transactional Template

All Resend emails render through `src/lib/email.ts`:
- shared shell: `renderEmailLayout(...)`
- provider send path: `sendResendEmail(...)`
- message logging: `logEmailEvent(...)`

Sender identity is unified via:
- `EMAIL_FROM` (recommended: `pre <no-reply@presocial.app>`)

Each email includes:
- HTML version
- plaintext fallback

## Required Environment Variables

Validated by `src/instrumentation.ts` + `src/lib/config/server-env.ts`:
- `NEXT_PUBLIC_SITE_URL`
- `SUPABASE_SERVICE_ROLE_KEY` (server-only)
- `RESEND_API_KEY` (server-only)
- `EMAIL_FROM`

Optional for debug route gating:
- `INTERNAL_DEBUG_TOKEN`

Never expose service role or Resend API keys in client bundles.

## Supabase Auth Configuration

In Supabase Auth settings:
- Site URL: `https://app.presocial.app`
- Redirect URLs must include at minimum:
  - `https://app.presocial.app/auth/callback`
  - `https://app.presocial.app/auth/reset`
  - `http://localhost:3000/auth/callback`
  - `http://localhost:3000/auth/reset`
- If supporting additional domains (preview/LAN), add matching callback/reset URLs.

Required web routes:
- `src/app/auth/callback/route.ts`
- `src/app/auth/reset/page.tsx`
- `src/app/auth/reset/error/page.tsx`

## Debug and Observability

Structured email logging helper:
- `src/lib/email/observability.ts`

Debug endpoint:
- `GET /api/debug/email`
  - checks provider mapping + required env presence (booleans only)
- `POST /api/debug/email`
  - sends transactional test emails (`university_verification`, `access_application_notification`)
  - supports `dryRun=true`

Production access is blocked unless `x-debug-token` matches `INTERNAL_DEBUG_TOKEN`.

## Test Checklist (Production and Local)

1. Signup OTP
- Submit signup on `/auth`.
- Confirm Supabase sends OTP email.
- Verify OTP and confirm redirect to onboarding.

2. OTP resend
- From OTP step, click resend.
- Confirm email arrives and route logs `signup_verification_resend`.

3. Password recovery
- On sign-in, run forgot password.
- Confirm generic success message is shown.
- Confirm recovery email arrives.
- Open link and confirm `/auth/callback` -> `/auth/reset`.
- Update password successfully.

4. University verification
- Request university verification in Safety & Verification.
- Confirm Resend email arrives with branded template and valid link.
- Confirm verification updates profile state after click.

5. Vetted access request
- Submit request access.
- Confirm row is created in `public.access_applications`.
- Confirm review notification email is sent to review inbox.

6. Debug route (non-prod or token-gated)
- `GET /api/debug/email` shows env status.
- `POST /api/debug/email` sends each transactional template test.
