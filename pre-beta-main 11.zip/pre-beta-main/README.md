# pre (beta)

`pre` is an invite-gated social app focused on real-world connection: people discovery, follows, private messaging, circles, events, campus verification, and safety tooling.

## Monorepo Structure

```
.
├── src/                    # Web app (Next.js App Router)
├── apps/mobile/            # iOS app (Expo / React Native)
├── supabase/               # Database migrations & edge functions
├── data/swot/              # University verification dataset (git submodule)
├── docs/                   # Documentation (email system, messages UI, security)
├── public/                 # Web app static assets
├── package.json            # Web app dependencies
└── README.md
```

## Current Scope (V1)

- Invite-only access with nomination links and access requests
- Email/OAuth auth flows with OTP signup confirmation
- Onboarding + profile editing
- Public profiles (`/profile/[username]`, `/u/[username]`)
- Followers/following lists for self and other users
- Direct messages with thread/message participant security
- Events (create/list/detail/chat/RSVP)
- Circles (create/list/join/leave)
- University verification via JetBrains SWoT + email ownership confirmation
- College selection as **self-reported** (private table)
- Safety tools: blocked users, emergency contacts, panic alerts
- Badges/plaque system and founder override endpoint

## Tech Stack

### Web App
- Framework: Next.js `16.1.x` (App Router)
- Language: TypeScript
- Styling: Tailwind CSS + design tokens
- Backend: Supabase (Auth + Postgres + RLS + Storage)
- Verification dataset: JetBrains SWoT (`data/swot` git submodule)
- Moderation dataset: Restricted words list (`src/data/restricted-words` git submodule)
- Transactional email: Resend API
- Location: Nominatim / OpenStreetMap (geocoding + autocomplete)
- Deploy: Vercel

### Mobile App (iOS)
- Framework: Expo SDK 54 + React Native 0.81
- Navigation: Expo Router v6 (file-based routing)
- Animations: React Native Reanimated v4
- Gestures: React Native Gesture Handler v2
- State: TanStack Query v5 + Supabase real-time
- Auth: Supabase + Apple Sign In
- Haptics: expo-haptics throughout

## Prerequisites

- Node.js `20+`
- npm `10+`
- Supabase project
- Resend account (for university verification emails)
- For mobile: Expo CLI, Xcode (iOS builds), EAS CLI

## Web App Setup

### 1) Install dependencies

```bash
npm install
```

### 2) Pull submodules

```bash
git submodule update --init --recursive
```

### 3) Create `.env.local`

```env
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=
SUPABASE_SECRET_KEY=
NEXT_PUBLIC_SITE_URL=http://localhost:3000
RESEND_API_KEY=
EMAIL_FROM="pre <no-reply@presocial.app>"
```

### 4) Apply database migrations

Run files in `supabase/migrations/` in order (001 through 033).

### 5) Run

```bash
npm run dev
```

## Mobile App Setup

See [`apps/mobile/README.md`](apps/mobile/README.md) for full setup instructions.

Quick start:

```bash
cd apps/mobile
npm install
cp .env.example .env   # Add your Supabase + API credentials
npx expo start
```

## Route Map (Web)

- `/` - splash/auth gate
- `/auth` - signin/signup/OTP/forgot password
- `/home` - primary hub
- `/messages`, `/messages/[id]` - DM list and conversation
- `/events`, `/events/new`, `/events/[id]`, `/events/[id]/chat`
- `/profile`, `/profile/edit`, `/profile/[username]`
- `/settings`, `/settings/privacy`, `/settings/safety-verification`, `/settings/invites`, `/settings/password`
- `/badges`, `/badges/early-supporter`

## API Surface

- **Auth**: sign-up, sign-in, OTP verify/resend, password forgot/update, 2FA status
- **Profile**: ensure, update, onboarding complete
- **Social**: follow, unfollow, followers, following, user search/preview
- **Messaging**: DMs (list/detail/messages), presence
- **Events**: CRUD, RSVP, attendees, chat
- **Circles**: CRUD, members
- **Verification**: university request/confirm/unlock, college selection
- **Safety**: emergency contacts, panic alerts, blocks
- **Access/Invites**: apply, create/list/validate/claim/revoke

## University Verification

1. User enters university email in settings
2. Server checks domain against SWoT allowlist
3. One-time token created (hashed, 15min expiry)
4. Verification email sent via Resend
5. Confirm route validates token and marks profile as verified

College is self-reported, stored in private table `profile_college`, with 30-day cooldown.

## Security

- DMs use participant-based RLS (non-recursive)
- API endpoints enforce same-origin, validation, rate limits, auth backoff
- `profile_college` is private with owner-only RLS
- Global CSP, frame denial, MIME sniffing protection
- See `docs/security.md` for full details

## Branding

- Wordmark: always use `PreWordmark` component (SVG), not text
- Color system: ceramic/obsidian base with restrained tints
- Typography: Sailec-inspired compact scale
- Bento visual system for card layouts

## License

Private repository. All rights reserved.
