import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { getNormalizedUniversityName } from '@/lib/verification/university'

const SELECT_FIELDS = 'id, username, full_name, avatar_url, bio, location, early_supporter_number, founder_number, is_founder, interests, profile_visibility, show_location, show_university, show_college, university_verified, university_domain, university_name'

export const runtime = 'nodejs'

async function getCollegeNameForProfile(userId: string): Promise<string | null> {
  try {
    const admin = createAdminClient() as any
    const { data, error } = await admin
      .from('profile_college')
      .select('college_name')
      .eq('user_id', userId)
      .maybeSingle()

    if (error) {
      return null
    }

    const value = data?.college_name
    return typeof value === 'string' && value.trim() ? value.trim() : null
  } catch {
    return null
  }
}

export async function GET(request: Request) {
  const supabase = await createClient()
  const admin = createAdminClient() as any

  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { searchParams } = new URL(request.url)
  const username = searchParams.get('u')?.toLowerCase().trim()
  if (!username) {
    return NextResponse.json({ error: 'Missing username' }, { status: 400 })
  }

  const { data: targetProfile, error: targetError } = await admin
    .from('profiles')
    .select('id')
    .eq('username', username)
    .single()

  if (targetError || !targetProfile) {
    return NextResponse.json({ error: 'Not found' }, { status: 404 })
  }

  const { data: blockRows } = await supabase
    .from('blocks')
    .select('id')
    .or(`and(blocker_id.eq.${user.id},blocked_id.eq.${targetProfile.id}),and(blocker_id.eq.${targetProfile.id},blocked_id.eq.${user.id})`)
    .limit(1)

  if (blockRows && blockRows.length > 0) {
    return NextResponse.json({ error: 'Not found' }, { status: 404 })
  }

  const { data: profile, error: profileError } = await admin
    .from('profiles')
    .select(SELECT_FIELDS)
    .eq('username', username)
    .single()

  if (profileError || !profile) {
    return NextResponse.json({ error: 'Not found' }, { status: 404 })
  }

  const visibility = profile.profile_visibility ?? 'public'
  const showLocation = profile.show_location ?? true

  if (visibility === 'private' && profile.id !== user.id) {
    return NextResponse.json({ error: 'Not found' }, { status: 404 })
  }

  if (visibility === 'friends' && profile.id !== user.id) {
    const { data: viewerFollows } = await supabase
      .from('follows')
      .select('follower_id')
      .eq('follower_id', user.id)
      .eq('following_id', profile.id)
      .maybeSingle()

    const { data: targetFollows } = await supabase
      .from('follows')
      .select('follower_id')
      .eq('follower_id', profile.id)
      .eq('following_id', user.id)
      .maybeSingle()

    if (!viewerFollows || !targetFollows) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 })
    }
  }

  const [{ count: followersCount }, { count: followingCount }] = await Promise.all([
    supabase
      .from('follows')
      .select('follower_id', { count: 'exact', head: true })
      .eq('following_id', profile.id),
    supabase
      .from('follows')
      .select('following_id', { count: 'exact', head: true })
      .eq('follower_id', profile.id),
  ])

  const { data: followRow } = await supabase
    .from('follows')
    .select('following_id')
    .eq('follower_id', user.id)
    .eq('following_id', profile.id)
    .maybeSingle()

  const canShowLocation = showLocation || profile.id === user.id
  const shouldShowUniversity = profile.show_university !== false && profile.university_verified === true
  const universityName = shouldShowUniversity
    ? getNormalizedUniversityName(profile.university_domain, profile.university_name)
    : null
  const shouldShowCollege = shouldShowUniversity && profile.show_college === true
  const collegeName = shouldShowCollege ? await getCollegeNameForProfile(profile.id) : null

  return NextResponse.json({
    profile: {
      id: profile.id,
      username: profile.username,
      full_name: profile.full_name,
      avatar_url: profile.avatar_url,
      bio: profile.bio,
      location: canShowLocation ? profile.location : null,
      interests: profile.interests ?? [],
      early_supporter_number: profile.early_supporter_number,
      founder_number: profile.founder_number,
      is_founder: profile.is_founder,
      followers_count: followersCount ?? 0,
      following_count: followingCount ?? 0,
      is_following: !!followRow,
      university_name: universityName,
      college_name: collegeName,
    },
  })
}
