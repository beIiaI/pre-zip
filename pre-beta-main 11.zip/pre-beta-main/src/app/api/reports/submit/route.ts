import { createClient } from '@/lib/supabase/server'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import { badRequest, enforceRateLimit, serverFailure, unauthorized } from '@/lib/security/guards'

const REPORT_TYPES = new Set(['bug', 'abuse', 'spam', 'content', 'safety', 'other'])

export const runtime = 'nodejs'

type ReportPayload = {
  type?: string
  description?: string
}

export async function POST(request: Request) {
  const requestId = createRequestId()
  const supabase = await createClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'reports:submit',
    request,
    requestId,
    userId: user.id,
    limit: 20,
    windowMs: 15 * 60 * 1000,
  })
  if (rateLimitResponse) return rateLimitResponse

  let payload: ReportPayload = {}
  try {
    payload = (await request.json()) as ReportPayload
  } catch {
    return badRequest(requestId, 'Invalid JSON payload')
  }

  const reportType = typeof payload.type === 'string' ? payload.type.trim().toLowerCase() : ''
  const description =
    typeof payload.description === 'string' ? payload.description.trim().slice(0, 2000) : ''

  if (!REPORT_TYPES.has(reportType)) {
    return badRequest(requestId, 'Invalid report type')
  }

  if (!description) {
    return badRequest(requestId, 'Description is required')
  }

  const { error } = await supabase.from('reports').insert({
    reporter_id: user.id,
    reason: reportType,
    description,
  })

  if (error) {
    logServerError('reports.submit.insert', requestId, error, { userId: user.id })
    return serverFailure(requestId)
  }

  return successResponse(requestId, { ok: true })
}
