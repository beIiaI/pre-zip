import { createClient } from '@/lib/supabase/server'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import { badRequest, enforceRateLimit, serverFailure, unauthorized } from '@/lib/security/guards'

export const runtime = 'nodejs'

export async function GET(
  request: Request,
  context: { params: Promise<{ id: string }> }
) {
  const requestId = createRequestId()
  const supabase = await createClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'events:my-rsvp',
    request,
    requestId,
    userId: user.id,
    limit: 120,
    windowMs: 15 * 60 * 1000,
  })
  if (rateLimitResponse) return rateLimitResponse

  const { id: eventId } = await context.params
  if (!eventId) {
    return badRequest(requestId, 'Missing event id')
  }

  const { data: rsvp, error } = await supabase
    .from('event_rsvps')
    .select('status')
    .eq('event_id', eventId)
    .eq('user_id', user.id)
    .maybeSingle()

  if (error) {
    logServerError('events.my-rsvp.query', requestId, error, {
      eventId,
      userId: user.id,
    })
    return serverFailure(requestId)
  }

  return successResponse(requestId, { status: rsvp?.status ?? null })
}
