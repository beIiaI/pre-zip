import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'

export const runtime = 'nodejs'

export async function POST(request: Request) {
  const supabase = await createClient()
  const admin = createAdminClient() as any
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { data: adminProfile } = await admin
    .from('profiles')
    .select('is_internal')
    .eq('id', user.id)
    .maybeSingle()

  if (!adminProfile?.is_internal) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  let payload: Record<string, unknown> = {}
  try {
    payload = (await request.json()) as Record<string, unknown>
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload' }, { status: 400 })
  }

  const targetId = typeof payload.user_id === 'string' ? payload.user_id : null
  if (!targetId) {
    return NextResponse.json({ error: 'Missing user_id' }, { status: 400 })
  }

  const founderNumberRaw = payload.founder_number
  let founderNumber: number | null | undefined
  if (founderNumberRaw !== undefined) {
    if (founderNumberRaw === null || founderNumberRaw === '') {
      founderNumber = null
    } else if (typeof founderNumberRaw === 'number' && Number.isInteger(founderNumberRaw)) {
      founderNumber = founderNumberRaw
    } else if (typeof founderNumberRaw === 'string' && founderNumberRaw.trim()) {
      const parsed = Number(founderNumberRaw)
      founderNumber = Number.isInteger(parsed) ? parsed : undefined
    } else {
      founderNumber = undefined
    }

    if (founderNumber === undefined || (founderNumber !== null && (founderNumber < 0 || founderNumber > 999))) {
      return NextResponse.json({ error: 'founder_number must be an integer between 0 and 999' }, { status: 400 })
    }
  }

  const updates: Record<string, unknown> = {
    is_founder: true,
    updated_at: new Date().toISOString(),
  }

  if (founderNumber !== undefined) {
    updates.founder_number = founderNumber
  }

  const { error } = await admin
    .from('profiles')
    .update(updates)
    .eq('id', targetId)

  if (error) {
    if (error.code === '23505') {
      return NextResponse.json({ error: 'Founder number is already assigned to another founder.' }, { status: 409 })
    }
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ ok: true })
}
