'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { ArrowLeft, Bell } from 'lucide-react'

type NotificationItem = {
  id: string
  type: string
  title: string
  body: string | null
  data?: { [key: string]: any } | null
  read: boolean
  read_at?: string | null
  created_at: string
}

const formatTime = (value: string) => {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return ''
  return date.toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })
}

export default function NotificationsPage() {
  const { user, loading, initialized } = useAuth()
  const router = useRouter()
  const [notifications, setNotifications] = useState<NotificationItem[]>([])
  const [loadingNotifications, setLoadingNotifications] = useState(true)
  const [redirecting, setRedirecting] = useState(false)

  useEffect(() => {
    if (!initialized || loading) return
    if (!user) {
      setRedirecting(true)
      router.replace('/')
    }
  }, [initialized, loading, user, router])

  useEffect(() => {
    if (!initialized || loading || !user) return
    let active = true
    setLoadingNotifications(true)
    fetch('/api/notifications')
      .then((res) => res.json())
      .then((data) => {
        if (active) {
          setNotifications(data.notifications ?? [])
        }
      })
      .finally(() => {
        if (active) setLoadingNotifications(false)
      })

    fetch('/api/notifications', { method: 'POST' }).catch(() => {})
    return () => {
      active = false
    }
  }, [initialized, loading, user])

  if (!initialized || loading || redirecting) {
    return <LoadingScreen />
  }

  if (!user) {
    return <LoadingScreen />
  }

  return (
    <div className="min-h-screen bg-surface-primary safe-top safe-bottom">
      {/* Header */}
      <header className="px-4 py-4 flex items-center justify-between border-b border-border-secondary">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">Notifications</h1>
        <div className="w-9" />
      </header>

      <main className="px-4 py-6">
        {loadingNotifications ? (
          <LoadingScreen />
        ) : notifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="h-16 w-16 rounded-full bg-surface-secondary flex items-center justify-center mb-4">
              <Bell className="h-8 w-8 text-content-tertiary" />
            </div>
            <h3 className="text-headline text-content-primary mb-2">No notifications</h3>
            <p className="text-body text-content-secondary max-w-xs">
              You're all caught up! Check back later for updates.
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {notifications.map((notification) => (
              <div
                key={notification.id}
                className="p-4 rounded-card bg-surface-secondary border border-border-secondary"
              >
                <div className="flex items-center justify-between">
                  <p className="text-body text-content-primary">{notification.title}</p>
                  <span className="text-caption text-content-tertiary">
                    {formatTime(notification.created_at)}
                  </span>
                </div>
                {notification.body && (
                  <p className="text-callout text-content-secondary mt-1">{notification.body}</p>
                )}
                {notification.type === 'panic_alert' && notification.data?.lat && notification.data?.lng && (
                  <a
                    href={`https://maps.apple.com/?q=${notification.data.lat},${notification.data.lng}`}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-3 inline-flex text-sm text-content-primary underline"
                  >
                    View location
                  </a>
                )}
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
