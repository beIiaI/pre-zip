'use client'

import { Suspense, useEffect, useMemo, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Avatar } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { ArrowLeft, UserPlus } from 'lucide-react'
import { MemberBadgeStack } from '@/components/ui/member-badge-stack'

type FollowProfile = {
  id: string
  username: string | null
  full_name: string | null
  avatar_url: string | null
  early_supporter_number: number | null
  founder_number: number | null
  is_founder?: boolean | null
  is_following: boolean
}

function FollowingPageContent() {
  const { user, loading, initialized } = useAuth()
  const router = useRouter()
  const searchParams = useSearchParams()
  const [profiles, setProfiles] = useState<FollowProfile[]>([])
  const [loadingList, setLoadingList] = useState(true)
  const targetId = useMemo(() => searchParams.get('uid'), [searchParams])
  const [redirecting, setRedirecting] = useState(false)

  useEffect(() => {
    if (!initialized || loading) return
    if (!user) {
      setRedirecting(true)
      router.replace('/')
    }
  }, [initialized, loading, user, router])

  useEffect(() => {
    if (!user) return
    let active = true
    setLoadingList(true)
    const id = targetId || user.id
    fetch(`/api/following?user_id=${encodeURIComponent(id)}`)
      .then((res) => res.json())
      .then((data) => {
        if (active) {
          setProfiles(data.results ?? [])
        }
      })
      .finally(() => {
        if (active) setLoadingList(false)
      })
    return () => {
      active = false
    }
  }, [user, targetId])

  if (!initialized || loading || redirecting) {
    return <LoadingScreen />
  }

  if (!user) {
    return <LoadingScreen />
  }

  const handleFollowToggle = async (person: FollowProfile, shouldFollow: boolean) => {
    const endpoint = shouldFollow ? '/api/follow' : '/api/unfollow'
    setProfiles((prev) =>
      prev.map((item) => (item.id === person.id ? { ...item, is_following: shouldFollow } : item))
    )

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ following_id: person.id }),
      })
      if (!response.ok) throw new Error('Request failed')
    } catch {
      setProfiles((prev) =>
        prev.map((item) => (item.id === person.id ? { ...item, is_following: !shouldFollow } : item))
      )
    }
  }

  return (
    <div className="min-h-screen bg-surface-primary safe-top safe-bottom">
      <header className="px-4 py-4 flex items-center justify-between border-b border-border-secondary">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">Following</h1>
        <div className="w-9" />
      </header>

      <main className="px-4 py-6">
        {loadingList ? (
          <LoadingScreen />
        ) : profiles.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="h-16 w-16 rounded-full bg-surface-secondary flex items-center justify-center mb-4">
              <UserPlus className="h-8 w-8 text-content-tertiary" />
            </div>
            <h3 className="text-headline text-content-primary mb-2">No following yet</h3>
            <p className="text-body text-content-secondary max-w-xs">
              Explore people to start building your network.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {profiles.map((person) => {
              const hasEarlySupporter =
                person.early_supporter_number !== null && person.early_supporter_number !== undefined
              const hasFounder = person.is_founder === true
              const hasMemberBadges = hasFounder || hasEarlySupporter
              return (
                <div
                  key={person.id}
                  className="flex items-center gap-4 p-4 rounded-card bg-surface-secondary border border-border-secondary"
                >
                  <Avatar src={person.avatar_url} size="lg" />
                  <div className="flex-1 min-w-0">
                    <p className="text-body font-medium text-content-primary truncate">
                      {person.full_name || person.username || 'Unknown'}
                    </p>
                    {person.username && (
                      <p className="text-callout text-content-secondary">@{person.username}</p>
                    )}
                    {hasMemberBadges && (
                      <div className="mt-2">
                        <MemberBadgeStack
                          isFounder={person.is_founder}
                          founderNumber={person.founder_number}
                          earlySupporterNumber={person.early_supporter_number}
                          size="sm"
                        />
                      </div>
                    )}
                  </div>
                  <Button
                    size="sm"
                    variant={person.is_following ? 'secondary' : 'primary'}
                    onClick={() => handleFollowToggle(person, !person.is_following)}
                  >
                    {person.is_following ? 'Following' : 'Follow'}
                  </Button>
                </div>
              )
            })}
          </div>
        )}
      </main>
    </div>
  )
}

export default function FollowingPage() {
  return (
    <Suspense fallback={<LoadingScreen />}>
      <FollowingPageContent />
    </Suspense>
  )
}
