'use client'

import { cn } from '@/lib/utils'

interface SegmentedOption {
  label: string
  value: string
}

interface Props {
  options: SegmentedOption[]
  value: string
  onChange: (value: string) => void
  className?: string
}

export function SegmentedControl({ options, value, onChange, className }: Props) {
  return (
    <div
      className={cn(
        'inline-flex rounded-full bg-surface-secondary/58 p-1 backdrop-blur-sm',
        'border border-border-secondary/30',
        className
      )}
    >
      {options.map(option => {
        const isActive = value === option.value
        return (
          <button
            key={option.value}
            type="button"
            onClick={() => onChange(option.value)}
            className={cn(
              'px-5 py-2 text-callout rounded-full transition-all duration-300',
              isActive
                ? 'bg-surface-primary text-content-primary font-semibold'
                : 'text-content-tertiary hover:text-content-primary'
            )}
          >
            {option.label}
          </button>
        )
      })}
    </div>
  )
}
