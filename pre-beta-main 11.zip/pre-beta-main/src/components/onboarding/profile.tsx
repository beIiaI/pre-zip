'use client'

import { Button } from '@/components/ui/button'
import { Avatar } from '@/components/ui/avatar'
import { Alert } from '@/components/ui/alert'
import { OnboardingLayout } from './layout'
import { Camera } from 'lucide-react'
import { useState } from 'react'
import { LoadingDots } from '@/components/ui/loading-dots'

interface Props {
  bio: string
  avatarUrl?: string
  onChangeBio: (bio: string) => void
  onChangeAvatar: (url: string) => void
  onComplete: () => Promise<void>
  onBack: () => void
  isCompleting?: boolean
  error?: string | null
  onDismissError?: () => void
}

export function OnboardingProfile({ 
  bio, 
  avatarUrl, 
  onChangeBio, 
  onChangeAvatar, 
  onComplete, 
  onBack,
  isCompleting = false,
  error = null,
  onDismissError
}: Props) {
  const [uploading, setUploading] = useState(false)
  const [uploadError, setUploadError] = useState<string | null>(null)

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Validate file
    if (!file.type.startsWith('image/')) {
      setUploadError('Please select an image file')
      return
    }
    if (file.size > 5 * 1024 * 1024) {
      setUploadError('Image must be less than 5MB')
      return
    }

    setUploading(true)
    setUploadError(null)

    // For now, create a local preview URL
    // In production, this would upload to Supabase Storage
    const url = URL.createObjectURL(file)
    onChangeAvatar(url)
    setUploading(false)
  }

  const handleComplete = async () => {
    // Don't allow if already completing
    if (isCompleting) return
    
    try {
      await onComplete()
    } catch (err) {
      // Error is handled by parent component
      console.error('Error in handleComplete:', err)
    }
  }

  const displayError = error || uploadError

  return (
    <OnboardingLayout
      step={9}
      totalSteps={9}
      title="Complete your profile"
      subtitle="Add a photo and bio. You can always change these later."
      onBack={isCompleting ? undefined : onBack}
    >
      <div className="space-y-8">
        {/* Error Alert */}
        {displayError && (
          <Alert 
            variant="error" 
            dismissible 
            onDismiss={() => {
              setUploadError(null)
              onDismissError?.()
            }}
          >
            {displayError}
          </Alert>
        )}

        {/* Avatar Upload */}
        <div className="flex flex-col items-center space-y-4">
          <div className="relative">
            <Avatar src={avatarUrl} size="xl" />
            <label
              className={`absolute bottom-0 right-0 h-8 w-8 rounded-full bg-content-primary flex items-center justify-center border-2 border-surface-primary ${isCompleting ? 'opacity-50' : 'cursor-pointer'}`}
            >
              {uploading ? (
                <LoadingDots size="sm" className="text-content-inverse" />
              ) : (
                <Camera className="h-4 w-4 text-content-inverse" />
              )}
              <input
                type="file"
                accept="image/*"
                onChange={handleAvatarChange}
                className="hidden"
                disabled={isCompleting}
                data-testid="onboarding-avatar-input"
              />
            </label>
          </div>
          <p className="text-caption text-content-secondary">Tap to add a photo</p>
        </div>

        {/* Bio */}
        <div className="space-y-2">
          <label className="text-callout font-medium text-content-primary">Bio</label>
          <textarea
            placeholder="Tell us a bit about yourself..."
            value={bio}
            onChange={(e) => onChangeBio(e.target.value)}
            maxLength={150}
            rows={4}
            disabled={isCompleting}
            className="flex w-full rounded-input border bg-surface-secondary px-4 py-3 text-body text-content-primary placeholder:text-content-tertiary border-border-primary focus:border-border-focus focus:outline-none focus:ring-1 focus:ring-border-focus resize-none disabled:opacity-50"
            data-testid="onboarding-bio-input"
          />
          <p className="text-caption text-content-tertiary text-right">
            {bio.length}/150
          </p>
        </div>

        {/* Complete Button */}
        <Button
          className="w-full"
          size="lg"
          type="button"
          onClick={handleComplete}
          disabled={isCompleting}
          data-testid="onboarding-complete-button"
        >
          {isCompleting ? (
            <span className="inline-flex items-center gap-2">
              <LoadingDots size="sm" className="text-content-inverse" />
              Completing...
            </span>
          ) : (
            'Complete Profile'
          )}
        </Button>
      </div>
    </OnboardingLayout>
  )
}
