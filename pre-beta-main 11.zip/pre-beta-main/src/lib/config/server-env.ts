import 'server-only'

type RequiredServerEnvKey =
  | 'NEXT_PUBLIC_SITE_URL'
  | 'SUPABASE_SECRET_KEY'
  | 'RESEND_API_KEY'
  | 'EMAIL_FROM'

const REQUIRED_SERVER_ENV_KEYS: RequiredServerEnvKey[] = [
  'NEXT_PUBLIC_SITE_URL',
  'SUPABASE_SECRET_KEY',
  'RESEND_API_KEY',
  'EMAIL_FROM',
]

export function getServerEnvStatus() {
  return REQUIRED_SERVER_ENV_KEYS.reduce<Record<RequiredServerEnvKey, boolean>>((acc, key) => {
    // For SUPABASE_SECRET_KEY, also accept the legacy SUPABASE_SERVICE_ROLE_KEY
    if (key === 'SUPABASE_SECRET_KEY') {
      acc[key] = Boolean(process.env.SUPABASE_SECRET_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY)
    } else {
      acc[key] = Boolean(process.env[key])
    }
    return acc
  }, {} as Record<RequiredServerEnvKey, boolean>)
}

export function getMissingServerEnv() {
  return REQUIRED_SERVER_ENV_KEYS.filter((key) => {
    if (key === 'SUPABASE_SECRET_KEY') {
      return !process.env.SUPABASE_SECRET_KEY && !process.env.SUPABASE_SERVICE_ROLE_KEY
    }
    return !process.env[key]
  })
}

export function assertServerEnv(options?: { throwOnMissing?: boolean }) {
  const missing = getMissingServerEnv()
  if (missing.length === 0) {
    return
  }

  const message = `Missing required server environment variables: ${missing.join(', ')}`
  if (options?.throwOnMissing) {
    throw new Error(message)
  }

  console.warn(`[config.env] ${message}`)
}

export type { RequiredServerEnvKey }
