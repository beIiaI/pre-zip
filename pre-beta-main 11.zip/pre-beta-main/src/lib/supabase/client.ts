import { createBrowserClient } from '@supabase/ssr'

let cachedClient: ReturnType<typeof createBrowserClient> | null = null

// Placeholder values used during Next.js static prerendering when env vars
// are not yet available.  The client is created but never issues real requests
// during prerender (useEffect doesn't run), so this is safe.
const PRERENDER_PLACEHOLDER_URL = 'https://placeholder.supabase.co'
const PRERENDER_PLACEHOLDER_KEY = 'placeholder'

export function createClient() {
  if (cachedClient) return cachedClient
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || PRERENDER_PLACEHOLDER_URL
  const supabaseKey =
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ??
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ??
    PRERENDER_PLACEHOLDER_KEY

  cachedClient = createBrowserClient(supabaseUrl, supabaseKey, {
    isSingleton: false,
  })

  return cachedClient
}
