import 'server-only'

import { createClient } from '@supabase/supabase-js'
import type { Database } from '@/types/database'

export function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL
  const secretKey = process.env.SUPABASE_SECRET_KEY ?? process.env.SUPABASE_SERVICE_ROLE_KEY
  if (!url || !secretKey) {
    throw new Error('Supabase secret key is not configured (set SUPABASE_SECRET_KEY)')
  }

  return createClient<Database>(url, secretKey, {
    auth: { persistSession: false },
  })
}
