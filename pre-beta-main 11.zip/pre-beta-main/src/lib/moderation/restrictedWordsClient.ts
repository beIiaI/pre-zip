import { RESTRICTED_WORDS_EN } from '@/data/restricted-words-lite'
import { RESERVED_WORDS, getNormalizedVariants } from './restrictedWordsShared'

let cachedExactWithReserved: Set<string> | null = null
let cachedHighRiskWithReserved: string[] | null = null
let cachedExactWithoutReserved: Set<string> | null = null
let cachedHighRiskWithoutReserved: string[] | null = null

function buildClientIndex(includeReserved: boolean) {
  const exact = new Set<string>()
  const highRisk = new Set<string>()

  const addWord = (word: string, isHighRisk: boolean) => {
    if (!word) return
    const variants = getNormalizedVariants(word)
    const allVariants = [
      variants.base,
      variants.joined,
      ...variants.leet,
      ...variants.joinedLeet,
    ].filter(Boolean)

    for (const variant of allVariants) {
      exact.add(variant)
    }

    if (isHighRisk) {
      const highRiskVariants = [variants.joined, ...variants.joinedLeet].filter(Boolean)
      for (const variant of highRiskVariants) {
        if (variant.length >= 3) {
          highRisk.add(variant)
        }
      }
    }
  }

  for (const word of RESTRICTED_WORDS_EN) {
    addWord(word, true)
  }

  if (includeReserved) {
    for (const word of RESERVED_WORDS) {
      addWord(word, true)
    }
  }

  return { exact, highRisk: Array.from(highRisk) }
}

function getIndex(includeReserved: boolean) {
  if (includeReserved) {
    if (!cachedExactWithReserved || !cachedHighRiskWithReserved) {
      const next = buildClientIndex(true)
      cachedExactWithReserved = next.exact
      cachedHighRiskWithReserved = next.highRisk
    }
    return { exact: cachedExactWithReserved!, highRisk: cachedHighRiskWithReserved! }
  }
  if (!cachedExactWithoutReserved || !cachedHighRiskWithoutReserved) {
    const next = buildClientIndex(false)
    cachedExactWithoutReserved = next.exact
    cachedHighRiskWithoutReserved = next.highRisk
  }
  return { exact: cachedExactWithoutReserved!, highRisk: cachedHighRiskWithoutReserved! }
}

function isRestricted(value: string, includeReserved: boolean, checkSubstrings = true): boolean {
  if (!value || !value.trim()) return false
  const { exact, highRisk } = getIndex(includeReserved)
  const variants = getNormalizedVariants(value)
  const exactCandidates = [
    variants.base,
    variants.joined,
    ...variants.leet,
    ...variants.joinedLeet,
  ].filter(Boolean)

  if (exactCandidates.some(candidate => exact.has(candidate))) {
    return true
  }

  if (checkSubstrings) {
    const joinedCandidates = [variants.joined, ...variants.joinedLeet].filter(Boolean)
    for (const candidate of joinedCandidates) {
      for (const word of highRisk) {
        if (candidate.includes(word)) {
          return true
        }
      }
    }
  }

  return false
}

export function isRestrictedUsername(value: string): boolean {
  return isRestricted(value, true)
}

export function isRestrictedDisplayName(value: string): boolean {
  // Display names allow spaces, so joining strips them and creates false positives
  // (e.g. "Hassan Ahmed" → "hassanahmed" contains "ass").
  // Use exact-match-only: no substring scan on the joined form.
  return isRestricted(value, true, false)
}

export function isRestrictedBio(value: string): boolean {
  return isRestricted(value, false)
}
