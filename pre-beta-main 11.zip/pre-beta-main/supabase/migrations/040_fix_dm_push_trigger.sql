-- Fix DM push notification trigger
--
-- The original trigger (migration 999, now removed) had two bugs:
--   1. Used NEW.content but column was renamed to "body" in migration 014
--   2. Authorization header used JWT role string instead of a valid token
--
-- Push notifications are now primarily handled CLIENT-SIDE via
-- apps/mobile/lib/push.ts which calls supabase.functions.invoke('send-push').
-- That path uses the user's valid JWT automatically.
--
-- This trigger is kept as a server-side backup but ONLY fires if
-- a service_role_key is available in Supabase Vault. If Vault isn't
-- configured, the trigger gracefully skips without blocking the insert.

-- Ensure pg_net is available
CREATE EXTENSION IF NOT EXISTS pg_net;

CREATE OR REPLACE FUNCTION notify_dm_message()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  recipient_id UUID;
  sender_name TEXT;
  service_key TEXT;
  request_id BIGINT;
BEGIN
  -- Try to read service role key from Vault (may not exist)
  BEGIN
    SELECT decrypted_secret INTO service_key
    FROM vault.decrypted_secrets
    WHERE name = 'service_role_key'
    LIMIT 1;
  EXCEPTION
    WHEN OTHERS THEN
      -- Vault not available — skip silently (client-side push handles it)
      RETURN NEW;
  END;

  -- No key in vault — skip (client-side push handles it)
  IF service_key IS NULL THEN
    RETURN NEW;
  END IF;

  -- Get the recipient (other user in thread)
  SELECT user_id INTO recipient_id
  FROM dm_participants
  WHERE thread_id = NEW.thread_id
    AND user_id != NEW.sender_id
  LIMIT 1;

  IF recipient_id IS NULL THEN
    RETURN NEW;
  END IF;

  -- Get sender's display name
  SELECT COALESCE(full_name, username, 'Someone')
  INTO sender_name
  FROM profiles
  WHERE id = NEW.sender_id;

  -- Call edge function via pg_net
  SELECT net.http_post(
    url := 'https://sqwupgqtwajiiigbotiy.supabase.co/functions/v1/send-push',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || service_key
    ),
    body := jsonb_build_object(
      'user_id', recipient_id::text,
      'title', sender_name,
      'body', LEFT(NEW.body, 100),
      'data', jsonb_build_object(
        'type', 'dm',
        'thread_id', NEW.thread_id::text,
        'sender_id', NEW.sender_id::text
      )
    )
  ) INTO request_id;

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Never block the DM insert
    RAISE WARNING 'notify_dm_message: push failed — %', SQLERRM;
    RETURN NEW;
END;
$$;

-- Re-create trigger (idempotent)
DROP TRIGGER IF EXISTS on_dm_message_inserted ON dm_messages;
CREATE TRIGGER on_dm_message_inserted
  AFTER INSERT ON dm_messages
  FOR EACH ROW
  EXECUTE FUNCTION notify_dm_message();
