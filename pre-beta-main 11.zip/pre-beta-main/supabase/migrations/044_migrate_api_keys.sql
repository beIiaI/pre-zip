-- Migrate from legacy Supabase API keys to new API key naming
--
-- Supabase is deprecating the JWT-based anon/service_role keys in favor of:
--   - Publishable key (sb_publishable_...) — replaces anon key
--   - Secret key (sb_secret_...) — replaces service_role key
--
-- See: https://github.com/orgs/supabase/discussions/29260
--
-- This migration updates the Vault secret name used by the DM push trigger
-- from 'service_role_key' to 'supabase_secret_key'. The trigger function
-- is updated to check both names for backwards compatibility.

-- Update the DM push trigger to use the new secret name (with fallback)
CREATE OR REPLACE FUNCTION notify_dm_message()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  recipient_id UUID;
  sender_name TEXT;
  service_key TEXT;
  request_id BIGINT;
BEGIN
  -- Try to read secret key from Vault (new name first, then legacy)
  BEGIN
    SELECT decrypted_secret INTO service_key
    FROM vault.decrypted_secrets
    WHERE name IN ('supabase_secret_key', 'service_role_key')
    LIMIT 1;
  EXCEPTION
    WHEN OTHERS THEN
      -- Vault not available — skip silently (client-side push handles it)
      RETURN NEW;
  END;

  -- No key in vault — skip (client-side push handles it)
  IF service_key IS NULL THEN
    RETURN NEW;
  END IF;

  -- Get the recipient (other user in thread)
  SELECT user_id INTO recipient_id
  FROM dm_participants
  WHERE thread_id = NEW.thread_id
    AND user_id != NEW.sender_id
  LIMIT 1;

  IF recipient_id IS NULL THEN
    RETURN NEW;
  END IF;

  -- Get sender's display name
  SELECT COALESCE(full_name, username, 'Someone')
  INTO sender_name
  FROM profiles
  WHERE id = NEW.sender_id;

  -- Call edge function via pg_net
  SELECT net.http_post(
    url := 'https://sqwupgqtwajiiigbotiy.supabase.co/functions/v1/send-push',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || service_key
    ),
    body := jsonb_build_object(
      'user_id', recipient_id::text,
      'title', sender_name,
      'body', LEFT(NEW.body, 100),
      'data', jsonb_build_object(
        'type', 'dm',
        'thread_id', NEW.thread_id::text,
        'sender_id', NEW.sender_id::text
      )
    )
  ) INTO request_id;

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Never block the DM insert
    RAISE WARNING 'notify_dm_message: push failed — %', SQLERRM;
    RETURN NEW;
END;
$$;

-- Rename existing vault secret if it exists (idempotent)
DO $$
BEGIN
  UPDATE vault.secrets
  SET name = 'supabase_secret_key'
  WHERE name = 'service_role_key';
EXCEPTION
  WHEN OTHERS THEN
    -- Vault may not be configured — skip
    NULL;
END;
$$;
