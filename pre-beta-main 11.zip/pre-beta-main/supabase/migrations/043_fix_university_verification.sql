-- =========================================================
-- Improve university verification robustness
--
-- 1. UNIQUE constraint on token_hash (prevent duplicate tokens)
-- 2. UNIQUE constraint on university_email in profiles
--    (two users should not claim the same university email)
-- =========================================================

-- Unique token hash (only if the column exists)
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'university_verifications'
      AND column_name = 'token_hash'
  ) THEN
    CREATE UNIQUE INDEX IF NOT EXISTS university_verifications_token_hash_uniq
      ON public.university_verifications (token_hash);
  END IF;
END $$;

-- Only one user per university email (prevent conflicts)
-- Only applies when the profile is actively verified
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'profiles'
      AND column_name = 'university_email'
  ) THEN
    CREATE UNIQUE INDEX IF NOT EXISTS profiles_university_email_uniq
      ON public.profiles (university_email)
      WHERE university_email IS NOT NULL AND university_verified = TRUE;
  END IF;
END $$;
