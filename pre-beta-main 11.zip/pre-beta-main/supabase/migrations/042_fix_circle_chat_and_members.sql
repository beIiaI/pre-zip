-- =========================================================
-- Fix circle member visibility
--
-- Problem: circle_members SELECT policy (from 033) only shows
-- your OWN membership row, so the members list on the
-- circle detail page is empty for other users.
--
-- Solution: Use a SECURITY DEFINER function to fetch the
-- user's circle IDs without triggering RLS recursion.
-- =========================================================

-- 1. Helper: get all circle IDs a user belongs to (bypasses RLS)
CREATE OR REPLACE FUNCTION public.user_circle_ids(uid uuid)
RETURNS SETOF uuid
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = ''
AS $$
  SELECT circle_id FROM public.circle_members WHERE user_id = uid;
$$;

-- 2. Fix circle_members SELECT: let members see ALL members of their circles
DROP POLICY IF EXISTS circle_members_select_authenticated ON public.circle_members;
CREATE POLICY circle_members_select_authenticated ON public.circle_members
  FOR SELECT TO authenticated
  USING (
    circle_id IN (SELECT public.user_circle_ids(auth.uid()))
  );

-- 3. Add circle_members to Realtime publication
DO $$
BEGIN
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.circle_members;
  EXCEPTION
    WHEN duplicate_object THEN NULL;
    WHEN undefined_object THEN NULL;
  END;
END $$;

-- 4. Index for the helper function performance
CREATE INDEX IF NOT EXISTS circle_members_user_id_idx
  ON public.circle_members (user_id);
