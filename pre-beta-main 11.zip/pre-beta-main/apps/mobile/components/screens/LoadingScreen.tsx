import React, { useEffect, useState, useRef } from 'react'
import { View, StyleSheet } from 'react-native'
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  Easing,
} from 'react-native-reanimated'
import { useTheme } from '@/contexts/ThemeContext'
import { BrandLoader } from '@/components/ui/BrandLoader'

interface LoadingScreenProps {
  onLoadComplete?: () => void
  name?: string | null
}

export function LoadingScreen({ onLoadComplete, name }: LoadingScreenProps) {
  const { colors } = useTheme()
  const opacity = useSharedValue(1)
  const displayName = (name || '').trim()
  const DISPLAY_MS = displayName ? 850 : 620
  const FADE_MS = 220

  useEffect(() => {
    const timer = setTimeout(() => {
      opacity.value = withTiming(0, {
        duration: FADE_MS,
        easing: Easing.inOut(Easing.ease),
      })

      setTimeout(() => {
        onLoadComplete?.()
      }, FADE_MS)
    }, DISPLAY_MS)

    return () => clearTimeout(timer)
  }, [onLoadComplete, DISPLAY_MS, FADE_MS])

  const animatedStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
  }))

  return (
    <Animated.View
      style={[
        styles.container,
        { backgroundColor: colors.surfacePrimary },
        animatedStyle,
      ]}
    >
      <BrandLoader name={displayName || undefined} showWelcome />
    </Animated.View>
  )
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 9999,
    alignItems: 'center',
    justifyContent: 'center',
  },
})
