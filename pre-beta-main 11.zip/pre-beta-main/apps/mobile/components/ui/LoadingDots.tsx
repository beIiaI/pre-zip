import React, { useEffect } from 'react'
import { View, StyleSheet } from 'react-native'
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withSequence,
  withTiming,
  withDelay,
  Easing,
} from 'react-native-reanimated'

interface LoadingDotsProps {
  size?: 'sm' | 'md' | 'lg'
  color?: string
}

const sizes = {
  sm: 6,
  md: 8,
  lg: 10,
}

function Dot({ size, color, delay }: { size: number; color: string; delay: number }) {
  const opacity = useSharedValue(0.4)

  useEffect(() => {
    opacity.value = withDelay(
      delay,
      withRepeat(
        withSequence(
          withTiming(1, { duration: 550, easing: Easing.inOut(Easing.ease) }),
          withTiming(0.4, { duration: 550, easing: Easing.inOut(Easing.ease) })
        ),
        -1,
        false
      )
    )
  }, [delay])

  const animatedStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
  }))

  return (
    <Animated.View
      style={[
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: color,
        },
        animatedStyle,
      ]}
    />
  )
}

export function LoadingDots({ size = 'md', color = '#8D877F' }: LoadingDotsProps) {
  const dotSize = sizes[size]

  return (
    <View style={styles.container}>
      <Dot size={dotSize} color={color} delay={0} />
      <Dot size={dotSize} color={color} delay={200} />
      <Dot size={dotSize} color={color} delay={400} />
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
})
