import React, { useEffect, useState } from 'react'
import { View, Text, StyleSheet, Dimensions } from 'react-native'
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withSequence,
  withTiming,
  withDelay,
  withSpring,
  Easing,
} from 'react-native-reanimated'
import { useTheme } from '@/contexts/ThemeContext'
import { PreWordmark } from '@/components/ui/PreWordmark'
import { LoadingDots } from '@/components/ui/LoadingDots'

const { width } = Dimensions.get('window')

interface BrandLoaderProps {
  name?: string | null
  message?: string
  showWelcome?: boolean
  showDots?: boolean
}

const LOADER_LINES = [
  'Preparing your circles',
  'Syncing conversations',
  'Preparing your next move',
]

const getSalutation = () => {
  const hour = new Date().getHours()
  if (hour >= 5 && hour < 12) return 'Good morning'
  if (hour >= 12 && hour < 17) return 'Good afternoon'
  if (hour >= 17 && hour < 22) return 'Good evening'
  return 'Good night'
}

// Subtle breathing ring - iOS native feel
function BreathingRing({
  size,
  color,
  delay = 0,
}: {
  size: number
  color: string
  delay?: number
}) {
  const scale = useSharedValue(0.95)
  const opacity = useSharedValue(0.12)

  useEffect(() => {
    // Subtle iOS-like breathing animation
    scale.value = withDelay(
      delay,
      withRepeat(
        withSequence(
          withTiming(1.02, { duration: 2400, easing: Easing.inOut(Easing.ease) }),
          withTiming(0.95, { duration: 2400, easing: Easing.inOut(Easing.ease) })
        ),
        -1,
        false
      )
    )
    opacity.value = withDelay(
      delay,
      withRepeat(
        withSequence(
          withTiming(0.2, { duration: 2400, easing: Easing.inOut(Easing.ease) }),
          withTiming(0.08, { duration: 2400, easing: Easing.inOut(Easing.ease) })
        ),
        -1,
        false
      )
    )
  }, [delay])

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
    opacity: opacity.value,
  }))

  return (
    <Animated.View
      style={[
        styles.ring,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          borderColor: color,
        },
        animatedStyle,
      ]}
    />
  )
}

// Logo with subtle entrance and breathing
function AnimatedLogo({ color }: { color: string }) {
  const translateY = useSharedValue(8)
  const opacity = useSharedValue(0)
  const scale = useSharedValue(0.98)

  useEffect(() => {
    // Smooth iOS spring entrance
    opacity.value = withTiming(1, { duration: 600, easing: Easing.out(Easing.ease) })
    translateY.value = withSpring(0, { damping: 20, stiffness: 90 })
    
    // Subtle breathing after entrance
    setTimeout(() => {
      scale.value = withRepeat(
        withSequence(
          withTiming(1.01, { duration: 2000, easing: Easing.inOut(Easing.ease) }),
          withTiming(0.99, { duration: 2000, easing: Easing.inOut(Easing.ease) })
        ),
        -1,
        false
      )
    }, 800)
  }, [])

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }, { scale: scale.value }],
    opacity: opacity.value,
  }))

  return (
    <Animated.View style={[styles.logoContainer, animatedStyle]}>
      <PreWordmark size="hero" color={color} />
    </Animated.View>
  )
}

// Welcome text with staggered fade
function WelcomeText({ text, color, delay = 0 }: { text: string; color: string; delay?: number }) {
  const translateY = useSharedValue(6)
  const opacity = useSharedValue(0)

  useEffect(() => {
    translateY.value = withDelay(delay, withSpring(0, { damping: 20, stiffness: 90 }))
    opacity.value = withDelay(delay, withTiming(1, { duration: 500, easing: Easing.out(Easing.ease) }))
  }, [delay])

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }],
    opacity: opacity.value,
  }))

  return (
    <Animated.Text style={[styles.welcomeText, { color }, animatedStyle]}>
      {text}
    </Animated.Text>
  )
}

// Status message with crossfade
function StatusMessage({ message, color }: { message: string; color: string }) {
  const opacity = useSharedValue(0)

  useEffect(() => {
    opacity.value = 0
    opacity.value = withSequence(
      withTiming(1, { duration: 300, easing: Easing.out(Easing.ease) }),
      withDelay(1100, withTiming(0, { duration: 300, easing: Easing.in(Easing.ease) }))
    )
  }, [message])

  const animatedStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
  }))

  return (
    <Animated.Text style={[styles.statusText, { color }, animatedStyle]}>
      {message}
    </Animated.Text>
  )
}

export function BrandLoader({
  name,
  message,
  showWelcome,
  showDots = true,
}: BrandLoaderProps) {
  const { colors } = useTheme()
  const trimmedName = typeof name === 'string' ? name.trim() : ''
  const shouldShowWelcome = showWelcome ?? !!trimmedName
  const [salutation, setSalutation] = useState('Welcome back')
  const [lineIndex, setLineIndex] = useState(0)

  useEffect(() => {
    setSalutation(getSalutation())
  }, [])

  useEffect(() => {
    if (message) return
    const interval = setInterval(() => {
      setLineIndex((current) => (current + 1) % LOADER_LINES.length)
    }, 1700)
    return () => clearInterval(interval)
  }, [message])

  const greetingLine = trimmedName ? `${salutation}, ${trimmedName}.` : `${salutation}.`
  const loaderSize = Math.min(width * 0.38, 140)

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        {/* Welcome section */}
        {shouldShowWelcome && (
          <View style={styles.welcomeSection}>
            <WelcomeText text={greetingLine} color={colors.contentTertiary} delay={0} />
            <WelcomeText text="Welcome to" color={colors.contentSecondary} delay={100} />
          </View>
        )}

        {/* Logo with subtle rings */}
        <View style={[styles.loaderContainer, { width: loaderSize, height: loaderSize }]}>
          {/* Breathing rings - subtle, iOS native feel */}
          <View style={styles.ringsContainer}>
            <BreathingRing size={loaderSize * 1.6} color={colors.contentPrimary} delay={0} />
            <BreathingRing size={loaderSize * 1.35} color={colors.contentPrimary} delay={400} />
            <BreathingRing size={loaderSize * 1.15} color={colors.contentPrimary} delay={800} />
          </View>

          {/* Logo */}
          <AnimatedLogo color={colors.contentPrimary} />
        </View>

        {/* Bottom section */}
        <View style={styles.bottomSection}>
          {showDots && <LoadingDots size="md" color={colors.contentSecondary} />}
          <StatusMessage
            message={message || LOADER_LINES[lineIndex]}
            color={colors.contentTertiary}
          />
        </View>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
    paddingVertical: 40,
  },
  content: {
    alignItems: 'center',
  },
  welcomeSection: {
    marginBottom: 48,
    alignItems: 'center',
    gap: 4,
  },
  welcomeText: {
    fontSize: 11,
    textTransform: 'uppercase',
    letterSpacing: 2,
    fontWeight: '500',
  },
  loaderContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  ringsContainer: {
    position: 'absolute',
    width: '160%',
    height: '160%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  ring: {
    position: 'absolute',
    borderWidth: 1,
  },
  logoContainer: {
    zIndex: 10,
  },
  bottomSection: {
    marginTop: 64,
    alignItems: 'center',
    minHeight: 60,
  },
  statusText: {
    marginTop: 16,
    fontSize: 11,
    textTransform: 'uppercase',
    letterSpacing: 1.5,
    fontWeight: '500',
  },
})
