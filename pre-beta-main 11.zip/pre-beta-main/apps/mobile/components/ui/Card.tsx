import React from 'react'
import { View, ViewStyle, StyleSheet, ViewProps } from 'react-native'
import { LinearGradient } from 'expo-linear-gradient'
import { useTheme } from '@/contexts/ThemeContext'
import { BorderRadius, Shadows } from '@/constants/theme'

type CardVariant = 'default' | 'elevated' | 'flat' | 'bento'
type CardTint = 'none' | 'rose' | 'peach' | 'honey' | 'sage' | 'mist' | 'lilac'

interface CardProps extends ViewProps {
  variant?: CardVariant
  tint?: CardTint
  children: React.ReactNode
  style?: ViewStyle
  gradient?: boolean
}

export function Card({ 
  variant = 'default', 
  tint = 'none',
  children, 
  style,
  gradient = true,
  ...props 
}: CardProps) {
  const { colors } = useTheme()

  // Calculate gradient colors based on your web design
  const getGradientColors = (): [string, string] => {
    if (tint !== 'none') {
      const tintColor = colors[`tint${tint.charAt(0).toUpperCase() + tint.slice(1)}` as keyof typeof colors] as string
      return [tintColor, colors.surfacePrimary]
    }
    
    // Default gradient: secondary 35% -> primary 96%
    return [colors.surfaceSecondary, colors.surfacePrimary]
  }

  const cardStyles: ViewStyle = {
    borderRadius: BorderRadius.card,
    borderWidth: 1,
    borderColor: colors.bentoBorder || colors.borderPrimary,
    overflow: 'hidden',
  }

  // Add variant-specific styles
  if (variant === 'elevated') {
    Object.assign(cardStyles, Shadows.card)
  } else if (variant === 'flat') {
    cardStyles.borderWidth = 0
  }

  if (gradient && variant !== 'flat') {
    const [startColor, endColor] = getGradientColors()
    
    return (
      <View style={[cardStyles, style]} {...props}>
        <LinearGradient
          colors={[startColor, endColor]}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
        <View style={{ position: 'relative', zIndex: 1 }}>
          {children}
        </View>
      </View>
    )
  }

  return (
    <View 
      style={[
        cardStyles,
        { backgroundColor: tint !== 'none' ? colors[`tint${tint.charAt(0).toUpperCase() + tint.slice(1)}` as keyof typeof colors] as string : colors.surfaceSecondary },
        style
      ]} 
      {...props}
    >
      {children}
    </View>
  )
}
