import React from 'react'
import { View, Text, StyleSheet } from 'react-native'
import { useTheme } from '@/contexts/ThemeContext'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'
import { getBadgeMetadata, BadgeName } from '@/lib/badges'

interface BadgeProps {
  badge: string
  size?: 'small' | 'medium'
}

export function Badge({ badge, size = 'medium' }: BadgeProps) {
  const { colors } = useTheme()
  const metadata = getBadgeMetadata(badge)
  
  if (!metadata) return null

  const isFounder = badge === 'founder'
  const isSmall = size === 'small'

  return (
    <View
      style={[
        styles.badge,
        isSmall ? styles.badgeSmall : styles.badgeMedium,
        {
          backgroundColor: isFounder 
            ? colors.accentPrimary 
            : colors.surfaceSecondary,
          borderColor: colors.borderPrimary,
        },
      ]}
    >
      {metadata.emoji && (
        <Text style={[styles.emoji, isSmall && styles.emojiSmall]}>
          {metadata.emoji}
        </Text>
      )}
      <Text
        style={[
          styles.label,
          isSmall ? styles.labelSmall : styles.labelMedium,
          {
            color: isFounder ? colors.accentOnPrimary : colors.contentPrimary,
          },
        ]}
      >
        {metadata.displayName}
      </Text>
    </View>
  )
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: BorderRadius.full,
    borderWidth: 1,
    paddingHorizontal: Spacing.sm,
    gap: 4,
  },
  badgeSmall: {
    paddingVertical: 2,
  },
  badgeMedium: {
    paddingVertical: 4,
  },
  emoji: {
    fontSize: 12,
  },
  emojiSmall: {
    fontSize: 10,
  },
  label: {
    fontWeight: '600',
  },
  labelSmall: {
    fontSize: Typography.caption,
  },
  labelMedium: {
    fontSize: Typography.callout,
  },
})
