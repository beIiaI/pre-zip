import React, { useEffect } from 'react'
import { View, StyleSheet, Dimensions } from 'react-native'
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  interpolate,
  Easing,
} from 'react-native-reanimated'
import { useTheme } from '@/contexts/ThemeContext'
import { BorderRadius, Spacing } from '@/constants/theme'

const { width: screenWidth } = Dimensions.get('window')

interface SkeletonProps {
  width?: number | string
  height?: number
  borderRadius?: number
  style?: object
}

/**
 * Skeleton loading component with iOS-native shimmer animation
 */
export function Skeleton({
  width = '100%',
  height = 16,
  borderRadius = 8,
  style,
}: SkeletonProps) {
  const { colors, isDark } = useTheme()
  const shimmer = useSharedValue(0)

  useEffect(() => {
    shimmer.value = withRepeat(
      withTiming(1, {
        duration: 1200,
        easing: Easing.inOut(Easing.ease),
      }),
      -1,
      false
    )
  }, [])

  const baseColor = isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)'
  const shimmerColor = isDark ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.12)'

  const animatedStyle = useAnimatedStyle(() => {
    const translateX = interpolate(shimmer.value, [0, 1], [-100, 100])
    return {
      opacity: interpolate(shimmer.value, [0, 0.5, 1], [0.6, 1, 0.6]),
    }
  })

  return (
    <Animated.View
      style={[
        styles.skeleton,
        {
          width,
          height,
          borderRadius,
          backgroundColor: baseColor,
        },
        animatedStyle,
        style,
      ]}
    />
  )
}

/**
 * Skeleton card for events
 */
export function EventCardSkeleton() {
  const { colors } = useTheme()
  
  return (
    <View style={[styles.eventCard, { backgroundColor: colors.surfaceSecondary }]}>
      <View style={styles.eventCardContent}>
        <View style={styles.eventCardLeft}>
          <Skeleton width={60} height={12} borderRadius={4} />
          <Skeleton width="80%" height={18} borderRadius={4} style={{ marginTop: 8 }} />
          <Skeleton width="60%" height={14} borderRadius={4} style={{ marginTop: 6 }} />
        </View>
        <View style={styles.eventCardRight}>
          <View style={styles.avatarStack}>
            <Skeleton width={28} height={28} borderRadius={14} />
            <Skeleton width={28} height={28} borderRadius={14} style={{ marginLeft: -8 }} />
            <Skeleton width={28} height={28} borderRadius={14} style={{ marginLeft: -8 }} />
          </View>
        </View>
      </View>
    </View>
  )
}

/**
 * Skeleton for horizontal event scroll
 */
export function EventScrollSkeleton() {
  return (
    <View style={styles.scrollContainer}>
      {[0, 1, 2].map((i) => (
        <View key={i} style={styles.scrollCard}>
          <Skeleton width={180} height={100} borderRadius={12} />
          <Skeleton width={140} height={14} borderRadius={4} style={{ marginTop: 10 }} />
          <Skeleton width={100} height={12} borderRadius={4} style={{ marginTop: 6 }} />
        </View>
      ))}
    </View>
  )
}

/**
 * Skeleton for my plans section
 */
export function MyPlansSkeleton() {
  const { colors } = useTheme()
  
  return (
    <View style={styles.plansContainer}>
      {[0, 1].map((i) => (
        <View 
          key={i} 
          style={[styles.planCard, { backgroundColor: colors.surfaceSecondary }]}
        >
          <View style={styles.planLeft}>
            <Skeleton width={40} height={40} borderRadius={8} />
          </View>
          <View style={styles.planRight}>
            <Skeleton width="70%" height={14} borderRadius={4} />
            <Skeleton width="50%" height={12} borderRadius={4} style={{ marginTop: 6 }} />
          </View>
        </View>
      ))}
    </View>
  )
}

/**
 * Full home screen skeleton
 */
export function HomeScreenSkeleton() {
  const { colors } = useTheme()

  return (
    <View style={[styles.container, { backgroundColor: colors.surfacePrimary }]}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Skeleton width={140} height={12} borderRadius={4} />
          <Skeleton width={100} height={20} borderRadius={4} style={{ marginTop: 6 }} />
        </View>
        <Skeleton width={32} height={32} borderRadius={16} />
      </View>

      {/* My Plans Section */}
      <View style={styles.section}>
        <Skeleton width={80} height={14} borderRadius={4} />
        <MyPlansSkeleton />
      </View>

      {/* Discover Events Section */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Skeleton width={120} height={14} borderRadius={4} />
          <Skeleton width={60} height={12} borderRadius={4} />
        </View>
        <EventScrollSkeleton />
      </View>

      {/* This Week Section */}
      <View style={styles.section}>
        <Skeleton width={100} height={14} borderRadius={4} />
        <View style={{ marginTop: 12 }}>
          <EventCardSkeleton />
          <EventCardSkeleton />
        </View>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  skeleton: {
    overflow: 'hidden',
  },
  container: {
    flex: 1,
    paddingHorizontal: Spacing.lg,
    paddingTop: 60,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 32,
  },
  section: {
    marginBottom: 28,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  eventCard: {
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    marginBottom: 12,
  },
  eventCardContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  eventCardLeft: {
    flex: 1,
  },
  eventCardRight: {
    alignItems: 'flex-end',
    justifyContent: 'center',
  },
  avatarStack: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  scrollContainer: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 12,
  },
  scrollCard: {
    width: 180,
  },
  plansContainer: {
    marginTop: 12,
    gap: 10,
  },
  planCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.md,
    borderRadius: BorderRadius.lg,
    gap: 12,
  },
  planLeft: {},
  planRight: {
    flex: 1,
  },
})
