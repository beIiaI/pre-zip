import React, { useEffect, useCallback } from 'react'
import { View, StyleSheet, RefreshControl as RNRefreshControl, Platform } from 'react-native'
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withSequence,
  withTiming,
  withSpring,
  interpolate,
  Easing,
  runOnJS,
} from 'react-native-reanimated'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'

interface CustomRefreshControlProps {
  refreshing: boolean
  onRefresh: () => void
  progressViewOffset?: number
}

/**
 * Animated refresh indicator matching the brand
 */
function RefreshIndicator({ refreshing }: { refreshing: boolean }) {
  const { colors } = useTheme()
  const rotation = useSharedValue(0)
  const scale = useSharedValue(0.8)
  const opacity = useSharedValue(0)

  useEffect(() => {
    if (refreshing) {
      // Fade in
      opacity.value = withTiming(1, { duration: 200 })
      scale.value = withSpring(1, { damping: 15, stiffness: 100 })
      
      // Continuous rotation
      rotation.value = withRepeat(
        withTiming(360, { duration: 1000, easing: Easing.linear }),
        -1,
        false
      )
    } else {
      // Fade out
      opacity.value = withTiming(0, { duration: 200 })
      scale.value = withTiming(0.8, { duration: 200 })
    }
  }, [refreshing])

  const containerStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ scale: scale.value }],
  }))

  const outerRingStyle = useAnimatedStyle(() => ({
    transform: [{ rotate: `${rotation.value}deg` }],
  }))

  const innerRingStyle = useAnimatedStyle(() => ({
    transform: [{ rotate: `${-rotation.value * 0.7}deg` }],
  }))

  return (
    <Animated.View style={[styles.indicatorContainer, containerStyle]}>
      {/* Outer ring */}
      <Animated.View
        style={[
          styles.ring,
          styles.outerRing,
          { borderColor: colors.contentPrimary },
          outerRingStyle,
        ]}
      />
      {/* Inner ring */}
      <Animated.View
        style={[
          styles.ring,
          styles.innerRing,
          { borderColor: colors.contentSecondary },
          innerRingStyle,
        ]}
      />
      {/* Center dot */}
      <View style={[styles.centerDot, { backgroundColor: colors.contentPrimary }]} />
    </Animated.View>
  )
}

/**
 * Custom RefreshControl with branded animation and haptics
 */
export function CustomRefreshControl({
  refreshing,
  onRefresh,
  progressViewOffset = 0,
}: CustomRefreshControlProps) {
  const { colors } = useTheme()

  const handleRefresh = useCallback(() => {
    // Haptic feedback when pull-to-refresh triggers
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)
    onRefresh()
  }, [onRefresh])

  // Use native RefreshControl for reliability, customize colors
  return (
    <RNRefreshControl
      refreshing={refreshing}
      onRefresh={handleRefresh}
      tintColor={colors.contentPrimary}
      colors={[colors.contentPrimary]} // Android
      progressBackgroundColor={colors.surfaceSecondary} // Android
      progressViewOffset={progressViewOffset}
    />
  )
}

/**
 * Haptic feedback utilities for consistent tactile experience
 */
export const HapticFeedback = {
  // Light tap for selections, toggles
  light: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light),
  
  // Medium impact for button presses, confirmations
  medium: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium),
  
  // Heavy impact for important actions
  heavy: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy),
  
  // Selection feedback for picker/list selections
  selection: () => Haptics.selectionAsync(),
  
  // Success notification
  success: () => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success),
  
  // Warning notification
  warning: () => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning),
  
  // Error notification
  error: () => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error),
  
  // Soft tap for subtle interactions
  soft: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Soft),
  
  // Rigid tap for firm feedback
  rigid: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Rigid),
}

const styles = StyleSheet.create({
  indicatorContainer: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  ring: {
    position: 'absolute',
    borderRadius: 9999,
    borderWidth: 2,
  },
  outerRing: {
    width: 36,
    height: 36,
    borderStyle: 'dashed',
    opacity: 0.6,
  },
  innerRing: {
    width: 24,
    height: 24,
    opacity: 0.4,
  },
  centerDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
})
