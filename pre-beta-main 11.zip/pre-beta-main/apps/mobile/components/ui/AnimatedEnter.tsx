import React, { useEffect } from 'react'
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withDelay,
  withSpring,
  Easing,
} from 'react-native-reanimated'

interface AnimatedEnterProps {
  children: React.ReactNode
  delay?: number
  style?: object
}

/**
 * Animated entrance wrapper component
 * iOS-native feel with spring physics
 */
export function AnimatedEnter({ children, delay = 0, style }: AnimatedEnterProps) {
  const translateY = useSharedValue(12)
  const opacity = useSharedValue(0)

  useEffect(() => {
    // iOS-native spring animation
    translateY.value = withDelay(
      delay,
      withSpring(0, {
        damping: 20,
        stiffness: 90,
        mass: 1,
      })
    )
    opacity.value = withDelay(
      delay,
      withTiming(1, {
        duration: 350,
        easing: Easing.out(Easing.ease),
      })
    )
  }, [delay])

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }],
    opacity: opacity.value,
  }))

  return <Animated.View style={[animatedStyle, style]}>{children}</Animated.View>
}
