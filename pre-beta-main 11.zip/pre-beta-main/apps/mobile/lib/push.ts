/**
 * Push notification delivery via Supabase Edge Function.
 *
 * Calls the `send-push` edge function which looks up the recipient's
 * Expo push token and forwards the notification through Expo Push API.
 */

import { supabase } from './supabase'

interface PushPayload {
  user_id: string
  title: string
  body: string
  data?: Record<string, any>
}

/**
 * Send a push notification to a specific user.
 * Uses supabase.functions.invoke which automatically includes the
 * caller's valid JWT in the Authorization header.
 */
export async function sendPushNotification(payload: PushPayload): Promise<void> {
  try {
    await supabase.functions.invoke('send-push', {
      body: payload,
    })
  } catch {
    // Push delivery is best-effort — never block the calling flow
  }
}

/**
 * Send a DM notification to the recipient.
 */
export function sendDMNotification(
  recipientId: string,
  senderName: string,
  messageBody: string,
  threadId: string,
  senderId: string,
): void {
  // Fire and forget — don't await
  sendPushNotification({
    user_id: recipientId,
    title: senderName,
    body: messageBody.length > 100 ? messageBody.slice(0, 100) + '…' : messageBody,
    data: {
      type: 'dm',
      thread_id: threadId,
      sender_id: senderId,
    },
  })
}
