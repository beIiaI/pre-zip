/**
 * Notifications API integration
 */

import { apiRequest } from './api'

export interface Notification {
  id: string
  type: string
  title: string
  body: string
  data: any
  read: boolean
  read_at: string | null
  created_at: string
}

export async function getNotifications(): Promise<{ notifications: Notification[]; error?: string }> {
  const result = await apiRequest('/api/notifications')

  if (result.error) {
    return { notifications: [], error: result.error }
  }

  return { notifications: result.data?.notifications || [] }
}

export async function markAllNotificationsAsRead(): Promise<{ success: boolean; error?: string }> {
  const result = await apiRequest('/api/notifications', {
    method: 'POST',
  })

  if (result.error) {
    return { success: false, error: result.error }
  }

  return { success: true }
}

export async function markNotificationAsRead(notificationId: string): Promise<{ success: boolean; error?: string }> {
  const result = await apiRequest(`/api/notifications/${notificationId}/read`, {
    method: 'POST',
  })

  if (result.error) {
    return { success: false, error: result.error }
  }

  return { success: true }
}
