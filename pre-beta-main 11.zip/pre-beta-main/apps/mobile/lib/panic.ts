/**
 * Panic button system - sends emergency alerts to contacts
 */

import { apiRequest } from './api'
import { Alert } from 'react-native'
import * as Location from 'expo-location'

export interface PanicOptions {
  message?: string
  includeLocation?: boolean
}

export async function triggerPanic(options: PanicOptions = {}): Promise<{ success: boolean; error?: string }> {
  try {
    // Show confirmation
    return await new Promise((resolve) => {
      Alert.alert(
        'Emergency Alert',
        'This will notify your emergency contacts immediately. Continue?',
        [
          {
            text: 'Cancel',
            style: 'cancel',
            onPress: () => resolve({ success: false }),
          },
          {
            text: 'Send Alert',
            style: 'destructive',
            onPress: async () => {
              let location = null
              
              if (options.includeLocation) {
                try {
                  const { status } = await Location.requestForegroundPermissionsAsync()
                  if (status === 'granted') {
                    const loc = await Location.getCurrentPositionAsync({})
                    location = {
                      latitude: loc.coords.latitude,
                      longitude: loc.coords.longitude,
                    }
                  }
                } catch (err) {
                  console.warn('Failed to get location:', err)
                }
              }

              const result = await apiRequest('/api/panic', {
                method: 'POST',
                body: {
                  message: options.message || 'Emergency alert triggered',
                  location,
                },
              })

              if (result.error) {
                resolve({ success: false, error: result.error })
              } else {
                Alert.alert(
                  'Alert Sent',
                  'Your emergency contacts have been notified.',
                  [{ text: 'OK' }]
                )
                resolve({ success: true })
              }
            },
          },
        ]
      )
    })
  } catch (error) {
    console.error('Panic trigger error:', error)
    return { success: false, error: 'Failed to send alert' }
  }
}
