/**
 * Circles API integration
 */

import { apiRequest } from './api'

export async function joinCircle(circleId: string): Promise<{ success: boolean; error?: string }> {
  const result = await apiRequest('/api/circles/members', {
    method: 'POST',
    body: { circle_id: circleId },
  })

  if (result.error) {
    return { success: false, error: result.error }
  }

  return { success: true }
}

export async function leaveCircle(circleId: string): Promise<{ success: boolean; error?: string }> {
  const result = await apiRequest('/api/circles/members', {
    method: 'DELETE',
    body: { circle_id: circleId },
  })

  if (result.error) {
    return { success: false, error: result.error }
  }

  return { success: true }
}
