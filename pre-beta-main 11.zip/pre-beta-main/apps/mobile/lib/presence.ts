/**
 * Presence tracking - updates user's last_active_at
 */

import { apiRequest } from './api'

let presenceInterval: NodeJS.Timeout | null = null

export async function updatePresence(): Promise<void> {
  try {
    await apiRequest('/api/presence', { method: 'POST' })
  } catch (error) {
    console.error('Presence update failed:', error)
  }
}

/**
 * Start presence tracking (heartbeat every 60 seconds)
 */
export function startPresenceTracking(): void {
  if (presenceInterval) return
  
  // Initial update
  updatePresence()
  
  // Update every 60 seconds
  presenceInterval = setInterval(() => {
    updatePresence()
  }, 60000)
}

/**
 * Stop presence tracking
 */
export function stopPresenceTracking(): void {
  if (presenceInterval) {
    clearInterval(presenceInterval)
    presenceInterval = null
  }
}
