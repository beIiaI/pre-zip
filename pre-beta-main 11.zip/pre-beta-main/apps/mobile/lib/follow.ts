/**
 * Follow/Unfollow API integration
 */

import { apiRequest } from './api'

export async function followUser(userId: string): Promise<{ success: boolean; error?: string }> {
  const result = await apiRequest('/api/follow', {
    method: 'POST',
    body: { following_id: userId },
  })

  if (result.error) {
    return { success: false, error: result.error }
  }

  return { success: true }
}

export async function unfollowUser(userId: string): Promise<{ success: boolean; error?: string }> {
  const result = await apiRequest('/api/unfollow', {
    method: 'POST',
    body: { following_id: userId },
  })

  if (result.error) {
    return { success: false, error: result.error }
  }

  return { success: true }
}

export async function checkFollowStatus(userId: string): Promise<{ isFollowing: boolean; error?: string }> {
  const result = await apiRequest(`/api/follow/status?user_id=${userId}`)

  if (result.error) {
    return { isFollowing: false, error: result.error }
  }

  return { isFollowing: Boolean(result.data?.isFollowing ?? result.data?.is_following ?? false) }
}
