/**
 * Badge system integration
 */

import { apiRequest } from './api'

export type BadgeName = 'founder' | 'early_supporter' | 'verified'

export interface Badge {
  name: BadgeName
  displayName: string
  description: string
  emoji?: string
}

const BADGE_METADATA: Record<BadgeName, Omit<Badge, 'name'>> = {
  founder: {
    displayName: 'Founder',
    description: 'Original founding member',
    emoji: '👑',
  },
  early_supporter: {
    displayName: 'Early Supporter',
    description: 'Joined during early access',
    emoji: '🌟',
  },
  verified: {
    displayName: 'Verified',
    description: 'Verified member',
    emoji: '✓',
  },
}

export async function getUserBadges(): Promise<{ badges: string[]; error?: string }> {
  try {
    const result = await apiRequest('/api/badges')
    if (result.error) {
      return { badges: [], error: result.error }
    }
    return { badges: result.data?.badges || [] }
  } catch (error) {
    console.error('Failed to fetch badges:', error)
    return { badges: [], error: 'Failed to load badges' }
  }
}

export function getBadgeMetadata(badgeName: string): Badge | null {
  if (badgeName in BADGE_METADATA) {
    return {
      name: badgeName as BadgeName,
      ...BADGE_METADATA[badgeName as BadgeName],
    }
  }
  return null
}
