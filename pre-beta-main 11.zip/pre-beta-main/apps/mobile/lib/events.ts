/**
 * Events API integration - properly handles RSVP with all backend logic
 */

import { apiRequest } from './api'

export type RSVPStatus = 'going' | 'interested' | 'cant_go' | 'none'

export interface RSVPResponse {
  status: RSVPStatus | null
  counts?: {
    going: number
    interested: number
    cant_go: number
  }
  error?: string
}

/**
 * RSVP to an event - uses API to properly handle:
 * - Campus-only verification
 * - Capacity checks
 * - Badge awarding (Social Butterfly, Initiator)
 * - Rate limiting
 */
export async function rsvpToEvent(
  eventId: string,
  status: RSVPStatus
): Promise<RSVPResponse> {
  const result = await apiRequest('/api/events/rsvp', {
    method: 'POST',
    body: {
      event_id: eventId,
      status,
    },
  })

  if (result.error) {
    return { status: null, error: result.error }
  }

  return {
    status: result.data?.status || null,
    counts: result.data?.counts,
  }
}

/**
 * Get user's RSVP status for an event
 */
export async function getMyRSVP(eventId: string): Promise<{ status: RSVPStatus | null; error?: string }> {
  const result = await apiRequest(`/api/events/${eventId}/my-rsvp`)

  if (result.error) {
    return { status: null, error: result.error }
  }

  return { status: result.data?.status || null }
}

/**
 * Get all user's RSVPs
 */
export async function getMyRSVPs(): Promise<{ rsvps: any[]; error?: string }> {
  const result = await apiRequest('/api/events/my-rsvps')

  if (result.error) {
    return { rsvps: [], error: result.error }
  }

  return { rsvps: result.data?.events || [] }
}
