/**
 * Blocks API integration
 */

import { apiRequest } from './api'

export async function blockUser(userId: string): Promise<{ success: boolean; error?: string }> {
  const result = await apiRequest('/api/blocks', {
    method: 'POST',
    body: { blocked_id: userId },
  })

  if (result.error) {
    return { success: false, error: result.error }
  }

  return { success: true }
}

export async function unblockUser(userId: string): Promise<{ success: boolean; error?: string }> {
  const result = await apiRequest(`/api/blocks/${encodeURIComponent(userId)}`, {
    method: 'DELETE',
  })

  if (result.error) {
    return { success: false, error: result.error }
  }

  return { success: true }
}
