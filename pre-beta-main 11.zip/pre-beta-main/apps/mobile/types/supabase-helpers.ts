/**
 * Supabase query type helpers
 * These help TypeScript correctly infer types from complex Supabase queries
 */

import { Database } from './database'

// Full table row types
export type DmThread = Database['public']['Tables']['dm_threads']['Row']
export type DmParticipant = Database['public']['Tables']['dm_participants']['Row']
export type DmMessage = Database['public']['Tables']['dm_messages']['Row']
export type CircleMemberRow = Database['public']['Tables']['circle_members']['Row']
export type CircleRow = Database['public']['Tables']['circles']['Row']
export type EventRow = Database['public']['Tables']['events']['Row']
export type EventRsvp = Database['public']['Tables']['event_rsvps']['Row']
export type EventAttendee = Database['public']['Tables']['event_attendees']['Row']
export type ProfileRow = Database['public']['Tables']['profiles']['Row']
export type NotificationRow = Database['public']['Tables']['notifications']['Row']

// Partial types for select queries
export type DmThreadPartial = Pick<DmThread, 'id' | 'user_a' | 'user_b'>
export type DmParticipantPartial = Pick<DmParticipant, 'thread_id' | 'last_read_at'>
export type DmMessagePartial = Pick<DmMessage, 'id' | 'thread_id' | 'body' | 'sender_id' | 'created_at'>
export type CircleMemberPartial = Pick<CircleMemberRow, 'circle_id' | 'user_id' | 'role'>
export type ProfilePartial = Pick<ProfileRow, 'id' | 'full_name' | 'username' | 'avatar_url'>

// Update types
export type ProfileUpdate = Database['public']['Tables']['profiles']['Update']
export type DmParticipantUpdate = Database['public']['Tables']['dm_participants']['Update']
export type CircleUpdate = Database['public']['Tables']['circles']['Update']

// Event with RSVP info
export interface EventWithRsvp extends EventRow {
  rsvp_status?: 'going' | 'interested' | 'cant_go' | null
}

// Circle with membership
export interface CircleWithMembership extends CircleRow {
  is_member?: boolean
  member_role?: 'admin' | 'moderator' | 'member' | null
}

// Helper to safely cast query results
export function castQueryResult<T>(data: unknown): T[] {
  return (data ?? []) as T[]
}

// Helper to safely cast single result
export function castSingleResult<T>(data: unknown): T | null {
  return (data ?? null) as T | null
}
