/**
 * Location utilities for handling coordinates and city names
 */

/**
 * Pattern to detect raw coordinate strings like "43.6704, -79.3942"
 */
const COORDINATE_PATTERN = /^-?\d+(\.\d+)?,\s*-?\d+(\.\d+)?$/

/**
 * Check if a location string is raw coordinates
 */
export function isCoordinateString(location: string | null | undefined): boolean {
  if (!location) return false
  return COORDINATE_PATTERN.test(location.trim())
}

/**
 * Filter out coordinate strings to prevent exposing precise location
 * Returns null if the location is coordinates, otherwise returns the location
 */
export function filterCoordinates(location: string | null | undefined): string | null {
  if (!location) return null
  if (isCoordinateString(location)) return null
  return location
}

/**
 * Format location for display - filters coordinates and returns safe location
 */
export function formatLocationForDisplay(location: string | null | undefined): string | null {
  return filterCoordinates(location)
}

/**
 * Get safe location label from location_text or location,
 * filtering out raw coordinates for privacy.
 */
export function getSafeLocationLabel(
  locationText: string | null | undefined,
  location: string | null | undefined
): string | null {
  if (locationText && !isCoordinateString(locationText)) return locationText
  if (location && !isCoordinateString(location)) return location
  return null
}

/**
 * Reverse geocode coordinates to city name using Nominatim directly.
 * Does not require the web app API — calls OpenStreetMap Nominatim.
 */
export async function reverseGeocode(
  lat: number,
  lon: number
): Promise<{ label: string | null; error?: string }> {
  try {
    const response = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&zoom=10&addressdetails=1`,
      {
        headers: {
          'User-Agent': 'pre-mobile/1.0',
          Accept: 'application/json',
        },
      }
    )

    if (!response.ok) {
      return { label: null, error: 'Geocoding failed' }
    }

    const data = await response.json()
    const addr = data.address
    if (!addr) return { label: null, error: 'No address data' }

    const city = addr.city || addr.town || addr.village || addr.municipality || addr.county || ''
    const state = addr.state || ''
    const country = addr.country || ''

    // Build a clean label like "Toronto, Ontario, Canada"
    const parts = [city, state, country].filter(Boolean)
    const label = parts.join(', ')

    return { label: label || null }
  } catch (error) {
    return { label: null, error: 'Network error' }
  }
}

/**
 * Search for locations using Nominatim autocomplete.
 * Calls OpenStreetMap directly without requiring the web app API.
 */
export async function searchLocations(
  query: string
): Promise<{ results: Array<{ label: string; lat: number; lon: number; city?: string; state?: string; country?: string }> }> {
  try {
    const response = await fetch(
      `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=8&addressdetails=1`,
      {
        headers: {
          'User-Agent': 'pre-mobile/1.0',
          Accept: 'application/json',
        },
      }
    )

    if (!response.ok) {
      return { results: [] }
    }

    const data = await response.json()
    const seen = new Set<string>()

    const results = data
      .map((item: any) => {
        const addr = item.address || {}
        const city = addr.city || addr.town || addr.village || addr.municipality || ''
        const state = addr.state || ''
        const country = addr.country || ''
        const label = [city, state, country].filter(Boolean).join(', ')
        return {
          label: label || item.display_name,
          lat: parseFloat(item.lat),
          lon: parseFloat(item.lon),
          city,
          state,
          country,
        }
      })
      .filter((item: any) => {
        const key = `${item.city}:${item.country}`
        if (seen.has(key)) return false
        seen.add(key)
        return true
      })

    return { results }
  } catch (error) {
    return { results: [] }
  }
}
