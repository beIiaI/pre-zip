/**
 * Age calculation and gating utilities
 */

/** Calculate age in years from a date string (YYYY-MM-DD) */
export function calculateAge(dateOfBirth: string | null | undefined): number | null {
  if (!dateOfBirth) return null
  const dob = new Date(dateOfBirth)
  if (isNaN(dob.getTime())) return null

  const today = new Date()
  let age = today.getFullYear() - dob.getFullYear()
  const monthDiff = today.getMonth() - dob.getMonth()
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
    age--
  }
  return age
}

/** Minimum age requirement for the app */
export const MINIMUM_AGE = 13

/** Check if a user meets the minimum age requirement */
export function meetsMinimumAge(dateOfBirth: string | null | undefined): boolean {
  const age = calculateAge(dateOfBirth)
  if (age === null) return false
  return age >= MINIMUM_AGE
}

/** Check if user is at least a given age */
export function isAtLeast(dateOfBirth: string | null | undefined, requiredAge: number): boolean {
  const age = calculateAge(dateOfBirth)
  if (age === null) return false
  return age >= requiredAge
}

/** Age brackets for feature gating */
export const AGE_GATES = {
  /** Basic app access */
  APP_ACCESS: 13,
  /** Can share location */
  LOCATION_SHARING: 16,
  /** Can use panic features */
  SAFETY_FEATURES: 13,
  /** Can create events */
  EVENT_CREATION: 16,
} as const
