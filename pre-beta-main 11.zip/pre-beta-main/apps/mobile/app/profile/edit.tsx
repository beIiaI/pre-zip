import React, { useState, useEffect } from 'react'
import {
  View,
  Text,
  TextInput,
  ScrollView,
  Pressable,
  StyleSheet,
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Image,
  Switch,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import * as ImagePicker from 'expo-image-picker'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'
import { apiRequest } from '@/lib/api'

const INTEREST_OPTIONS = [
  'Music', 'Sports', 'Tech', 'Art', 'Gaming', 'Fitness', 'Travel', 'Food',
  'Movies', 'Books', 'Photography', 'Fashion', 'Coding', 'Design', 'Science',
  'Politics', 'Finance', 'Nature', 'Comedy', 'Dance',
]

const LOCATION_OPTIONS = [
  'San Francisco, CA',
  'Los Angeles, CA',
  'New York, NY',
  'Austin, TX',
  'Seattle, WA',
  'Portland, OR',
  'Denver, CO',
  'Boston, MA',
]

function getInitials(name: string | null, email: string | null | undefined): string {
  if (name) return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
  if (email) return email[0].toUpperCase()
  return '?'
}

export default function EditProfileScreen() {
  const router = useRouter()
  const { colors } = useTheme()
  const { profile, user, refreshProfile } = useAuth()

  const [fullName, setFullName] = useState(profile?.full_name ?? '')
  const [username, setUsername] = useState(profile?.username ?? '')
  const [bio, setBio] = useState(profile?.bio ?? '')
  const [location, setLocation] = useState(profile?.location ?? '')
  const [interests, setInterests] = useState<string[]>(profile?.interests ?? [])
  const [avatarUri, setAvatarUri] = useState<string | null>(profile?.avatar_url ?? null)
  const [avatarChanged, setAvatarChanged] = useState(false)
  const [showUniversity, setShowUniversity] = useState(profile?.show_university !== false)
  const [showCollege, setShowCollege] = useState(profile?.show_college === true)
  const [collegeName, setCollegeName] = useState<string | null>(null)
  const [hasCollegeOptions, setHasCollegeOptions] = useState(false)
  const [showLocationPicker, setShowLocationPicker] = useState(false)

  const [saving, setSaving] = useState(false)
  const [usernameError, setUsernameError] = useState<string | null>(null)
  const [checkingUsername, setCheckingUsername] = useState(false)

  const isUniversityVerified = profile?.university_verified === true

  // Load college info for verified users
  useEffect(() => {
    if (!isUniversityVerified) {
      setCollegeName(null)
      setHasCollegeOptions(false)
      return
    }

    let active = true
    apiRequest<{ profile?: { college_name?: string | null }; collegeOptions?: string[] }>('/api/verification/college')
      .then((result) => {
        if (!active || result.error) return
        const nextCollege =
          typeof result.data?.profile?.college_name === 'string' && result.data.profile.college_name.trim()
            ? result.data.profile.college_name.trim()
            : null
        setCollegeName(nextCollege)
        setHasCollegeOptions(Array.isArray(result.data?.collegeOptions) && result.data!.collegeOptions!.length > 0)
      })

    return () => { active = false }
  }, [isUniversityVerified])

  // Username validation
  useEffect(() => {
    if (!username || username === profile?.username) {
      setUsernameError(null)
      return
    }

    if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) {
      setUsernameError('3-20 characters, letters, numbers, and underscores only')
      return
    }

    setUsernameError(null)
    setCheckingUsername(true)

    const timer = setTimeout(async () => {
      const { data } = await supabase
        .from('profiles')
        .select('id')
        .eq('username', username.toLowerCase())
        .neq('id', user?.id ?? '')
        .maybeSingle()

      setCheckingUsername(false)
      if (data) setUsernameError('Username is already taken')
    }, 500)

    return () => clearTimeout(timer)
  }, [username, profile?.username, user?.id])

  const pickAvatar = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync()
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Please allow photo library access to change your avatar.')
      return
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    })

    if (!result.canceled && result.assets[0]) {
      setAvatarUri(result.assets[0].uri)
      setAvatarChanged(true)
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)
    }
  }

  const toggleInterest = (tag: string) => {
    Haptics.selectionAsync()
    setInterests(prev =>
      prev.includes(tag) ? prev.filter(i => i !== tag) : [...prev, tag]
    )
  }

  const uploadAvatar = async (): Promise<string | null> => {
    if (!avatarChanged || !avatarUri || !user) return profile?.avatar_url ?? null

    try {
      const ext = avatarUri.split('.').pop()?.toLowerCase() ?? 'jpg'
      const fileName = `${user.id}/avatar.${ext}`
      const contentType = ext === 'png' ? 'image/png' : 'image/jpeg'

      const response = await fetch(avatarUri)
      const blob = await response.blob()

      const { error } = await supabase.storage
        .from('avatars')
        .upload(fileName, blob, { contentType, upsert: true })

      if (error) throw error

      const { data: { publicUrl } } = supabase.storage.from('avatars').getPublicUrl(fileName)
      return publicUrl
    } catch {
      return profile?.avatar_url ?? null
    }
  }

  const handleSave = async () => {
    if (usernameError || checkingUsername || saving) return
    if (!fullName.trim()) {
      Alert.alert('Name required', 'Please enter your full name.')
      return
    }

    setSaving(true)
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)

    const uploadedAvatarUrl = await uploadAvatar()

    const updates: Record<string, any> = {
      full_name: fullName.trim(),
      username: username.trim().toLowerCase() || null,
      bio: bio.trim() || null,
      location: location.trim() || null,
      interests,
      show_university: showUniversity,
      show_college: showUniversity ? showCollege : false,
      updated_at: new Date().toISOString(),
    }

    if (uploadedAvatarUrl !== undefined) {
      updates.avatar_url = uploadedAvatarUrl
    }

    const { error } = await supabase
      .from('profiles')
      .update(updates as any)
      .eq('id', user!.id)

    setSaving(false)

    if (error) {
      Alert.alert('Error', 'Could not save changes. Please try again.')
      return
    }

    await refreshProfile()
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success)
    router.back()
  }

  const initials = getInitials(fullName || profile?.full_name || null, user?.email)
  const canOfferCollegeToggle = isUniversityVerified && hasCollegeOptions && !!collegeName
  const universityDisplayName = profile?.university_name || 'Verified university'

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        {/* Header */}
        <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
          <Pressable onPress={() => router.back()} style={styles.headerBtn}>
            <Text style={[styles.headerBtnText, { color: colors.contentSecondary }]}>Cancel</Text>
          </Pressable>
          <Text style={[styles.headerTitle, { color: colors.contentPrimary }]}>Edit Profile</Text>
          <Pressable
            onPress={handleSave}
            disabled={saving || !!usernameError || checkingUsername}
            style={styles.headerBtn}
          >
            {saving
              ? <ActivityIndicator size="small" color={colors.contentPrimary} />
              : <Text style={[styles.headerBtnSave, { color: saving || usernameError ? colors.contentTertiary : colors.contentPrimary }]}>
                  Save
                </Text>
            }
          </Pressable>
        </View>

        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          {/* Avatar */}
          <Pressable onPress={pickAvatar} style={styles.avatarSection}>
            {avatarUri ? (
              <Image source={{ uri: avatarUri }} style={styles.avatar} />
            ) : (
              <View style={[styles.avatar, styles.avatarFallback, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
                <Text style={[styles.avatarText, { color: colors.contentPrimary }]}>{initials}</Text>
              </View>
            )}
            <View style={[styles.avatarOverlay, { backgroundColor: colors.contentPrimary }]}>
              <Ionicons name="camera" size={14} color={colors.contentInverse} />
            </View>
            <Text style={[styles.avatarHint, { color: colors.contentTertiary }]}>Change photo</Text>
          </Pressable>

          {/* Fields */}
          <View style={styles.fields}>
            <Field label="Full Name" colors={colors}>
              <TextInput
                value={fullName}
                onChangeText={setFullName}
                placeholder="Your name"
                placeholderTextColor={colors.contentTertiary}
                style={[styles.input, { color: colors.contentPrimary }]}
                autoCapitalize="words"
                returnKeyType="next"
              />
            </Field>

            <Field label="Username" colors={colors} error={usernameError} loading={checkingUsername}>
              <View style={styles.usernameRow}>
                <Text style={[styles.atSign, { color: colors.contentTertiary }]}>@</Text>
                <TextInput
                  value={username}
                  onChangeText={t => setUsername(t.replace(/[^a-zA-Z0-9_]/g, ''))}
                  placeholder="username"
                  placeholderTextColor={colors.contentTertiary}
                  style={[styles.input, styles.usernameInput, { color: colors.contentPrimary }]}
                  autoCapitalize="none"
                  autoCorrect={false}
                  returnKeyType="next"
                  maxLength={20}
                />
              </View>
            </Field>

            <Field label="Bio" colors={colors}>
              <TextInput
                value={bio}
                onChangeText={setBio}
                placeholder="Tell people about yourself..."
                placeholderTextColor={colors.contentTertiary}
                style={[styles.input, styles.bioInput, { color: colors.contentPrimary }]}
                multiline
                numberOfLines={3}
                maxLength={150}
                textAlignVertical="top"
              />
              <Text style={[styles.charCount, { color: colors.contentTertiary }]}>{bio.length}/150</Text>
            </Field>

            <Field label="Location" colors={colors}>
              <Pressable onPress={() => setShowLocationPicker(!showLocationPicker)}>
                <Text style={[styles.input, { color: location ? colors.contentPrimary : colors.contentTertiary, paddingVertical: 8 }]}>
                  {location || 'Add location'}
                </Text>
              </Pressable>
              {showLocationPicker && (
                <View style={styles.locationOptions}>
                  {LOCATION_OPTIONS.map((loc) => (
                    <Pressable
                      key={loc}
                      onPress={() => {
                        setLocation(loc)
                        setShowLocationPicker(false)
                        Haptics.selectionAsync()
                      }}
                      style={[
                        styles.locationOption,
                        {
                          backgroundColor: location === loc ? colors.surfaceSecondary : 'transparent',
                        },
                      ]}
                    >
                      <Text style={[styles.locationOptionText, { color: location === loc ? colors.contentPrimary : colors.contentSecondary }]}>
                        {loc}
                      </Text>
                    </Pressable>
                  ))}
                </View>
              )}
            </Field>
          </View>

          {/* University Visibility Toggles (matching web app) */}
          {isUniversityVerified && (
            <View style={styles.universitySection}>
              <Text style={[styles.sectionLabel, { color: colors.contentTertiary }]}>University</Text>
              <Text style={[styles.sectionSub, { color: colors.contentTertiary }]}>
                {universityDisplayName}
              </Text>

              {/* Show University toggle */}
              <View style={[styles.toggleCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
                <View style={[styles.toggleIcon, { backgroundColor: colors.surfacePrimary }]}>
                  <Ionicons name="school-outline" size={18} color={colors.contentPrimary} />
                </View>
                <View style={styles.toggleText}>
                  <Text style={[styles.toggleLabel, { color: colors.contentPrimary }]}>Show university</Text>
                  <Text style={[styles.toggleDesc, { color: colors.contentSecondary }]}>
                    Display your verified university on your public profile
                  </Text>
                </View>
                <Switch
                  value={showUniversity}
                  onValueChange={(v) => {
                    Haptics.selectionAsync()
                    setShowUniversity(v)
                    if (!v) setShowCollege(false)
                  }}
                  trackColor={{ false: colors.surfaceTertiary, true: colors.contentPrimary }}
                />
              </View>

              {/* Show College toggle (only if options available) */}
              {canOfferCollegeToggle && (
                <View style={[
                  styles.toggleCard,
                  {
                    backgroundColor: colors.surfaceSecondary,
                    borderColor: colors.borderSecondary,
                    opacity: showUniversity ? 1 : 0.6,
                  },
                ]}>
                  <View style={[styles.toggleIcon, { backgroundColor: colors.surfacePrimary }]}>
                    <Ionicons name="business-outline" size={18} color={colors.contentPrimary} />
                  </View>
                  <View style={styles.toggleText}>
                    <Text style={[styles.toggleLabel, { color: colors.contentPrimary }]}>Show college</Text>
                    <Text style={[styles.toggleDesc, { color: colors.contentSecondary }]}>
                      {collegeName
                        ? `Add "${collegeName}" to your profile`
                        : 'Select your college first in Safety & Verification'}
                    </Text>
                  </View>
                  <Switch
                    value={showCollege}
                    onValueChange={(v) => {
                      if (!showUniversity || !collegeName) return
                      Haptics.selectionAsync()
                      setShowCollege(v)
                    }}
                    disabled={!showUniversity || !collegeName}
                    trackColor={{ false: colors.surfaceTertiary, true: colors.contentPrimary }}
                  />
                </View>
              )}
            </View>
          )}

          {/* Interests */}
          <View style={styles.interestsSection}>
            <Text style={[styles.sectionLabel, { color: colors.contentTertiary }]}>Interests</Text>
            <Text style={[styles.sectionSub, { color: colors.contentTertiary }]}>
              {interests.length} selected
            </Text>
            <View style={styles.tagsGrid}>
              {INTEREST_OPTIONS.map(tag => {
                const active = interests.includes(tag)
                return (
                  <Pressable
                    key={tag}
                    onPress={() => toggleInterest(tag)}
                    style={[
                      styles.tag,
                      {
                        backgroundColor: active ? colors.contentPrimary : colors.surfaceSecondary,
                        borderColor: active ? colors.contentPrimary : colors.borderSecondary,
                      },
                    ]}
                  >
                    <Text style={[styles.tagText, { color: active ? colors.contentInverse : colors.contentSecondary }]}>
                      {tag}
                    </Text>
                  </Pressable>
                )
              })}
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

function Field({
  label, children, colors, error, loading,
}: { label: string; children: React.ReactNode; colors: any; error?: string | null; loading?: boolean }) {
  return (
    <View style={fieldStyles.wrapper}>
      <View style={fieldStyles.labelRow}>
        <Text style={[fieldStyles.label, { color: colors.contentTertiary }]}>{label}</Text>
        {loading && <ActivityIndicator size="small" color={colors.contentTertiary} style={{ marginLeft: 6 }} />}
      </View>
      <View style={[fieldStyles.inputWrap, { backgroundColor: colors.surfaceSecondary, borderColor: error ? colors.error : colors.borderSecondary }]}>
        {children}
      </View>
      {error && <Text style={[fieldStyles.error, { color: colors.error }]}>{error}</Text>}
    </View>
  )
}

const fieldStyles = StyleSheet.create({
  wrapper: { gap: 6 },
  labelRow: { flexDirection: 'row', alignItems: 'center' },
  label: {
    fontSize: Typography.caption,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
  },
  inputWrap: {
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
  },
  error: { fontSize: Typography.caption },
})

const styles = StyleSheet.create({
  container: { flex: 1 },
  flex: { flex: 1 },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
  },
  headerBtn: { minWidth: 60 },
  headerTitle: { fontSize: Typography.callout, fontWeight: '700' },
  headerBtnText: { fontSize: Typography.callout },
  headerBtnSave: { fontSize: Typography.callout, fontWeight: '700', textAlign: 'right' },

  scrollContent: {
    padding: Spacing.base,
    gap: Spacing.xl,
    paddingBottom: 100,
  },

  avatarSection: {
    alignItems: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.md,
  },
  avatar: { width: 88, height: 88, borderRadius: 44 },
  avatarFallback: { borderWidth: 1, justifyContent: 'center', alignItems: 'center' },
  avatarText: { fontSize: 32, fontWeight: '600' },
  avatarOverlay: {
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: -22,
    marginLeft: 56,
    alignSelf: 'center',
  },
  avatarHint: { fontSize: Typography.caption, marginTop: 4 },

  fields: { gap: Spacing.base },
  input: { fontSize: Typography.callout, paddingVertical: 4 },
  usernameRow: { flexDirection: 'row', alignItems: 'center' },
  atSign: { fontSize: Typography.callout, marginRight: 2 },
  usernameInput: { flex: 1 },
  bioInput: { minHeight: 72, paddingTop: 4 },
  charCount: { fontSize: 10, textAlign: 'right', marginTop: 4 },

  locationOptions: {
    marginTop: Spacing.sm,
    gap: 2,
  },
  locationOption: {
    paddingVertical: 10,
    paddingHorizontal: Spacing.sm,
    borderRadius: BorderRadius.sm,
  },
  locationOptionText: {
    fontSize: Typography.callout,
  },

  // University toggles
  universitySection: { gap: Spacing.md },
  toggleCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.base,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    gap: Spacing.md,
  },
  toggleIcon: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.md,
    justifyContent: 'center',
    alignItems: 'center',
  },
  toggleText: { flex: 1, gap: 2 },
  toggleLabel: { fontSize: Typography.body },
  toggleDesc: { fontSize: Typography.caption, lineHeight: Typography.caption * 1.4 },

  interestsSection: { gap: Spacing.md },
  sectionLabel: {
    fontSize: Typography.caption,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
  },
  sectionSub: { fontSize: Typography.caption, marginTop: -Spacing.sm },
  tagsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  tag: {
    paddingHorizontal: Spacing.md,
    paddingVertical: 8,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
  tagText: { fontSize: Typography.callout },
})
