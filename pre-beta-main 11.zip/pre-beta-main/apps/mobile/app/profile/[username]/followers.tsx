import { View, Text, StyleSheet, FlatList, Pressable, Image, ActivityIndicator } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter, useLocalSearchParams } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import { useTheme } from '@/contexts/ThemeContext'
import { Spacing, Typography, BorderRadius } from '@/constants/theme'
import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'

type UserItem = {
  id: string
  full_name: string | null
  username: string | null
  avatar_url: string | null
}

function getInitials(name: string | null): string {
  if (!name) return '?'
  return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
}

export default function FollowersScreen() {
  const { colors } = useTheme()
  const router = useRouter()
  const { username } = useLocalSearchParams<{ username: string }>()
  const [users, setUsers] = useState<UserItem[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!username) return
    let active = true

    const load = async () => {
      // First get the profile ID from the username
      const { data: profileData } = await supabase
        .from('profiles')
        .select('id')
        .eq('username', username)
        .maybeSingle()

      if (!active || !profileData) {
        setLoading(false)
        return
      }

      // Get followers
      const { data: followData } = await supabase
        .from('follows')
        .select('follower_id')
        .eq('following_id', profileData.id)

      if (!active || !followData || followData.length === 0) {
        setLoading(false)
        return
      }

      const followerIds = followData.map(f => f.follower_id)
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, full_name, username, avatar_url')
        .in('id', followerIds)

      if (active) {
        setUsers(profiles ?? [])
        setLoading(false)
      }
    }

    load()
    return () => { active = false }
  }, [username])

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      <View style={[styles.navBar, { borderBottomColor: colors.borderSecondary }]}>
        <Pressable onPress={() => router.back()} hitSlop={8} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
          <Text style={[styles.backLabel, { color: colors.contentPrimary }]}>Back</Text>
        </Pressable>
        <Text style={[styles.navTitle, { color: colors.contentPrimary }]}>Followers</Text>
        <View style={styles.navSpacer} />
      </View>

      {loading ? (
        <View style={styles.emptyState}>
          <ActivityIndicator size="large" color={colors.contentTertiary} />
        </View>
      ) : users.length === 0 ? (
        <View style={styles.emptyState}>
          <View style={[styles.emptyIcon, { backgroundColor: colors.surfaceSecondary }]}>
            <Ionicons name="people-outline" size={32} color={colors.contentTertiary} />
          </View>
          <Text style={[styles.emptyTitle, { color: colors.contentPrimary }]}>No followers yet</Text>
          <Text style={[styles.emptyDesc, { color: colors.contentSecondary }]}>
            Followers will appear here.
          </Text>
        </View>
      ) : (
        <FlatList
          data={users}
          contentContainerStyle={styles.list}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <Pressable
              onPress={() => router.push(`/user/${item.id}` as any)}
              style={[styles.userRow, { borderColor: colors.borderSecondary }]}
            >
              {item.avatar_url ? (
                <Image source={{ uri: item.avatar_url }} style={styles.avatar} />
              ) : (
                <View style={[styles.avatar, styles.avatarFallback, { backgroundColor: colors.surfaceTertiary }]}>
                  <Text style={[styles.avatarText, { color: colors.contentPrimary }]}>
                    {getInitials(item.full_name)}
                  </Text>
                </View>
              )}
              <View style={styles.userInfo}>
                <Text style={[styles.userName, { color: colors.contentPrimary }]}>
                  {item.full_name || 'User'}
                </Text>
                {item.username && (
                  <Text style={[styles.userHandle, { color: colors.contentSecondary }]}>@{item.username}</Text>
                )}
              </View>
              <Ionicons name="chevron-forward" size={16} color={colors.contentTertiary} />
            </Pressable>
          )}
        />
      )}
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  navBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    height: 44,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backBtn: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  backLabel: { fontSize: 17, marginLeft: 2 },
  navTitle: { fontSize: 17, fontWeight: '600' },
  navSpacer: { flex: 1 },

  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  emptyIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  emptyTitle: { fontSize: Typography.headline, fontWeight: '600' },
  emptyDesc: { fontSize: Typography.body, maxWidth: 240, textAlign: 'center' },

  list: { padding: Spacing.base, gap: Spacing.sm },
  userRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    paddingVertical: Spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  avatar: { width: 44, height: 44, borderRadius: 22 },
  avatarFallback: { justifyContent: 'center', alignItems: 'center' },
  avatarText: { fontSize: Typography.body, fontWeight: '600' },
  userInfo: { flex: 1 },
  userName: { fontSize: Typography.body, fontWeight: '500' },
  userHandle: { fontSize: Typography.caption },
})
