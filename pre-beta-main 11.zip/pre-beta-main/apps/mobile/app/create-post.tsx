import React, { useState } from 'react'
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
  Image,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import * as ImagePicker from 'expo-image-picker'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'
import { HapticFeedback } from '@/components/ui/RefreshControl'

const MAX_LENGTH = 500

export default function CreatePostScreen() {
  const router = useRouter()
  const { colors } = useTheme()
  const { user, profile } = useAuth()

  const [body, setBody] = useState('')
  const [imageUri, setImageUri] = useState<string | null>(null)
  const [posting, setPosting] = useState(false)

  const canPost = body.trim().length > 0 && !posting

  const handlePickImage = async () => {
    HapticFeedback.light()
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync()
    if (status !== 'granted') {
      Alert.alert('Permission Required', 'Please grant photo library access.')
      return
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 0.8,
      base64: true,
    })

    if (result.canceled || !result.assets[0]) return

    const asset = result.assets[0]
    const dataUri = `data:${asset.mimeType || 'image/jpeg'};base64,${asset.base64}`
    setImageUri(dataUri)
    HapticFeedback.success()
  }

  const handleRemoveImage = () => {
    HapticFeedback.light()
    setImageUri(null)
  }

  const handlePost = async () => {
    if (!canPost || !user) return

    setPosting(true)
    HapticFeedback.medium()

    const { error } = await supabase.from('posts').insert({
      author_id: user.id,
      body: body.trim(),
      image_url: imageUri,
    })

    setPosting(false)

    if (error) {
      HapticFeedback.error()
      Alert.alert('Error', 'Failed to create post. Try again.')
      return
    }

    HapticFeedback.success()
    router.back()
  }

  const initials = profile?.full_name
    ? profile.full_name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
    : '?'

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
        <Pressable onPress={() => router.back()} style={styles.cancelBtn}>
          <Text style={[styles.cancelText, { color: colors.contentSecondary }]}>Cancel</Text>
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.contentPrimary }]}>New Post</Text>
        <Pressable
          onPress={handlePost}
          disabled={!canPost}
          style={[
            styles.postBtn,
            { backgroundColor: canPost ? colors.contentPrimary : colors.surfaceElevated },
          ]}
        >
          <Text
            style={[
              styles.postBtnText,
              { color: canPost ? colors.contentInverse : colors.contentTertiary },
            ]}
          >
            Post
          </Text>
        </Pressable>
      </View>

      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Author row */}
          <View style={styles.authorRow}>
            {profile?.avatar_url ? (
              <Image source={{ uri: profile.avatar_url }} style={styles.avatar} />
            ) : (
              <View style={[styles.avatar, styles.avatarFallback, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
                <Text style={[styles.avatarText, { color: colors.contentPrimary }]}>{initials}</Text>
              </View>
            )}
            <View>
              <Text style={[styles.authorName, { color: colors.contentPrimary }]}>
                {profile?.full_name || 'You'}
              </Text>
              {profile?.username && (
                <Text style={[styles.authorUsername, { color: colors.contentTertiary }]}>
                  @{profile.username}
                </Text>
              )}
            </View>
          </View>

          {/* Text input */}
          <TextInput
            value={body}
            onChangeText={setBody}
            placeholder="What's on your mind?"
            placeholderTextColor={colors.contentTertiary}
            style={[styles.textInput, { color: colors.contentPrimary }]}
            multiline
            maxLength={MAX_LENGTH}
            autoFocus
            textAlignVertical="top"
          />

          {/* Image preview */}
          {imageUri && (
            <View style={styles.imagePreviewWrap}>
              <Image source={{ uri: imageUri }} style={styles.imagePreview} resizeMode="cover" />
              <Pressable
                onPress={handleRemoveImage}
                style={[styles.removeImageBtn, { backgroundColor: 'rgba(0,0,0,0.6)' }]}
              >
                <Ionicons name="close" size={18} color="#FFFFFF" />
              </Pressable>
            </View>
          )}
        </ScrollView>

        {/* Bottom toolbar */}
        <View style={[styles.toolbar, { borderTopColor: colors.borderSecondary, backgroundColor: colors.surfacePrimary }]}>
          <Pressable onPress={handlePickImage} style={styles.toolbarBtn}>
            <Ionicons name="image-outline" size={22} color={colors.contentSecondary} />
          </Pressable>
          <Text style={[styles.charCount, { color: body.length > MAX_LENGTH - 50 ? colors.warning : colors.contentTertiary }]}>
            {body.length}/{MAX_LENGTH}
          </Text>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  flex: { flex: 1 },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
  },
  headerTitle: { fontSize: Typography.callout, fontWeight: '600' },
  cancelBtn: { paddingVertical: Spacing.xs, paddingRight: Spacing.sm },
  cancelText: { fontSize: Typography.callout },
  postBtn: {
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
  },
  postBtnText: { fontSize: Typography.callout, fontWeight: '600' },

  scrollContent: {
    padding: Spacing.base,
    paddingBottom: Spacing.xxl,
  },

  authorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    marginBottom: Spacing.base,
  },
  avatar: { width: 40, height: 40, borderRadius: 20 },
  avatarFallback: { borderWidth: 1, justifyContent: 'center', alignItems: 'center' },
  avatarText: { fontSize: 14, fontWeight: '600' },
  authorName: { fontSize: Typography.callout, fontWeight: '600' },
  authorUsername: { fontSize: Typography.caption },

  textInput: {
    fontSize: Typography.body,
    lineHeight: Typography.body * 1.6,
    minHeight: 120,
  },

  imagePreviewWrap: {
    marginTop: Spacing.base,
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
    position: 'relative',
  },
  imagePreview: {
    width: '100%',
    height: 240,
    borderRadius: BorderRadius.lg,
  },
  removeImageBtn: {
    position: 'absolute',
    top: Spacing.sm,
    right: Spacing.sm,
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },

  toolbar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderTopWidth: 1,
  },
  toolbarBtn: { padding: Spacing.xs },
  charCount: { fontSize: Typography.caption },
})
