import { useEffect, useState } from 'react'
import { Redirect, useRouter } from 'expo-router'
import { View, StyleSheet } from 'react-native'
import { useAuth } from '@/contexts/AuthContext'
import { useTheme } from '@/contexts/ThemeContext'
import { LoadingScreen } from '@/components/screens/LoadingScreen'

/**
 * Root index - auth gate and routing logic
 * Matches pre-beta behavior: animated loading → auth check → route to appropriate screen
 */
export default function Index() {
  const { user, profile, loading, initialized, profileLoaded } = useAuth()
  const { colors } = useTheme()
  const router = useRouter()
  const [showLoading, setShowLoading] = useState(true)

  // Get user's first name for personalized greeting
  const firstName = profile?.full_name?.split(' ')[0] || null

  // Wait for auth to initialize
  if (!initialized || loading || !profileLoaded) {
    return (
      <View style={[styles.container, { backgroundColor: colors.surfacePrimary }]}>
        <LoadingScreen
          name={firstName}
          onLoadComplete={() => setShowLoading(false)}
        />
      </View>
    )
  }

  // Show animated loading screen on initial load
  if (showLoading) {
    return (
      <View style={[styles.container, { backgroundColor: colors.surfacePrimary }]}>
        <LoadingScreen
          name={firstName}
          onLoadComplete={() => setShowLoading(false)}
        />
      </View>
    )
  }

  // Not authenticated → redirect to splash
  if (!user) {
    return <Redirect href="/auth/splash" />
  }

  // Authenticated but onboarding incomplete → redirect to onboarding
  if (!profile?.onboarding_completed) {
    return <Redirect href="/auth/onboarding" />
  }

  // Authenticated and onboarded → redirect to home
  return <Redirect href="/(tabs)/home" />
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
})
