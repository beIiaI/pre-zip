import { View, Text, StyleSheet, ScrollView, Pressable, Image, Switch } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

type ThemeMode = 'light' | 'dark' | 'amoled' | 'system'

// iOS-style colored icon backgrounds
const ICON_COLORS: Record<string, string> = {
  'person-outline': '#007AFF',
  'notifications-outline': '#FF3B30',
  'lock-closed-outline': '#5856D6',
  'key-outline': '#FF9500',
  'person-add-outline': '#34C759',
  'shield-checkmark-outline': '#007AFF',
  'call-outline': '#34C759',
  'ban-outline': '#FF3B30',
  'help-circle-outline': '#5856D6',
  'flag-outline': '#FF9500',
}

type NavItem = {
  label: string
  icon: string
  route: string
  detail?: string
}

export default function SettingsScreen() {
  const { colors, theme, setTheme } = useTheme()
  const { signOut, profile } = useAuth()
  const router = useRouter()

  const handleSignOut = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)
    await signOut()
    router.replace('/auth/splash')
  }

  const handleTheme = (mode: ThemeMode) => {
    Haptics.selectionAsync()
    setTheme(mode)
  }

  const isVerified = profile?.university_verified === true

  const accountItems: NavItem[] = [
    { label: 'Edit Profile', icon: 'person-outline', route: '/profile/edit' },
    { label: 'Notifications', icon: 'notifications-outline', route: '/notifications' },
    { label: 'Privacy', icon: 'lock-closed-outline', route: '/settings/privacy' },
    { label: 'Password', icon: 'key-outline', route: '/settings/password' },
    { label: 'Invite Users', icon: 'person-add-outline', route: '/settings/invites' },
  ]

  const safetyItems: NavItem[] = [
    {
      label: 'Safety & Verification',
      icon: 'shield-checkmark-outline',
      route: '/settings/verification',
      detail: isVerified ? 'Verified' : undefined,
    },
    { label: 'Emergency Contacts', icon: 'call-outline', route: '/settings/emergency' },
    { label: 'Blocked Users', icon: 'ban-outline', route: '/settings/blocked' },
  ]

  const supportItems: NavItem[] = [
    { label: 'Help & Support', icon: 'help-circle-outline', route: '/settings/help' },
    { label: 'Report a Problem', icon: 'flag-outline', route: '/settings/report' },
  ]

  const showAmoled = theme === 'dark' || theme === 'amoled'

  const renderRow = (item: NavItem, index: number, total: number) => {
    const iconBg = ICON_COLORS[item.icon] || '#8E8E93'
    return (
      <Pressable
        key={item.route}
        onPress={() => {
          Haptics.selectionAsync()
          router.push(item.route as any)
        }}
        style={({ pressed }) => [
          styles.row,
          pressed && { backgroundColor: colors.surfaceElevated },
        ]}
      >
        <View style={[styles.rowIcon, { backgroundColor: iconBg }]}>
          <Ionicons name={item.icon as any} size={18} color="#FFFFFF" />
        </View>
        <View style={[
          styles.rowContent,
          index < total - 1 && { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.borderSecondary },
        ]}>
          <Text style={[styles.rowLabel, { color: colors.contentPrimary }]}>{item.label}</Text>
          <View style={styles.rowRight}>
            {item.detail && (
              <Text style={[styles.rowDetail, { color: colors.contentTertiary }]}>{item.detail}</Text>
            )}
            <Ionicons name="chevron-forward" size={16} color={colors.contentTertiary} />
          </View>
        </View>
      </Pressable>
    )
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>

        <Text style={[styles.largeTitle, { color: colors.contentPrimary }]}>Settings</Text>

        {/* Profile card - iOS style Apple ID row */}
        {profile && (
          <Pressable
            onPress={() => router.push('/profile/edit' as any)}
            style={({ pressed }) => [
              styles.profileRow,
              { backgroundColor: colors.surfaceSecondary },
              pressed && { opacity: 0.8 },
            ]}
          >
            {profile.avatar_url ? (
              <Image source={{ uri: profile.avatar_url }} style={styles.profileAvatar} />
            ) : (
              <View style={[styles.profileAvatar, { backgroundColor: colors.contentTertiary }]}>
                <Text style={styles.profileAvatarText}>
                  {(profile.full_name || profile.username || '?')[0].toUpperCase()}
                </Text>
              </View>
            )}
            <View style={styles.profileText}>
              <Text style={[styles.profileName, { color: colors.contentPrimary }]} numberOfLines={1}>
                {profile.full_name || profile.username || 'Set up profile'}
              </Text>
              <Text style={[styles.profileSub, { color: colors.contentTertiary }]} numberOfLines={1}>
                {profile.email || (profile.username ? `@${profile.username}` : '')}
              </Text>
              {profile.early_supporter_number != null && (
                <Text style={[styles.profileSub, { color: colors.contentTertiary }]}>
                  Early Supporter #{profile.early_supporter_number}
                </Text>
              )}
            </View>
            <Ionicons name="chevron-forward" size={18} color={colors.contentTertiary} />
          </Pressable>
        )}

        {/* Appearance group */}
        <View style={styles.group}>
          <Text style={[styles.groupHeader, { color: colors.contentTertiary }]}>APPEARANCE</Text>
          <View style={[styles.groupCard, { backgroundColor: colors.surfaceSecondary }]}>
            {/* Theme selector - horizontal pills */}
            <View style={styles.themeContainer}>
              {(['system', 'light', 'dark'] as ThemeMode[]).map((mode) => {
                const active = (theme === mode) || (mode === 'dark' && theme === 'amoled')
                const icons: Record<string, string> = {
                  system: 'phone-portrait-outline',
                  light: 'sunny-outline',
                  dark: 'moon-outline',
                }
                const labels: Record<string, string> = {
                  system: 'System',
                  light: 'Light',
                  dark: 'Dark',
                }
                return (
                  <Pressable
                    key={mode}
                    onPress={() => handleTheme(mode)}
                    style={[
                      styles.themePill,
                      {
                        backgroundColor: active ? colors.contentPrimary : 'transparent',
                      },
                    ]}
                  >
                    <Text style={[
                      styles.themePillText,
                      { color: active ? colors.contentInverse : colors.contentPrimary },
                    ]}>
                      {labels[mode]}
                    </Text>
                  </Pressable>
                )
              })}
            </View>
            {/* AMOLED toggle - only when dark is active */}
            {showAmoled && (
              <View style={[styles.row, { paddingLeft: Spacing.base }]}>
                <View style={[styles.rowContent, { paddingLeft: 0 }]}>
                  <Text style={[styles.rowLabel, { color: colors.contentPrimary }]}>AMOLED Black</Text>
                  <Switch
                    value={theme === 'amoled'}
                    onValueChange={(v) => handleTheme(v ? 'amoled' : 'dark')}
                    trackColor={{ false: colors.surfaceTertiary, true: colors.contentPrimary }}
                  />
                </View>
              </View>
            )}
          </View>
        </View>

        {/* Account */}
        <View style={styles.group}>
          <Text style={[styles.groupHeader, { color: colors.contentTertiary }]}>ACCOUNT</Text>
          <View style={[styles.groupCard, { backgroundColor: colors.surfaceSecondary }]}>
            {accountItems.map((item, i) => renderRow(item, i, accountItems.length))}
          </View>
        </View>

        {/* Safety */}
        <View style={styles.group}>
          <Text style={[styles.groupHeader, { color: colors.contentTertiary }]}>SAFETY</Text>
          <View style={[styles.groupCard, { backgroundColor: colors.surfaceSecondary }]}>
            {safetyItems.map((item, i) => renderRow(item, i, safetyItems.length))}
          </View>
        </View>

        {/* Support */}
        <View style={styles.group}>
          <Text style={[styles.groupHeader, { color: colors.contentTertiary }]}>SUPPORT</Text>
          <View style={[styles.groupCard, { backgroundColor: colors.surfaceSecondary }]}>
            {supportItems.map((item, i) => renderRow(item, i, supportItems.length))}
          </View>
        </View>

        {/* Sign Out */}
        <View style={styles.group}>
          <Pressable
            onPress={handleSignOut}
            style={({ pressed }) => [
              styles.signOutRow,
              { backgroundColor: colors.surfaceSecondary },
              pressed && { opacity: 0.7 },
            ]}
          >
            <Text style={[styles.signOutText, { color: '#FF3B30' }]}>Sign Out</Text>
          </Pressable>
        </View>

        <Text style={[styles.footer, { color: colors.contentTertiary }]}>pre · pre-beta</Text>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: {
    paddingBottom: 100,
  },

  largeTitle: {
    fontSize: 34,
    fontWeight: '700',
    paddingHorizontal: Spacing.base,
    paddingTop: Spacing.sm,
    paddingBottom: Spacing.md,
  },

  // Profile row (like Apple ID in iOS Settings)
  profileRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: Spacing.base,
    padding: Spacing.md,
    borderRadius: BorderRadius.lg,
    gap: Spacing.md,
    marginBottom: Spacing.lg,
  },
  profileAvatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  profileAvatarText: {
    fontSize: 22,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  profileText: { flex: 1, gap: 1 },
  profileName: { fontSize: 18, fontWeight: '600' },
  profileSub: { fontSize: Typography.caption },

  // Groups
  group: {
    marginBottom: Spacing.lg,
  },
  groupHeader: {
    fontSize: 13,
    fontWeight: '400',
    paddingHorizontal: Spacing.base + Spacing.base,
    paddingBottom: 6,
    letterSpacing: -0.08,
  },
  groupCard: {
    marginHorizontal: Spacing.base,
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
  },

  // Rows
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: 44,
    paddingLeft: Spacing.md,
  },
  rowIcon: {
    width: 29,
    height: 29,
    borderRadius: 7,
    justifyContent: 'center',
    alignItems: 'center',
  },
  rowContent: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    minHeight: 44,
    paddingLeft: Spacing.md,
    paddingRight: Spacing.md,
  },
  rowLabel: {
    fontSize: 17,
    flex: 1,
  },
  rowRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  rowDetail: {
    fontSize: 17,
  },

  // Theme selector
  themeContainer: {
    flexDirection: 'row',
    margin: Spacing.md,
    borderRadius: 9,
    overflow: 'hidden',
    gap: 0,
  },
  themePill: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 8,
  },
  themePillText: {
    fontSize: 13,
    fontWeight: '600',
  },

  // Sign out
  signOutRow: {
    marginHorizontal: Spacing.base,
    borderRadius: BorderRadius.lg,
    alignItems: 'center',
    paddingVertical: 12,
  },
  signOutText: {
    fontSize: 17,
  },

  footer: {
    fontSize: 13,
    textAlign: 'center',
    paddingTop: Spacing.md,
    paddingBottom: Spacing.xl,
  },
})
