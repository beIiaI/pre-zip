import React, { useState, useCallback, useEffect, useRef } from 'react'
import {
  View,
  Text,
  FlatList,
  Pressable,
  StyleSheet,
  ActivityIndicator,
  Alert,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'
import { joinCircle, leaveCircle } from '@/lib/circles'
import { CustomRefreshControl, HapticFeedback } from '@/components/ui/RefreshControl'
import { Skeleton } from '@/components/ui/Skeleton'
import { AnimatedEnter } from '@/components/ui/AnimatedEnter'
import type { CircleMemberPartial } from '@/types/supabase-helpers'

// ─── Types ────────────────────────────────────────────────────────────────────

interface Circle {
  id: string
  name: string
  description: string | null
  is_public: boolean
  category: string | null
  creator_id: string
  member_count: number
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function CirclesScreen() {
  const router = useRouter()
  const { colors } = useTheme()
  const { user } = useAuth()

  const [circles, setCircles] = useState<Circle[]>([])
  const [joinedIds, setJoinedIds] = useState<Set<string>>(new Set())
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const fetched = useRef(false)

  const fetchCircles = useCallback(async (refresh = false) => {
    if (!user) return
    if (refresh) setRefreshing(true)
    else setLoading(true)

    const [circlesRes, membershipRes] = await Promise.all([
      supabase
        .from('circles')
        .select('id, name, description, is_public, category, creator_id, member_count')
        .eq('is_public', true)
        .order('member_count', { ascending: false })
        .limit(40),
      supabase
        .from('circle_members')
        .select('circle_id')
        .eq('user_id', user.id),
    ])

    if (circlesRes.data) setCircles(circlesRes.data)
    if (membershipRes.data) {
      const memberships = membershipRes.data as CircleMemberPartial[]
      setJoinedIds(new Set(memberships.map(m => m.circle_id)))
    }

    setLoading(false)
    setRefreshing(false)
    fetched.current = true
  }, [user])

  useEffect(() => { fetchCircles() }, [fetchCircles])

  const handleJoin = useCallback(async (circleId: string) => {
    if (!user) return
    HapticFeedback.medium()

    if (joinedIds.has(circleId)) {
      // Optimistic update
      setJoinedIds(prev => { const n = new Set(prev); n.delete(circleId); return n })
      setCircles(prev => prev.map(c => c.id === circleId ? { ...c, member_count: Math.max(0, c.member_count - 1) } : c))
      
      // Use API
      const result = await leaveCircle(circleId)
      if (result.error) {
        // Revert on error
        setJoinedIds(prev => new Set([...prev, circleId]))
        setCircles(prev => prev.map(c => c.id === circleId ? { ...c, member_count: c.member_count + 1 } : c))
        Alert.alert('Error', result.error)
      }
    } else {
      // Optimistic update
      setJoinedIds(prev => new Set([...prev, circleId]))
      setCircles(prev => prev.map(c => c.id === circleId ? { ...c, member_count: c.member_count + 1 } : c))
      
      // Use API
      const result = await joinCircle(circleId)
      if (result.error) {
        // Revert on error
        setJoinedIds(prev => { const n = new Set(prev); n.delete(circleId); return n })
        setCircles(prev => prev.map(c => c.id === circleId ? { ...c, member_count: Math.max(0, c.member_count - 1) } : c))
        Alert.alert('Unable to Join', result.error)
      }
    }
  }, [user, joinedIds])

  const renderSkeletonItem = ({ index }: { index: number }) => (
    <View
      key={`skeleton-${index}`}
      style={[styles.card, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}
    >
      <View style={styles.cardTop}>
        <Skeleton width={40} height={40} borderRadius={BorderRadius.md} />
        <View style={styles.cardInfo}>
          <Skeleton width={140} height={16} />
          <Skeleton width={80} height={12} style={{ marginTop: 4 }} />
        </View>
        <Skeleton width={60} height={28} borderRadius={BorderRadius.full} />
      </View>
      <Skeleton width="90%" height={14} style={{ marginTop: Spacing.sm }} />
      <Skeleton width="70%" height={14} style={{ marginTop: 4 }} />
      <View style={[styles.metaRow, { marginTop: Spacing.sm }]}>
        <Skeleton width={80} height={12} />
      </View>
    </View>
  )

  const renderItem = ({ item }: { item: Circle }) => {
    const joined = joinedIds.has(item.id)
    return (
      <Pressable
        onPress={() => { HapticFeedback.selection(); router.push(`/circle/${item.id}` as any) }}
        style={[styles.card, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}
      >
        <View style={styles.cardTop}>
          <View style={[styles.iconBox, { backgroundColor: colors.surfaceElevated }]}>
            <Ionicons name="people" size={18} color={colors.contentPrimary} />
          </View>
          <View style={styles.cardInfo}>
            <Text style={[styles.cardName, { color: colors.contentPrimary }]} numberOfLines={1}>
              {item.name}
            </Text>
            {item.category && (
              <Text style={[styles.cardCategory, { color: colors.contentTertiary }]}>
                {item.category}
              </Text>
            )}
          </View>
          <Pressable
            onPress={e => { e.stopPropagation(); handleJoin(item.id) }}
            style={[
              styles.joinPill,
              joined
                ? { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }
                : { backgroundColor: colors.contentPrimary, borderColor: colors.contentPrimary },
            ]}
          >
            <Text style={[styles.joinPillText, { color: joined ? colors.contentPrimary : colors.contentInverse }]}>
              {joined ? 'Joined' : 'Join'}
            </Text>
          </Pressable>
        </View>

        {item.description && (
          <Text style={[styles.cardDesc, { color: colors.contentSecondary }]} numberOfLines={2}>
            {item.description}
          </Text>
        )}

        <View style={styles.metaRow}>
          <Ionicons name="people-outline" size={12} color={colors.contentTertiary} />
          <Text style={[styles.metaText, { color: colors.contentTertiary }]}>
            {item.member_count.toLocaleString()} {item.member_count === 1 ? 'member' : 'members'}
          </Text>
          <Ionicons name="chevron-forward" size={12} color={colors.contentTertiary} style={{ marginLeft: 'auto' }} />
        </View>
      </Pressable>
    )
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      {/* Header */}
      <AnimatedEnter delay={0}>
        <View style={styles.header}>
          <Text style={[styles.headerTitle, { color: colors.contentPrimary }]}>Circles</Text>
          <Pressable
            onPress={() => { HapticFeedback.selection(); router.push('/create-circle' as any) }}
            style={[styles.createBtn, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}
          >
            <Ionicons name="add" size={16} color={colors.contentPrimary} />
            <Text style={[styles.createBtnText, { color: colors.contentPrimary }]}>New</Text>
          </Pressable>
        </View>
      </AnimatedEnter>

      {loading ? (
        <FlatList
          data={Array.from({ length: 5 })}
          keyExtractor={(_, idx) => `skeleton-${idx}`}
          renderItem={renderSkeletonItem}
          contentContainerStyle={styles.listContent}
          ListHeaderComponent={
            <Skeleton width={80} height={12} style={{ marginBottom: Spacing.xs }} />
          }
          showsVerticalScrollIndicator={false}
        />
      ) : (
        <FlatList
          data={circles}
          keyExtractor={item => item.id}
          renderItem={renderItem}
          contentContainerStyle={styles.listContent}
          refreshControl={
            <CustomRefreshControl
              refreshing={refreshing}
              onRefresh={() => fetchCircles(true)}
            />
          }
          ListHeaderComponent={
            <Text style={[styles.sectionLabel, { color: colors.contentTertiary }]}>DISCOVER</Text>
          }
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <Ionicons name="people-outline" size={36} color={colors.contentTertiary} />
              <Text style={[styles.emptyTitle, { color: colors.contentPrimary }]}>No circles yet</Text>
              <Text style={[styles.emptySub, { color: colors.contentSecondary }]}>
                Be the first to create a circle.
              </Text>
            </View>
          }
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  )
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
  },
  headerTitle: { fontSize: Typography.title, fontWeight: '700' },
  createBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
    borderWidth: StyleSheet.hairlineWidth,
  },
  createBtnText: { fontSize: Typography.caption, fontWeight: '600' },

  listContent: {
    padding: Spacing.base,
    gap: Spacing.sm,
    paddingBottom: 110,
  },
  sectionLabel: {
    fontSize: Typography.labelCaps,
    fontWeight: '700',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    marginBottom: Spacing.xs,
  },

  card: {
    borderRadius: BorderRadius.lg,
    borderWidth: StyleSheet.hairlineWidth,
    padding: Spacing.base,
    gap: Spacing.sm,
  },
  cardTop: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  iconBox: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.md,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardInfo: { flex: 1 },
  cardName: { fontSize: Typography.callout, fontWeight: '600' },
  cardCategory: { fontSize: Typography.caption, marginTop: 2 },
  joinPill: {
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
  joinPillText: { fontSize: Typography.caption, fontWeight: '600' },
  cardDesc: { fontSize: Typography.callout, lineHeight: Typography.callout * 1.5 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  metaText: { fontSize: Typography.caption },

  emptyState: { alignItems: 'center', gap: Spacing.sm, paddingVertical: Spacing.xxl },
  emptyTitle: { fontSize: Typography.headline, fontWeight: '600' },
  emptySub: { fontSize: Typography.callout, textAlign: 'center' },
})
