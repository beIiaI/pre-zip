import { useState, useEffect, useCallback } from 'react'
import { View, Text, StyleSheet, ScrollView, Image, Pressable } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'
import { isCoordinateString, reverseGeocode } from '@/utils/location'
import { HapticFeedback } from '@/components/ui/RefreshControl'

function getInitials(name: string | null, email: string | null | undefined): string {
  if (name) return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
  if (email) return email[0].toUpperCase()
  return '?'
}

function formatMemberSince(iso: string): string {
  const d = new Date(iso)
  return d.toLocaleDateString('en-US', { month: 'short', year: '2-digit' })
}

export default function ProfileScreen() {
  const { colors } = useTheme()
  const { profile, user } = useAuth()
  const router = useRouter()
  const [resolvedLocation, setResolvedLocation] = useState<string | null>(null)
  const [followersCount, setFollowersCount] = useState(0)
  const [followingCount, setFollowingCount] = useState(0)
  const [myPosts, setMyPosts] = useState<any[]>([])

  const initials = getInitials(profile?.full_name ?? null, user?.email)

  const isFounder = profile?.is_founder === true
  const hasEarlySupporterNumber =
    profile?.early_supporter_number !== null && profile?.early_supporter_number !== undefined
  const hasMemberBadges = isFounder || hasEarlySupporterNumber
  const isUniversityVerified =
    profile?.university_verified === true ||
    (profile?.is_verified === true && (profile as any)?.verification_type === 'university_email')
  const showUniversityOnProfile = profile?.show_university !== false
  const showCollegeOnProfile = profile?.show_college === true
  const membershipSince = profile?.created_at ? formatMemberSince(profile.created_at) : ''
  const [collegeName, setCollegeName] = useState<string | null>(null)

  useEffect(() => {
    if (!profile?.id) return
    let active = true

    const fetchCounts = async () => {
      const [followersRes, followingRes, postsRes] = await Promise.all([
        supabase.from('follows').select('follower_id', { count: 'exact', head: true }).eq('following_id', profile.id),
        supabase.from('follows').select('following_id', { count: 'exact', head: true }).eq('follower_id', profile.id),
        supabase.from('posts').select('id, body, image_url, like_count, comment_count, created_at').eq('author_id', profile.id).order('created_at', { ascending: false }).limit(10),
      ])
      if (!active) return
      setFollowersCount(followersRes.count ?? 0)
      setFollowingCount(followingRes.count ?? 0)
      setMyPosts(postsRes.data ?? [])
    }

    // Fetch college name for badge display
    const fetchCollege = async () => {
      try {
        const { data } = await supabase
          .from('profiles')
          .select('college_name')
          .eq('id', profile.id)
          .maybeSingle()
        if (active && data?.college_name) {
          setCollegeName(data.college_name)
        }
      } catch {}
    }

    fetchCounts()
    if (showCollegeOnProfile) fetchCollege()
    return () => { active = false }
  }, [profile?.id, showCollegeOnProfile])

  useEffect(() => {
    if (!profile) return
    const loc = profile.location
    if (loc && isCoordinateString(loc)) {
      const parts = loc.split(',').map(s => parseFloat(s.trim()))
      if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
        reverseGeocode(parts[0], parts[1]).then(({ label }) => {
          if (label) setResolvedLocation(label)
        })
      }
    } else if (loc) {
      setResolvedLocation(loc)
    }
  }, [profile?.location])

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header row */}
        <View style={styles.topRow}>
          <Text style={[styles.screenTitle, { color: colors.contentPrimary }]}>Profile</Text>
          <Pressable onPress={() => router.push('/profile/edit')} style={styles.editButton}>
            <Ionicons name="create-outline" size={20} color={colors.contentPrimary} />
            <Text style={[styles.editText, { color: colors.contentPrimary }]}>Edit</Text>
          </Pressable>
        </View>

        {/* Avatar + Name */}
        <View style={styles.heroSection}>
          <View style={styles.avatarWrap}>
            {profile?.avatar_url ? (
              <Image source={{ uri: profile.avatar_url }} style={styles.avatar} />
            ) : (
              <View style={[styles.avatar, styles.avatarFallback, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
                <Text style={[styles.avatarText, { color: colors.contentPrimary }]}>{initials}</Text>
              </View>
            )}
          </View>

          <Text style={[styles.name, { color: colors.contentPrimary }]}>
            {profile?.full_name || user?.email?.split('@')[0] || 'Your Name'}
          </Text>

          {profile?.username && (
            <View style={styles.usernameRow}>
              <Text style={[styles.username, { color: colors.contentSecondary }]}>@{profile.username}</Text>
              {profile?.is_verified && (
                <Ionicons name="checkmark-circle" size={15} color={colors.contentPrimary} style={{ marginLeft: 4 }} />
              )}
            </View>
          )}

          {/* Membership + Access badges (matching web) */}
          <View style={styles.chipRow}>
            <View style={[styles.chip, { borderColor: colors.borderSecondary, backgroundColor: colors.surfaceSecondary }]}>
              <Text style={[styles.chipText, { color: colors.contentPrimary }]}>
                {isFounder ? 'Founder' : 'Access'}
              </Text>
            </View>
            {membershipSince ? (
              <View style={styles.sinceRow}>
                <Ionicons name="shield-checkmark-outline" size={13} color={colors.contentTertiary} />
                <Text style={[styles.sinceText, { color: colors.contentSecondary }]}>
                  Since {membershipSince}
                </Text>
              </View>
            ) : null}
          </View>
        </View>

        {/* University + Member Badges */}
        {((isUniversityVerified && showUniversityOnProfile) || hasMemberBadges) && (
          <View style={styles.badgesRow}>
            {isUniversityVerified && showUniversityOnProfile && profile?.university_name && (
              <View style={[styles.badge, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
                <Text style={[styles.badgeText, { color: colors.contentPrimary }]}>
                  {profile.university_name}
                </Text>
              </View>
            )}
            {isUniversityVerified && showUniversityOnProfile && showCollegeOnProfile && collegeName && (
              <View style={[styles.badge, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
                <Text style={[styles.badgeText, { color: colors.contentPrimary }]}>
                  {collegeName}
                </Text>
              </View>
            )}
            {profile?.early_supporter_number != null && (
              <View style={[styles.badge, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
                <Ionicons name="star-outline" size={12} color={colors.contentSecondary} />
                <Text style={[styles.badgeText, { color: colors.contentSecondary }]}>
                  Early Supporter #{profile.early_supporter_number}
                </Text>
              </View>
            )}
            {profile?.is_founder && profile.founder_number != null && (
              <View style={[styles.badge, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
                <Ionicons name="ribbon-outline" size={12} color={colors.contentSecondary} />
                <Text style={[styles.badgeText, { color: colors.contentSecondary }]}>
                  Founder #{profile.founder_number}
                </Text>
              </View>
            )}
          </View>
        )}

        {/* Stats row - tappable Followers / Following */}
        <View style={[styles.statsCard, { borderColor: colors.borderSecondary, backgroundColor: colors.surfaceSecondary + '70' }]}>
          <View style={styles.statsInner}>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: colors.contentPrimary }]}>
                {(profile?.total_points ?? 0).toLocaleString()}
              </Text>
              <Text style={[styles.statLabel, { color: colors.contentSecondary }]}>Points</Text>
            </View>
            <View style={[styles.statDivider, { backgroundColor: colors.borderSecondary }]} />
            <Pressable
              style={styles.statItem}
              onPress={() => {
                HapticFeedback.light()
                if (profile?.username) {
                  router.push(`/profile/${encodeURIComponent(profile.username)}/followers` as any)
                }
              }}
            >
              <Text style={[styles.statValue, { color: colors.contentPrimary }]}>
                {followersCount}
              </Text>
              <Text style={[styles.statLabel, { color: colors.contentSecondary }]}>Followers</Text>
            </Pressable>
            <View style={[styles.statDivider, { backgroundColor: colors.borderSecondary }]} />
            <Pressable
              style={styles.statItem}
              onPress={() => {
                HapticFeedback.light()
                if (profile?.username) {
                  router.push(`/profile/${encodeURIComponent(profile.username)}/following` as any)
                }
              }}
            >
              <Text style={[styles.statValue, { color: colors.contentPrimary }]}>
                {followingCount}
              </Text>
              <Text style={[styles.statLabel, { color: colors.contentSecondary }]}>Following</Text>
            </Pressable>
          </View>
        </View>

        {/* Bio */}
        {profile?.bio && (
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: colors.contentTertiary }]}>About</Text>
            <Text style={[styles.bioText, { color: colors.contentSecondary }]}>{profile.bio}</Text>
          </View>
        )}

        {/* Details: Location + Joined */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.contentTertiary }]}>Details</Text>
          <View style={styles.detailsWrap}>
            {resolvedLocation && (
              <View style={[styles.detailPill, { borderColor: colors.borderSecondary, backgroundColor: colors.surfaceSecondary + '70' }]}>
                <Ionicons name="location-outline" size={14} color={colors.contentTertiary} />
                <Text style={[styles.detailPillText, { color: colors.contentPrimary }]}>{resolvedLocation}</Text>
              </View>
            )}
            {profile?.created_at && (
              <View style={[styles.detailPill, { borderColor: colors.borderSecondary, backgroundColor: colors.surfaceSecondary + '70' }]}>
                <Ionicons name="calendar-outline" size={14} color={colors.contentTertiary} />
                <Text style={[styles.detailPillText, { color: colors.contentPrimary }]}>
                  Joined {new Date(profile.created_at).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Interests */}
        {Array.isArray(profile?.interests) && profile.interests.length > 0 && (
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: colors.contentTertiary }]}>Interests</Text>
            <View style={styles.tagsRow}>
              {profile.interests.map((tag: string) => (
                <View key={tag} style={[styles.tag, { backgroundColor: colors.surfaceSecondary + '60', borderColor: colors.borderSecondary }]}>
                  <Text style={[styles.tagText, { color: colors.contentPrimary }]}>{tag}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Invite card - matching web app's referral network card */}
        <Pressable
          onPress={() => {
            HapticFeedback.light()
            router.push('/settings/invites' as any)
          }}
          style={[styles.inviteCard, { backgroundColor: colors.surfaceSecondary + '65', borderColor: colors.borderSecondary }]}
        >
          <View style={[styles.inviteIconWrap, { backgroundColor: colors.surfacePrimary + '80', borderColor: colors.borderSecondary }]}>
            <Ionicons name="person-add-outline" size={16} color={colors.contentPrimary} />
          </View>
          <Text style={[styles.inviteLabel, { color: colors.contentTertiary }]}>REFERRAL NETWORK</Text>
          <Text style={[styles.inviteTitle, { color: colors.contentPrimary }]}>Invite Your Crew</Text>
          <Text style={[styles.inviteSub, { color: colors.contentSecondary }]}>
            Share your invite links and bring trusted people into pre.
          </Text>
        </Pressable>

        {/* View Badges / Verification CTA */}
        {!isUniversityVerified && (
          <Pressable
            onPress={() => {
              HapticFeedback.light()
              router.push('/settings/verification' as any)
            }}
            style={[styles.badgesButton, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}
          >
            <Ionicons name="shield-checkmark-outline" size={16} color={colors.contentPrimary} />
            <Text style={[styles.badgesButtonText, { color: colors.contentPrimary }]}>Get Verified</Text>
          </Pressable>
        )}

        {/* My posts */}
        {myPosts.length > 0 && (
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: colors.contentTertiary }]}>Posts</Text>
            <View style={styles.postsGrid}>
              {myPosts.map(post => (
                <Pressable
                  key={post.id}
                  onPress={() => { Haptics.selectionAsync(); router.push(`/post/${post.id}` as any) }}
                  style={[styles.postCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}
                >
                  <Text style={[styles.postBody, { color: colors.contentPrimary }]} numberOfLines={3}>
                    {post.body}
                  </Text>
                  <View style={styles.postMeta}>
                    <View style={styles.postMetaItem}>
                      <Ionicons name="heart-outline" size={12} color={colors.contentTertiary} />
                      <Text style={[styles.postMetaText, { color: colors.contentTertiary }]}>{post.like_count}</Text>
                    </View>
                    <View style={styles.postMetaItem}>
                      <Ionicons name="chatbubble-outline" size={11} color={colors.contentTertiary} />
                      <Text style={[styles.postMetaText, { color: colors.contentTertiary }]}>{post.comment_count}</Text>
                    </View>
                  </View>
                </Pressable>
              ))}
            </View>
          </View>
        )}

        {/* Settings shortcut */}
        <Pressable
          onPress={() => {
            HapticFeedback.light()
            router.push('/(tabs)/settings')
          }}
          style={[styles.settingsRow, { borderColor: colors.borderSecondary }]}
        >
          <Ionicons name="settings-outline" size={18} color={colors.contentSecondary} />
          <Text style={[styles.settingsText, { color: colors.contentSecondary }]}>Settings</Text>
          <Ionicons name="chevron-forward" size={16} color={colors.contentTertiary} style={{ marginLeft: 'auto' }} />
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: {
    padding: Spacing.base,
    paddingBottom: 100,
    gap: Spacing.sm,
  },

  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: Spacing.sm,
  },
  screenTitle: { fontSize: Typography.headline, fontWeight: '700' },
  editButton: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  editText: { fontSize: Typography.callout, fontWeight: '500' },

  heroSection: { alignItems: 'center', paddingVertical: Spacing.lg, gap: Spacing.sm },
  avatarWrap: { marginBottom: Spacing.sm },
  avatar: { width: 88, height: 88, borderRadius: 44 },
  avatarFallback: { borderWidth: 1, justifyContent: 'center', alignItems: 'center' },
  avatarText: { fontSize: 34, fontWeight: '600' },
  name: { fontSize: Typography.title, fontWeight: '700', textAlign: 'center' },
  usernameRow: { flexDirection: 'row', alignItems: 'center' },
  username: { fontSize: Typography.body },

  chipRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    paddingTop: 4,
  },
  chip: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
  chipText: {
    fontSize: Typography.eyebrow,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  sinceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  sinceText: {
    fontSize: Typography.caption,
  },

  badgesRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
  badgeText: { fontSize: Typography.caption },

  statsCard: {
    borderWidth: 1,
    borderRadius: 20,
    overflow: 'hidden',
    marginVertical: Spacing.sm,
    padding: 10,
  },
  statsInner: {
    flexDirection: 'row',
  },
  statItem: { flex: 1, alignItems: 'center', paddingVertical: Spacing.sm },
  statValue: { fontSize: Typography.title, fontWeight: '700' },
  statLabel: { fontSize: Typography.caption, marginTop: 2 },
  statDivider: { width: 1 },

  section: { paddingVertical: Spacing.base, gap: Spacing.sm },
  sectionTitle: {
    fontSize: Typography.caption,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
  },
  bioText: { fontSize: Typography.body, lineHeight: Typography.body * 1.5 },

  detailsWrap: { gap: Spacing.sm },
  detailPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
    paddingHorizontal: Spacing.base,
    paddingVertical: 10,
  },
  detailPillText: { fontSize: Typography.callout },

  tagsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  tag: {
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
  tagText: { fontSize: Typography.caption },

  inviteCard: {
    borderRadius: 22,
    borderWidth: 1,
    padding: 20,
    marginTop: Spacing.sm,
  },
  inviteIconWrap: {
    width: 36,
    height: 36,
    borderRadius: 18,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: Spacing.md,
  },
  inviteLabel: {
    fontSize: Typography.eyebrow,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
  },
  inviteTitle: { fontSize: Typography.title, fontWeight: '700' },
  inviteSub: { fontSize: Typography.body, lineHeight: Typography.body * 1.4, marginTop: 4 },

  badgesButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.button,
    borderWidth: 1,
    marginTop: Spacing.sm,
  },
  badgesButtonText: {
    fontSize: Typography.callout,
    fontWeight: '600',
  },

  postsGrid: { gap: Spacing.sm },
  postCard: {
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    borderWidth: StyleSheet.hairlineWidth,
    gap: Spacing.sm,
  },
  postBody: { fontSize: Typography.callout, lineHeight: Typography.callout * 1.5 },
  postMeta: { flexDirection: 'row', gap: Spacing.md },
  postMetaItem: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  postMetaText: { fontSize: Typography.caption },

  settingsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    paddingVertical: Spacing.base,
    borderWidth: 1,
    borderRadius: BorderRadius.lg,
    paddingHorizontal: Spacing.base,
    marginTop: Spacing.base,
  },
  settingsText: { fontSize: Typography.callout },
})
