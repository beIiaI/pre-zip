import React, { useState, useCallback, useEffect, useRef } from 'react'
import {
  View,
  Text,
  FlatList,
  Pressable,
  StyleSheet,
  ActivityIndicator,
  Image,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ScrollView,
  Modal,
  Dimensions,
} from 'react-native'
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context'
import { useLocalSearchParams, useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import * as ImagePicker from 'expo-image-picker'
import { Swipeable } from 'react-native-gesture-handler'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'
import { HapticFeedback } from '@/components/ui/RefreshControl'
import { AnimatedEnter } from '@/components/ui/AnimatedEnter'
import { sendDMNotification } from '@/lib/push'

// ─── Constants ────────────────────────────────────────────────────────────────

const EMOJIS = ['😊', '😂', '😍', '🔥', '🎉', '🥳', '🙏', '✨', '🤍', '😎']
const UNSEND_WINDOW_MS = 5 * 60 * 1000 // 5 minutes
const MAX_IMAGE_SIZE = 900 * 1024 // 900KB

// ─── Types ────────────────────────────────────────────────────────────────────

interface Message {
  id: string
  body: string
  sender_id: string
  created_at: string
  deleted_at: string | null
}

interface OtherUser {
  id: string
  full_name: string | null
  username: string | null
  avatar_url: string | null
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getInitials(name: string | null, username: string | null): string {
  if (name) return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
  if (username) return username[0].toUpperCase()
  return '?'
}

function formatMessageTime(iso: string): string {
  const d = new Date(iso)
  const now = new Date()
  const isToday = d.toDateString() === now.toDateString()
  if (isToday) return d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) +
    ' ' + d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function ConversationScreen() {
  const { id: threadId } = useLocalSearchParams<{ id: string }>()
  const router = useRouter()
  const { colors } = useTheme()
  const { user, profile } = useAuth()
  const insets = useSafeAreaInsets()

  const [messages, setMessages] = useState<Message[]>([])
  const [otherUser, setOtherUser] = useState<OtherUser | null>(null)
  const [loading, setLoading] = useState(true)
  const [draft, setDraft] = useState('')
  const [sending, setSending] = useState(false)
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null)
  const [emojiPickerOpen, setEmojiPickerOpen] = useState(false)
  const [otherReadAt, setOtherReadAt] = useState<string | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const flatListRef = useRef<FlatList>(null)
  const swipeableRefs = useRef<Map<string, Swipeable>>(new Map())
  const lastMessageCountRef = useRef(0)

  // ─── Load thread ───────────────────────────────────────────────────────────

  const loadThread = useCallback(async () => {
    if (!user || !threadId) return

    // Get other user
    const { data: thread } = await supabase
      .from('dm_threads')
      .select('id, user_a, user_b')
      .eq('id', threadId)
      .single()

    if (thread) {
      const otherId = thread.user_a === user.id ? thread.user_b : thread.user_a
      if (otherId) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('id, full_name, username, avatar_url')
          .eq('id', otherId)
          .single()
        if (profile) setOtherUser(profile)
      }
    }

    // Get messages (oldest first for display, FlatList is inverted)
    const { data: msgs } = await supabase
      .from('dm_messages')
      .select('id, body, sender_id, created_at, deleted_at')
      .eq('thread_id', threadId)
      .order('created_at', { ascending: false })
      .limit(100)

    if (msgs) setMessages(msgs)
    setLoading(false)

    // Mark thread as read
    await supabase
      .from('dm_participants')
      .update({ last_read_at: new Date().toISOString() })
      .match({ thread_id: threadId, user_id: user.id })

    // Fetch other user's last_read_at for read receipts
    const { data: otherParticipant } = await supabase
      .from('dm_participants')
      .select('last_read_at')
      .match({ thread_id: threadId })
      .neq('user_id', user.id)
      .single()
    if (otherParticipant) setOtherReadAt(otherParticipant.last_read_at)
  }, [user, threadId])

  useEffect(() => { loadThread() }, [loadThread])

  // ─── Auto-scroll to bottom on new messages ─────────────────────────────────

  useEffect(() => {
    // Auto-scroll when new messages arrive (but not on initial load)
    if (messages.length > 0 && lastMessageCountRef.current > 0 && messages.length > lastMessageCountRef.current) {
      // Small delay to ensure FlatList has rendered
      setTimeout(() => {
        flatListRef.current?.scrollToOffset({ offset: 0, animated: true })
      }, 100)
    }
    lastMessageCountRef.current = messages.length
  }, [messages.length])

  // ─── Can unsend check ──────────────────────────────────────────────────────

  const canUnsendMessage = useCallback((message: Message) => {
    if (!user || message.sender_id !== user.id || message.deleted_at) return false
    const createdAtMs = new Date(message.created_at).getTime()
    if (Number.isNaN(createdAtMs)) return false
    return Date.now() - createdAtMs <= UNSEND_WINDOW_MS
  }, [user])

  // ─── Unsend message ────────────────────────────────────────────────────────

  const unsendMessage = useCallback(async (messageId: string) => {
    if (!threadId || sending) return
    setSending(true)
    HapticFeedback.warning()
    setActiveMenuId(null)

    // Close any open swipeables
    swipeableRefs.current.get(messageId)?.close()

    try {
      // Use supabase directly to update message
      const { data, error } = await supabase
        .from('dm_messages')
        .update({ deleted_at: new Date().toISOString() })
        .eq('id', messageId)
        .eq('sender_id', user?.id) // Security: only allow sender to unsend
        .select('id, body, sender_id, created_at, deleted_at')
        .single()

      if (error || !data) {
        throw new Error('Unable to unsend message')
      }

      // Update message with deleted_at
      setMessages(prev => prev.map(m => m.id === messageId ? data : m))
      HapticFeedback.success()
    } catch (err) {
      HapticFeedback.error()
      Alert.alert('Error', err instanceof Error ? err.message : 'Unable to unsend message')
    } finally {
      setSending(false)
    }
  }, [threadId, sending, user?.id])

  const confirmUnsend = useCallback((message: Message) => {
    Alert.alert(
      'Unsend Message',
      'This message will be removed for everyone. This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel', onPress: () => swipeableRefs.current.get(message.id)?.close() },
        { text: 'Unsend', style: 'destructive', onPress: () => unsendMessage(message.id) },
      ]
    )
  }, [unsendMessage])

  // ─── Realtime subscription ─────────────────────────────────────────────────

  useEffect(() => {
    if (!threadId) return

    const channel = supabase
      .channel(`thread:${threadId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'dm_messages',
          filter: `thread_id=eq.${threadId}`,
        },
        (payload) => {
          const newMsg = payload.new as Message
          setMessages(prev => {
            // Avoid duplicates (we optimistically insert before the event arrives)
            if (prev.some(m => m.id === newMsg.id)) return prev
            return [newMsg, ...prev]
          })
          // Mark as read if message is from the other user
          if (newMsg.sender_id !== user?.id) {
            supabase
              .from('dm_participants')
              .update({ last_read_at: new Date().toISOString() })
              .match({ thread_id: threadId, user_id: user?.id })
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'dm_messages',
          filter: `thread_id=eq.${threadId}`,
        },
        (payload) => {
          const updatedMsg = payload.new as Message
          setMessages(prev => prev.map(m => m.id === updatedMsg.id ? updatedMsg : m))
        }
      )
      .subscribe()

    return () => { supabase.removeChannel(channel) }
  }, [threadId, user?.id])

  // ─── Image & Emoji Handlers ───────────────────────────────────────────────

  const handleEmojiSelect = useCallback((emoji: string) => {
    setDraft(prev => prev + emoji)
    setEmojiPickerOpen(false)
    HapticFeedback.selection()
  }, [])

  const handleImagePick = useCallback(async () => {
    HapticFeedback.light()
    
    // Request permissions
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync()
    if (status !== 'granted') {
      Alert.alert('Permission Required', 'Please grant photo library access to send images.')
      return
    }

    // Pick image
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 0.8,
      base64: true,
    })

    if (result.canceled || !result.assets[0]) return

    const asset = result.assets[0]
    
    // Check size (estimate from base64)
    const base64Length = asset.base64?.length || 0
    const sizeBytes = (base64Length * 3) / 4
    
    if (sizeBytes > MAX_IMAGE_SIZE) {
      Alert.alert('Image Too Large', 'Please select an image under 900KB.')
      return
    }

    // Send as base64 data URI
    const dataUri = `data:${asset.mimeType || 'image/jpeg'};base64,${asset.base64}`
    await handleSendMessage(dataUri)
  }, [threadId, user, sending])

  const handleSendMessage = useCallback(async (body: string) => {
    if (!body || !user || !threadId || sending) return

    setSending(true)
    HapticFeedback.light()

    // Optimistic insert
    const optimisticId = `optimistic-${Date.now()}`
    const optimistic: Message = {
      id: optimisticId,
      body,
      sender_id: user.id,
      created_at: new Date().toISOString(),
      deleted_at: null,
    }
    setMessages(prev => [optimistic, ...prev])

    const { data, error } = await supabase
      .from('dm_messages')
      .insert({ thread_id: threadId, sender_id: user.id, body })
      .select('id, body, sender_id, created_at, deleted_at')
      .single()

    setSending(false)

    if (error) {
      HapticFeedback.error()
      setMessages(prev => prev.filter(m => m.id !== optimisticId))
      Alert.alert('Error', 'Failed to send message')
    } else if (data) {
      setMessages(prev => prev.map(m => m.id === optimisticId ? data : m))

      // Send push notification to recipient (fire-and-forget)
      if (otherUser?.id) {
        const senderName = profile?.full_name || profile?.username || 'Someone'
        sendDMNotification(otherUser.id, senderName, body, threadId, user.id)
      }
    }
  }, [user, threadId, sending, otherUser?.id, profile])

  // ─── Send ──────────────────────────────────────────────────────────────────

  const handleSend = async () => {
    const body = draft.trim()
    if (!body) return
    setDraft('')
    setEmojiPickerOpen(false)
    await handleSendMessage(body)
  }

  // ─── Image Preview ─────────────────────────────────────────────────────────

  const handleImagePress = useCallback((imageUri: string) => {
    HapticFeedback.light()
    setImagePreview(imageUri)
  }, [])

  // ─── Render ────────────────────────────────────────────────────────────────

  const renderRightActions = (message: Message) => {
    return (
      <Pressable
        style={[styles.deleteAction, { backgroundColor: '#FF3B30' }]}
        onPress={() => confirmUnsend(message)}
      >
        <Ionicons name="trash-outline" size={20} color="#FFFFFF" />
        <Text style={styles.deleteActionText}>Unsend</Text>
      </Pressable>
    )
  }

  const renderMessage = ({ item, index }: { item: Message; index: number }) => {
    const isMine = item.sender_id === user?.id
    const isDeleted = Boolean(item.deleted_at)
    const isImage = !isDeleted && item.body?.startsWith('data:image/')
    const canUnsend = canUnsendMessage(item)
    const prevItem = messages[index + 1] // older (list is inverted)
    const showTime = !prevItem ||
      new Date(prevItem.created_at).getTime() < new Date(item.created_at).getTime() - 5 * 60_000

    const bubbleContent = (
      <View style={[styles.msgOuter, isMine ? styles.msgOuterMine : styles.msgOuterTheirs]}>
        {showTime && (
          <Text style={[styles.msgTime, { color: colors.contentTertiary }]}>
            {formatMessageTime(item.created_at)}
          </Text>
        )}
        <View
          style={[
            styles.bubble,
            isDeleted
              ? [styles.bubbleDeleted, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]
              : isImage
                ? [styles.bubbleImage, { backgroundColor: colors.surfaceSecondary }]
                : isMine
                  ? [styles.bubbleMine, { backgroundColor: colors.contentPrimary }]
                  : [styles.bubbleTheirs, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }],
          ]}
        >
          {isDeleted ? (
            <Text style={[styles.bubbleText, { color: colors.contentTertiary, fontStyle: 'italic' }]}>
              Message unsent
            </Text>
          ) : isImage ? (
            <Pressable onPress={() => handleImagePress(item.body)}>
              <View style={styles.imageContainer}>
                <Image
                  source={{ uri: item.body }}
                  style={styles.messageImage}
                  resizeMode="cover"
                />
                <View style={styles.imageLabel}>
                  <Text style={styles.imageLabelText}>SHARED PHOTO</Text>
                </View>
              </View>
            </Pressable>
          ) : (
            <Text style={[styles.bubbleText, { color: isMine ? colors.contentInverse : colors.contentPrimary }]}>
              {item.body}
            </Text>
          )}
        </View>
        {canUnsend && !isDeleted && (
          <Pressable
            style={styles.moreButton}
            onPress={() => setActiveMenuId(activeMenuId === item.id ? null : item.id)}
          >
            <Ionicons name="ellipsis-horizontal" size={14} color={colors.contentTertiary} />
          </Pressable>
        )}
        {activeMenuId === item.id && (
          <View style={[styles.actionMenu, { backgroundColor: colors.surfacePrimary, borderColor: colors.borderSecondary }]}>
            <Pressable
              style={styles.actionMenuItem}
              onPress={() => confirmUnsend(item)}
            >
              <Ionicons name="trash-outline" size={16} color="#FF3B30" />
              <Text style={[styles.actionMenuText, { color: '#FF3B30' }]}>Unsend</Text>
            </Pressable>
          </View>
        )}
      </View>
    )

    // Read receipt: show on the latest message from current user that has been read
    const isLatestMine = isMine && !isDeleted && index === 0 || (
      isMine && !isDeleted && messages.slice(0, index).every(m => m.sender_id !== user?.id || m.deleted_at)
    )
    const isRead = isLatestMine && otherReadAt && new Date(otherReadAt) >= new Date(item.created_at)

    const bubbleWithReceipt = (
      <View>
        {bubbleContent}
        {isRead && (
          <Text style={[styles.readReceipt, { color: colors.contentTertiary }]}>Read</Text>
        )}
      </View>
    )

    // Only allow swipe-to-delete on own messages within unsend window
    if (isMine && canUnsend && !isDeleted) {
      return (
        <Swipeable
          ref={(ref) => {
            if (ref) swipeableRefs.current.set(item.id, ref)
            else swipeableRefs.current.delete(item.id)
          }}
          renderRightActions={() => renderRightActions(item)}
          overshootRight={false}
          friction={2}
          rightThreshold={40}
        >
          {bubbleWithReceipt}
        </Swipeable>
      )
    }

    return bubbleWithReceipt
  }

  const initials = getInitials(otherUser?.full_name ?? null, otherUser?.username ?? null)

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      {/* Header */}
      <AnimatedEnter delay={0}>
        <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
          <Pressable onPress={() => router.back()} style={styles.backButton}>
            <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
          </Pressable>

          <View style={styles.headerUser}>
            {otherUser?.avatar_url ? (
              <Image source={{ uri: otherUser.avatar_url }} style={styles.headerAvatar} />
            ) : (
              <View style={[styles.headerAvatar, styles.headerAvatarFallback, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
                <Text style={[styles.headerAvatarText, { color: colors.contentPrimary }]}>{initials}</Text>
              </View>
            )}
            <View>
              <Text style={[styles.headerName, { color: colors.contentPrimary }]} numberOfLines={1}>
                {otherUser?.full_name || otherUser?.username || '…'}
              </Text>
              {otherUser?.username && (
                <Text style={[styles.headerUsername, { color: colors.contentSecondary }]}>
                  @{otherUser.username}
                </Text>
              )}
            </View>
          </View>
        </View>
      </AnimatedEnter>

      {/* Messages */}
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={0}
      >
        {loading ? (
          <View style={styles.centered}>
            <ActivityIndicator color={colors.contentTertiary} />
          </View>
        ) : (
          <FlatList
            ref={flatListRef}
            data={messages}
            keyExtractor={item => item.id}
            renderItem={renderMessage}
            inverted
            contentContainerStyle={styles.listContent}
            showsVerticalScrollIndicator={false}
            keyboardDismissMode="on-drag"
            keyboardShouldPersistTaps="handled"
            ListEmptyComponent={
              <View style={styles.emptyCentered}>
                <Text style={[styles.emptyText, { color: colors.contentTertiary }]}>
                  Start the conversation
                </Text>
              </View>
            }
          />
        )}

        {/* Input bar */}
        <View style={{ backgroundColor: colors.surfacePrimary, paddingBottom: insets.bottom }}>
          {/* Emoji Picker */}
          {emojiPickerOpen && (
            <View style={[styles.emojiPicker, { backgroundColor: colors.surfaceSecondary, borderTopColor: colors.borderSecondary }]}>
              <ScrollView 
                horizontal 
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.emojiPickerContent}
              >
                {EMOJIS.map((emoji) => (
                  <Pressable
                    key={emoji}
                    onPress={() => handleEmojiSelect(emoji)}
                    style={[styles.emojiButton, { backgroundColor: colors.surfacePrimary }]}
                  >
                    <Text style={styles.emojiText}>{emoji}</Text>
                  </Pressable>
                ))}
              </ScrollView>
            </View>
          )}

          <View style={[styles.inputBar, { borderTopColor: colors.borderSecondary }]}>
            {/* Emoji button */}
            <Pressable
              onPress={() => {
                setEmojiPickerOpen(!emojiPickerOpen)
                HapticFeedback.light()
              }}
              style={styles.iconButton}
            >
              <Ionicons
                name={emojiPickerOpen ? "happy" : "happy-outline"}
                size={22}
                color={colors.contentTertiary}
              />
            </Pressable>

            {/* Image button */}
            <Pressable
              onPress={handleImagePick}
              style={styles.iconButton}
              disabled={sending}
            >
              <Ionicons
                name="image-outline"
                size={22}
                color={colors.contentTertiary}
              />
            </Pressable>

            {/* Text input */}
            <TextInput
              value={draft}
              onChangeText={setDraft}
              placeholder="Message…"
              placeholderTextColor={colors.contentTertiary}
              style={[
                styles.inputField,
                {
                  color: colors.contentPrimary,
                  backgroundColor: colors.surfaceSecondary,
                  borderColor: colors.borderSecondary,
                },
              ]}
              multiline
              maxLength={2000}
              onSubmitEditing={handleSend}
              blurOnSubmit={false}
            />

            {/* Send button */}
            <Pressable
              onPress={handleSend}
              disabled={!draft.trim() || sending}
              style={[
                styles.sendButton,
                {
                  backgroundColor: draft.trim() ? colors.contentPrimary : colors.surfaceElevated,
                },
              ]}
            >
              {sending ? (
                <ActivityIndicator size="small" color={colors.contentInverse} />
              ) : (
                <Ionicons
                  name="arrow-up"
                  size={18}
                  color={draft.trim() ? colors.contentInverse : colors.contentTertiary}
                />
              )}
            </Pressable>
          </View>
        </View>
      </KeyboardAvoidingView>

      {/* Image Preview Modal */}
      <Modal
        visible={!!imagePreview}
        transparent
        animationType="fade"
        onRequestClose={() => setImagePreview(null)}
      >
        <Pressable
          style={styles.imagePreviewModal}
          onPress={() => {
            HapticFeedback.light()
            setImagePreview(null)
          }}
        >
          <View style={[styles.imagePreviewHeader, { backgroundColor: 'rgba(0,0,0,0.9)' }]}>
            <Pressable
              onPress={() => setImagePreview(null)}
              style={styles.imagePreviewClose}
            >
              <Ionicons name="close" size={28} color="#FFFFFF" />
            </Pressable>
          </View>
          {imagePreview && (
            <Image
              source={{ uri: imagePreview }}
              style={styles.imagePreviewFull}
              resizeMode="contain"
            />
          )}
        </Pressable>
      </Modal>
    </SafeAreaView>
  )
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1 },
  flex: { flex: 1 },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.sm,
    borderBottomWidth: 1,
    gap: Spacing.sm,
  },
  backButton: { width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },
  headerUser: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, flex: 1 },
  headerAvatar: { width: 36, height: 36, borderRadius: 18 },
  headerAvatarFallback: { borderWidth: 1, justifyContent: 'center', alignItems: 'center' },
  headerAvatarText: { fontSize: 13, fontWeight: '600' },
  headerName: { fontSize: Typography.callout, fontWeight: '600', maxWidth: 200 },
  headerUsername: { fontSize: Typography.caption },

  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  listContent: { paddingHorizontal: Spacing.base, paddingVertical: Spacing.md, gap: 2 },

  emptyCentered: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: Spacing.xl },
  emptyText: { fontSize: Typography.callout },

  msgOuter: { marginVertical: 2 },
  msgOuterMine: { alignItems: 'flex-end' },
  msgOuterTheirs: { alignItems: 'flex-start' },
  msgTime: { fontSize: 11, textAlign: 'center', marginVertical: Spacing.sm, width: '100%' },

  bubble: { maxWidth: '78%', paddingHorizontal: 14, paddingVertical: 10, borderRadius: 18 },
  bubbleMine: { borderBottomRightRadius: 4 },
  bubbleTheirs: { borderWidth: 1, borderBottomLeftRadius: 4 },
  bubbleDeleted: { borderWidth: 1, borderBottomLeftRadius: 4, opacity: 0.6 },
  bubbleImage: { padding: 4, maxWidth: '85%', borderRadius: 18 },
  bubbleText: { fontSize: Typography.callout, lineHeight: Typography.callout * 1.45 },
  readReceipt: {
    fontSize: 11,
    textAlign: 'right',
    paddingRight: Spacing.base,
    paddingTop: 2,
    paddingBottom: 4,
  },

  imageContainer: {
    borderRadius: 14,
    overflow: 'hidden',
    position: 'relative',
  },
  messageImage: {
    width: 240,
    height: 240,
    borderRadius: 14,
  },
  imageLabel: {
    position: 'absolute',
    bottom: 8,
    left: 8,
    backgroundColor: 'rgba(0,0,0,0.6)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  imageLabelText: {
    color: '#FFFFFF',
    fontSize: 9,
    fontWeight: '700',
    letterSpacing: 1.2,
  },

  moreButton: {
    marginTop: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },

  actionMenu: {
    position: 'absolute',
    top: '100%',
    right: 0,
    marginTop: 4,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    zIndex: 10,
  },
  actionMenuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    minWidth: 120,
  },
  actionMenuText: {
    fontSize: Typography.callout,
    fontWeight: '500',
  },

  deleteAction: {
    justifyContent: 'center',
    alignItems: 'center',
    width: 80,
    marginLeft: Spacing.sm,
    borderRadius: 18,
    paddingHorizontal: Spacing.md,
  },
  deleteActionText: {
    color: '#FFFFFF',
    fontSize: Typography.caption,
    fontWeight: '600',
    marginTop: 2,
  },

  emojiPicker: {
    paddingVertical: Spacing.sm,
    borderTopWidth: 1,
  },
  emojiPickerContent: {
    paddingHorizontal: Spacing.base,
    gap: Spacing.sm,
  },
  emojiButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emojiText: {
    fontSize: 24,
  },

  inputBar: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: Spacing.xs,
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.sm,
    borderTopWidth: 1,
  },
  iconButton: {
    width: 36,
    height: 36,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 2,
  },
  inputField: {
    flex: 1,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    paddingHorizontal: Spacing.md,
    paddingVertical: 10,
    fontSize: Typography.callout,
    maxHeight: 120,
  },
  sendButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 2,
  },

  imagePreviewModal: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.95)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  imagePreviewHeader: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 100,
    paddingTop: 50,
    paddingHorizontal: Spacing.base,
    zIndex: 10,
  },
  imagePreviewClose: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  imagePreviewFull: {
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height,
  },
})
