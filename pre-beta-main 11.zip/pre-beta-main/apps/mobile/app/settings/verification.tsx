import { View, Text, StyleSheet, ScrollView, Pressable, Alert, KeyboardAvoidingView, Platform, TextInput, ActivityIndicator, Image, Linking } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import * as Location from 'expo-location'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { Button } from '@/components/ui/Button'
import { Spacing, Typography, BorderRadius } from '@/constants/theme'
import { useState, useEffect, useRef, useCallback } from 'react'
import { validateEmail, normalizePhoneNumber } from '@/utils/validation'
import { apiRequest } from '@/lib/api'

// ─── Types ───────────────────────────────────────────────────────────────────

type ContactProfile = {
  id: string
  username: string | null
  full_name: string | null
  avatar_url: string | null
}

type EmergencyContact = {
  id: string
  type: 'user' | 'phone'
  contact_user_id: string | null
  external_name: string | null
  external_phone: string | null
  username: string | null
  full_name: string | null
  avatar_url: string | null
}

type PanicAlert = {
  id: string
  owner_id: string
  lat: number | null
  lng: number | null
  created_at: string
}

type CollegeState = {
  college_name: string | null
  college_self_reported: boolean
  college_updated_at: string | null
  college_change_count: number
}

// ─── Constants ───────────────────────────────────────────────────────────────

const CONSUMER_DOMAINS = new Set([
  'gmail.com', 'googlemail.com', 'yahoo.com', 'yahoo.co.uk',
  'outlook.com', 'hotmail.com', 'live.com', 'msn.com',
  'icloud.com', 'me.com', 'mac.com', 'aol.com',
  'proton.me', 'protonmail.com', 'pm.me',
])

const YEAR_MS = 365 * 24 * 60 * 60 * 1000
const MIN_GRAD_YEAR = 1900
const MAX_GRAD_YEAR = 2300
const COLLEGE_MAX_SAVES = 2
const SUPPORT_EMAIL = 'support@presocial.app'

const defaultCollegeState: CollegeState = {
  college_name: null,
  college_self_reported: false,
  college_updated_at: null,
  college_change_count: 0,
}

function normalizeCollegeState(value: unknown): CollegeState {
  if (!value || typeof value !== 'object') return defaultCollegeState
  const row = value as Partial<CollegeState>
  return {
    college_name: typeof row.college_name === 'string' && row.college_name.trim() ? row.college_name : null,
    college_self_reported: row.college_self_reported === true,
    college_updated_at: typeof row.college_updated_at === 'string' ? row.college_updated_at : null,
    college_change_count:
      typeof row.college_change_count === 'number' && Number.isFinite(row.college_change_count)
        ? Math.max(0, row.college_change_count)
        : 0,
  }
}

function isConsumerEmail(email: string): boolean {
  const domain = email.split('@')[1]?.toLowerCase()
  return domain ? CONSUMER_DOMAINS.has(domain) : false
}

function getInitials(name: string | null): string {
  if (!name) return '?'
  return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
}

// ─── Main Component ──────────────────────────────────────────────────────────

export default function VerificationSettings() {
  const { colors } = useTheme()
  const { profile, user, refreshProfile } = useAuth()
  const router = useRouter()

  // University verification state
  const [email, setEmail] = useState('')
  const [emailTouched, setEmailTouched] = useState(false)
  const [emailUnlocked, setEmailUnlocked] = useState(false)
  const [verificationStatus, setVerificationStatus] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle')
  const [verificationMessage, setVerificationMessage] = useState<string | null>(null)
  const [unlockLoading, setUnlockLoading] = useState<'change_email' | 'graduated' | null>(null)

  // Graduation year state
  const [graduationYear, setGraduationYear] = useState('')
  const [gradYearLoading, setGradYearLoading] = useState(false)
  const [gradYearMessage, setGradYearMessage] = useState<string | null>(null)
  const [gradYearConfirmed, setGradYearConfirmed] = useState(false)

  // College state
  const [collegeDraft, setCollegeDraft] = useState('')
  const [collegeSaving, setCollegeSaving] = useState(false)
  const [collegeLoading, setCollegeLoading] = useState(false)
  const [collegeMessage, setCollegeMessage] = useState<string | null>(null)
  const [collegeError, setCollegeError] = useState<string | null>(null)
  const [collegeState, setCollegeState] = useState<CollegeState>(defaultCollegeState)
  const [collegeOptions, setCollegeOptions] = useState<string[]>([])
  const [collegeEditing, setCollegeEditing] = useState(false)

  // Emergency contacts state
  const [contacts, setContacts] = useState<EmergencyContact[]>([])
  const [contactsLoading, setContactsLoading] = useState(true)
  const [contactQuery, setContactQuery] = useState('')
  const [contactResults, setContactResults] = useState<ContactProfile[]>([])
  const [contactSearching, setContactSearching] = useState(false)
  const [externalName, setExternalName] = useState('')
  const [externalPhone, setExternalPhone] = useState('')
  const [externalSaving, setExternalSaving] = useState(false)
  const [contactError, setContactError] = useState<string | null>(null)
  const [showAddContact, setShowAddContact] = useState(false)

  // Panic state
  const [panicLoading, setPanicLoading] = useState(false)
  const [panicMessage, setPanicMessage] = useState<string | null>(null)
  const [panicError, setPanicError] = useState<string | null>(null)
  const [alerts, setAlerts] = useState<PanicAlert[]>([])
  const [alertsLoading, setAlertsLoading] = useState(true)

  const searchTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  // Derived state
  const isUniversityVerified = profile?.university_verified === true
  const profileEmail = profile?.university_email ?? ''
  const profileName = profile?.university_name ?? null
  const profileGraduationYear = profile?.university_graduation_year ?? null
  const gradConfirmedAt = profile?.university_grad_year_confirmed_at ?? null
  const gradYearLockUntil = gradConfirmedAt
    ? new Date(new Date(gradConfirmedAt).getTime() + YEAR_MS)
    : null
  const gradYearChangeLocked =
    profileGraduationYear !== null &&
    gradYearLockUntil !== null &&
    gradYearLockUntil.getTime() > Date.now()
  const emailLocked = isUniversityVerified && !emailUnlocked
  const profileCollege = collegeState.college_name
  const collegeChangeCount = collegeState.college_change_count
  const hasSavedCollege = !!profileCollege
  const collegeLocked = hasSavedCollege && collegeChangeCount >= COLLEGE_MAX_SAVES
  const collegeChangesRemaining = Math.max(0, COLLEGE_MAX_SAVES - collegeChangeCount)

  // ─── Effects ─────────────────────────────────────────────────────────────

  useEffect(() => {
    if (!emailTouched) setEmail(profileEmail)
  }, [profileEmail, emailTouched])

  useEffect(() => {
    if (isUniversityVerified) {
      setVerificationStatus('idle')
      setVerificationMessage(null)
      setEmailUnlocked(false)
    }
  }, [isUniversityVerified])

  useEffect(() => {
    setGraduationYear(profileGraduationYear ? String(profileGraduationYear) : '')
    setGradYearConfirmed(false)
  }, [profileGraduationYear])

  useEffect(() => {
    setCollegeDraft(collegeState.college_name ?? '')
    setCollegeEditing(!(collegeState.college_name && collegeState.college_name.trim()))
  }, [collegeState.college_name])

  // Load college state
  useEffect(() => {
    if (!user) return
    let active = true
    setCollegeLoading(true)

    apiRequest<{ ok?: boolean; profile?: any; collegeOptions?: string[] }>('/api/verification/college')
      .then((result) => {
        if (!active || result.error) return
        const data = result.data
        if (data?.ok) {
          setCollegeState(normalizeCollegeState(data.profile))
          setCollegeOptions(
            Array.isArray(data.collegeOptions)
              ? data.collegeOptions.filter((item: unknown): item is string => typeof item === 'string' && (item as string).trim().length > 0)
              : []
          )
        }
      })
      .finally(() => { if (active) setCollegeLoading(false) })

    return () => { active = false }
  }, [user?.id])

  // Load contacts and alerts
  useEffect(() => {
    if (!user) return

    setContactsLoading(true)
    apiRequest<{ contacts?: EmergencyContact[] }>('/api/emergency-contacts')
      .then((result) => {
        if (!result.error) setContacts(result.data?.contacts ?? [])
      })
      .finally(() => setContactsLoading(false))

    setAlertsLoading(true)
    apiRequest<{ alerts?: PanicAlert[] }>('/api/panic/alerts')
      .then((result) => {
        if (!result.error) setAlerts(result.data?.alerts ?? [])
      })
      .finally(() => setAlertsLoading(false))
  }, [user?.id])

  // Contact search
  useEffect(() => {
    if (!contactQuery.trim()) {
      setContactResults([])
      setContactSearching(false)
      return
    }

    if (searchTimerRef.current) clearTimeout(searchTimerRef.current)
    setContactSearching(true)

    searchTimerRef.current = setTimeout(async () => {
      const result = await apiRequest<{ results?: ContactProfile[] }>(
        `/api/users/search?q=${encodeURIComponent(contactQuery.trim())}`
      )
      const exclude = new Set<string>([
        user?.id ?? '',
        ...contacts.map(c => c.contact_user_id).filter((id): id is string => !!id),
      ])
      const filtered = (result.data?.results ?? []).filter(p => !exclude.has(p.id))
      setContactResults(filtered)
      setContactSearching(false)
    }, 300)

    return () => {
      if (searchTimerRef.current) clearTimeout(searchTimerRef.current)
    }
  }, [contactQuery, contacts, user?.id])

  // ─── Handlers ────────────────────────────────────────────────────────────

  const handleVerify = async () => {
    if (verificationStatus === 'sending') return
    if (emailLocked) {
      setVerificationStatus('error')
      setVerificationMessage('Your verified university email is locked. Request an email change first.')
      return
    }

    const trimmed = email.trim().toLowerCase()
    if (!trimmed) {
      setVerificationStatus('error')
      setVerificationMessage('Enter your university email to continue.')
      return
    }
    if (!validateEmail(trimmed)) {
      setVerificationStatus('error')
      setVerificationMessage('Enter a valid university email.')
      return
    }
    if (isConsumerEmail(trimmed)) {
      setVerificationStatus('error')
      setVerificationMessage('Personal email providers are not eligible. Use your university email.')
      return
    }

    setVerificationStatus('sending')
    setVerificationMessage(null)
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)

    const result = await apiRequest('/api/verification/university/request', {
      method: 'POST',
      body: { email: trimmed, allowEmailChange: emailUnlocked },
    })

    if (result.error) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error)
      setVerificationStatus('error')
      setVerificationMessage(result.error)
    } else {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success)
      setVerificationStatus('sent')
      setVerificationMessage(`Verification email sent to ${trimmed}. Check your inbox (expires in 15 min).`)
      setEmailTouched(false)
      await refreshProfile()
    }
  }

  const handleUnlockEmail = async (reason: 'change_email' | 'graduated') => {
    if (unlockLoading) return
    setVerificationMessage(null)
    setUnlockLoading(reason)

    const result = await apiRequest('/api/verification/university/unlock', {
      method: 'POST',
      body: { reason },
    })

    if (result.error) {
      setVerificationStatus('error')
      setVerificationMessage(result.error)
    } else if (reason === 'change_email') {
      setEmail('')
      setEmailTouched(true)
      setEmailUnlocked(true)
      setVerificationStatus('idle')
      setVerificationMessage('Email unlocked. Enter your new university email.')
    } else {
      setEmailUnlocked(false)
      setVerificationStatus('idle')
      setVerificationMessage('Marked as graduated. Campus-only verification removed.')
    }
    setUnlockLoading(null)
    await refreshProfile()
  }

  const handleSaveGradYear = async () => {
    if (gradYearLoading) return
    if (gradYearChangeLocked) {
      setGradYearMessage(`Locked until ${gradYearLockUntil?.toLocaleDateString() ?? 'next year'}. Contact ${SUPPORT_EMAIL}.`)
      return
    }
    if (!gradYearConfirmed) {
      setGradYearMessage('Please confirm your graduation year before saving.')
      return
    }
    const parsed = Number(graduationYear)
    if (!Number.isInteger(parsed) || parsed < MIN_GRAD_YEAR || parsed > MAX_GRAD_YEAR) {
      setGradYearMessage('Enter a valid graduation year.')
      return
    }

    setGradYearLoading(true)
    setGradYearMessage(null)

    const result = await apiRequest<{ graduated?: boolean }>('/api/verification/university/graduation-year', {
      method: 'POST',
      body: { graduationYear: parsed },
    })

    if (result.error) {
      setGradYearMessage(result.error)
    } else if (result.data?.graduated) {
      setVerificationStatus('idle')
      setVerificationMessage('Graduation year saved. Campus-only verification removed.')
    } else {
      setGradYearMessage('Graduation year saved. You can change it again in one year.')
    }
    setGradYearConfirmed(false)
    setGradYearLoading(false)
    await refreshProfile()
  }

  const handleSaveCollege = async () => {
    if (collegeSaving) return
    if (!isUniversityVerified) {
      setCollegeError('Verify your university email first.')
      return
    }
    if (collegeLocked) {
      setCollegeError(`College is locked. Contact ${SUPPORT_EMAIL}.`)
      return
    }
    if (collegeOptions.length === 0) {
      setCollegeError('College self-report unavailable for your domain.')
      return
    }

    const normalizedCollege = collegeDraft.trim()
    if (!normalizedCollege) {
      setCollegeError('Select your college from the listed options.')
      return
    }
    const isAllowed = collegeOptions.some(
      opt => opt.trim().toLowerCase() === normalizedCollege.toLowerCase()
    )
    if (!isAllowed) {
      setCollegeError('Select your college from the listed options.')
      return
    }

    setCollegeSaving(true)
    setCollegeMessage(null)
    setCollegeError(null)

    const result = await apiRequest<{ profile?: any; noChange?: boolean }>('/api/verification/college', {
      method: 'POST',
      body: { collegeName: normalizedCollege },
    })

    if (result.error) {
      setCollegeError(result.error)
    } else {
      const nextState = normalizeCollegeState(result.data?.profile)
      setCollegeState(nextState)
      setCollegeDraft(nextState.college_name ?? normalizedCollege)
      setCollegeEditing(false)
      if (result.data?.noChange) {
        setCollegeMessage('College is already up to date.')
      } else if ((nextState.college_change_count ?? 0) >= COLLEGE_MAX_SAVES) {
        setCollegeMessage(`College saved. Further changes require ${SUPPORT_EMAIL}.`)
      } else {
        setCollegeMessage('College saved. You have one final edit remaining.')
      }
    }
    setCollegeSaving(false)
  }

  const handleAddPreContact = async (person: ContactProfile) => {
    setContactError(null)
    const result = await apiRequest<{ contact?: EmergencyContact }>('/api/emergency-contacts', {
      method: 'POST',
      body: { contact_user_id: person.id },
    })
    if (result.error) {
      setContactError(result.error)
      return
    }
    const next = result.data?.contact
    if (next) {
      setContacts(prev => prev.some(c => c.id === next.id) ? prev : [...prev, next])
    }
    setContactQuery('')
    setContactResults([])
  }

  const handleAddExternalContact = async () => {
    if (externalSaving) return
    const phone = externalPhone.trim()
    if (!phone) {
      setContactError('Enter a phone number.')
      return
    }
    const normalizedPhone = normalizePhoneNumber(phone)
    if (!/^\+\d{7,15}$/.test(normalizedPhone)) {
      setContactError('Phone must include 7-15 digits.')
      return
    }

    setContactError(null)
    setExternalSaving(true)

    const result = await apiRequest<{ contact?: EmergencyContact }>('/api/emergency-contacts', {
      method: 'POST',
      body: { external_name: externalName.trim(), external_phone: normalizedPhone },
    })

    if (result.error) {
      setContactError(result.error)
    } else {
      const next = result.data?.contact
      if (next) setContacts(prev => prev.some(c => c.id === next.id) ? prev : [...prev, next])
      setExternalName('')
      setExternalPhone('')
    }
    setExternalSaving(false)
  }

  const handleRemoveContact = (contactId: string) => {
    Alert.alert('Remove Contact', 'Remove this emergency contact?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: async () => {
          setContactError(null)
          const result = await apiRequest('/api/emergency-contacts', {
            method: 'DELETE',
            body: { contact_id: contactId },
          })
          if (result.error) {
            setContactError(result.error)
          } else {
            setContacts(prev => prev.filter(c => c.id !== contactId))
          }
        },
      },
    ])
  }

  const handlePanic = async () => {
    if (panicLoading) return
    setPanicError(null)
    setPanicMessage(null)

    const smsTargets = contacts
      .map(c => c.external_phone)
      .filter((phone): phone is string => !!phone && phone.length > 0)

    if (smsTargets.length === 0) {
      setPanicError('Add at least one external phone contact to send emergency SMS.')
      return
    }

    Alert.alert(
      'Emergency Alert',
      'This will open an SMS draft to your emergency contacts with your current location. Continue?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Continue',
          style: 'destructive',
          onPress: async () => {
            setPanicLoading(true)
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning)

            let lat: number | null = null
            let lng: number | null = null

            try {
              const { status } = await Location.requestForegroundPermissionsAsync()
              if (status === 'granted') {
                const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced })
                lat = loc.coords.latitude
                lng = loc.coords.longitude
              }
            } catch {}

            // Log panic event
            try {
              await apiRequest('/api/panic', { method: 'POST', body: { lat, lng } })
            } catch {}

            // Build SMS
            const senderName = profile?.full_name || profile?.username || 'A pre user'
            const timestamp = new Date().toLocaleString()
            const mapLink = lat !== null && lng !== null
              ? `https://maps.apple.com/?q=${lat},${lng}`
              : null
            const bodyLines = [
              `Emergency alert from ${senderName}.`,
              'I need help right now. Please check in with me immediately.',
              mapLink ? `My current location: ${mapLink}` : 'Location unavailable. Please call me now.',
              `Sent from pre at ${timestamp}.`,
            ]
            const messageBody = bodyLines.join('\n')

            const isIOS = Platform.OS === 'ios'
            const delimiter = isIOS ? ',' : ';'
            const recipients = smsTargets.join(delimiter)
            const queryPrefix = isIOS ? '&' : '?'
            const smsUrl = `sms:${recipients}${queryPrefix}body=${encodeURIComponent(messageBody)}`

            try {
              await Linking.openURL(smsUrl)
              setPanicMessage('Emergency SMS draft opened. Review and tap send.')
            } catch {
              setPanicError('Could not open SMS app.')
            }

            // Refresh alerts
            const alertResult = await apiRequest<{ alerts?: PanicAlert[] }>('/api/panic/alerts')
            if (!alertResult.error) setAlerts(alertResult.data?.alerts ?? [])

            setPanicLoading(false)
          },
        },
      ]
    )
  }

  // ─── Render ──────────────────────────────────────────────────────────────

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      {/* Nav bar */}
      <View style={[styles.navBar, { borderBottomColor: colors.borderSecondary }]}>
        <Pressable onPress={() => router.back()} hitSlop={8} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
          <Text style={[styles.backLabel, { color: colors.contentPrimary }]}>Settings</Text>
        </Pressable>
        <Text style={[styles.navTitle, { color: colors.contentPrimary }]}>Safety & Verification</Text>
        <View style={styles.navSpacer} />
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* ─── SECTION 1: University Verification ─── */}
          <View style={styles.group}>
            <Text style={[styles.groupHeader, { color: colors.contentTertiary }]}>VERIFICATION</Text>

            {/* Status message */}
            {verificationMessage && (
              <View style={[styles.alertCard, {
                backgroundColor: verificationStatus === 'error'
                  ? colors.error + '15'
                  : colors.success + '15',
                borderColor: verificationStatus === 'error'
                  ? colors.error + '40'
                  : colors.success + '40',
              }]}>
                <Ionicons
                  name={verificationStatus === 'error' ? 'alert-circle' : 'checkmark-circle'}
                  size={18}
                  color={verificationStatus === 'error' ? colors.error : colors.success}
                />
                <Text style={[styles.alertText, {
                  color: verificationStatus === 'error' ? colors.error : colors.success,
                }]}>
                  {verificationMessage}
                </Text>
              </View>
            )}

            <View style={[styles.groupCard, { backgroundColor: colors.surfaceSecondary }]}>
              {/* Verification status header */}
              <View style={styles.verificationHeader}>
                <View style={[styles.verifyIcon, {
                  backgroundColor: isUniversityVerified ? colors.contentPrimary : colors.surfaceTertiary,
                }]}>
                  <Ionicons
                    name={isUniversityVerified ? 'checkmark' : 'mail-outline'}
                    size={20}
                    color={isUniversityVerified ? colors.contentInverse : colors.contentTertiary}
                  />
                </View>
                <View style={styles.verifyText}>
                  <Text style={[styles.verifyTitle, { color: colors.contentPrimary }]}>
                    {isUniversityVerified ? 'University verification active' : 'Verify with university email'}
                  </Text>
                  <Text style={[styles.verifyDesc, { color: colors.contentSecondary }]}>
                    {isUniversityVerified
                      ? `Verified at ${profileName || profileEmail}`
                      : 'Use your university email to unlock campus-only events.'}
                  </Text>
                </View>
              </View>

              {/* Email input */}
              <View style={[styles.emailRow, { borderColor: colors.borderSecondary, backgroundColor: colors.surfacePrimary + '90' }]}>
                <Ionicons
                  name={emailLocked ? 'lock-closed' : 'mail-outline'}
                  size={16}
                  color={colors.contentTertiary}
                />
                <TextInput
                  value={email}
                  onChangeText={(t) => {
                    if (emailLocked) return
                    setEmail(t)
                    setEmailTouched(true)
                    setVerificationStatus('idle')
                    setVerificationMessage(null)
                  }}
                  placeholder="name@university.edu"
                  placeholderTextColor={colors.contentTertiary}
                  style={[styles.emailInput, { color: emailLocked ? colors.contentTertiary : colors.contentPrimary }]}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                  editable={!emailLocked}
                />
              </View>

              {/* Action buttons */}
              {emailLocked ? (
                <View style={styles.lockActions}>
                  <Text style={[styles.lockNote, { color: colors.contentTertiary }]}>
                    Verified email is locked. Request a change to edit.
                  </Text>
                  <View style={styles.lockBtnRow}>
                    <Pressable
                      onPress={() => handleUnlockEmail('change_email')}
                      disabled={!!unlockLoading}
                      style={[styles.lockBtn, { borderColor: colors.borderSecondary }]}
                    >
                      {unlockLoading === 'change_email' ? (
                        <ActivityIndicator size="small" color={colors.contentPrimary} />
                      ) : (
                        <>
                          <Ionicons name="lock-open-outline" size={16} color={colors.contentPrimary} />
                          <Text style={[styles.lockBtnText, { color: colors.contentPrimary }]}>Change Email</Text>
                        </>
                      )}
                    </Pressable>
                    <Pressable
                      onPress={() => handleUnlockEmail('graduated')}
                      disabled={!!unlockLoading}
                      style={[styles.lockBtn, { borderColor: colors.borderSecondary }]}
                    >
                      {unlockLoading === 'graduated' ? (
                        <ActivityIndicator size="small" color={colors.contentPrimary} />
                      ) : (
                        <>
                          <Ionicons name="school-outline" size={16} color={colors.contentPrimary} />
                          <Text style={[styles.lockBtnText, { color: colors.contentPrimary }]}>I Graduated</Text>
                        </>
                      )}
                    </Pressable>
                  </View>
                </View>
              ) : (
                <View style={styles.verifyBtnWrap}>
                  <Button
                    onPress={handleVerify}
                    loading={verificationStatus === 'sending'}
                    disabled={verificationStatus === 'sending' || !email.trim()}
                    fullWidth
                    variant="secondary"
                  >
                    {verificationStatus === 'sent' ? 'Resend Verification Email' : 'Send Verification Email'}
                  </Button>
                </View>
              )}

              {/* Graduation Year */}
              <View style={styles.gradSection}>
                <View style={styles.gradRow}>
                  <Ionicons name="calendar-outline" size={16} color={colors.contentTertiary} />
                  <Text style={[styles.gradLabel, { color: colors.contentPrimary }]}>Graduation year</Text>
                </View>
                <Text style={[styles.gradNote, { color: colors.contentTertiary }]}>
                  We ask for this yearly to keep campus access accurate.
                </Text>
                <View style={styles.gradInputRow}>
                  <TextInput
                    value={graduationYear}
                    onChangeText={t => {
                      setGraduationYear(t.replace(/\D/g, '').slice(0, 4))
                      setGradYearConfirmed(false)
                      setGradYearMessage(null)
                    }}
                    placeholder="e.g. 2027"
                    placeholderTextColor={colors.contentTertiary}
                    style={[styles.gradInput, { color: colors.contentPrimary, borderColor: colors.borderSecondary, backgroundColor: colors.surfacePrimary + '90' }]}
                    keyboardType="number-pad"
                    maxLength={4}
                    editable={!gradYearChangeLocked}
                  />
                  {!gradYearChangeLocked && graduationYear.length === 4 && (
                    <Pressable
                      onPress={() => {
                        Haptics.selectionAsync()
                        setGradYearConfirmed(!gradYearConfirmed)
                      }}
                      style={styles.confirmRow}
                    >
                      <Ionicons
                        name={gradYearConfirmed ? 'checkbox' : 'square-outline'}
                        size={20}
                        color={gradYearConfirmed ? colors.contentPrimary : colors.contentTertiary}
                      />
                      <Text style={[styles.confirmText, { color: colors.contentSecondary }]}>
                        This is my expected graduation year
                      </Text>
                    </Pressable>
                  )}
                  {!gradYearChangeLocked && graduationYear.length === 4 && (
                    <Button
                      onPress={handleSaveGradYear}
                      loading={gradYearLoading}
                      disabled={gradYearLoading || !gradYearConfirmed}
                      fullWidth
                      variant="secondary"
                      size="small"
                    >
                      Save Graduation Year
                    </Button>
                  )}
                  {gradYearMessage && (
                    <Text style={[styles.gradMessage, { color: colors.contentSecondary }]}>{gradYearMessage}</Text>
                  )}
                </View>
              </View>
            </View>
          </View>

          {/* ─── SECTION 2: College / Subdivision ─── */}
          {isUniversityVerified && collegeOptions.length > 0 && (
            <View style={styles.group}>
              <Text style={[styles.groupHeader, { color: colors.contentTertiary }]}>COLLEGE / SUBDIVISION</Text>
              <View style={[styles.groupCard, { backgroundColor: colors.surfaceSecondary }]}>
                <View style={styles.collegeHeader}>
                  <Ionicons name="business-outline" size={16} color={colors.contentTertiary} />
                  <Text style={[styles.collegeTitleText, { color: colors.contentPrimary }]}>
                    Select your college
                  </Text>
                </View>

                {!collegeEditing && profileCollege ? (
                  <View style={styles.collegeCurrent}>
                    <View style={[styles.collegeValueCard, { backgroundColor: colors.surfacePrimary + '90', borderColor: colors.borderSecondary }]}>
                      <Text style={[styles.collegeValue, { color: colors.contentPrimary }]}>{profileCollege}</Text>
                      {collegeLocked && (
                        <Ionicons name="lock-closed" size={14} color={colors.contentTertiary} />
                      )}
                    </View>
                    {!collegeLocked && (
                      <Pressable onPress={() => setCollegeEditing(true)}>
                        <Text style={[styles.collegeEditLink, { color: colors.contentPrimary }]}>Edit</Text>
                      </Pressable>
                    )}
                    {collegeLocked && (
                      <Text style={[styles.gradNote, { color: colors.contentTertiary }]}>
                        Contact {SUPPORT_EMAIL} to change.
                      </Text>
                    )}
                  </View>
                ) : (
                  <View style={styles.collegePickerWrap}>
                    {collegeOptions.map((opt) => (
                      <Pressable
                        key={opt}
                        onPress={() => {
                          Haptics.selectionAsync()
                          setCollegeDraft(opt)
                        }}
                        style={[
                          styles.collegeOption,
                          {
                            backgroundColor: collegeDraft.toLowerCase() === opt.toLowerCase()
                              ? colors.contentPrimary
                              : colors.surfacePrimary + '90',
                            borderColor: collegeDraft.toLowerCase() === opt.toLowerCase()
                              ? colors.contentPrimary
                              : colors.borderSecondary,
                          },
                        ]}
                      >
                        <Text style={{
                          fontSize: Typography.callout,
                          color: collegeDraft.toLowerCase() === opt.toLowerCase()
                            ? colors.contentInverse
                            : colors.contentPrimary,
                        }}>
                          {opt}
                        </Text>
                      </Pressable>
                    ))}
                    <Button
                      onPress={handleSaveCollege}
                      loading={collegeSaving}
                      disabled={collegeSaving || !collegeDraft.trim()}
                      fullWidth
                      variant="secondary"
                      size="small"
                    >
                      Save College
                    </Button>
                    {collegeChangesRemaining < COLLEGE_MAX_SAVES && (
                      <Text style={[styles.gradNote, { color: colors.contentTertiary }]}>
                        {collegeChangesRemaining} edit{collegeChangesRemaining !== 1 ? 's' : ''} remaining
                      </Text>
                    )}
                  </View>
                )}

                {collegeMessage && (
                  <Text style={[styles.gradMessage, { color: colors.success }]}>{collegeMessage}</Text>
                )}
                {collegeError && (
                  <Text style={[styles.gradMessage, { color: colors.error }]}>{collegeError}</Text>
                )}
              </View>
            </View>
          )}

          {/* ─── SECTION 3: Emergency Contacts ─── */}
          <View style={styles.group}>
            <Text style={[styles.groupHeader, { color: colors.contentTertiary }]}>EMERGENCY CONTACTS</Text>
            <View style={[styles.groupCard, { backgroundColor: colors.surfaceSecondary }]}>
              <View style={styles.contactsHeader}>
                <Ionicons name="call-outline" size={16} color={colors.contentTertiary} />
                <Text style={[styles.contactsTitle, { color: colors.contentPrimary }]}>
                  Trusted contacts for emergencies
                </Text>
              </View>
              <Text style={[styles.gradNote, { color: colors.contentTertiary }]}>
                Add pre users or external phone numbers to your emergency contact list.
              </Text>

              {/* Contact error */}
              {contactError && (
                <View style={[styles.alertCard, { backgroundColor: colors.error + '15', borderColor: colors.error + '40' }]}>
                  <Ionicons name="alert-circle" size={16} color={colors.error} />
                  <Text style={[styles.alertText, { color: colors.error }]}>{contactError}</Text>
                </View>
              )}

              {/* Existing contacts list */}
              {contactsLoading ? (
                <ActivityIndicator size="small" color={colors.contentTertiary} style={{ padding: Spacing.md }} />
              ) : contacts.length === 0 ? (
                <Text style={[styles.emptyNote, { color: colors.contentTertiary }]}>
                  No emergency contacts yet.
                </Text>
              ) : (
                <View style={styles.contactsList}>
                  {contacts.map((contact) => (
                    <View key={contact.id} style={[styles.contactRow, { borderColor: colors.borderSecondary }]}>
                      <View style={[styles.contactAvatar, { backgroundColor: colors.surfaceTertiary }]}>
                        {contact.avatar_url ? (
                          <Image source={{ uri: contact.avatar_url }} style={styles.contactAvatarImg} />
                        ) : (
                          <Text style={[styles.contactAvatarText, { color: colors.contentPrimary }]}>
                            {getInitials(contact.full_name || contact.external_name)}
                          </Text>
                        )}
                      </View>
                      <View style={styles.contactInfo}>
                        <Text style={[styles.contactName, { color: colors.contentPrimary }]}>
                          {contact.full_name || contact.external_name || 'Unknown'}
                        </Text>
                        <Text style={[styles.contactSub, { color: colors.contentTertiary }]}>
                          {contact.type === 'user'
                            ? `@${contact.username || 'user'}`
                            : contact.external_phone || 'Phone'}
                        </Text>
                      </View>
                      <Pressable onPress={() => handleRemoveContact(contact.id)} hitSlop={8}>
                        <Ionicons name="close-circle" size={22} color={colors.contentTertiary} />
                      </Pressable>
                    </View>
                  ))}
                </View>
              )}

              {/* Add contact toggle */}
              <Pressable
                onPress={() => setShowAddContact(!showAddContact)}
                style={[styles.addContactToggle, { borderColor: colors.borderSecondary }]}
              >
                <Ionicons name={showAddContact ? 'chevron-up' : 'add-circle-outline'} size={18} color={colors.contentPrimary} />
                <Text style={[styles.addContactToggleText, { color: colors.contentPrimary }]}>
                  {showAddContact ? 'Hide' : 'Add Emergency Contact'}
                </Text>
              </Pressable>

              {/* Add contact form */}
              {showAddContact && (
                <View style={styles.addContactSection}>
                  {/* Search pre users */}
                  <Text style={[styles.addSubHeader, { color: colors.contentTertiary }]}>Search pre users</Text>
                  <View style={[styles.searchRow, { borderColor: colors.borderSecondary, backgroundColor: colors.surfacePrimary + '90' }]}>
                    <Ionicons name="search" size={16} color={colors.contentTertiary} />
                    <TextInput
                      value={contactQuery}
                      onChangeText={setContactQuery}
                      placeholder="Search by name or username..."
                      placeholderTextColor={colors.contentTertiary}
                      style={[styles.searchInput, { color: colors.contentPrimary }]}
                      autoCapitalize="none"
                    />
                    {contactSearching && <ActivityIndicator size="small" color={colors.contentTertiary} />}
                  </View>

                  {contactResults.length > 0 && (
                    <View style={styles.searchResults}>
                      {contactResults.map((person) => (
                        <Pressable
                          key={person.id}
                          onPress={() => handleAddPreContact(person)}
                          style={[styles.searchResult, { borderColor: colors.borderSecondary }]}
                        >
                          <View style={[styles.contactAvatar, { backgroundColor: colors.surfaceTertiary }]}>
                            {person.avatar_url ? (
                              <Image source={{ uri: person.avatar_url }} style={styles.contactAvatarImg} />
                            ) : (
                              <Text style={[styles.contactAvatarText, { color: colors.contentPrimary }]}>
                                {getInitials(person.full_name)}
                              </Text>
                            )}
                          </View>
                          <View style={styles.contactInfo}>
                            <Text style={[styles.contactName, { color: colors.contentPrimary }]}>
                              {person.full_name || 'User'}
                            </Text>
                            {person.username && (
                              <Text style={[styles.contactSub, { color: colors.contentTertiary }]}>
                                @{person.username}
                              </Text>
                            )}
                          </View>
                          <Ionicons name="add-circle" size={22} color={colors.contentPrimary} />
                        </Pressable>
                      ))}
                    </View>
                  )}

                  {/* External phone contact */}
                  <Text style={[styles.addSubHeader, { color: colors.contentTertiary, marginTop: Spacing.md }]}>
                    Or add external phone number
                  </Text>
                  <TextInput
                    value={externalName}
                    onChangeText={setExternalName}
                    placeholder="Contact name"
                    placeholderTextColor={colors.contentTertiary}
                    style={[styles.externalInput, { color: colors.contentPrimary, borderColor: colors.borderSecondary, backgroundColor: colors.surfacePrimary + '90' }]}
                    autoCapitalize="words"
                  />
                  <TextInput
                    value={externalPhone}
                    onChangeText={setExternalPhone}
                    placeholder="+1 (555) 123-4567"
                    placeholderTextColor={colors.contentTertiary}
                    style={[styles.externalInput, { color: colors.contentPrimary, borderColor: colors.borderSecondary, backgroundColor: colors.surfacePrimary + '90' }]}
                    keyboardType="phone-pad"
                  />
                  <Button
                    onPress={handleAddExternalContact}
                    loading={externalSaving}
                    disabled={externalSaving || !externalPhone.trim()}
                    fullWidth
                    variant="secondary"
                    size="small"
                  >
                    Add Phone Contact
                  </Button>
                </View>
              )}
            </View>
          </View>

          {/* ─── SECTION 4: Panic Alert ─── */}
          <View style={styles.group}>
            <Text style={[styles.groupHeader, { color: colors.contentTertiary }]}>PANIC ALERT</Text>
            <View style={[styles.panicCard, { backgroundColor: '#FF3B3015', borderColor: '#FF3B3040' }]}>
              <View style={styles.panicHeader}>
                <View style={[styles.panicIcon, { backgroundColor: '#FF3B30' }]}>
                  <Ionicons name="alert-circle" size={24} color="#FFFFFF" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.panicTitle, { color: colors.contentPrimary }]}>Panic Alert</Text>
                  <Text style={[styles.panicDesc, { color: colors.contentSecondary }]}>
                    Opens an SMS draft to your emergency contacts with your live location.
                  </Text>
                </View>
              </View>
              <Pressable
                onPress={handlePanic}
                disabled={panicLoading}
                style={({ pressed }) => [
                  styles.panicButton,
                  { backgroundColor: '#FF3B30', opacity: pressed || panicLoading ? 0.8 : 1 },
                ]}
              >
                {panicLoading ? (
                  <ActivityIndicator size="small" color="#FFFFFF" />
                ) : (
                  <>
                    <Ionicons name="warning" size={18} color="#FFFFFF" />
                    <Text style={styles.panicButtonText}>Send Emergency Alert</Text>
                  </>
                )}
              </Pressable>
              {panicMessage && (
                <Text style={[styles.gradNote, { color: colors.success }]}>{panicMessage}</Text>
              )}
              {panicError && (
                <Text style={[styles.gradNote, { color: colors.error }]}>{panicError}</Text>
              )}
            </View>
          </View>

          {/* ─── SECTION 5: Alert History ─── */}
          {alerts.length > 0 && (
            <View style={styles.group}>
              <Text style={[styles.groupHeader, { color: colors.contentTertiary }]}>ALERT HISTORY</Text>
              <View style={[styles.groupCard, { backgroundColor: colors.surfaceSecondary }]}>
                {alerts.map((alert, index) => (
                  <View key={alert.id}>
                    <View style={[styles.alertHistoryRow, index > 0 && { borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.borderSecondary }]}>
                      <View style={[styles.alertHistoryIcon, { backgroundColor: '#FF3B3015' }]}>
                        <Ionicons name="alert" size={16} color="#FF3B30" />
                      </View>
                      <View style={styles.alertHistoryText}>
                        <Text style={[styles.alertHistoryDate, { color: colors.contentPrimary }]}>
                          {new Date(alert.created_at).toLocaleDateString('en-US', {
                            month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit'
                          })}
                        </Text>
                        <Text style={[styles.alertHistoryLoc, { color: colors.contentTertiary }]}>
                          {alert.lat != null && alert.lng != null
                            ? `Location: ${alert.lat.toFixed(4)}, ${alert.lng.toFixed(4)}`
                            : 'No location data'}
                        </Text>
                      </View>
                    </View>
                  </View>
                ))}
              </View>
            </View>
          )}

          {/* ─── SECTION 6: Verification Benefits ─── */}
          <View style={styles.group}>
            <Text style={[styles.groupHeader, { color: colors.contentTertiary }]}>
              VERIFICATION BENEFITS
            </Text>
            <View style={[styles.groupCard, { backgroundColor: colors.surfaceSecondary }]}>
              {[
                { icon: 'people-outline', text: 'Connect with verified students at your school' },
                { icon: 'shield-checkmark-outline', text: 'Build trust within the community' },
                { icon: 'school-outline', text: 'Access university-specific circles & events' },
                { icon: 'lock-closed-outline', text: 'Your email is only used for verification' },
              ].map((item, i) => (
                <View
                  key={i}
                  style={[styles.benefitRow, { paddingLeft: Spacing.base }]}
                >
                  <View style={[
                    styles.benefitContent,
                    i < 3 && {
                      borderBottomWidth: StyleSheet.hairlineWidth,
                      borderBottomColor: colors.borderSecondary,
                    },
                  ]}>
                    <Ionicons name={item.icon as any} size={20} color="#007AFF" style={{ marginTop: 2 }} />
                    <Text style={[styles.benefitText, { color: colors.contentPrimary }]}>
                      {item.text}
                    </Text>
                  </View>
                </View>
              ))}
            </View>
          </View>

          {/* Privacy & Security note */}
          <View style={[styles.infoCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
            <Ionicons name="shield-checkmark" size={24} color={colors.contentPrimary} style={{ marginBottom: Spacing.sm }} />
            <Text style={[styles.infoTitle, { color: colors.contentPrimary }]}>Privacy & Security</Text>
            <Text style={[styles.infoText, { color: colors.contentTertiary }]}>
              Your emergency contacts will only be notified if you activate the panic alert. Your university email is only used for verification and is never shared.
            </Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

// ─── Styles ──────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1 },

  navBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    height: 44,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backBtn: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  backLabel: { fontSize: 17, marginLeft: 2 },
  navTitle: { fontSize: 17, fontWeight: '600' },
  navSpacer: { flex: 1 },

  scrollContent: { paddingBottom: 60 },

  // Groups
  group: { marginTop: Spacing.lg },
  groupHeader: {
    fontSize: 13,
    fontWeight: '400',
    paddingHorizontal: Spacing.base + Spacing.base,
    paddingBottom: 6,
    letterSpacing: -0.08,
  },
  groupCard: {
    marginHorizontal: Spacing.base,
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
    padding: Spacing.base,
    gap: Spacing.md,
  },

  // Alert card
  alertCard: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.sm,
    marginHorizontal: Spacing.base,
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    marginBottom: Spacing.sm,
  },
  alertText: {
    flex: 1,
    fontSize: Typography.callout,
    lineHeight: Typography.callout * 1.4,
  },

  // Verification header
  verificationHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.md,
  },
  verifyIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  verifyText: { flex: 1, gap: 2 },
  verifyTitle: { fontSize: 18, fontWeight: '600' },
  verifyDesc: { fontSize: Typography.callout, lineHeight: Typography.callout * 1.5 },

  // Email row
  emailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    borderWidth: 1,
    borderRadius: BorderRadius.md,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
  },
  emailInput: {
    flex: 1,
    fontSize: Typography.callout,
    padding: 0,
  },

  // Lock actions
  lockActions: { gap: Spacing.sm },
  lockNote: { fontSize: Typography.caption, lineHeight: Typography.caption * 1.4 },
  lockBtnRow: { flexDirection: 'row', gap: Spacing.sm },
  lockBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
  },
  lockBtnText: { fontSize: Typography.callout, fontWeight: '500' },

  verifyBtnWrap: {},

  // Graduation year
  gradSection: {
    gap: Spacing.sm,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(0,0,0,0.08)',
    paddingTop: Spacing.md,
    marginTop: Spacing.sm,
  },
  gradRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  gradLabel: { fontSize: Typography.callout, fontWeight: '500' },
  gradNote: { fontSize: Typography.caption, lineHeight: Typography.caption * 1.4 },
  gradInputRow: { gap: Spacing.sm },
  gradInput: {
    fontSize: Typography.callout,
    borderWidth: 1,
    borderRadius: BorderRadius.md,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
  },
  confirmRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  confirmText: { fontSize: Typography.caption, flex: 1 },
  gradMessage: { fontSize: Typography.caption, lineHeight: Typography.caption * 1.4 },

  // College
  collegeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  collegeTitleText: { fontSize: Typography.callout, fontWeight: '500' },
  collegeCurrent: { gap: Spacing.sm },
  collegeValueCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderRadius: BorderRadius.md,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
  },
  collegeValue: { fontSize: Typography.callout },
  collegeEditLink: {
    fontSize: Typography.callout,
    fontWeight: '500',
    textDecorationLine: 'underline',
  },
  collegePickerWrap: { gap: Spacing.sm },
  collegeOption: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
  },

  // Emergency contacts
  contactsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  contactsTitle: { fontSize: Typography.callout, fontWeight: '500' },
  emptyNote: { fontSize: Typography.callout, paddingVertical: Spacing.sm },
  contactsList: { gap: Spacing.sm },
  contactRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    paddingVertical: Spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  contactAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  contactAvatarImg: { width: 36, height: 36, borderRadius: 18 },
  contactAvatarText: { fontSize: Typography.callout, fontWeight: '600' },
  contactInfo: { flex: 1 },
  contactName: { fontSize: Typography.callout, fontWeight: '500' },
  contactSub: { fontSize: Typography.caption },

  addContactToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.sm,
    borderTopWidth: StyleSheet.hairlineWidth,
  },
  addContactToggleText: { fontSize: Typography.callout, fontWeight: '500' },

  addContactSection: { gap: Spacing.sm },
  addSubHeader: {
    fontSize: Typography.caption,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    borderWidth: 1,
    borderRadius: BorderRadius.md,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
  },
  searchInput: { flex: 1, fontSize: Typography.callout, padding: 0 },
  searchResults: { gap: Spacing.xs },
  searchResult: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    paddingVertical: Spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  externalInput: {
    fontSize: Typography.callout,
    borderWidth: 1,
    borderRadius: BorderRadius.md,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
  },

  // Panic
  panicCard: {
    marginHorizontal: Spacing.base,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    padding: Spacing.base,
    gap: Spacing.md,
  },
  panicHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
  },
  panicIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  panicTitle: { fontSize: Typography.body, fontWeight: '600' },
  panicDesc: { fontSize: Typography.caption, lineHeight: 18, marginTop: 2 },
  panicButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    paddingVertical: 14,
    borderRadius: BorderRadius.md,
  },
  panicButtonText: {
    color: '#FFFFFF',
    fontSize: Typography.body,
    fontWeight: '600',
  },

  // Alert history
  alertHistoryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    paddingVertical: Spacing.md,
  },
  alertHistoryIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertHistoryText: { flex: 1, gap: 2 },
  alertHistoryDate: { fontSize: Typography.callout },
  alertHistoryLoc: { fontSize: Typography.caption },

  // Benefits
  benefitRow: { flexDirection: 'row', alignItems: 'flex-start' },
  benefitContent: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.md,
    minHeight: 48,
    paddingRight: Spacing.base,
    paddingVertical: 12,
  },
  benefitText: { fontSize: 15, flex: 1, lineHeight: 20 },

  // Info card
  infoCard: {
    marginHorizontal: Spacing.base,
    marginTop: Spacing.lg,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    padding: Spacing.base,
    alignItems: 'center',
    marginBottom: Spacing.lg,
  },
  infoTitle: { fontSize: Typography.body, fontWeight: '600', marginBottom: Spacing.sm },
  infoText: { fontSize: Typography.caption, lineHeight: 18, textAlign: 'center' },
})
