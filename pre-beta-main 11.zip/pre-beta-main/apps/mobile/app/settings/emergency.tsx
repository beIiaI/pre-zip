import { View, Text, StyleSheet, ScrollView, Pressable, Alert, KeyboardAvoidingView, Platform, TextInput, ActivityIndicator, Image, Linking } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { Button } from '@/components/ui/Button'
import { Spacing, Typography, BorderRadius } from '@/constants/theme'
import { useState, useEffect, useRef } from 'react'
import { normalizePhoneNumber } from '@/utils/validation'
import { apiRequest } from '@/lib/api'
import { triggerPanic } from '@/lib/panic'
import * as Haptics from 'expo-haptics'
import * as Location from 'expo-location'

type ContactProfile = {
  id: string
  username: string | null
  full_name: string | null
  avatar_url: string | null
}

type EmergencyContact = {
  id: string
  type: 'user' | 'phone'
  contact_user_id: string | null
  external_name: string | null
  external_phone: string | null
  username: string | null
  full_name: string | null
  avatar_url: string | null
}

function getInitials(name: string | null): string {
  if (!name) return '?'
  return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
}

export default function EmergencySettings() {
  const { colors } = useTheme()
  const { profile, refreshProfile } = useAuth()
  const { user } = useAuth()
  const router = useRouter()

  const [contacts, setContacts] = useState<EmergencyContact[]>([])
  const [contactsLoading, setContactsLoading] = useState(true)
  const [contactQuery, setContactQuery] = useState('')
  const [contactResults, setContactResults] = useState<ContactProfile[]>([])
  const [contactSearching, setContactSearching] = useState(false)
  const [externalName, setExternalName] = useState('')
  const [externalPhone, setExternalPhone] = useState('')
  const [externalSaving, setExternalSaving] = useState(false)
  const [contactError, setContactError] = useState<string | null>(null)
  const [showAddContact, setShowAddContact] = useState(false)
  const [panicLoading, setPanicLoading] = useState(false)

  const searchTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    loadContacts()
  }, [])

  const loadContacts = async () => {
    setContactsLoading(true)
    const result = await apiRequest<{ contacts?: EmergencyContact[] }>('/api/emergency-contacts')
    if (!result.error) setContacts(result.data?.contacts ?? [])
    setContactsLoading(false)
  }

  // Contact search
  useEffect(() => {
    if (!contactQuery.trim()) {
      setContactResults([])
      setContactSearching(false)
      return
    }

    if (searchTimerRef.current) clearTimeout(searchTimerRef.current)
    setContactSearching(true)

    searchTimerRef.current = setTimeout(async () => {
      const result = await apiRequest<{ results?: ContactProfile[] }>(
        `/api/users/search?q=${encodeURIComponent(contactQuery.trim())}`
      )
      const exclude = new Set<string>([
        user?.id ?? '',
        ...contacts.map(c => c.contact_user_id).filter((id): id is string => !!id),
      ])
      const filtered = (result.data?.results ?? []).filter(p => !exclude.has(p.id))
      setContactResults(filtered)
      setContactSearching(false)
    }, 300)

    return () => {
      if (searchTimerRef.current) clearTimeout(searchTimerRef.current)
    }
  }, [contactQuery, contacts, user?.id])

  const handleAddPreContact = async (person: ContactProfile) => {
    setContactError(null)
    const result = await apiRequest<{ contact?: EmergencyContact }>('/api/emergency-contacts', {
      method: 'POST',
      body: { contact_user_id: person.id },
    })
    if (result.error) {
      setContactError(result.error)
      return
    }
    const next = result.data?.contact
    if (next) setContacts(prev => prev.some(c => c.id === next.id) ? prev : [...prev, next])
    setContactQuery('')
    setContactResults([])
  }

  const handleAddExternalContact = async () => {
    if (externalSaving) return
    const phone = externalPhone.trim()
    if (!phone) {
      setContactError('Enter a phone number.')
      return
    }
    const normalizedPhone = normalizePhoneNumber(phone)
    if (!/^\+\d{7,15}$/.test(normalizedPhone)) {
      setContactError('Phone must include 7-15 digits.')
      return
    }

    setContactError(null)
    setExternalSaving(true)

    const result = await apiRequest<{ contact?: EmergencyContact }>('/api/emergency-contacts', {
      method: 'POST',
      body: { external_name: externalName.trim(), external_phone: normalizedPhone },
    })

    if (result.error) {
      setContactError(result.error)
    } else {
      const next = result.data?.contact
      if (next) setContacts(prev => prev.some(c => c.id === next.id) ? prev : [...prev, next])
      setExternalName('')
      setExternalPhone('')
    }
    setExternalSaving(false)
  }

  const handleRemoveContact = (contactId: string) => {
    Alert.alert('Remove Contact', 'Remove this emergency contact?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: async () => {
          setContactError(null)
          const result = await apiRequest('/api/emergency-contacts', {
            method: 'DELETE',
            body: { contact_id: contactId },
          })
          if (result.error) {
            setContactError(result.error)
          } else {
            setContacts(prev => prev.filter(c => c.id !== contactId))
          }
        },
      },
    ])
  }

  const handlePanic = async () => {
    if (panicLoading) return
    const smsTargets = contacts
      .map(c => c.external_phone)
      .filter((phone): phone is string => !!phone && phone.length > 0)

    if (smsTargets.length === 0) {
      Alert.alert('No Contacts', 'Add at least one phone contact before using the panic alert.')
      return
    }

    Alert.alert(
      'Emergency Alert',
      'This will open an SMS draft to your emergency contacts with your current location. Continue?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Continue',
          style: 'destructive',
          onPress: async () => {
            setPanicLoading(true)
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning)

            let lat: number | null = null
            let lng: number | null = null
            try {
              const { status } = await Location.requestForegroundPermissionsAsync()
              if (status === 'granted') {
                const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced })
                lat = loc.coords.latitude
                lng = loc.coords.longitude
              }
            } catch {}

            try {
              await apiRequest('/api/panic', { method: 'POST', body: { lat, lng } })
            } catch {}

            const senderName = profile?.full_name || profile?.username || 'A pre user'
            const timestamp = new Date().toLocaleString()
            const mapLink = lat !== null && lng !== null
              ? `https://maps.apple.com/?q=${lat},${lng}` : null
            const bodyLines = [
              `Emergency alert from ${senderName}.`,
              'I need help right now. Please check in with me immediately.',
              mapLink ? `My current location: ${mapLink}` : 'Location unavailable. Please call me now.',
              `Sent from pre at ${timestamp}.`,
            ]
            const messageBody = bodyLines.join('\n')
            const isIOS = Platform.OS === 'ios'
            const delimiter = isIOS ? ',' : ';'
            const recipients = smsTargets.join(delimiter)
            const queryPrefix = isIOS ? '&' : '?'
            const smsUrl = `sms:${recipients}${queryPrefix}body=${encodeURIComponent(messageBody)}`

            try {
              await Linking.openURL(smsUrl)
            } catch {
              Alert.alert('Error', 'Could not open SMS app.')
            }

            setPanicLoading(false)
          },
        },
      ]
    )
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      <View style={[styles.navBar, { borderBottomColor: colors.borderSecondary }]}>
        <Pressable onPress={() => router.back()} hitSlop={8} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
          <Text style={[styles.backLabel, { color: colors.contentPrimary }]}>Settings</Text>
        </Pressable>
        <Text style={[styles.navTitle, { color: colors.contentPrimary }]}>Emergency</Text>
        <View style={styles.navSpacer} />
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Hero */}
          <View style={styles.hero}>
            <View style={[styles.heroIcon, { backgroundColor: colors.surfaceSecondary }]}>
              <Ionicons name="call" size={36} color={colors.contentPrimary} />
            </View>
            <Text style={[styles.heroTitle, { color: colors.contentPrimary }]}>Safety First</Text>
            <Text style={[styles.heroDesc, { color: colors.contentTertiary }]}>
              Add trusted contacts who can be notified in case of emergency. Search for pre users or add external phone numbers.
            </Text>
          </View>

          {/* Contact error */}
          {contactError && (
            <View style={[styles.alertCard, { backgroundColor: colors.error + '15', borderColor: colors.error + '40' }]}>
              <Ionicons name="alert-circle" size={16} color={colors.error} />
              <Text style={[styles.alertText, { color: colors.error }]}>{contactError}</Text>
            </View>
          )}

          {/* Existing contacts */}
          <View style={styles.group}>
            <Text style={[styles.groupHeader, { color: colors.contentTertiary }]}>YOUR CONTACTS</Text>
            <View style={[styles.groupCard, { backgroundColor: colors.surfaceSecondary }]}>
              {contactsLoading ? (
                <ActivityIndicator size="small" color={colors.contentTertiary} style={{ padding: Spacing.md }} />
              ) : contacts.length === 0 ? (
                <Text style={[styles.emptyNote, { color: colors.contentTertiary }]}>
                  No emergency contacts yet. Add someone below.
                </Text>
              ) : (
                contacts.map((contact) => (
                  <View key={contact.id} style={[styles.contactRow, { borderColor: colors.borderSecondary }]}>
                    <View style={[styles.contactAvatar, { backgroundColor: colors.surfaceTertiary }]}>
                      {contact.avatar_url ? (
                        <Image source={{ uri: contact.avatar_url }} style={styles.contactAvatarImg} />
                      ) : (
                        <Text style={[styles.contactAvatarText, { color: colors.contentPrimary }]}>
                          {getInitials(contact.full_name || contact.external_name)}
                        </Text>
                      )}
                    </View>
                    <View style={styles.contactInfo}>
                      <Text style={[styles.contactName, { color: colors.contentPrimary }]}>
                        {contact.full_name || contact.external_name || 'Unknown'}
                      </Text>
                      <Text style={[styles.contactSub, { color: colors.contentTertiary }]}>
                        {contact.type === 'user'
                          ? `@${contact.username || 'user'}`
                          : contact.external_phone || 'Phone'}
                      </Text>
                    </View>
                    <Pressable onPress={() => handleRemoveContact(contact.id)} hitSlop={8}>
                      <Ionicons name="close-circle" size={22} color={colors.contentTertiary} />
                    </Pressable>
                  </View>
                ))
              )}
            </View>
          </View>

          {/* Add contact */}
          <View style={styles.group}>
            <Pressable
              onPress={() => setShowAddContact(!showAddContact)}
              style={[styles.addToggle, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}
            >
              <Ionicons name={showAddContact ? 'chevron-up' : 'add-circle-outline'} size={18} color={colors.contentPrimary} />
              <Text style={[styles.addToggleText, { color: colors.contentPrimary }]}>
                {showAddContact ? 'Hide' : 'Add Emergency Contact'}
              </Text>
            </Pressable>

            {showAddContact && (
              <View style={[styles.groupCard, { backgroundColor: colors.surfaceSecondary }]}>
                {/* Search pre users */}
                <Text style={[styles.subHeader, { color: colors.contentTertiary }]}>Search pre users</Text>
                <View style={[styles.searchRow, { borderColor: colors.borderSecondary, backgroundColor: colors.surfacePrimary + '90' }]}>
                  <Ionicons name="search" size={16} color={colors.contentTertiary} />
                  <TextInput
                    value={contactQuery}
                    onChangeText={setContactQuery}
                    placeholder="Search by name or username..."
                    placeholderTextColor={colors.contentTertiary}
                    style={[styles.searchInput, { color: colors.contentPrimary }]}
                    autoCapitalize="none"
                  />
                  {contactSearching && <ActivityIndicator size="small" color={colors.contentTertiary} />}
                </View>

                {contactResults.length > 0 && (
                  <View style={styles.searchResults}>
                    {contactResults.map((person) => (
                      <Pressable
                        key={person.id}
                        onPress={() => handleAddPreContact(person)}
                        style={[styles.searchResult, { borderColor: colors.borderSecondary }]}
                      >
                        <View style={[styles.contactAvatar, { backgroundColor: colors.surfaceTertiary }]}>
                          {person.avatar_url ? (
                            <Image source={{ uri: person.avatar_url }} style={styles.contactAvatarImg} />
                          ) : (
                            <Text style={[styles.contactAvatarText, { color: colors.contentPrimary }]}>
                              {getInitials(person.full_name)}
                            </Text>
                          )}
                        </View>
                        <View style={styles.contactInfo}>
                          <Text style={[styles.contactName, { color: colors.contentPrimary }]}>
                            {person.full_name || 'User'}
                          </Text>
                          {person.username && (
                            <Text style={[styles.contactSub, { color: colors.contentTertiary }]}>@{person.username}</Text>
                          )}
                        </View>
                        <Ionicons name="add-circle" size={22} color={colors.contentPrimary} />
                      </Pressable>
                    ))}
                  </View>
                )}

                {/* External phone */}
                <Text style={[styles.subHeader, { color: colors.contentTertiary, marginTop: Spacing.md }]}>Or add external phone</Text>
                <TextInput
                  value={externalName}
                  onChangeText={setExternalName}
                  placeholder="Contact name"
                  placeholderTextColor={colors.contentTertiary}
                  style={[styles.textInput, { color: colors.contentPrimary, borderColor: colors.borderSecondary, backgroundColor: colors.surfacePrimary + '90' }]}
                  autoCapitalize="words"
                />
                <TextInput
                  value={externalPhone}
                  onChangeText={setExternalPhone}
                  placeholder="+1 (555) 123-4567"
                  placeholderTextColor={colors.contentTertiary}
                  style={[styles.textInput, { color: colors.contentPrimary, borderColor: colors.borderSecondary, backgroundColor: colors.surfacePrimary + '90' }]}
                  keyboardType="phone-pad"
                />
                <Button
                  onPress={handleAddExternalContact}
                  loading={externalSaving}
                  disabled={externalSaving || !externalPhone.trim()}
                  fullWidth
                  variant="secondary"
                  size="small"
                >
                  Add Phone Contact
                </Button>
              </View>
            )}
          </View>

          {/* Panic Alert */}
          <View style={styles.group}>
            <Text style={[styles.groupHeader, { color: colors.contentTertiary }]}>PANIC ALERT</Text>
            <View style={[styles.panicCard, { backgroundColor: '#FF3B3015', borderColor: '#FF3B3040' }]}>
              <View style={styles.panicHeader}>
                <View style={[styles.panicIcon, { backgroundColor: '#FF3B30' }]}>
                  <Ionicons name="alert-circle" size={24} color="#FFFFFF" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.panicTitle, { color: colors.contentPrimary }]}>Panic Alert</Text>
                  <Text style={[styles.panicDesc, { color: colors.contentSecondary }]}>
                    Opens an SMS draft to your emergency contacts with your live location
                  </Text>
                </View>
              </View>
              <Pressable
                onPress={handlePanic}
                disabled={panicLoading}
                style={({ pressed }) => [
                  styles.panicButton,
                  { backgroundColor: '#FF3B30', opacity: pressed || panicLoading ? 0.8 : 1 },
                ]}
              >
                {panicLoading ? (
                  <ActivityIndicator size="small" color="#FFFFFF" />
                ) : (
                  <>
                    <Ionicons name="warning" size={18} color="#FFFFFF" />
                    <Text style={styles.panicButtonText}>Send Emergency Alert</Text>
                  </>
                )}
              </Pressable>
            </View>
          </View>

          {/* Privacy note */}
          <View style={[styles.infoCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
            <Ionicons name="shield-checkmark" size={24} color={colors.contentPrimary} style={{ marginBottom: Spacing.sm }} />
            <Text style={[styles.infoTitle, { color: colors.contentPrimary }]}>Privacy & Security</Text>
            <Text style={[styles.infoText, { color: colors.contentTertiary }]}>
              Your emergency contacts will only be notified if you activate the panic alert. We take your privacy seriously.
            </Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  navBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    height: 44,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backBtn: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  backLabel: { fontSize: 17, marginLeft: 2 },
  navTitle: { fontSize: 17, fontWeight: '600' },
  navSpacer: { flex: 1 },
  scrollContent: { paddingBottom: 60 },

  hero: {
    alignItems: 'center',
    paddingHorizontal: Spacing.xl,
    paddingTop: Spacing.xl,
    paddingBottom: Spacing.md,
    gap: Spacing.sm,
  },
  heroIcon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  heroTitle: { fontSize: 22, fontWeight: '700', textAlign: 'center' },
  heroDesc: { fontSize: 15, textAlign: 'center', lineHeight: 20 },

  alertCard: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.sm,
    marginHorizontal: Spacing.base,
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
  },
  alertText: { flex: 1, fontSize: Typography.callout, lineHeight: Typography.callout * 1.4 },

  group: { marginTop: Spacing.lg },
  groupHeader: {
    fontSize: 13,
    fontWeight: '400',
    paddingHorizontal: Spacing.base + Spacing.base,
    paddingBottom: 6,
    letterSpacing: -0.08,
  },
  groupCard: {
    marginHorizontal: Spacing.base,
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
    padding: Spacing.base,
    gap: Spacing.sm,
  },
  emptyNote: { fontSize: Typography.callout, paddingVertical: Spacing.sm },

  contactRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    paddingVertical: Spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  contactAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  contactAvatarImg: { width: 40, height: 40, borderRadius: 20 },
  contactAvatarText: { fontSize: Typography.callout, fontWeight: '600' },
  contactInfo: { flex: 1 },
  contactName: { fontSize: Typography.callout, fontWeight: '500' },
  contactSub: { fontSize: Typography.caption },

  addToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginHorizontal: Spacing.base,
    padding: Spacing.base,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
  },
  addToggleText: { fontSize: Typography.callout, fontWeight: '500' },

  subHeader: {
    fontSize: Typography.caption,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    borderWidth: 1,
    borderRadius: BorderRadius.md,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
  },
  searchInput: { flex: 1, fontSize: Typography.callout, padding: 0 },
  searchResults: { gap: Spacing.xs },
  searchResult: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    paddingVertical: Spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  textInput: {
    fontSize: Typography.callout,
    borderWidth: 1,
    borderRadius: BorderRadius.md,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
  },

  panicCard: {
    marginHorizontal: Spacing.base,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    padding: Spacing.base,
    gap: Spacing.md,
  },
  panicHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  panicIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  panicTitle: { fontSize: Typography.body, fontWeight: '600' },
  panicDesc: { fontSize: Typography.caption, lineHeight: 18, marginTop: 2 },
  panicButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    paddingVertical: 14,
    borderRadius: BorderRadius.md,
  },
  panicButtonText: { color: '#FFFFFF', fontSize: Typography.body, fontWeight: '600' },

  infoCard: {
    marginHorizontal: Spacing.base,
    marginTop: Spacing.lg,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    padding: Spacing.base,
    alignItems: 'center',
    marginBottom: Spacing.lg,
  },
  infoTitle: { fontSize: Typography.body, fontWeight: '600', marginBottom: Spacing.sm },
  infoText: { fontSize: Typography.caption, lineHeight: 18, textAlign: 'center' },
})
