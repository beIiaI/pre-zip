import { View, Text, StyleSheet, FlatList, Pressable, TouchableOpacity, Alert } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import { useTheme } from '@/contexts/ThemeContext'
import { Spacing, Typography, BorderRadius } from '@/constants/theme'
import { useState, useEffect } from 'react'
import { apiRequest } from '@/lib/api'
import { unblockUser } from '@/lib/blocks'

export default function BlockedUsers() {
  const { colors } = useTheme()
  const router = useRouter()
  const [blockedUsers, setBlockedUsers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadBlockedUsers()
  }, [])

  const loadBlockedUsers = async () => {
    setLoading(true)
    const result = await apiRequest<{ results?: any[] }>('/api/blocks')
    if (result.error) {
      Alert.alert('Error', result.error)
      setBlockedUsers([])
      setLoading(false)
      return
    }
    setBlockedUsers(result.data?.results ?? [])
    setLoading(false)
  }

  const handleUnblock = async (blockedUserId: string) => {
    Alert.alert(
      'Unblock User',
      'Are you sure you want to unblock this user?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Unblock',
          onPress: async () => {
            const result = await unblockUser(blockedUserId)
            if (result.error) {
              Alert.alert('Error', result.error)
              return
            }
            loadBlockedUsers()
          },
        },
      ]
    )
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
        <Pressable onPress={() => router.back()} hitSlop={8} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
          <Text style={[styles.backLabel, { color: colors.contentPrimary }]}>Privacy</Text>
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.contentPrimary }]}>Blocked</Text>
        <View style={styles.placeholder} />
      </View>

      {blockedUsers.length === 0 ? (
        <View style={styles.emptyState}>
          <View style={[styles.emptyIcon, { backgroundColor: colors.surfaceSecondary }]}>
            <Ionicons name="person-remove-outline" size={32} color={colors.contentTertiary} />
          </View>
          <Text style={[styles.emptyTitle, { color: colors.contentPrimary }]}>
            {loading ? 'Loading...' : 'No blocked users'}
          </Text>
          {!loading && (
            <Text style={[styles.emptyDesc, { color: colors.contentSecondary }]}>
              You haven't blocked anyone yet.
            </Text>
          )}
        </View>
      ) : (
        <FlatList
          data={blockedUsers}
          contentContainerStyle={styles.list}
          keyExtractor={(item) => item.blocked_id}
          renderItem={({ item }) => (
            <View style={[styles.userCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
              <View style={styles.userInfo}>
                <View style={[styles.avatar, { backgroundColor: colors.surfaceTertiary }]}>
                  <Text style={[styles.avatarText, { color: colors.contentPrimary }]}>
                    {(item.profile?.full_name || item.profile?.username || 'U')[0]}
                  </Text>
                </View>
                <View>
                  <Text style={[styles.userName, { color: colors.contentPrimary }]}>
                    {item.profile?.full_name || item.profile?.username || 'Unknown User'}
                  </Text>
                  {item.profile?.username && (
                    <Text style={[styles.userHandle, { color: colors.contentSecondary }]}>@{item.profile.username}</Text>
                  )}
                </View>
              </View>
              <TouchableOpacity
                onPress={() => handleUnblock(item.blocked_id)}
                style={[styles.unblockButton, { borderColor: colors.borderSecondary }]}
              >
                <Text style={[styles.unblockText, { color: colors.contentPrimary }]}>Unblock</Text>
              </TouchableOpacity>
            </View>
          )}
        />
      )}
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    height: 44,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backBtn: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  backLabel: { fontSize: 17, marginLeft: 2 },
  headerTitle: { fontSize: 17, fontWeight: '600' },
  placeholder: { flex: 1 },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  emptyIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  emptyTitle: { fontSize: Typography.headline, fontWeight: '600' },
  emptyDesc: { fontSize: Typography.body, maxWidth: 240, textAlign: 'center' },
  list: { padding: Spacing.base, gap: Spacing.md },
  userCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: Spacing.md,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: { fontSize: Typography.title, fontWeight: '600' },
  userName: { fontSize: Typography.body, fontWeight: '500' },
  userHandle: { fontSize: Typography.caption },
  unblockButton: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.sm,
    borderWidth: 1,
  },
  unblockText: { fontSize: Typography.callout },
})
