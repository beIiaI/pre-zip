import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Pressable, Alert, KeyboardAvoidingView, Platform, Share } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Clipboard from 'expo-clipboard'
import { useTheme } from '@/contexts/ThemeContext'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Spacing, Typography, BorderRadius } from '@/constants/theme'
import { useState, useEffect, useCallback } from 'react'
import { validateEmail } from '@/utils/validation'
import { apiRequest } from '@/lib/api'

type InviteItem = {
  id: string
  invitee_email: string | null
  invitee_name: string | null
  invite_code: string
  status: 'pending' | 'accepted' | 'revoked' | 'expired'
  accepted_member_label?: string | null
  signed_up?: boolean
  created_at: string
  expires_at?: string | null
  accepted_at: string | null
}

function formatInviteDate(value: string | null) {
  if (!value) return null
  return new Date(value).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  })
}

function maskEmail(value: string) {
  const [localPart, domain] = value.split('@')
  if (!localPart || !domain) return value
  if (localPart.length <= 2) {
    return `${localPart[0] ?? '*'}*@${domain}`
  }
  return `${localPart[0]}${'*'.repeat(Math.min(4, localPart.length - 2))}${localPart[localPart.length - 1]}@${domain}`
}

export default function InvitesSettings() {
  const { colors } = useTheme()
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [name, setName] = useState('')
  const [loading, setLoading] = useState(false)
  const [refreshingInvites, setRefreshingInvites] = useState(false)
  const [invitesLoading, setInvitesLoading] = useState(true)
  const [invites, setInvites] = useState<InviteItem[]>([])
  const [stats, setStats] = useState({
    remaining: 0,
    used: 0,
    pending: 0,
    acceptedCount: 0,
    max: 5,
    baseMax: 5,
    isFounder: false,
    canRefresh: false,
    refreshCount: 0,
  })

  const loadInvites = useCallback(async () => {
    setInvitesLoading(true)
    const result = await apiRequest('/api/invites/list')
    setInvitesLoading(false)

    if (result.data) {
      setInvites(result.data.invites || [])
      setStats({
        remaining: result.data.remaining ?? 0,
        used: result.data.used || 0,
        pending: result.data.pending || 0,
        acceptedCount: result.data.acceptedCount || 0,
        max: result.data.max ?? 5,
        baseMax: result.data.baseMax ?? 5,
        isFounder: result.data.isFounder || false,
        canRefresh: result.data.canRefresh || false,
        refreshCount: result.data.refreshCount || 0,
      })
    }
  }, [])

  useEffect(() => {
    loadInvites()
  }, [])

  const handleCreateInvite = async () => {
    const trimmedEmail = email.trim().toLowerCase()

    if (trimmedEmail && !validateEmail(trimmedEmail)) {
      Alert.alert('Invalid Email', 'Please enter a valid email address or leave it blank')
      return
    }

    if (!stats.isFounder && stats.remaining <= 0) {
      Alert.alert('No Invites Available', 'You have used all your invite slots')
      return
    }

    setLoading(true)
    const result = await apiRequest('/api/invites/create', {
      method: 'POST',
      body: {
        email: trimmedEmail || undefined,
        name: name.trim() || undefined
      },
    })
    setLoading(false)

    if (result.error) {
      Alert.alert('Error', result.error)
    } else {
      const inviteUrl = buildInviteLink(result.data?.invite?.invite_code)

      if (inviteUrl) {
        await Clipboard.setStringAsync(inviteUrl)
        Alert.alert(
          'Invite Created',
          trimmedEmail
            ? 'Invite link reserved for that email. Link copied.'
            : 'Open invite link created. Link copied.',
        )
      } else {
        Alert.alert('Success', 'Invite created')
      }

      setEmail('')
      setName('')
      loadInvites()
    }
  }

  const handleRefreshInvites = async () => {
    setRefreshingInvites(true)
    const result = await apiRequest('/api/invites/refresh', {
      method: 'POST',
    })
    setRefreshingInvites(false)

    if (result.error) {
      Alert.alert('Error', result.error)
    } else {
      Alert.alert('Refreshed', result.data?.message || 'Referrals refreshed.')
      loadInvites()
    }
  }

  const buildInviteLink = (code: string) => {
    if (!code) return null
    return `https://app.presocial.app/auth?mode=signup&invite=${encodeURIComponent(code)}`
  }

  const handleCopyLink = async (invite: InviteItem) => {
    const link = buildInviteLink(invite.invite_code)
    if (!link) return

    await Clipboard.setStringAsync(link)
    Alert.alert('Copied', 'Invite link copied to clipboard')
  }

  const handleShareLink = async (invite: InviteItem) => {
    const link = buildInviteLink(invite.invite_code)
    if (!link) return

    try {
      await Share.share({
        message: `Join me on pre! Use my invite link: ${link}`,
        url: link,
      })
    } catch (error) {
      // Share cancelled
    }
  }

  const handleRevokeInvite = async (inviteId: string) => {
    Alert.alert(
      'Revoke Invite',
      'Are you sure you want to revoke this invite? This cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Revoke',
          style: 'destructive',
          onPress: async () => {
            const result = await apiRequest('/api/invites/revoke', {
              method: 'POST',
              body: { inviteId },
            })

            if (result.error) {
              Alert.alert('Error', result.error)
            } else {
              Alert.alert('Success', 'Invite revoked successfully')
              loadInvites()
            }
          },
        },
      ]
    )
  }

  const getStatusIcon = (status: string): string => {
    switch (status) {
      case 'accepted': return 'checkmark-circle'
      case 'pending': return 'time-outline'
      default: return 'close-circle-outline'
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'accepted': return colors.success
      case 'pending': return colors.contentPrimary
      case 'expired':
      case 'revoked': return colors.contentTertiary
      default: return colors.contentSecondary
    }
  }

  const getInviteLabels = (invite: InviteItem) => {
    const isExpired =
      invite.status === 'pending' &&
      !!invite.expires_at &&
      new Date(invite.expires_at).getTime() < Date.now()
    const statusLabel = isExpired ? 'expired' : invite.status

    const primaryLabel =
      statusLabel === 'accepted'
        ? invite.accepted_member_label || 'Used by invited member'
        : invite.invitee_name || (invite.invitee_email ? maskEmail(invite.invitee_email) : 'Open invite link')

    const secondaryLabel =
      statusLabel === 'accepted'
        ? 'Signed up successfully'
        : invite.invitee_email
          ? invite.invitee_name
            ? maskEmail(invite.invitee_email)
            : 'Reserved invite'
          : 'First signup that claims this code gets the slot.'

    return { primaryLabel, secondaryLabel, statusLabel }
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
        <Pressable onPress={() => router.back()} hitSlop={8} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
          <Text style={[styles.backLabel, { color: colors.contentPrimary }]}>Settings</Text>
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.contentPrimary }]}>Invites</Text>
        <View style={styles.placeholder} />
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Intro card */}
          <View style={[styles.card, { backgroundColor: colors.surfaceSecondary }]}>
            <View style={[styles.introIcon, { backgroundColor: colors.surfacePrimary, borderColor: colors.borderSecondary }]}>
              <Ionicons name="sparkles" size={18} color={colors.contentPrimary} />
            </View>
            <Text style={[styles.introTitle, { color: colors.contentPrimary }]}>Private Member Access</Text>
            <Text style={[styles.introDesc, { color: colors.contentSecondary }]}>
              {stats.isFounder
                ? 'pre is invite-only. Founder accounts have unlimited private referral links.'
                : `pre is invite-only. Each member can nominate in batches of ${stats.baseMax} people.`}
            </Text>

            {/* Stats grid */}
            <View style={styles.statsGrid}>
              <View style={[styles.statBox, { backgroundColor: colors.surfacePrimary, borderColor: colors.borderSecondary }]}>
                <Text style={[styles.statLabel, { color: colors.contentTertiary }]}>Remaining</Text>
                <Text style={[styles.statValue, { color: colors.contentPrimary }]}>
                  {stats.isFounder ? '∞' : stats.remaining}
                </Text>
              </View>
              <View style={[styles.statBox, { backgroundColor: colors.surfacePrimary, borderColor: colors.borderSecondary }]}>
                <Text style={[styles.statLabel, { color: colors.contentTertiary }]}>Pending</Text>
                <Text style={[styles.statValue, { color: colors.contentPrimary }]}>{stats.pending}</Text>
              </View>
              <View style={[styles.statBox, { backgroundColor: colors.surfacePrimary, borderColor: colors.borderSecondary }]}>
                <Text style={[styles.statLabel, { color: colors.contentTertiary }]}>Accepted</Text>
                <Text style={[styles.statValue, { color: colors.contentPrimary }]}>{stats.acceptedCount}</Text>
              </View>
              <View style={[styles.statBox, { backgroundColor: colors.surfacePrimary, borderColor: colors.borderSecondary }]}>
                <Text style={[styles.statLabel, { color: colors.contentTertiary }]}>Capacity</Text>
                <Text style={[styles.statValue, { color: colors.contentPrimary }]}>
                  {stats.isFounder ? '∞' : stats.max}
                </Text>
              </View>
            </View>
          </View>

          {/* Create Invite Form */}
          <View style={[styles.card, { backgroundColor: colors.surfaceSecondary }]}>
            <Text style={[styles.cardTitle, { color: colors.contentPrimary }]}>Create invite link</Text>
            <View style={styles.form}>
              <Input
                label="Invitee email (optional)"
                placeholder="name@domain.com"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
              />
              <Text style={[styles.inputHint, { color: colors.contentTertiary }]}>
                Leave blank to create an open invite link you can share anywhere.
              </Text>
              <Input
                label="Name (optional)"
                placeholder="Full name"
                value={name}
                onChangeText={setName}
                maxLength={80}
              />
              <Button
                onPress={handleCreateInvite}
                loading={loading}
                disabled={loading || (!stats.isFounder && stats.remaining <= 0)}
                fullWidth
              >
                Create Link
              </Button>
            </View>
          </View>

          {/* Refresh referrals (non-founders only) */}
          {!stats.isFounder && (
            <View style={[styles.card, { backgroundColor: colors.surfaceSecondary }]}>
              <Text style={[styles.cardTitle, { color: colors.contentPrimary }]}>Refresh referrals</Text>
              <Text style={[styles.refreshDesc, { color: colors.contentSecondary }]}>
                Once all current slots are accepted, refresh to unlock {stats.baseMax} additional referrals.
              </Text>
              <Button
                onPress={handleRefreshInvites}
                loading={refreshingInvites}
                disabled={refreshingInvites || !stats.canRefresh}
                variant="secondary"
                fullWidth
              >
                {stats.canRefresh ? `Refresh (+${stats.baseMax})` : 'Not available yet'}
              </Button>
            </View>
          )}

          {/* Invites List */}
          <View style={[styles.card, { backgroundColor: colors.surfaceSecondary }]}>
            <Text style={[styles.cardTitle, { color: colors.contentPrimary }]}>Your invite links</Text>
            {invitesLoading ? (
              <Text style={[styles.emptyText, { color: colors.contentTertiary }]}>Loading...</Text>
            ) : invites.length === 0 ? (
              <Text style={[styles.emptyText, { color: colors.contentTertiary }]}>No invite links yet.</Text>
            ) : (
              <View style={styles.invitesList}>
                {invites.map((invite) => {
                  const { primaryLabel, secondaryLabel, statusLabel } = getInviteLabels(invite)
                  const isPending = statusLabel === 'pending'
                  const statusColor = getStatusColor(statusLabel)

                  return (
                    <View
                      key={invite.id}
                      style={[
                        styles.inviteCard,
                        { backgroundColor: colors.surfacePrimary, borderColor: colors.borderSecondary },
                      ]}
                    >
                      <View style={styles.inviteHeader}>
                        <View style={{ flex: 1 }}>
                          <Text style={[styles.invitePrimary, { color: colors.contentPrimary }]}>
                            {primaryLabel}
                          </Text>
                          <Text style={[styles.inviteSecondary, { color: colors.contentSecondary }]}>
                            {secondaryLabel}
                          </Text>
                        </View>
                        <View style={[styles.statusBadge, { backgroundColor: statusColor + '20' }]}>
                          <Ionicons name={getStatusIcon(statusLabel) as any} size={12} color={statusColor} />
                          <Text style={[styles.statusText, { color: statusColor }]}>
                            {statusLabel}
                          </Text>
                        </View>
                      </View>

                      <View style={styles.inviteMeta}>
                        <View style={styles.inviteCodeRow}>
                          <Ionicons name="link-outline" size={13} color={colors.contentTertiary} />
                          <Text style={[styles.inviteCode, { color: colors.contentTertiary }]}>
                            Code: {invite.invite_code}
                          </Text>
                        </View>
                        <Text style={[styles.inviteDate, { color: colors.contentTertiary }]}>
                          Sent {formatInviteDate(invite.created_at)}
                          {invite.accepted_at ? ` · Accepted ${formatInviteDate(invite.accepted_at)}` : ''}
                          {!invite.accepted_at && invite.expires_at ? ` · Expires ${formatInviteDate(invite.expires_at)}` : ''}
                        </Text>
                      </View>

                      {isPending && (
                        <View style={styles.inviteActions}>
                          <TouchableOpacity
                            onPress={() => handleCopyLink(invite)}
                            style={[styles.actionButton, { backgroundColor: colors.surfaceSecondary }]}
                          >
                            <Ionicons name="copy-outline" size={16} color={colors.contentPrimary} />
                            <Text style={[styles.actionLabel, { color: colors.contentPrimary }]}>Copy</Text>
                          </TouchableOpacity>
                          <TouchableOpacity
                            onPress={() => handleShareLink(invite)}
                            style={[styles.actionButton, { backgroundColor: colors.surfaceSecondary }]}
                          >
                            <Ionicons name="share-outline" size={16} color={colors.contentPrimary} />
                            <Text style={[styles.actionLabel, { color: colors.contentPrimary }]}>Share</Text>
                          </TouchableOpacity>
                          <TouchableOpacity
                            onPress={() => handleRevokeInvite(invite.id)}
                            style={[styles.actionButton, { backgroundColor: colors.error + '15' }]}
                          >
                            <Ionicons name="close" size={16} color={colors.error} />
                            <Text style={[styles.actionLabel, { color: colors.error }]}>Revoke</Text>
                          </TouchableOpacity>
                        </View>
                      )}
                    </View>
                  )
                })}
              </View>
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    height: 44,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backBtn: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  backLabel: { fontSize: 17, marginLeft: 2 },
  headerTitle: { fontSize: 17, fontWeight: '600' },
  placeholder: { flex: 1 },
  content: { padding: Spacing.base, gap: Spacing.lg, paddingBottom: 40 },

  card: {
    borderRadius: BorderRadius.lg,
    padding: Spacing.base,
  },
  cardTitle: {
    fontSize: Typography.body,
    fontWeight: '500',
    marginBottom: Spacing.md,
  },

  // Intro card
  introIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: Spacing.md,
  },
  introTitle: {
    fontSize: Typography.body,
    fontWeight: '500',
    marginBottom: 4,
  },
  introDesc: {
    fontSize: Typography.caption,
    lineHeight: 18,
    marginBottom: Spacing.md,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.sm,
  },
  statBox: {
    flex: 1,
    minWidth: '45%',
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.sm,
    alignItems: 'center',
  },
  statLabel: { fontSize: Typography.caption },
  statValue: { fontSize: Typography.body, fontWeight: '600', marginTop: 2 },

  // Form
  form: { gap: Spacing.md },
  inputHint: { fontSize: Typography.caption, marginTop: -4, lineHeight: 16 },

  // Refresh
  refreshDesc: {
    fontSize: Typography.caption,
    lineHeight: 18,
    marginBottom: Spacing.md,
  },

  emptyText: { fontSize: Typography.callout, textAlign: 'center', paddingVertical: Spacing.lg },
  invitesList: { gap: Spacing.sm },

  // Invite cards
  inviteCard: {
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    padding: Spacing.md,
    gap: Spacing.sm,
  },
  inviteHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    gap: Spacing.md,
  },
  invitePrimary: { fontSize: Typography.callout, fontWeight: '500' },
  inviteSecondary: { fontSize: Typography.caption, marginTop: 2 },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 10,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  inviteMeta: {
    gap: 2,
  },
  inviteCodeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  inviteCode: { fontSize: Typography.caption },
  inviteDate: { fontSize: Typography.caption, lineHeight: 16 },
  inviteActions: {
    flexDirection: 'row',
    gap: Spacing.sm,
    marginTop: 4,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    height: 36,
    borderRadius: BorderRadius.sm,
  },
  actionLabel: {
    fontSize: Typography.caption,
    fontWeight: '500',
  },
})
