import { View, Text, StyleSheet, ScrollView, Pressable, Alert, KeyboardAvoidingView, Platform, TextInput } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import { useTheme } from '@/contexts/ThemeContext'
import { Button } from '@/components/ui/Button'
import { Spacing, Typography, BorderRadius } from '@/constants/theme'
import { useState } from 'react'
import { apiRequest } from '@/lib/api'

type ReportType = 'bug' | 'abuse' | 'spam' | 'content' | 'safety' | 'other'

export default function ReportSettings() {
  const { colors } = useTheme()
  const router = useRouter()
  const [selectedType, setSelectedType] = useState<ReportType | null>(null)
  const [description, setDescription] = useState('')
  const [loading, setLoading] = useState(false)

  const reportTypes: { id: ReportType; label: string; icon: string; subtitle: string }[] = [
    { id: 'bug', label: 'Bug or Technical Issue', icon: 'bug-outline', subtitle: 'App crashes or errors' },
    { id: 'abuse', label: 'Harassment or Abuse', icon: 'warning-outline', subtitle: 'Bullying or threatening behavior' },
    { id: 'spam', label: 'Spam or Scam', icon: 'shield-outline', subtitle: 'Unwanted messages or fraud' },
    { id: 'content', label: 'Inappropriate Content', icon: 'eye-off-outline', subtitle: 'Offensive or explicit material' },
    { id: 'safety', label: 'Safety Concern', icon: 'alert-circle-outline', subtitle: 'Immediate safety issue' },
    { id: 'other', label: 'Other', icon: 'ellipsis-horizontal', subtitle: 'Something else' },
  ]

  const handleSubmit = async () => {
    if (!selectedType) {
      Alert.alert('Select a Type', 'Please select what you want to report')
      return
    }

    if (!description.trim()) {
      Alert.alert('Add Details', 'Please describe the issue')
      return
    }

    setLoading(true)
    const result = await apiRequest('/api/reports/submit', {
      method: 'POST',
      body: {
        type: selectedType,
        description: description.trim(),
      },
    })
    setLoading(false)

    if (result.error) {
      Alert.alert('Error', result.error)
    } else {
      Alert.alert(
        'Thank You',
        'Your report has been submitted. We\'ll review it promptly and take appropriate action.',
        [
          {
            text: 'OK',
            onPress: () => router.back()
          }
        ]
      )
    }
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
        <Pressable onPress={() => router.back()} hitSlop={8} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
          <Text style={[styles.backLabel, { color: colors.contentPrimary }]}>Settings</Text>
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.contentPrimary }]}>Report</Text>
        <View style={styles.placeholder} />
      </View>

      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView 
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
        >
          <Text style={[styles.sectionTitle, { color: colors.contentSecondary }]}>WHAT'S THE ISSUE?</Text>
          <View style={[styles.card, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
            {reportTypes.map((type, index) => (
              <Pressable
                key={type.id}
                onPress={() => setSelectedType(type.id)}
                style={[
                  styles.item,
                  index > 0 && { borderTopWidth: 1, borderTopColor: colors.borderSecondary },
                ]}
              >
                <View style={styles.itemContent}>
                  <View style={[styles.iconWrap, { backgroundColor: colors.surfaceElevated }]}>
                    <Ionicons name={type.icon as any} size={20} color={colors.contentPrimary} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.itemText, { color: colors.contentPrimary }]}>{type.label}</Text>
                    <Text style={[styles.itemSubtitle, { color: colors.contentTertiary }]}>{type.subtitle}</Text>
                  </View>
                </View>
                {selectedType === type.id && (
                  <Ionicons name="checkmark-circle" size={24} color={colors.contentPrimary} />
                )}
              </Pressable>
            ))}
          </View>

          <Text style={[styles.sectionTitle, { color: colors.contentSecondary }]}>ADDITIONAL DETAILS</Text>
          <View style={[styles.textAreaWrap, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
            <TextInput
              placeholder="Describe the issue in detail..."
              placeholderTextColor={colors.contentTertiary}
              value={description}
              onChangeText={setDescription}
              multiline
              numberOfLines={6}
              textAlignVertical="top"
              style={[styles.textArea, { color: colors.contentPrimary }]}
              maxLength={1000}
            />
            <Text style={[styles.charCount, { color: colors.contentTertiary }]}>
              {description.length}/1000
            </Text>
          </View>

          <Button 
            onPress={handleSubmit}
            loading={loading}
            disabled={loading || !selectedType || !description.trim()}
            fullWidth
          >
            Submit Report
          </Button>

          <View style={[styles.infoCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
            <Ionicons name="lock-closed" size={24} color={colors.contentPrimary} style={{ marginBottom: Spacing.sm }} />
            <Text style={[styles.infoTitle, { color: colors.contentPrimary }]}>Anonymous & Secure</Text>
            <Text style={[styles.infoText, { color: colors.contentTertiary }]}>
              Your report helps us maintain a safe community. We review all reports promptly and take appropriate action while protecting your privacy.
            </Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    height: 44,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backBtn: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  backLabel: { fontSize: 17, marginLeft: 2 },
  headerTitle: { fontSize: 17, fontWeight: '600' },
  placeholder: { flex: 1 },
  content: { padding: Spacing.base, gap: Spacing.lg, paddingBottom: 40 },
  sectionTitle: {
    fontSize: Typography.caption,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 1,
    paddingHorizontal: Spacing.xs,
  },
  card: {
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    overflow: 'hidden',
  },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
  },
  itemContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    flex: 1,
  },
  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.sm,
    justifyContent: 'center',
    alignItems: 'center',
  },
  itemText: { fontSize: Typography.body, fontWeight: '500' },
  itemSubtitle: { fontSize: Typography.caption, marginTop: 2 },
  textAreaWrap: {
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    padding: Spacing.md,
  },
  textArea: {
    fontSize: Typography.body,
    minHeight: 120,
    padding: 0,
  },
  charCount: {
    fontSize: Typography.caption,
    textAlign: 'right',
    marginTop: Spacing.sm,
  },
  infoCard: {
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    padding: Spacing.base,
    alignItems: 'center',
  },
  infoTitle: {
    fontSize: Typography.body,
    fontWeight: '600',
    marginBottom: Spacing.sm,
  },
  infoText: { 
    fontSize: Typography.caption, 
    lineHeight: 18, 
    textAlign: 'center',
  },
})