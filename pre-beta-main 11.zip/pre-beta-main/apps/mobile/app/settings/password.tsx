import { View, Text, StyleSheet, ScrollView, Pressable, Alert, KeyboardAvoidingView, Platform } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Spacing, Typography, BorderRadius } from '@/constants/theme'
import { useState } from 'react'
import { supabase } from '@/lib/supabase'
import { validatePassword } from '@/utils/validation'

export default function PasswordSettings() {
  const { colors } = useTheme()
  const router = useRouter()
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [loading, setLoading] = useState(false)

  const handleChangePassword = async () => {
    const validation = validatePassword(newPassword)
    if (!validation.valid) {
      Alert.alert('Invalid Password', validation.error || 'Password does not meet requirements')
      return
    }
    
    if (newPassword !== confirmPassword) {
      Alert.alert('Error', 'Passwords do not match')
      return
    }

    setLoading(true)
    
    const { error } = await supabase.auth.updateUser({ 
      password: newPassword 
    })
    
    setLoading(false)

    if (error) {
      Alert.alert('Error', error.message)
    } else {
      Alert.alert(
        'Success', 
        'Your password has been updated successfully',
        [
          {
            text: 'OK',
            onPress: () => {
              setNewPassword('')
              setConfirmPassword('')
              router.back()
            }
          }
        ]
      )
    }
  }

  const passwordChecks = {
    length: newPassword.length >= 8,
    lower: /[a-z]/.test(newPassword),
    upper: /[A-Z]/.test(newPassword),
    number: /[0-9]/.test(newPassword),
    symbol: /[^A-Za-z0-9]/.test(newPassword),
  }

  const allChecksPassed = Object.values(passwordChecks).every(Boolean)

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
        <Pressable onPress={() => router.back()} hitSlop={8} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
          <Text style={[styles.backLabel, { color: colors.contentPrimary }]}>Settings</Text>
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.contentPrimary }]}>Password</Text>
        <View style={styles.placeholder} />
      </View>

      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView 
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.form}>
            <Input
              label="New Password"
              placeholder="Create a new password"
              value={newPassword}
              onChangeText={setNewPassword}
              secureTextEntry
              showPasswordToggle
              textContentType="newPassword"
              autoComplete="password-new"
            />

            <Input
              label="Confirm New Password"
              placeholder="Re-enter new password"
              value={confirmPassword}
              onChangeText={setConfirmPassword}
              secureTextEntry
              showPasswordToggle
              textContentType="newPassword"
              autoComplete="password-new"
            />

            <View style={[styles.passwordChecks, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
              <Text style={[styles.checksTitle, { color: colors.contentSecondary }]}>Password must include:</Text>
              {[
                { label: 'At least 8 characters', ok: passwordChecks.length },
                { label: 'One lowercase letter', ok: passwordChecks.lower },
                { label: 'One uppercase letter', ok: passwordChecks.upper },
                { label: 'One number', ok: passwordChecks.number },
                { label: 'One symbol', ok: passwordChecks.symbol },
              ].map((rule) => (
                <View key={rule.label} style={styles.checkRow}>
                  <Ionicons 
                    name={rule.ok ? 'checkmark-circle' : 'ellipse-outline'} 
                    size={16} 
                    color={rule.ok ? colors.success : colors.contentTertiary} 
                  />
                  <Text style={[styles.checkText, { color: rule.ok ? colors.success : colors.contentTertiary }]}>
                    {rule.label}
                  </Text>
                </View>
              ))}
            </View>

            <Button 
              onPress={handleChangePassword} 
              loading={loading} 
              disabled={loading || !allChecksPassed || !confirmPassword || newPassword !== confirmPassword}
              fullWidth
            >
              Update Password
            </Button>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    height: 44,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backBtn: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  backLabel: { fontSize: 17, marginLeft: 2 },
  headerTitle: { fontSize: 17, fontWeight: '600' },
  placeholder: { flex: 1 },
  content: { padding: Spacing.base, paddingBottom: 40 },
  form: { gap: Spacing.md },
  passwordChecks: {
    padding: Spacing.md,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    gap: Spacing.sm,
  },
  checksTitle: { fontSize: Typography.caption, marginBottom: Spacing.xs, fontWeight: '600' },
  checkRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  checkText: { fontSize: Typography.caption, flex: 1 },
})