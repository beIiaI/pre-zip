import { View, Text, StyleSheet, ScrollView, Pressable, Linking, Alert } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import { useTheme } from '@/contexts/ThemeContext'
import { Spacing, Typography, BorderRadius } from '@/constants/theme'

type HelpItem = {
  question: string
  answer: string
  route?: string
}

type HelpSection = {
  title: string
  icon: string
  items: HelpItem[]
}

const sections: HelpSection[] = [
  {
    title: 'Account',
    icon: 'person-outline',
    items: [
      {
        question: 'Update your profile',
        answer: 'Go to Profile > Edit Profile to change your name, bio, or avatar.',
        route: '/profile/edit',
      },
      {
        question: 'Reset your password',
        answer: 'Use the Sign In screen to request a password reset email, or change it in Settings > Password.',
        route: '/settings/password',
      },
      {
        question: 'Invite-only access',
        answer: 'Members can nominate in batches of 5 from Settings > Invite Users.',
        route: '/settings/invites',
      },
    ],
  },
  {
    title: 'Verification',
    icon: 'shield-checkmark-outline',
    items: [
      {
        question: 'University verification',
        answer: 'Add your university email to unlock campus-only events and features.',
        route: '/settings/verification',
      },
    ],
  },
  {
    title: 'Events',
    icon: 'calendar-outline',
    items: [
      {
        question: 'Create an event',
        answer: 'Tap the + button in Events to host a public or campus-only event.',
      },
      {
        question: 'RSVP status',
        answer: 'Your RSVP is visible on the event detail screen and in your Events list.',
      },
    ],
  },
  {
    title: 'Safety',
    icon: 'alert-circle-outline',
    items: [
      {
        question: 'Emergency contacts',
        answer: 'Add trusted contacts so they can receive your panic alerts.',
        route: '/settings/emergency',
      },
      {
        question: 'Blocked users',
        answer: 'Manage your block list from Privacy settings.',
        route: '/settings/blocked',
      },
    ],
  },
  {
    title: 'Reporting & Blocking',
    icon: 'lock-closed-outline',
    items: [
      {
        question: 'Report a profile',
        answer: 'Open any profile and use the Report option in the overflow menu.',
        route: '/settings/report',
      },
    ],
  },
]

export default function HelpSettings() {
  const { colors } = useTheme()
  const router = useRouter()

  const handleAction = async (url: string) => {
    const supported = await Linking.canOpenURL(url)
    if (supported) {
      await Linking.openURL(url)
    } else {
      Alert.alert('Error', 'Cannot open this link')
    }
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
        <Pressable onPress={() => router.back()} hitSlop={8} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
          <Text style={[styles.backLabel, { color: colors.contentPrimary }]}>Settings</Text>
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.contentPrimary }]}>Help & Support</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {sections.map((section) => (
          <View key={section.title} style={styles.section}>
            <View style={styles.sectionHeader}>
              <Ionicons name={section.icon as any} size={14} color={colors.contentTertiary} />
              <Text style={[styles.sectionTitle, { color: colors.contentTertiary }]}>
                {section.title.toUpperCase()}
              </Text>
            </View>
            <View style={styles.sectionCards}>
              {section.items.map((item) => (
                <Pressable
                  key={item.question}
                  onPress={() => {
                    if (item.route) router.push(item.route as any)
                  }}
                  disabled={!item.route}
                  style={({ pressed }) => [
                    styles.faqCard,
                    { backgroundColor: colors.surfaceSecondary },
                    pressed && item.route && { opacity: 0.8 },
                  ]}
                >
                  <Text style={[styles.faqQuestion, { color: colors.contentPrimary }]}>
                    {item.question}
                  </Text>
                  <Text style={[styles.faqAnswer, { color: colors.contentSecondary }]}>
                    {item.answer}
                  </Text>
                  {item.route && (
                    <Text style={[styles.faqLink, { color: colors.contentPrimary }]}>
                      Go to {section.title}
                    </Text>
                  )}
                </Pressable>
              ))}
            </View>
          </View>
        ))}

        {/* Contact section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Ionicons name="mail-outline" size={14} color={colors.contentTertiary} />
            <Text style={[styles.sectionTitle, { color: colors.contentTertiary }]}>
              CONTACT
            </Text>
          </View>
          <View style={[styles.contactCard, { backgroundColor: colors.surfaceSecondary }]}>
            <Text style={[styles.contactDesc, { color: colors.contentSecondary }]}>
              Need help with your account or an urgent safety issue? Reach us directly.
            </Text>
            <Pressable
              onPress={() => handleAction('mailto:support@presocial.app?subject=Pre%20Support')}
              style={[styles.contactButton, { backgroundColor: colors.contentPrimary }]}
            >
              <Ionicons name="mail" size={16} color={colors.contentInverse} />
              <Text style={[styles.contactText, { color: colors.contentInverse }]}>Contact Support</Text>
            </Pressable>
          </View>
        </View>

        <View style={styles.versionInfo}>
          <Text style={[styles.versionText, { color: colors.contentTertiary }]}>pre v1.0.0 · Mobile</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    height: 44,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backBtn: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  backLabel: { fontSize: 17, marginLeft: 2 },
  headerTitle: { fontSize: 17, fontWeight: '600' },
  placeholder: { flex: 1 },
  content: { paddingBottom: 40 },

  // Sections
  section: {
    marginTop: Spacing.lg,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: Spacing.base + Spacing.base,
    paddingBottom: 6,
  },
  sectionTitle: {
    fontSize: 13,
    fontWeight: '400',
    letterSpacing: -0.08,
  },
  sectionCards: {
    paddingHorizontal: Spacing.base,
    gap: Spacing.sm,
  },

  // FAQ cards
  faqCard: {
    borderRadius: BorderRadius.lg,
    padding: Spacing.base,
    gap: 4,
  },
  faqQuestion: {
    fontSize: Typography.body,
    fontWeight: '500',
  },
  faqAnswer: {
    fontSize: Typography.callout,
    lineHeight: 20,
  },
  faqLink: {
    fontSize: Typography.callout,
    textDecorationLine: 'underline',
    marginTop: Spacing.sm,
  },

  // Contact card
  contactCard: {
    marginHorizontal: Spacing.base,
    borderRadius: BorderRadius.lg,
    padding: Spacing.base,
    gap: Spacing.md,
  },
  contactDesc: {
    fontSize: Typography.callout,
    lineHeight: 20,
  },
  contactButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.md,
  },
  contactText: { fontSize: Typography.callout, fontWeight: '600' },

  versionInfo: {
    alignItems: 'center',
    paddingVertical: Spacing.lg,
  },
  versionText: { fontSize: Typography.caption },
})
