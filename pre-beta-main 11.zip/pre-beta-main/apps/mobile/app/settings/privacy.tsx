import { View, Text, StyleSheet, ScrollView, Pressable, Switch, Alert } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { Spacing, Typography, BorderRadius } from '@/constants/theme'
import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'

type Visibility = 'public' | 'friends' | 'private'
type MessageRequests = 'everyone' | 'friends' | 'off'

export default function PrivacySettings() {
  const { colors } = useTheme()
  const { profile, refreshProfile } = useAuth()
  const router = useRouter()
  const [loading, setLoading] = useState(false)

  const [profileVisibility, setProfileVisibility] = useState<Visibility>('public')
  const [messageRequests, setMessageRequests] = useState<MessageRequests>('everyone')
  const [activityStatus, setActivityStatus] = useState(true)
  const [readReceipts, setReadReceipts] = useState(true)
  const [locationSharing, setLocationSharing] = useState(true)
  const [searchable, setSearchable] = useState(true)
  const [showCollege, setShowCollege] = useState(false)

  useEffect(() => {
    if (!profile) return
    setProfileVisibility((profile.profile_visibility as Visibility) || 'public')
    setMessageRequests((profile.message_requests as MessageRequests) || 'everyone')
    setActivityStatus(profile.show_activity_status ?? true)
    setReadReceipts(profile.show_read_receipts ?? true)
    setLocationSharing(profile.show_location ?? true)
    setSearchable(profile.discoverable ?? true)
    setShowCollege(profile.show_college ?? false)
  }, [profile])

  const updateSetting = async (updates: Record<string, any>) => {
    if (!profile || loading) return
    setLoading(true)
    Haptics.selectionAsync()

    const { error } = await supabase
      .from('profiles')
      .update(updates as any)
      .eq('id', profile.id)

    if (error) {
      Alert.alert('Error', error.message)
    } else {
      await refreshProfile()
    }
    setLoading(false)
  }

  const visibilityOptions: { value: Visibility; label: string; desc: string }[] = [
    { value: 'public', label: 'Public', desc: 'Anyone on pre can see your profile' },
    { value: 'friends', label: 'Friends Only', desc: 'Only people you follow' },
    { value: 'private', label: 'Private', desc: 'Only you can see your full profile' },
  ]

  const messageOptions: { value: MessageRequests; label: string; desc: string }[] = [
    { value: 'everyone', label: 'Everyone', desc: 'Any member can message you' },
    { value: 'friends', label: 'Friends Only', desc: 'Only people you follow' },
    { value: 'off', label: 'Nobody', desc: 'Block all new message requests' },
  ]

  const toggleItems: {
    key: string
    label: string
    desc: string
    icon: string
    iconColor: string
    value: boolean
    onToggle: (v: boolean) => void
    disabled?: boolean
  }[] = [
    {
      key: 'activity',
      label: 'Activity Status',
      desc: 'Show when you\'re online',
      icon: 'radio-button-on',
      iconColor: '#34C759',
      value: activityStatus,
      onToggle: (v) => { setActivityStatus(v); updateSetting({ show_activity_status: v }) },
    },
    {
      key: 'receipts',
      label: 'Read Receipts',
      desc: 'Show when you\'ve read messages',
      icon: 'checkmark-done-outline',
      iconColor: '#007AFF',
      value: readReceipts,
      onToggle: (v) => { setReadReceipts(v); updateSetting({ show_read_receipts: v }) },
    },
    {
      key: 'location',
      label: 'Location Sharing',
      desc: 'Share your city with others',
      icon: 'location-outline',
      iconColor: '#FF9500',
      value: locationSharing,
      onToggle: (v) => { setLocationSharing(v); updateSetting({ show_location: v }) },
    },
    {
      key: 'discover',
      label: 'Discoverable',
      desc: 'Allow others to find you via search',
      icon: 'eye-outline',
      iconColor: '#5856D6',
      value: searchable,
      onToggle: (v) => { setSearchable(v); updateSetting({ discoverable: v }) },
    },
    {
      key: 'college',
      label: 'Show College',
      desc: profile?.university_verified ? 'Display your college on profile' : 'Verify university first',
      icon: 'school-outline',
      iconColor: '#AF52DE',
      value: showCollege,
      onToggle: (v) => { setShowCollege(v); updateSetting({ show_college: v }) },
      disabled: !profile?.university_verified,
    },
  ]

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      {/* Native iOS nav bar */}
      <View style={[styles.navBar, { borderBottomColor: colors.borderSecondary }]}>
        <Pressable onPress={() => router.back()} hitSlop={8} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
          <Text style={[styles.backLabel, { color: colors.contentPrimary }]}>Settings</Text>
        </Pressable>
        <Text style={[styles.navTitle, { color: colors.contentPrimary }]}>Privacy</Text>
        <View style={styles.navSpacer} />
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>

        {/* Profile Visibility */}
        <View style={styles.group}>
          <View style={styles.sectionHeader}>
            <Ionicons name={profileVisibility === 'public' ? 'eye-outline' : 'eye-off-outline'} size={14} color={colors.contentTertiary} />
            <Text style={[styles.groupHeader, { color: colors.contentTertiary }]}>
              PROFILE VISIBILITY
            </Text>
          </View>
          <View style={[styles.groupCard, { backgroundColor: colors.surfaceSecondary }]}>
            {visibilityOptions.map((opt, i) => {
              const active = profileVisibility === opt.value
              return (
                <Pressable
                  key={opt.value}
                  onPress={() => {
                    setProfileVisibility(opt.value)
                    updateSetting({ profile_visibility: opt.value })
                  }}
                  style={({ pressed }) => [
                    styles.selectRow,
                    pressed && { backgroundColor: colors.surfaceElevated },
                  ]}
                >
                  <View style={[
                    styles.selectContent,
                    i < visibilityOptions.length - 1 && {
                      borderBottomWidth: StyleSheet.hairlineWidth,
                      borderBottomColor: colors.borderSecondary,
                    },
                  ]}>
                    <View style={styles.selectText}>
                      <Text style={[styles.selectLabel, { color: colors.contentPrimary }]}>{opt.label}</Text>
                      <Text style={[styles.selectDesc, { color: colors.contentTertiary }]}>{opt.desc}</Text>
                    </View>
                    {active && (
                      <Ionicons name="checkmark" size={20} color="#007AFF" />
                    )}
                  </View>
                </Pressable>
              )
            })}
          </View>
          <Text style={[styles.groupFooter, { color: colors.contentTertiary }]}>
            Controls who can see your profile details, posts, and activity.
          </Text>
        </View>

        {/* Message Requests */}
        <View style={styles.group}>
          <View style={styles.sectionHeader}>
            <Ionicons name="lock-closed-outline" size={14} color={colors.contentTertiary} />
            <Text style={[styles.groupHeader, { color: colors.contentTertiary }]}>
              MESSAGE REQUESTS
            </Text>
          </View>
          <View style={[styles.groupCard, { backgroundColor: colors.surfaceSecondary }]}>
            {messageOptions.map((opt, i) => {
              const active = messageRequests === opt.value
              return (
                <Pressable
                  key={opt.value}
                  onPress={() => {
                    setMessageRequests(opt.value)
                    updateSetting({ message_requests: opt.value })
                  }}
                  style={({ pressed }) => [
                    styles.selectRow,
                    pressed && { backgroundColor: colors.surfaceElevated },
                  ]}
                >
                  <View style={[
                    styles.selectContent,
                    i < messageOptions.length - 1 && {
                      borderBottomWidth: StyleSheet.hairlineWidth,
                      borderBottomColor: colors.borderSecondary,
                    },
                  ]}>
                    <View style={styles.selectText}>
                      <Text style={[styles.selectLabel, { color: colors.contentPrimary }]}>{opt.label}</Text>
                      <Text style={[styles.selectDesc, { color: colors.contentTertiary }]}>{opt.desc}</Text>
                    </View>
                    {active && (
                      <Ionicons name="checkmark" size={20} color="#007AFF" />
                    )}
                  </View>
                </Pressable>
              )
            })}
          </View>
        </View>

        {/* Toggles */}
        <View style={styles.group}>
          <Text style={[styles.groupHeader, { color: colors.contentTertiary }]}>
            ACTIVITY & SHARING
          </Text>
          <View style={[styles.groupCard, { backgroundColor: colors.surfaceSecondary }]}>
            {toggleItems.map((item, i) => (
              <View
                key={item.key}
                style={[
                  styles.toggleRow,
                  { paddingLeft: Spacing.md },
                ]}
              >
                <View style={[styles.toggleIcon, { backgroundColor: item.iconColor }]}>
                  <Ionicons name={item.icon as any} size={16} color="#FFFFFF" />
                </View>
                <View style={[
                  styles.toggleContent,
                  i < toggleItems.length - 1 && {
                    borderBottomWidth: StyleSheet.hairlineWidth,
                    borderBottomColor: colors.borderSecondary,
                  },
                ]}>
                  <View style={styles.toggleText}>
                    <Text style={[
                      styles.toggleLabel,
                      { color: item.disabled ? colors.contentTertiary : colors.contentPrimary },
                    ]}>
                      {item.label}
                    </Text>
                    <Text style={[styles.toggleDesc, { color: colors.contentTertiary }]}>{item.desc}</Text>
                  </View>
                  <Switch
                    value={item.value}
                    onValueChange={item.onToggle}
                    trackColor={{ false: colors.surfaceTertiary, true: '#34C759' }}
                    disabled={loading || item.disabled}
                  />
                </View>
              </View>
            ))}
          </View>
        </View>

        {/* Blocked Users */}
        <View style={styles.group}>
          <View style={[styles.groupCard, { backgroundColor: colors.surfaceSecondary }]}>
            <Pressable
              onPress={() => router.push('/settings/blocked' as any)}
              style={({ pressed }) => [
                styles.navRow,
                pressed && { backgroundColor: colors.surfaceElevated },
              ]}
            >
              <View style={[styles.navRowIcon, { backgroundColor: '#FF3B30' }]}>
                <Ionicons name="ban-outline" size={18} color="#FFFFFF" />
              </View>
              <View style={styles.navRowContent}>
                <Text style={[styles.navRowLabel, { color: colors.contentPrimary }]}>Blocked Users</Text>
                <Ionicons name="chevron-forward" size={16} color={colors.contentTertiary} />
              </View>
            </Pressable>
          </View>
          <Text style={[styles.groupFooter, { color: colors.contentTertiary }]}>
            Blocked users cannot see your profile, send you messages, or interact with your content.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1 },

  // Nav bar
  navBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    height: 44,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  backLabel: { fontSize: 17, marginLeft: 2 },
  navTitle: { fontSize: 17, fontWeight: '600' },
  navSpacer: { flex: 1 },

  scrollContent: {
    paddingBottom: 60,
  },

  // Groups
  group: {
    marginTop: Spacing.lg,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: Spacing.base + Spacing.base,
    paddingBottom: 6,
  },
  groupHeader: {
    fontSize: 13,
    fontWeight: '400',
    letterSpacing: -0.08,
  },
  groupCard: {
    marginHorizontal: Spacing.base,
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
  },
  groupFooter: {
    fontSize: 13,
    paddingHorizontal: Spacing.base + Spacing.base,
    paddingTop: 6,
    lineHeight: 18,
  },

  // Select rows (radio-style)
  selectRow: {
    paddingLeft: Spacing.base,
  },
  selectContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    minHeight: 52,
    paddingRight: Spacing.base,
    paddingVertical: 10,
  },
  selectText: { flex: 1, gap: 2 },
  selectLabel: { fontSize: 17 },
  selectDesc: { fontSize: 13 },

  // Toggle rows
  toggleIcon: {
    width: 29,
    height: 29,
    borderRadius: 7,
    justifyContent: 'center',
    alignItems: 'center',
  },
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  toggleContent: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    minHeight: 52,
    paddingRight: Spacing.base,
    paddingVertical: 8,
  },
  toggleText: { flex: 1, gap: 2, paddingRight: Spacing.md },
  toggleLabel: { fontSize: 17 },
  toggleDesc: { fontSize: 13 },

  // Nav row (blocked users)
  navRow: {
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: 44,
    paddingLeft: Spacing.md,
  },
  navRowIcon: {
    width: 29,
    height: 29,
    borderRadius: 7,
    justifyContent: 'center',
    alignItems: 'center',
  },
  navRowContent: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    minHeight: 44,
    paddingLeft: Spacing.md,
    paddingRight: Spacing.md,
  },
  navRowLabel: { fontSize: 17 },
})
