import { View, Text, StyleSheet, Pressable, Dimensions } from 'react-native'
import { useRouter } from 'expo-router'
import { SafeAreaView } from 'react-native-safe-area-context'
import Animated, {
  useAnimatedStyle,
  withRepeat,
  withTiming,
  withSequence,
  withSpring,
  Easing,
  useSharedValue,
  withDelay,
} from 'react-native-reanimated'
import { useEffect } from 'react'
import { useTheme } from '@/contexts/ThemeContext'
import { PreWordmark } from '@/components/ui/PreWordmark'
import { Spacing } from '@/constants/theme'
import * as Haptics from 'expo-haptics'

const { width, height } = Dimensions.get('window')

// Circle configuration - subtle, floating feel
const circles = [
  { size: 280, x: 0.18, y: 0.28, duration: 10000, delay: 0 },
  { size: 240, x: 0.78, y: 0.42, duration: 12000, delay: 600 },
  { size: 200, x: 0.52, y: 0.58, duration: 14000, delay: 300 },
]

const accents = [
  { size: 120, x: 0.22, y: 0.72, duration: 8000, delay: 1200 },
  { size: 100, x: 0.82, y: 0.22, duration: 8000, delay: 1800 },
]

// Floating circle with subtle iOS-native animation
function FloatingCircle({
  size,
  x,
  y,
  duration,
  delay,
  borderColor,
}: {
  size: number
  x: number
  y: number
  duration: number
  delay: number
  borderColor: string
}) {
  const scale = useSharedValue(0.8)
  const opacity = useSharedValue(0)
  const translateY = useSharedValue(0)

  const left = x * width - size / 2
  const top = y * height - size / 2

  useEffect(() => {
    // Soft entrance
    scale.value = withDelay(
      delay,
      withSpring(1, { damping: 20, stiffness: 40 })
    )
    opacity.value = withDelay(
      delay,
      withTiming(0.35, { duration: 800, easing: Easing.out(Easing.ease) })
    )

    // Gentle floating - iOS feel
    translateY.value = withDelay(
      delay + 800,
      withRepeat(
        withSequence(
          withTiming(-8, { duration: duration / 2, easing: Easing.inOut(Easing.ease) }),
          withTiming(8, { duration: duration / 2, easing: Easing.inOut(Easing.ease) })
        ),
        -1,
        true
      )
    )
  }, [delay, duration])

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }, { translateY: translateY.value }],
    opacity: opacity.value,
  }))

  return (
    <Animated.View
      style={[
        styles.circle,
        {
          width: size,
          height: size,
          left,
          top,
          borderColor,
        },
        animatedStyle,
      ]}
    />
  )
}

// Pulsing accent circle
function PulsingAccent({
  size,
  x,
  y,
  duration,
  delay,
  borderColor,
}: {
  size: number
  x: number
  y: number
  duration: number
  delay: number
  borderColor: string
}) {
  const scale = useSharedValue(0.6)
  const opacity = useSharedValue(0)

  const left = x * width - size / 2
  const top = y * height - size / 2

  useEffect(() => {
    // Gentle pulse animation
    scale.value = withDelay(
      delay,
      withRepeat(
        withSequence(
          withTiming(1.1, { duration: duration * 0.4, easing: Easing.out(Easing.ease) }),
          withTiming(1.3, { duration: duration * 0.6, easing: Easing.inOut(Easing.ease) })
        ),
        -1,
        false
      )
    )

    opacity.value = withDelay(
      delay,
      withRepeat(
        withSequence(
          withTiming(0.3, { duration: duration * 0.4, easing: Easing.out(Easing.ease) }),
          withTiming(0, { duration: duration * 0.6, easing: Easing.inOut(Easing.ease) })
        ),
        -1,
        false
      )
    )
  }, [delay, duration])

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
    opacity: opacity.value,
  }))

  return (
    <Animated.View
      style={[
        styles.circle,
        {
          width: size,
          height: size,
          left,
          top,
          borderColor,
        },
        animatedStyle,
      ]}
    />
  )
}

// Content entrance animation - iOS spring feel
function AnimatedContent({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  const translateY = useSharedValue(16)
  const opacity = useSharedValue(0)

  useEffect(() => {
    translateY.value = withDelay(delay, withSpring(0, { damping: 20, stiffness: 90 }))
    opacity.value = withDelay(delay, withTiming(1, { duration: 400, easing: Easing.out(Easing.ease) }))
  }, [delay])

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }],
    opacity: opacity.value,
  }))

  return <Animated.View style={animatedStyle}>{children}</Animated.View>
}

/**
 * Splash screen for unauthenticated users
 * iOS-native feel with subtle floating circles
 */
export default function SplashScreen() {
  const router = useRouter()
  const { colors, isDark } = useTheme()

  // Circle border color - subtle tint
  const circleBorderColor = isDark ? 'rgba(58, 124, 175, 0.6)' : 'rgba(199, 229, 255, 0.8)'

  const handleSignUp = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)
    router.push('/auth?mode=signup')
  }

  const handleSignIn = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)
    router.push('/auth?mode=signin')
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.surfacePrimary }]}>
      {/* Animated circle field */}
      <View style={styles.circleField} pointerEvents="none">
        {circles.map((circle, index) => (
          <FloatingCircle
            key={`circle-${index}`}
            {...circle}
            borderColor={circleBorderColor}
          />
        ))}
        {accents.map((accent, index) => (
          <PulsingAccent
            key={`accent-${index}`}
            {...accent}
            borderColor={circleBorderColor}
          />
        ))}
      </View>

      {/* Content */}
      <SafeAreaView style={styles.contentContainer} edges={['top', 'bottom']}>
        <View style={styles.content}>
          {/* Wordmark at top */}
          <AnimatedContent delay={100}>
            <View style={styles.brandingTop}>
              <PreWordmark size="hero" color={colors.contentPrimary} />
            </View>
          </AnimatedContent>

          {/* Main content at bottom */}
          <View style={styles.bottomContent}>
            <AnimatedContent delay={200}>
              {/* Small tagline */}
              <Text style={[styles.eyebrow, { color: colors.contentSecondary }]}>
                INVITATION-ONLY SOCIAL CLUB
              </Text>
            </AnimatedContent>

            <AnimatedContent delay={300}>
              {/* Main headline */}
              <Text style={[styles.headline, { color: colors.contentPrimary }]}>
                Find your people.{'\n'}Enter by nomination.
              </Text>
            </AnimatedContent>

            {/* CTA Buttons */}
            <AnimatedContent delay={400}>
              <View style={styles.actions}>
                <Pressable
                  onPress={handleSignUp}
                  style={({ pressed }) => [
                    styles.primaryButton,
                    { 
                      backgroundColor: isDark ? '#FFFFFF' : '#1A1A1A',
                      transform: [{ scale: pressed ? 0.98 : 1 }],
                    },
                  ]}
                  testID="splash-signup-button"
                >
                  <Text
                    style={[
                      styles.primaryButtonText,
                      { color: isDark ? '#1A1A1A' : '#FFFFFF' },
                    ]}
                  >
                    Request access
                  </Text>
                </Pressable>

                <Text style={[styles.signinText, { color: colors.contentSecondary }]}>
                  Already have an account?{' '}
                  <Text
                    onPress={handleSignIn}
                    style={[styles.signinLink, { color: colors.contentPrimary }]}
                  >
                    Sign in
                  </Text>
                </Text>
              </View>
            </AnimatedContent>
          </View>
        </View>
      </SafeAreaView>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  circleField: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    overflow: 'hidden',
  },
  circle: {
    position: 'absolute',
    borderRadius: 9999,
    borderWidth: 1.5,
  },
  contentContainer: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: Spacing.lg,
  },
  brandingTop: {
    paddingTop: 56,
    alignItems: 'center',
  },
  bottomContent: {
    flex: 1,
    justifyContent: 'flex-end',
    paddingBottom: 40,
  },
  eyebrow: {
    fontSize: 10,
    fontWeight: '600',
    letterSpacing: 2.5,
    textAlign: 'center',
    marginBottom: 12,
  },
  headline: {
    fontSize: 36,
    fontWeight: '600',
    lineHeight: 42,
    textAlign: 'center',
    marginBottom: 40,
    letterSpacing: -0.5,
  },
  actions: {
    gap: 20,
  },
  primaryButton: {
    height: 54,
    borderRadius: 27,
    justifyContent: 'center',
    alignItems: 'center',
  },
  primaryButtonText: {
    fontSize: 16,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  signinText: {
    fontSize: 15,
    textAlign: 'center',
  },
  signinLink: {
    fontWeight: '600',
  },
})
