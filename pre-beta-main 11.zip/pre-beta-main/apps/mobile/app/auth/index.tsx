import { useState, useEffect } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
  Linking,
} from 'react-native'
import { useRouter, useLocalSearchParams } from 'expo-router'
import { SafeAreaView } from 'react-native-safe-area-context'
import * as AppleAuthentication from 'expo-apple-authentication'
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withDelay,
  Easing,
  FadeIn,
  SlideInDown,
} from 'react-native-reanimated'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { PreWordmark } from '@/components/ui/PreWordmark'
import { validateEmail, validatePassword, normalizeInviteCode } from '@/utils/validation'
import AsyncStorage from '@react-native-async-storage/async-storage'
import { validateInvite, requestPasswordReset } from '@/lib/api'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

type Mode = 'signin' | 'signup'
type Step = 'email' | 'otp'

// Animated wrapper for entrance animations
function AnimatedEnter({
  children,
  delay = 0,
  style,
}: {
  children: React.ReactNode
  delay?: number
  style?: object
}) {
  const translateY = useSharedValue(12)
  const opacity = useSharedValue(0)

  useEffect(() => {
    translateY.value = withDelay(
      delay,
      withTiming(0, {
        duration: 420,
        easing: Easing.bezier(0.16, 1, 0.3, 1),
      })
    )
    opacity.value = withDelay(
      delay,
      withTiming(1, {
        duration: 420,
        easing: Easing.bezier(0.16, 1, 0.3, 1),
      })
    )
  }, [delay])

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }],
    opacity: opacity.value,
  }))

  return <Animated.View style={[animatedStyle, style]}>{children}</Animated.View>
}

export default function AuthScreen() {
  const router = useRouter()
  const params = useLocalSearchParams()
  const { colors } = useTheme()
  const { signIn, signUp, signInWithApple } = useAuth()

  const [mode, setMode] = useState<Mode>((params.mode as Mode) || 'signin')
  const [step, setStep] = useState<Step>('email')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [inviteCode, setInviteCode] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [resending, setResending] = useState(false)
  const [forgotLoading, setForgotLoading] = useState(false)
  const [appleLoading, setAppleLoading] = useState(false)
  const [inviteValidating, setInviteValidating] = useState(false)
  const [inviteDetails, setInviteDetails] = useState<any>(null)

  const validateInviteForSignup = async (targetEmail: string) => {
    const normalizedCode = normalizeInviteCode(inviteCode)
    if (!normalizedCode) {
      setError('An invite code is required to create an account.')
      return false
    }
    if (!validateEmail(targetEmail)) {
      setError('Please enter a valid email before validating your invite.')
      return false
    }

    setInviteValidating(true)
    const result = await validateInvite(normalizedCode, targetEmail)
    setInviteValidating(false)

    if (result.error) {
      setInviteDetails(null)
      setError(result.error)
      return false
    }

    const invite = result.data?.invite
    if (!invite?.code) {
      setInviteDetails(null)
      setError('Invite validation returned an invalid response.')
      return false
    }

    setInviteCode(invite.code)
    setInviteDetails(invite)
    return true
  }

  const handleSubmit = async () => {
    setError(null)
    setSuccess(null)

    const normalizedEmail = email.trim().toLowerCase()

    if (!validateEmail(normalizedEmail)) {
      setError('Please enter a valid email address')
      return
    }

    if (mode === 'signup') {
      const passwordValidation = validatePassword(password)
      if (!passwordValidation.valid) {
        setError(passwordValidation.error || 'Invalid password')
        return
      }

      if (password !== confirmPassword) {
        setError('Passwords do not match')
        return
      }

      const inviteValid = await validateInviteForSignup(normalizedEmail)
      if (!inviteValid) {
        return
      }
    }

    setLoading(true)

    try {
      if (mode === 'signin') {
        const result = await signIn(normalizedEmail, password)
        if (result.error) {
          setError(result.error.message)
          setLoading(false)
        } else {
          setLoading(false)
          router.replace('/')
        }
      } else {
        const result = await signUp(normalizedEmail, password)
        if (result.error) {
          const message = result.error.message || 'Unable to create account'
          if (
            message.toLowerCase().includes('already exists') ||
            message.toLowerCase().includes('already registered')
          ) {
            setError('Account already exists — please sign in')
            setMode('signin')
          } else {
            setError(message)
          }
          setLoading(false)
        } else {
          // Store invite code for claiming after email confirmation
          await AsyncStorage.setItem(
            'pre-pending-invite',
            JSON.stringify({ code: normalizeInviteCode(inviteCode), email: normalizedEmail })
          )
          setSuccess('Check your email and tap the confirmation link to finish signing up.')
          setStep('otp')
          setLoading(false)
        }
      }
    } catch {
      setError('An unexpected error occurred. Please try again.')
      setLoading(false)
    }
  }

  const handleResendEmail = async () => {
    setError(null)
    setSuccess(null)

    const normalizedEmail = email.trim().toLowerCase()
    if (!validateEmail(normalizedEmail)) {
      setError('Enter your email to resend the verification email.')
      return
    }

    setResending(true)
    try {
      const { error: resendError } = await supabase.auth.resend({
        type: 'signup',
        email: normalizedEmail,
      })

      if (resendError) {
        throw new Error(resendError.message || 'Unable to resend email.')
      }

      setSuccess('Verification email resent.')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to resend email.')
    } finally {
      setResending(false)
    }
  }

  const handleForgotPassword = async () => {
    setError(null)
    setSuccess(null)

    const normalizedEmail = email.trim().toLowerCase()
    if (!validateEmail(normalizedEmail)) {
      setError('Enter your email to reset your password')
      return
    }

    setForgotLoading(true)
    const result = await requestPasswordReset(normalizedEmail)
    setForgotLoading(false)

    if (result.error) {
      setError(result.error)
    } else {
      setSuccess('If an account exists for that email, password reset instructions have been sent.')
    }
  }

  const handleAppleSignIn = async () => {
    setError(null)

    if (mode === 'signup') {
      const normalizedCode = normalizeInviteCode(inviteCode)
      if (!normalizedCode) {
        setError('An invite code is required to create an account.')
        return
      }
      // Store invite code so it can be claimed after Apple auth completes
      await AsyncStorage.setItem(
        'pre-pending-invite',
        JSON.stringify({ code: normalizedCode, email: '' })
      )
    }

    setAppleLoading(true)
    const result = await signInWithApple()
    setAppleLoading(false)
    if (result.error && result.error.message !== 'cancelled') {
      setError(result.error.message)
    }
  }

  const passwordChecks = {
    length: password.length >= 8,
    lower: /[a-z]/.test(password),
    upper: /[A-Z]/.test(password),
    number: /[0-9]/.test(password),
    symbol: /[^A-Za-z0-9]/.test(password),
  }

  if (step === 'otp') {
    return (
      <SafeAreaView
        style={[styles.container, { backgroundColor: colors.surfacePrimary }]}
        edges={['top', 'bottom']}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
        >
          <AnimatedEnter delay={0}>
            <View style={styles.header}>
              <PreWordmark size="medium" color={colors.contentPrimary} />
            </View>
          </AnimatedEnter>

          <View style={styles.content}>
            <AnimatedEnter delay={50}>
              <TouchableOpacity onPress={() => setStep('email')} style={styles.backButton}>
                <Text style={[styles.backText, { color: colors.contentPrimary }]}>← Back</Text>
              </TouchableOpacity>
            </AnimatedEnter>

            <AnimatedEnter delay={100}>
              <View style={styles.titleSection}>
                <Text style={[styles.title, { color: colors.contentPrimary }]}>
                  Check your email
                </Text>
                <Text style={[styles.subtitle, { color: colors.contentSecondary }]}>
                  We sent a confirmation link to verify your account.
                </Text>
              </View>
            </AnimatedEnter>

            {error && (
              <AnimatedEnter delay={150}>
                <View
                  style={[
                    styles.alert,
                    { backgroundColor: colors.error + '15', borderColor: colors.error },
                  ]}
                >
                  <Text style={[styles.alertText, { color: colors.error }]}>{error}</Text>
                </View>
              </AnimatedEnter>
            )}

            {success && (
              <AnimatedEnter delay={150}>
                <View
                  style={[
                    styles.alert,
                    { backgroundColor: colors.success + '15', borderColor: colors.success },
                  ]}
                >
                  <Text style={[styles.alertText, { color: colors.success }]}>{success}</Text>
                </View>
              </AnimatedEnter>
            )}

            <AnimatedEnter delay={200}>
              <View style={[styles.emailCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
                <Text style={styles.emailCardIcon}>✉️</Text>
                <Text style={[styles.emailCardTitle, { color: colors.contentPrimary }]}>
                  Confirmation sent
                </Text>
                <Text style={[styles.emailCardBody, { color: colors.contentSecondary }]}>
                  Open the email we sent to{' '}
                  <Text style={{ color: colors.contentPrimary, fontWeight: '500' }}>{email}</Text>
                  {' '}and tap the confirmation button to continue.
                </Text>
              </View>
            </AnimatedEnter>

            <AnimatedEnter delay={250}>
              <View style={styles.form}>
                <Button
                  onPress={() => Linking.openURL('message://')}
                  fullWidth
                >
                  Open Mail App
                </Button>

                <Button
                  onPress={handleResendEmail}
                  loading={resending}
                  variant="secondary"
                  fullWidth
                >
                  Resend Verification Email
                </Button>

                <TouchableOpacity
                  onPress={() => {
                    setStep('email')
                    setError(null)
                    setSuccess(null)
                  }}
                  style={styles.changeEmailButton}
                >
                  <Text style={[styles.changeEmailText, { color: colors.contentTertiary }]}>
                    Change email
                  </Text>
                </TouchableOpacity>
              </View>
            </AnimatedEnter>
          </View>
        </ScrollView>
      </SafeAreaView>
    )
  }

  return (
    <SafeAreaView
      style={[styles.container, { backgroundColor: colors.surfacePrimary }]}
      edges={['top', 'bottom']}
    >
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
        >
          <AnimatedEnter delay={0}>
            <View style={styles.header}>
              <PreWordmark size="medium" color={colors.contentPrimary} />
            </View>
          </AnimatedEnter>

          <View style={styles.content}>
            <AnimatedEnter delay={50}>
              <View style={styles.titleSection}>
                <Text style={[styles.title, { color: colors.contentPrimary }]}>
                  {mode === 'signin' ? 'Sign in' : 'Private Sign Up'}
                </Text>
                <Text style={[styles.subtitle, { color: colors.contentSecondary }]}>
                  {mode === 'signup'
                    ? 'pre is invite-only. Existing members nominate in batches of 5.'
                    : 'Connect with people who share your interests'}
                </Text>
              </View>
            </AnimatedEnter>

            {/* Mode Toggle */}
            <AnimatedEnter delay={100}>
              <View style={[styles.segmentedControl, { backgroundColor: colors.surfaceSecondary }]}>
                <TouchableOpacity
                  style={[
                    styles.segment,
                    mode === 'signin' && {
                      backgroundColor: colors.surfacePrimary,
                      borderColor: colors.borderPrimary,
                    },
                  ]}
                  onPress={() => {
                    setMode('signin')
                    setError(null)
                    setSuccess(null)
                  }}
                >
                  <Text
                    style={[
                      styles.segmentText,
                      {
                        color: mode === 'signin' ? colors.contentPrimary : colors.contentSecondary,
                      },
                    ]}
                  >
                    Sign in
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[
                    styles.segment,
                    mode === 'signup' && {
                      backgroundColor: colors.surfacePrimary,
                      borderColor: colors.borderPrimary,
                    },
                  ]}
                  onPress={() => {
                    setMode('signup')
                    setError(null)
                    setSuccess(null)
                  }}
                >
                  <Text
                    style={[
                      styles.segmentText,
                      {
                        color: mode === 'signup' ? colors.contentPrimary : colors.contentSecondary,
                      },
                    ]}
                  >
                    Sign up
                  </Text>
                </TouchableOpacity>
              </View>
            </AnimatedEnter>

            {error && (
              <AnimatedEnter delay={150}>
                <View
                  style={[
                    styles.alert,
                    { backgroundColor: colors.error + '15', borderColor: colors.error },
                  ]}
                >
                  <Text style={[styles.alertText, { color: colors.error }]}>{error}</Text>
                </View>
              </AnimatedEnter>
            )}

            {success && (
              <AnimatedEnter delay={150}>
                <View
                  style={[
                    styles.alert,
                    { backgroundColor: colors.success + '15', borderColor: colors.success },
                  ]}
                >
                  <Text style={[styles.alertText, { color: colors.success }]}>{success}</Text>
                </View>
              </AnimatedEnter>
            )}

            <AnimatedEnter delay={200}>
              <View style={styles.form}>
                <Input
                  label="Email"
                  placeholder="Email address"
                  value={email}
                  onChangeText={setEmail}
                  autoCapitalize="none"
                  autoCorrect={false}
                  keyboardType="email-address"
                  textContentType="emailAddress"
                  testID="auth-email-input"
                />

                <Input
                  label="Password"
                  placeholder={mode === 'signin' ? 'Enter your password' : 'Create a password'}
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry
                  showPasswordToggle
                  textContentType={mode === 'signin' ? 'password' : 'newPassword'}
                  testID="auth-password-input"
                />

                {mode === 'signup' && (
                  <>
                    <Input
                      label="Invite Code"
                      placeholder="Invitation code"
                      value={inviteCode}
                      onChangeText={(text) => {
                        setInviteCode(normalizeInviteCode(text))
                        setInviteDetails(null)
                      }}
                      autoCapitalize="characters"
                      autoCorrect={false}
                      testID="auth-invite-input"
                    />

                    {inviteDetails && (
                      <Text style={[styles.inviteSuccess, { color: colors.success }]}>
                        {inviteDetails.inviteeEmail
                          ? `Reserved by ${inviteDetails.inviterName} for ${inviteDetails.inviteeEmail}`
                          : `Invite shared by ${inviteDetails.inviterName}`}
                      </Text>
                    )}

                    <Input
                      label="Confirm Password"
                      placeholder="Re-enter your password"
                      value={confirmPassword}
                      onChangeText={setConfirmPassword}
                      secureTextEntry
                      showPasswordToggle
                      textContentType="newPassword"
                      testID="auth-confirm-password-input"
                    />

                    <View
                      style={[
                        styles.passwordChecks,
                        {
                          backgroundColor: colors.surfaceSecondary,
                          borderColor: colors.borderSecondary,
                        },
                      ]}
                    >
                      <Text
                        style={[styles.passwordChecksTitle, { color: colors.contentSecondary }]}
                      >
                        Password must include:
                      </Text>
                      {[
                        { label: 'At least 8 characters', ok: passwordChecks.length },
                        { label: 'One lowercase letter', ok: passwordChecks.lower },
                        { label: 'One uppercase letter', ok: passwordChecks.upper },
                        { label: 'One number', ok: passwordChecks.number },
                        { label: 'One symbol', ok: passwordChecks.symbol },
                      ].map((rule) => (
                        <Text
                          key={rule.label}
                          style={[
                            styles.passwordCheckText,
                            { color: rule.ok ? colors.success : colors.contentTertiary },
                          ]}
                        >
                          {rule.ok ? '✓' : '○'} {rule.label}
                        </Text>
                      ))}
                    </View>
                  </>
                )}

                {mode === 'signin' && (
                  <TouchableOpacity
                    onPress={handleForgotPassword}
                    disabled={forgotLoading}
                    style={styles.forgotButton}
                  >
                    <Text style={[styles.forgotText, { color: colors.contentPrimary }]}>
                      {forgotLoading ? 'Sending reset email…' : 'Forgot password?'}
                    </Text>
                  </TouchableOpacity>
                )}

                <Button
                  onPress={handleSubmit}
                  loading={loading}
                  disabled={loading || inviteValidating}
                  fullWidth
                  testID="auth-submit-button"
                >
                  {mode === 'signin' ? 'Sign In' : 'Create Account'}
                </Button>

                {Platform.OS === 'ios' && (
                  <>
                    <View style={styles.dividerRow}>
                      <View
                        style={[styles.dividerLine, { backgroundColor: colors.borderPrimary }]}
                      />
                      <Text style={[styles.dividerText, { color: colors.contentTertiary }]}>or</Text>
                      <View
                        style={[styles.dividerLine, { backgroundColor: colors.borderPrimary }]}
                      />
                    </View>

                    <AppleAuthentication.AppleAuthenticationButton
                      buttonType={
                        mode === 'signup'
                          ? AppleAuthentication.AppleAuthenticationButtonType.SIGN_UP
                          : AppleAuthentication.AppleAuthenticationButtonType.SIGN_IN
                      }
                      buttonStyle={AppleAuthentication.AppleAuthenticationButtonStyle.BLACK}
                      cornerRadius={BorderRadius.lg}
                      style={styles.appleButton}
                      onPress={handleAppleSignIn}
                    />
                  </>
                )}
              </View>
            </AnimatedEnter>

            <AnimatedEnter delay={300}>
              <Text style={[styles.disclaimer, { color: colors.contentTertiary }]}>
                By continuing, you agree to our Terms of Service and Privacy Policy
              </Text>
            </AnimatedEnter>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: Spacing.lg,
  },
  header: {
    paddingTop: Spacing.lg,
    paddingBottom: Spacing.xl,
    alignItems: 'center',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
  },
  backButton: {
    marginBottom: Spacing.md,
  },
  backText: {
    fontSize: Typography.body,
  },
  titleSection: {
    marginBottom: Spacing.xl,
  },
  title: {
    fontSize: Typography.display,
    fontWeight: Typography.medium,
    marginBottom: Spacing.sm,
  },
  subtitle: {
    fontSize: Typography.body,
  },
  segmentedControl: {
    flexDirection: 'row',
    padding: 3,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.lg,
  },
  segment: {
    flex: 1,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'transparent',
  },
  segmentText: {
    fontSize: Typography.callout,
    fontWeight: '500',
  },
  alert: {
    padding: Spacing.md,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: Spacing.md,
  },
  alertText: {
    fontSize: Typography.callout,
  },
  form: {
    gap: Spacing.md,
  },
  forgotButton: {
    alignSelf: 'flex-start',
    marginTop: -Spacing.sm,
  },
  forgotText: {
    fontSize: Typography.callout,
    textDecorationLine: 'underline',
  },
  inviteSuccess: {
    fontSize: Typography.caption,
    marginTop: -Spacing.sm,
  },
  passwordChecks: {
    padding: Spacing.md,
    borderRadius: 12,
    borderWidth: 1,
    gap: Spacing.xs,
  },
  passwordChecksTitle: {
    fontSize: Typography.caption,
    marginBottom: Spacing.xs,
  },
  passwordCheckText: {
    fontSize: Typography.caption,
  },
  emailCard: {
    padding: Spacing.lg,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: Spacing.md,
    alignItems: 'center' as const,
    gap: Spacing.sm,
  },
  emailCardIcon: {
    fontSize: 28,
  },
  emailCardTitle: {
    fontSize: Typography.body,
    fontWeight: '600' as const,
  },
  emailCardBody: {
    fontSize: Typography.callout,
    textAlign: 'center' as const,
    lineHeight: 20,
  },
  changeEmailButton: {
    alignItems: 'center' as const,
    paddingVertical: Spacing.sm,
  },
  changeEmailText: {
    fontSize: Typography.caption,
    textDecorationLine: 'underline' as const,
  },
  disclaimer: {
    fontSize: Typography.caption,
    textAlign: 'center',
    marginTop: Spacing.xl,
  },
  dividerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginVertical: Spacing.xs,
  },
  dividerLine: { flex: 1, height: 1 },
  dividerText: { fontSize: Typography.caption },
  appleButton: { height: 50, width: '100%' },
})
