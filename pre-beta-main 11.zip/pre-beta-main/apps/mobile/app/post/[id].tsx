import React, { useState, useCallback, useEffect } from 'react'
import {
  View,
  Text,
  FlatList,
  Pressable,
  StyleSheet,
  Image,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ActivityIndicator,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useLocalSearchParams, useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'
import { HapticFeedback } from '@/components/ui/RefreshControl'

// ─── Helpers ──────────────────────────────────────────────────────────────────

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return 'just now'
  if (mins < 60) return `${mins}m`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24) return `${hrs}h`
  const days = Math.floor(hrs / 24)
  if (days < 7) return `${days}d`
  return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
}

function getInitials(name: string | null, username: string | null): string {
  if (name) return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
  if (username) return username[0].toUpperCase()
  return '?'
}

// ─── Types ────────────────────────────────────────────────────────────────────

interface Post {
  id: string
  body: string
  image_url: string | null
  like_count: number
  comment_count: number
  created_at: string
  author: { id: string; full_name: string | null; username: string | null; avatar_url: string | null }
}

interface Comment {
  id: string
  body: string
  created_at: string
  author: { id: string; full_name: string | null; username: string | null; avatar_url: string | null }
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function PostDetailScreen() {
  const { id: postId } = useLocalSearchParams<{ id: string }>()
  const router = useRouter()
  const { colors } = useTheme()
  const { user } = useAuth()

  const [post, setPost] = useState<Post | null>(null)
  const [comments, setComments] = useState<Comment[]>([])
  const [loading, setLoading] = useState(true)
  const [liked, setLiked] = useState(false)
  const [likeCount, setLikeCount] = useState(0)
  const [commentDraft, setCommentDraft] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const loadPost = useCallback(async () => {
    if (!postId || !user) return

    const [postRes, commentsRes, likeRes] = await Promise.all([
      supabase
        .from('posts')
        .select('id, body, image_url, like_count, comment_count, created_at, author_id, profiles!posts_author_id_fkey(id, full_name, username, avatar_url)')
        .eq('id', postId)
        .single(),
      supabase
        .from('post_comments')
        .select('id, body, created_at, author_id, profiles!post_comments_author_id_fkey(id, full_name, username, avatar_url)')
        .eq('post_id', postId)
        .order('created_at', { ascending: true })
        .limit(100),
      supabase
        .from('post_likes')
        .select('post_id')
        .eq('post_id', postId)
        .eq('user_id', user.id)
        .maybeSingle(),
    ])

    if (postRes.data) {
      const p = postRes.data as any
      setPost({
        id: p.id,
        body: p.body,
        image_url: p.image_url,
        like_count: p.like_count,
        comment_count: p.comment_count,
        created_at: p.created_at,
        author: p.profiles,
      })
      setLikeCount(p.like_count)
    }

    if (commentsRes.data) {
      setComments(
        (commentsRes.data as any[]).map(c => ({
          id: c.id,
          body: c.body,
          created_at: c.created_at,
          author: c.profiles,
        }))
      )
    }

    setLiked(!!likeRes.data)
    setLoading(false)
  }, [postId, user])

  useEffect(() => { loadPost() }, [loadPost])

  const handleLike = async () => {
    if (!user || !postId) return
    HapticFeedback.light()

    const wasLiked = liked
    setLiked(!wasLiked)
    setLikeCount(prev => wasLiked ? Math.max(0, prev - 1) : prev + 1)

    if (wasLiked) {
      await supabase.from('post_likes').delete().eq('post_id', postId).eq('user_id', user.id)
    } else {
      await supabase.from('post_likes').insert({ post_id: postId, user_id: user.id })
    }
  }

  const handleComment = async () => {
    const text = commentDraft.trim()
    if (!text || !user || !postId || submitting) return

    setSubmitting(true)
    HapticFeedback.light()

    const { data, error } = await supabase
      .from('post_comments')
      .insert({ post_id: postId, author_id: user.id, body: text })
      .select('id, body, created_at, author_id, profiles!post_comments_author_id_fkey(id, full_name, username, avatar_url)')
      .single()

    setSubmitting(false)

    if (error) {
      HapticFeedback.error()
      Alert.alert('Error', 'Failed to post comment.')
      return
    }

    if (data) {
      const c = data as any
      setComments(prev => [...prev, { id: c.id, body: c.body, created_at: c.created_at, author: c.profiles }])
    }
    setCommentDraft('')
  }

  const handleDeletePost = () => {
    if (!post || post.author.id !== user?.id) return
    Alert.alert('Delete Post', 'Are you sure you want to delete this post?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          await supabase.from('posts').delete().eq('id', post.id)
          HapticFeedback.success()
          router.back()
        },
      },
    ])
  }

  // ─── Render ──────────────────────────────────────────────────────────────────

  const renderComment = ({ item }: { item: Comment }) => {
    const initials = getInitials(item.author?.full_name ?? null, item.author?.username ?? null)
    return (
      <View style={styles.commentRow}>
        {item.author?.avatar_url ? (
          <Image source={{ uri: item.author.avatar_url }} style={styles.commentAvatar} />
        ) : (
          <View style={[styles.commentAvatar, styles.commentAvatarFallback, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
            <Text style={[styles.commentAvatarText, { color: colors.contentPrimary }]}>{initials}</Text>
          </View>
        )}
        <View style={styles.commentContent}>
          <View style={styles.commentHeader}>
            <Text style={[styles.commentName, { color: colors.contentPrimary }]}>
              {item.author?.full_name || item.author?.username || 'Member'}
            </Text>
            <Text style={[styles.commentTime, { color: colors.contentTertiary }]}>
              {timeAgo(item.created_at)}
            </Text>
          </View>
          <Text style={[styles.commentBody, { color: colors.contentSecondary }]}>{item.body}</Text>
        </View>
      </View>
    )
  }

  if (loading) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
        <View style={styles.centered}>
          <ActivityIndicator color={colors.contentTertiary} />
        </View>
      </SafeAreaView>
    )
  }

  if (!post) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
        <View style={styles.centered}>
          <Text style={{ color: colors.contentTertiary }}>Post not found</Text>
        </View>
      </SafeAreaView>
    )
  }

  const authorInitials = getInitials(post.author?.full_name ?? null, post.author?.username ?? null)
  const isOwnPost = post.author?.id === user?.id

  const ListHeader = () => (
    <View style={styles.postSection}>
      {/* Author row */}
      <View style={styles.authorRow}>
        <Pressable
          onPress={() => {
            if (post.author?.id && post.author.id !== user?.id) {
              router.push(`/user/${post.author.id}` as any)
            }
          }}
          style={styles.authorInfo}
        >
          {post.author?.avatar_url ? (
            <Image source={{ uri: post.author.avatar_url }} style={styles.postAvatar} />
          ) : (
            <View style={[styles.postAvatar, styles.postAvatarFallback, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
              <Text style={[styles.postAvatarText, { color: colors.contentPrimary }]}>{authorInitials}</Text>
            </View>
          )}
          <View>
            <Text style={[styles.postAuthorName, { color: colors.contentPrimary }]}>
              {post.author?.full_name || 'Member'}
            </Text>
            <Text style={[styles.postTime, { color: colors.contentTertiary }]}>
              {post.author?.username ? `@${post.author.username} · ` : ''}{timeAgo(post.created_at)}
            </Text>
          </View>
        </Pressable>
        {isOwnPost && (
          <Pressable onPress={handleDeletePost} style={styles.moreBtn}>
            <Ionicons name="trash-outline" size={18} color={colors.contentTertiary} />
          </Pressable>
        )}
      </View>

      {/* Body */}
      <Text style={[styles.postBody, { color: colors.contentPrimary }]}>{post.body}</Text>

      {/* Image */}
      {post.image_url && (
        <Image source={{ uri: post.image_url }} style={styles.postImage} resizeMode="cover" />
      )}

      {/* Actions */}
      <View style={[styles.actions, { borderTopColor: colors.borderSecondary, borderBottomColor: colors.borderSecondary }]}>
        <Pressable onPress={handleLike} style={styles.actionBtn}>
          <Ionicons
            name={liked ? 'heart' : 'heart-outline'}
            size={20}
            color={liked ? colors.error : colors.contentSecondary}
          />
          <Text style={[styles.actionCount, { color: colors.contentSecondary }]}>{likeCount}</Text>
        </Pressable>
        <View style={styles.actionBtn}>
          <Ionicons name="chatbubble-outline" size={18} color={colors.contentSecondary} />
          <Text style={[styles.actionCount, { color: colors.contentSecondary }]}>{comments.length}</Text>
        </View>
      </View>

      {/* Comments header */}
      {comments.length > 0 && (
        <Text style={[styles.commentsLabel, { color: colors.contentTertiary }]}>COMMENTS</Text>
      )}
    </View>
  )

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.contentPrimary }]}>Post</Text>
        <View style={{ width: 36 }} />
      </View>

      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <FlatList
          data={comments}
          keyExtractor={item => item.id}
          renderItem={renderComment}
          ListHeaderComponent={ListHeader}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyComments}>
              <Text style={[styles.emptyText, { color: colors.contentTertiary }]}>
                No comments yet. Be the first.
              </Text>
            </View>
          }
        />

        {/* Comment input */}
        <View style={[styles.commentInputBar, { borderTopColor: colors.borderSecondary, backgroundColor: colors.surfacePrimary }]}>
          <TextInput
            value={commentDraft}
            onChangeText={setCommentDraft}
            placeholder="Add a comment..."
            placeholderTextColor={colors.contentTertiary}
            style={[styles.commentInput, { color: colors.contentPrimary, backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}
            maxLength={300}
            multiline
          />
          <Pressable
            onPress={handleComment}
            disabled={!commentDraft.trim() || submitting}
            style={[
              styles.sendBtn,
              { backgroundColor: commentDraft.trim() ? colors.contentPrimary : colors.surfaceElevated },
            ]}
          >
            <Ionicons
              name="arrow-up"
              size={16}
              color={commentDraft.trim() ? colors.contentInverse : colors.contentTertiary}
            />
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1 },
  flex: { flex: 1 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.sm,
    borderBottomWidth: 1,
  },
  headerTitle: { fontSize: Typography.callout, fontWeight: '600' },
  backBtn: { width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },

  listContent: { paddingBottom: 100 },

  postSection: { paddingHorizontal: Spacing.base },

  authorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: Spacing.base,
  },
  authorInfo: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, flex: 1 },
  postAvatar: { width: 42, height: 42, borderRadius: 21 },
  postAvatarFallback: { borderWidth: 1, justifyContent: 'center', alignItems: 'center' },
  postAvatarText: { fontSize: 15, fontWeight: '600' },
  postAuthorName: { fontSize: Typography.callout, fontWeight: '600' },
  postTime: { fontSize: Typography.caption },
  moreBtn: { padding: Spacing.sm },

  postBody: {
    fontSize: Typography.body,
    lineHeight: Typography.body * 1.55,
    marginBottom: Spacing.base,
  },
  postImage: {
    width: '100%',
    height: 280,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.base,
  },

  actions: {
    flexDirection: 'row',
    gap: Spacing.lg,
    paddingVertical: Spacing.md,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    marginBottom: Spacing.base,
  },
  actionBtn: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
  actionCount: { fontSize: Typography.callout },

  commentsLabel: {
    fontSize: Typography.labelCaps,
    fontWeight: '700',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    marginBottom: Spacing.md,
  },

  commentRow: {
    flexDirection: 'row',
    gap: Spacing.md,
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.sm,
  },
  commentAvatar: { width: 30, height: 30, borderRadius: 15 },
  commentAvatarFallback: { borderWidth: 1, justifyContent: 'center', alignItems: 'center' },
  commentAvatarText: { fontSize: 10, fontWeight: '600' },
  commentContent: { flex: 1, gap: 2 },
  commentHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  commentName: { fontSize: Typography.callout, fontWeight: '600' },
  commentTime: { fontSize: Typography.caption },
  commentBody: { fontSize: Typography.callout, lineHeight: Typography.callout * 1.5 },

  emptyComments: { padding: Spacing.xl, alignItems: 'center' },
  emptyText: { fontSize: Typography.callout },

  commentInputBar: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: Spacing.sm,
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.sm,
    borderTopWidth: 1,
  },
  commentInput: {
    flex: 1,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    paddingHorizontal: Spacing.md,
    paddingVertical: 10,
    fontSize: Typography.callout,
    maxHeight: 100,
  },
  sendBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 2,
  },
})
