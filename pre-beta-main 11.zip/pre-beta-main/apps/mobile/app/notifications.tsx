import { View, Text, StyleSheet, FlatList, TouchableOpacity, RefreshControl } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import { useTheme } from '@/contexts/ThemeContext'
import { Spacing, Typography, BorderRadius } from '@/constants/theme'
import { useState, useEffect, useCallback } from 'react'
import {
  getNotifications,
  markAllNotificationsAsRead,
  markNotificationAsRead,
} from '@/lib/notifications'

interface Notification {
  id: string
  type: string
  title: string
  body: string
  data: any
  read_at: string | null
  created_at: string
}

export default function NotificationsScreen() {
  const { colors } = useTheme()
  const router = useRouter()
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  useEffect(() => {
    loadNotifications()
  }, [])

  const loadNotifications = async () => {
    const result = await getNotifications()
    if (result.error) {
      setNotifications([])
    } else {
      setNotifications(
        (result.notifications || []).map((notification) => ({
          ...notification,
          read_at: notification.read_at ?? null,
        }))
      )
    }
    setLoading(false)
    setRefreshing(false)
  }

  const handleRefresh = useCallback(() => {
    setRefreshing(true)
    loadNotifications()
  }, [])

  const handleNotificationPress = async (notification: Notification) => {
    // Mark as read
    if (!notification.read_at) {
      await markNotificationAsRead(notification.id)
      loadNotifications()
    }

    // Navigate based on type
    if (notification.data?.thread_id) {
      router.push(`/conversation/${notification.data.thread_id}` as any)
    } else if (notification.data?.event_id) {
      router.push(`/event/${notification.data.event_id}` as any)
    } else if (notification.data?.circle_id) {
      router.push(`/circle/${notification.data.circle_id}` as any)
    }
  }

  const handleMarkAllRead = async () => {
    await markAllNotificationsAsRead()
    loadNotifications()
  }

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp)
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const minutes = Math.floor(diff / 60000)
    const hours = Math.floor(minutes / 60)
    const days = Math.floor(hours / 24)

    if (minutes < 1) return 'Just now'
    if (minutes < 60) return `${minutes}m ago`
    if (hours < 24) return `${hours}h ago`
    if (days < 7) return `${days}d ago`
    return date.toLocaleDateString()
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color={colors.contentPrimary} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.contentPrimary }]}>Notifications</Text>
        {notifications.some(n => !n.read_at) && (
          <TouchableOpacity onPress={handleMarkAllRead}>
            <Text style={[styles.markAllRead, { color: colors.accentPrimary }]}>Mark all read</Text>
          </TouchableOpacity>
        )}
        {!notifications.some(n => !n.read_at) && <View style={styles.placeholder} />}
      </View>

      <FlatList
        data={notifications}
        keyExtractor={(item) => item.id}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />
        }
        contentContainerStyle={styles.list}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => handleNotificationPress(item)}
            style={[
              styles.notificationItem,
              {
                backgroundColor: item.read_at ? colors.surfacePrimary : colors.surfaceSecondary,
                borderColor: colors.borderSecondary,
              },
            ]}
          >
            <View style={styles.notificationContent}>
              <View style={styles.notificationHeader}>
                <Text style={[styles.notificationTitle, { color: colors.contentPrimary }]}>
                  {item.title}
                </Text>
                {!item.read_at && (
                  <View style={[styles.unreadDot, { backgroundColor: colors.accentPrimary }]} />
                )}
              </View>
              <Text style={[styles.notificationBody, { color: colors.contentSecondary }]} numberOfLines={2}>
                {item.body}
              </Text>
              <Text style={[styles.notificationTime, { color: colors.contentTertiary }]}>
                {formatTime(item.created_at)}
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.contentTertiary} />
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <View style={[styles.emptyIcon, { backgroundColor: colors.surfaceSecondary }]}>
              <Ionicons name="notifications-outline" size={32} color={colors.contentTertiary} />
            </View>
            <Text style={[styles.emptyTitle, { color: colors.contentPrimary }]}>
              No notifications
            </Text>
            <Text style={[styles.emptyDesc, { color: colors.contentSecondary }]}>
              You're all caught up! Check back later for updates.
            </Text>
          </View>
        }
      />
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
  },
  backButton: { width: 40, height: 40, justifyContent: 'center' },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', flex: 1, textAlign: 'center' },
  markAllRead: { fontSize: Typography.callout },
  placeholder: { width: 40 },
  list: { padding: Spacing.base },
  notificationItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.base,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    marginBottom: Spacing.sm,
  },
  notificationContent: { flex: 1, gap: 4 },
  notificationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  notificationTitle: { fontSize: Typography.body, fontWeight: '600', flex: 1 },
  unreadDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  notificationBody: { fontSize: Typography.callout },
  notificationTime: { fontSize: Typography.caption },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: Spacing.xxl * 2,
    gap: Spacing.sm,
  },
  emptyIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  emptyTitle: { fontSize: Typography.headline, fontWeight: '600' },
  emptyDesc: { fontSize: Typography.body, maxWidth: 260, textAlign: 'center' },
})
