import { Stack, SplashScreen, useRouter } from 'expo-router'
import { StatusBar } from 'expo-status-bar'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { AuthProvider } from '@/contexts/AuthContext'
import { ThemeProvider, useTheme } from '@/contexts/ThemeContext'
import { useEffect, useRef } from 'react'
import { Platform, View } from 'react-native'
import { GestureHandlerRootView } from 'react-native-gesture-handler'
import * as SystemUI from 'expo-system-ui'
import * as Notifications from 'expo-notifications'
import { validateApiConfig, getApiBaseUrl } from '@/lib/api'
import { ConfigErrorScreen } from '@/components/ui/ConfigErrorScreen'

// ─── Foreground notification behaviour ──────────────────────────────────────
// Show banner + badge + sound even when the app is in the foreground.
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
})

// Prevent splash screen from auto-hiding
SplashScreen.preventAutoHideAsync()

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 5 * 60 * 1000, // 5 minutes
    },
  },
})

function RootLayoutContent() {
  const { colors, isDark } = useTheme()
  const router = useRouter()
  const responseListener = useRef<Notifications.Subscription>()

  // Check for configuration errors
  const configValidation = validateApiConfig()

  useEffect(() => {
    // Set system UI colors
    SystemUI.setBackgroundColorAsync(colors.surfacePrimary)
  }, [colors.surfacePrimary])

  useEffect(() => {
    // Hide splash screen once layout is ready
    const timer = setTimeout(() => {
      SplashScreen.hideAsync()
    }, 100)
    return () => clearTimeout(timer)
  }, [])

  // ─── Tap-to-navigate: when the user taps a push notification ──────────────
  useEffect(() => {
    // Handle notification that was tapped while app was killed / backgrounded
    Notifications.getLastNotificationResponseAsync().then((response) => {
      if (response) {
        navigateFromNotification(response.notification.request.content.data)
      }
    })

    // Handle notification taps while app is running
    responseListener.current = Notifications.addNotificationResponseReceivedListener(
      (response) => {
        navigateFromNotification(response.notification.request.content.data)
      },
    )

    return () => {
      if (responseListener.current) {
        Notifications.removeNotificationSubscription(responseListener.current)
      }
    }
  }, [])

  const navigateFromNotification = (data: Record<string, any> | undefined) => {
    if (!data) return
    if (data.thread_id) router.push(`/conversation/${data.thread_id}` as any)
    else if (data.post_id) router.push(`/post/${data.post_id}` as any)
    else if (data.circle_id) router.push(`/circle/${data.circle_id}` as any)
    else if (data.event_id) router.push(`/event/${data.event_id}` as any)
    else if (data.user_id) router.push(`/user/${data.user_id}` as any)
    else router.push('/notifications' as any)
  }

  // Show config error screen if validation fails
  if (!configValidation.valid) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.surfacePrimary }}>
        <StatusBar style={isDark ? 'light' : 'dark'} />
        <ConfigErrorScreen error={configValidation.error!} apiUrl={getApiBaseUrl()} />
      </View>
    )
  }

  return (
    <>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: colors.surfacePrimary },
          animation: Platform.OS === 'ios' ? 'ios_from_right' : 'slide_from_right',
          gestureEnabled: true,
          gestureDirection: 'horizontal',
          fullScreenGestureEnabled: true,
        }}
      >
        {/* Tab group - no animation when entering */}
        <Stack.Screen name="(tabs)" options={{ animation: 'none' }} />
        <Stack.Screen name="index" options={{ animation: 'none' }} />

        {/* Auth screens - fade for clean transitions */}
        <Stack.Screen name="auth" options={{ animation: 'fade', gestureEnabled: false }} />

        {/* Detail screens - native push (inherits default ios_from_right) */}
        <Stack.Screen name="event/[id]" />
        <Stack.Screen name="circle/[id]" />
        <Stack.Screen name="conversation/[id]" />
        <Stack.Screen name="user/[id]" />
        <Stack.Screen name="event-attendees/[id]" />
        <Stack.Screen name="notifications" />
        <Stack.Screen name="my-plans" />
        <Stack.Screen name="new-message" />

        {/* Post screens */}
        <Stack.Screen name="post/[id]" />
        <Stack.Screen
          name="create-post"
          options={{
            animation: 'slide_from_bottom',
            gestureDirection: 'vertical',
            fullScreenGestureEnabled: true,
            presentation: 'containedTransparentModal',
          }}
        />

        {/* Creation screens - slide up as modal with swipe-to-dismiss */}
        <Stack.Screen
          name="create-event"
          options={{
            animation: 'slide_from_bottom',
            gestureDirection: 'vertical',
            fullScreenGestureEnabled: true,
            presentation: 'containedTransparentModal',
          }}
        />
        <Stack.Screen
          name="create-circle"
          options={{
            animation: 'slide_from_bottom',
            gestureDirection: 'vertical',
            fullScreenGestureEnabled: true,
            presentation: 'containedTransparentModal',
          }}
        />

        {/* Edit screens */}
        <Stack.Screen name="edit-event/[id]" />
        <Stack.Screen name="edit-circle/[id]" />
        <Stack.Screen name="profile/edit" />

        {/* Settings screens - native push */}
        <Stack.Screen name="settings/privacy" />
        <Stack.Screen name="settings/password" />
        <Stack.Screen name="settings/blocked" />
        <Stack.Screen name="settings/emergency" />
        <Stack.Screen name="settings/verification" />
        <Stack.Screen name="settings/invites" />
        <Stack.Screen name="settings/help" />
        <Stack.Screen name="settings/report" />
      </Stack>
    </>
  )
}

export default function RootLayout() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <QueryClientProvider client={queryClient}>
        <ThemeProvider>
          <AuthProvider>
            <RootLayoutContent />
          </AuthProvider>
        </ThemeProvider>
      </QueryClientProvider>
    </GestureHandlerRootView>
  )
}
