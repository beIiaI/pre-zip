/**
 * Design tokens matching pre web app
 * Warm ceramic palette with tints and sophisticated gradients
 */

export const Colors = {
  light: {
    // Surface tokens - warm, elevated
    surfacePrimary: '#FFFCF8',
    surfaceSecondary: '#F3EEE7',
    surfaceTertiary: '#EAE4DC',
    surfaceElevated: '#FFFFFF',

    // Content tokens
    contentPrimary: '#181719',
    contentSecondary: '#5A5551',
    contentTertiary: '#807A75',
    contentInverse: '#FFFFFF',

    // Border tokens - subtle, rgba-based
    borderPrimary: 'rgba(24, 23, 25, 0.13)',
    borderSecondary: 'rgba(24, 23, 25, 0.08)',
    borderFocus: '#181719',

    // Accent tokens
    accent: '#1F2731',
    accentPrimary: '#1F2731',
    accentOnPrimary: '#FFFFFF',
    accentMuted: 'rgba(31, 39, 49, 0.1)',

    // Semantic colors
    success: '#22C55E',
    error: '#EF4444',
    warning: '#F59E0B',

    // Tints - your signature palette
    tintRose: '#F8EFF1',
    tintPeach: '#FCF1EB',
    tintHoney: '#F7F3E6',
    tintSage: '#EDF3EC',
    tintMist: '#EEF4F7',
    tintLilac: '#F2EFF8',

    // Dividers
    dividerStrong: 'rgba(24, 23, 25, 0.16)',
    dividerSoft: 'rgba(24, 23, 25, 0.08)',
    
    // Bento system
    bentoBorder: 'rgba(13, 13, 13, 0.34)',
    bentoDivider: 'rgba(13, 13, 13, 0.34)',
    bentoDividerSecondary: '#B7B7B7',
  },
  dark: {
    // Surface tokens
    surfacePrimary: '#111112',
    surfaceSecondary: '#1A1A1D',
    surfaceTertiary: '#222228',
    surfaceElevated: '#16161A',

    // Content tokens
    contentPrimary: '#F8F6F2',
    contentSecondary: '#B3ACA3',
    contentTertiary: '#8D877F',
    contentInverse: '#111112',

    // Border tokens
    borderPrimary: 'rgba(248, 246, 242, 0.16)',
    borderSecondary: 'rgba(248, 246, 242, 0.09)',
    borderFocus: '#F8F6F2',

    // Accent tokens
    accent: '#E6ECF3',
    accentPrimary: '#E6ECF3',
    accentOnPrimary: '#101217',
    accentMuted: 'rgba(230, 236, 243, 0.16)',

    // Semantic colors
    success: '#22C55E',
    error: '#EF4444',
    warning: '#F59E0B',

    // Tints - dark variants
    tintRose: '#232021',
    tintPeach: '#23211f',
    tintHoney: '#24231e',
    tintSage: '#202320',
    tintMist: '#202326',
    tintLilac: '#22222a',

    // Dividers
    dividerStrong: 'rgba(248, 246, 242, 0.2)',
    dividerSoft: 'rgba(248, 246, 242, 0.1)',
    
    // Bento system
    bentoBorder: 'rgba(248, 246, 242, 0.28)',
    bentoDivider: 'rgba(248, 246, 242, 0.28)',
    bentoDividerSecondary: 'rgba(183, 183, 183, 0.6)',
  },
  amoled: {
    // Pure black AMOLED mode
    surfacePrimary: '#000000',
    surfaceSecondary: '#0A0A0A',
    surfaceTertiary: '#141414',
    surfaceElevated: '#0A0A0A',

    // Content tokens
    contentPrimary: '#FFFFFF',
    contentSecondary: '#AAAAAA',
    contentTertiary: '#666666',
    contentInverse: '#000000',

    // Border tokens
    borderPrimary: 'rgba(255, 255, 255, 0.12)',
    borderSecondary: 'rgba(255, 255, 255, 0.06)',
    borderFocus: '#FFFFFF',

    // Accent tokens
    accent: '#E6ECF3',
    accentPrimary: '#E6ECF3',
    accentOnPrimary: '#000000',
    accentMuted: 'rgba(230, 236, 243, 0.18)',

    // Semantic colors
    success: '#22C55E',
    error: '#EF4444',
    warning: '#F59E0B',

    // Tints - AMOLED variants
    tintRose: '#150f12',
    tintPeach: '#15120f',
    tintHoney: '#14130d',
    tintSage: '#101411',
    tintMist: '#101317',
    tintLilac: '#12121a',

    // Dividers
    dividerStrong: 'rgba(255, 255, 255, 0.18)',
    dividerSoft: 'rgba(255, 255, 255, 0.08)',
    
    // Bento system
    bentoBorder: 'rgba(255, 255, 255, 0.3)',
    bentoDivider: 'rgba(255, 255, 255, 0.3)',
    bentoDividerSecondary: 'rgba(183, 183, 183, 0.5)',
  },
}

export const Typography = {
  // Font sizes (matching web scale exactly)
  display: 34,
  title: 26,
  headline: 20,
  body: 16,
  callout: 14,
  caption: 12,
  eyebrow: 10,
  labelCaps: 10, // Small uppercase labels

  // Line heights
  lineHeightHeading: 1.35,
  lineHeightBody: 1.5,
  lineHeightRelaxed: 1.6, // For longer text blocks

  // Font weights
  regular: '400' as const,
  medium: '500' as const,
  semibold: '600' as const,
  
  // Letter spacing
  letterSpacingLabel: 0.15,
  letterSpacingTight: 0,
  letterSpacingCaption: 0.02,
}

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  base: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
}

export const BorderRadius = {
  sm: 8,
  md: 12,
  lg: 20, // Updated to match web's card radius
  xl: 24,
  full: 9999,
  card: 20, // Bento card radius
  button: 16,
  input: 14,
  chip: 12,
}

export const Shadows = {
  subtle: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 2,
    elevation: 1,
  },
  card: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 2,
  },
  elevated: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 16,
    elevation: 4,
  },
}

