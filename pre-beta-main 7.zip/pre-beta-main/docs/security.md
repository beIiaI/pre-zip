# Security Hardening Checklist

Last updated: 2026-02-12

## Scope completed

- Auth/password safety for sign-up, sign-in, OTP verify/resend, forgot password, password update.
- API hardening for:
  - `/api/auth/*`
  - `/api/verification/*`
  - `/api/invites/*`
  - `/api/dms/*`
  - `/api/events/*` create/update/chat/rsvp paths
- Database/RLS hardening migration for DMs and sensitive verification surfaces.
- App-wide security headers in Next config.

## What changed

### 1) Auth and password safety

- Added shared password policy checks in `/Users/devansh/Developer/pre-beta/src/lib/security/password-policy.ts`:
  - minimum length `8`
  - requires lowercase, uppercase, number, symbol
  - blocks common/easy passwords and brand terms (`pre`, `presocial`, `password123`, etc.).
- Removed browser Supabase debug logging wrapper from `/Users/devansh/Developer/pre-beta/src/lib/supabase/client.ts` to avoid token/credential leakage in logs.
- Added/updated hardened auth routes:
  - `/Users/devansh/Developer/pre-beta/src/app/api/auth/sign-in/route.ts`
  - `/Users/devansh/Developer/pre-beta/src/app/api/auth/sign-up/route.ts`
  - `/Users/devansh/Developer/pre-beta/src/app/api/auth/otp/verify/route.ts`
  - `/Users/devansh/Developer/pre-beta/src/app/api/auth/otp/resend/route.ts`
  - `/Users/devansh/Developer/pre-beta/src/app/api/auth/password/forgot/route.ts`
  - `/Users/devansh/Developer/pre-beta/src/app/api/auth/password/update/route.ts`
  - `/Users/devansh/Developer/pre-beta/src/app/api/auth/2fa/status/route.ts` (readiness endpoint)
- Account-enumeration hardening:
  - sign-up/OTP/forgot flows use generic success messaging.
  - sign-in returns generic invalid-credentials responses.
- Added exponential backoff + request-level rate limits for auth endpoints.

### 2) Shared API security utilities

Added:

- `/Users/devansh/Developer/pre-beta/src/lib/security/api.ts`
- `/Users/devansh/Developer/pre-beta/src/lib/security/guards.ts`
- `/Users/devansh/Developer/pre-beta/src/lib/security/origin.ts`
- `/Users/devansh/Developer/pre-beta/src/lib/security/rate-limit.ts`
- `/Users/devansh/Developer/pre-beta/src/lib/security/validation.ts`

Behavior:

- request IDs on responses
- standardized client-safe error responses
- same-origin protection on mutating routes
- in-memory rate limiter (dev-safe fallback; see production note below)
- strict runtime body validation without trusting client `user_id`

### 3) Verification, invites, DMs, events API hardening

Hardened routes (validation + rate limits + ownership/auth checks + no raw DB error leakage):

- Verification:
  - `/Users/devansh/Developer/pre-beta/src/app/api/verification/university/request/route.ts`
  - `/Users/devansh/Developer/pre-beta/src/app/api/verification/university/confirm/route.ts`
  - `/Users/devansh/Developer/pre-beta/src/app/api/verification/university/graduation-year/route.ts`
  - `/Users/devansh/Developer/pre-beta/src/app/api/verification/university/unlock/route.ts`
  - `/Users/devansh/Developer/pre-beta/src/app/api/verification/college/route.ts`
  - Deprecated shims also rate-limited:
    - `/Users/devansh/Developer/pre-beta/src/app/api/verification/university/route.ts`
    - `/Users/devansh/Developer/pre-beta/src/app/api/verify/university/route.ts`

- Invites:
  - `/Users/devansh/Developer/pre-beta/src/app/api/invites/create/route.ts`
  - `/Users/devansh/Developer/pre-beta/src/app/api/invites/validate/route.ts`
  - `/Users/devansh/Developer/pre-beta/src/app/api/invites/claim/route.ts`
  - `/Users/devansh/Developer/pre-beta/src/app/api/invites/list/route.ts`
  - `/Users/devansh/Developer/pre-beta/src/app/api/invites/revoke/route.ts`

- DMs:
  - `/Users/devansh/Developer/pre-beta/src/app/api/dms/route.ts`
  - `/Users/devansh/Developer/pre-beta/src/app/api/dms/[id]/route.ts`
  - `/Users/devansh/Developer/pre-beta/src/app/api/dms/[id]/messages/route.ts`

- Events:
  - `/Users/devansh/Developer/pre-beta/src/app/api/events/route.ts`
  - `/Users/devansh/Developer/pre-beta/src/app/api/events/rsvp/route.ts`
  - `/Users/devansh/Developer/pre-beta/src/app/api/events/[id]/route.ts`
  - `/Users/devansh/Developer/pre-beta/src/app/api/events/[id]/chat/route.ts`

### 4) RLS, DM recursion fix, DB hardening

Added migration:

- `/Users/devansh/Developer/pre-beta/supabase/migrations/031_security_hardening.sql`

Key DB changes:

- Re-applies DM policies in a non-recursive way (no self-referential participant policy).
- Forces RLS on DM tables.
- Restricts DM access to authenticated participants only.
- Adds DM constraints + indexes (`body` non-empty/size, sender/thread indexes).
- Forces/reinforces RLS protections for `university_verifications` and private table access.
- Adds supporting FK/lookup indexes for hot paths.
- Adds constraints for events sanity (`max_attendees`, `ends_at >= starts_at`).
- Adds/standardizes `updated_at` triggers for core mutable tables.

### 5) Security headers

Updated:

- `/Users/devansh/Developer/pre-beta/next.config.js`

Headers added globally:

- `Content-Security-Policy`
- `X-Frame-Options: DENY`
- `X-Content-Type-Options: nosniff`
- `Referrer-Policy: strict-origin-when-cross-origin`
- `Permissions-Policy`

## Production note: rate limiter backend

Current limiter is in-memory (`/Users/devansh/Developer/pre-beta/src/lib/security/rate-limit.ts`).

- Good for local/dev and single-instance deployments.
- Not sufficient for horizontally scaled production.
- Recommended upgrade: Redis-backed limiter (e.g. Upstash) with shared counters.

## Manual security test plan

### A) Brute force / resend OTP rate limits

1. Hit `/api/auth/sign-in` repeatedly with wrong password for one email.
2. Verify responses become rate-limited (`429`) and include `retry-after`.
3. Hit `/api/auth/otp/resend` repeatedly and confirm rate limiting kicks in.

### B) Forgot password enumeration safety

1. Call `/api/auth/password/forgot` with an existing email.
2. Call it again with a random non-existing email.
3. Verify both return the same generic success message and status shape.

### C) DM privacy / participant-only access

1. Create DM thread between User A and User B.
2. As User C, call:
   - `/api/dms`
   - `/api/dms/{threadId}`
   - `/api/dms/{threadId}/messages` (POST)
3. Verify User C cannot read/write that thread/messages.

### D) Public profile output privacy

1. Hit public profile/search endpoints (`/api/users/search`, `/api/users/preview`, `/api/users/username`).
2. Verify payload excludes sensitive fields (no university email, no private verification tokens/data).

### E) Service role key exposure check

1. Search client bundle/source for `SUPABASE_SERVICE_ROLE_KEY`.
2. Verify service-role usage is server-only:
   - `/Users/devansh/Developer/pre-beta/src/lib/supabase/admin.ts` includes `import 'server-only'`.
3. Confirm no client component imports admin client.

