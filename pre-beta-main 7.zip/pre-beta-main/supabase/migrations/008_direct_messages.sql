-- ============================================
-- Direct Messages (1:1)
-- ============================================

CREATE TABLE IF NOT EXISTS public.dm_threads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.dm_threads
  ADD COLUMN IF NOT EXISTS id uuid,
  ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();

ALTER TABLE public.dm_threads
  ALTER COLUMN id SET DEFAULT gen_random_uuid(),
  ALTER COLUMN created_at SET DEFAULT now();

CREATE TABLE IF NOT EXISTS public.dm_participants (
  thread_id uuid NOT NULL REFERENCES public.dm_threads(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  last_read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (thread_id, user_id)
);

ALTER TABLE public.dm_participants
  ADD COLUMN IF NOT EXISTS thread_id uuid,
  ADD COLUMN IF NOT EXISTS user_id uuid,
  ADD COLUMN IF NOT EXISTS last_read_at timestamptz,
  ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();

CREATE INDEX IF NOT EXISTS dm_participants_user_id_idx ON public.dm_participants (user_id);
CREATE INDEX IF NOT EXISTS dm_participants_thread_id_idx ON public.dm_participants (thread_id);

CREATE TABLE IF NOT EXISTS public.dm_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id uuid NOT NULL REFERENCES public.dm_threads(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.dm_messages
  ADD COLUMN IF NOT EXISTS id uuid,
  ADD COLUMN IF NOT EXISTS thread_id uuid,
  ADD COLUMN IF NOT EXISTS sender_id uuid,
  ADD COLUMN IF NOT EXISTS content text,
  ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();

ALTER TABLE public.dm_messages
  ALTER COLUMN id SET DEFAULT gen_random_uuid(),
  ALTER COLUMN created_at SET DEFAULT now();

CREATE INDEX IF NOT EXISTS dm_messages_thread_id_idx ON public.dm_messages (thread_id);
CREATE INDEX IF NOT EXISTS dm_messages_created_at_idx ON public.dm_messages (created_at);

ALTER TABLE public.dm_threads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dm_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dm_messages ENABLE ROW LEVEL SECURITY;

-- Threads: only participants can view
DROP POLICY IF EXISTS dm_threads_select ON public.dm_threads;
CREATE POLICY dm_threads_select ON public.dm_threads
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM public.dm_participants p
      WHERE p.thread_id = dm_threads.id
        AND p.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS dm_threads_insert ON public.dm_threads;
CREATE POLICY dm_threads_insert ON public.dm_threads
  FOR INSERT TO authenticated
  WITH CHECK (true);

-- Participants: participants can read participant lists for their threads
DROP POLICY IF EXISTS dm_participants_select ON public.dm_participants;
CREATE POLICY dm_participants_select ON public.dm_participants
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM public.dm_participants p
      WHERE p.thread_id = dm_participants.thread_id
        AND p.user_id = auth.uid()
    )
  );

-- Participants: allow adding self; allow adding others if you already belong to the thread
DROP POLICY IF EXISTS dm_participants_insert ON public.dm_participants;
CREATE POLICY dm_participants_insert ON public.dm_participants
  FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    OR EXISTS (
      SELECT 1
      FROM public.dm_participants p
      WHERE p.thread_id = dm_participants.thread_id
        AND p.user_id = auth.uid()
    )
  );

-- Messages: only participants can read/send
DROP POLICY IF EXISTS dm_messages_select ON public.dm_messages;
CREATE POLICY dm_messages_select ON public.dm_messages
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM public.dm_participants p
      WHERE p.thread_id = dm_messages.thread_id
        AND p.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS dm_messages_insert ON public.dm_messages;
CREATE POLICY dm_messages_insert ON public.dm_messages
  FOR INSERT TO authenticated
  WITH CHECK (
    sender_id = auth.uid()
    AND EXISTS (
      SELECT 1
      FROM public.dm_participants p
      WHERE p.thread_id = dm_messages.thread_id
        AND p.user_id = auth.uid()
    )
  );
