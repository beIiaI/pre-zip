-- ============================================
-- Access invites: allow open/shareable links
-- ============================================

ALTER TABLE public.access_invites
  ALTER COLUMN invitee_email DROP NOT NULL;

UPDATE public.access_invites
SET invitee_email = NULL
WHERE invitee_email = '';
