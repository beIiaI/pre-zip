-- ============================================
-- Founder + Early Supporter dual badge model
-- ============================================

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS founder_number integer;

-- Migrate legacy founder #000 representation off early_supporter_number.
-- If multiple founders still carry legacy #0 and no founder #000 exists yet,
-- keep #000 on the earliest account and clear the rest.
WITH existing_zero AS (
  SELECT COUNT(*)::int AS count_zero
  FROM public.profiles
  WHERE founder_number = 0
),
ranked_legacy_zero AS (
  SELECT id, row_number() OVER (ORDER BY created_at ASC, id ASC) AS rn
  FROM public.profiles
  WHERE is_founder = true
    AND founder_number IS NULL
    AND early_supporter_number = 0
)
UPDATE public.profiles p
SET founder_number = CASE
      WHEN ranked_legacy_zero.rn = 1 AND (SELECT count_zero FROM existing_zero) = 0 THEN 0
      ELSE p.founder_number
    END,
    early_supporter_number = NULL
FROM ranked_legacy_zero
WHERE p.id = ranked_legacy_zero.id;

-- Keep data migration-safe before adding strict constraints/indexes.
UPDATE public.profiles
SET early_supporter_number = NULL
WHERE early_supporter_number IS NOT NULL
  AND (early_supporter_number < 1 OR early_supporter_number > 250);

UPDATE public.profiles
SET founder_number = NULL
WHERE founder_number IS NOT NULL
  AND (founder_number < 0 OR founder_number > 999);

-- Keep first-assigned row for duplicate numbers; clear later duplicates.
WITH ranked_founders AS (
  SELECT id,
         row_number() OVER (
           PARTITION BY founder_number
           ORDER BY created_at ASC, id ASC
         ) AS rn
  FROM public.profiles
  WHERE founder_number IS NOT NULL
)
UPDATE public.profiles p
SET founder_number = NULL
FROM ranked_founders r
WHERE p.id = r.id
  AND r.rn > 1;

WITH ranked_supporters AS (
  SELECT id,
         row_number() OVER (
           PARTITION BY early_supporter_number
           ORDER BY created_at ASC, id ASC
         ) AS rn
  FROM public.profiles
  WHERE early_supporter_number IS NOT NULL
)
UPDATE public.profiles p
SET early_supporter_number = NULL
FROM ranked_supporters r
WHERE p.id = r.id
  AND r.rn > 1;

ALTER TABLE public.profiles
  DROP CONSTRAINT IF EXISTS profiles_founder_number_range;

ALTER TABLE public.profiles
  ADD CONSTRAINT profiles_founder_number_range
  CHECK (
    founder_number IS NULL
    OR (founder_number BETWEEN 0 AND 999)
  );

ALTER TABLE public.profiles
  DROP CONSTRAINT IF EXISTS profiles_early_supporter_range;

ALTER TABLE public.profiles
  ADD CONSTRAINT profiles_early_supporter_range
  CHECK (
    early_supporter_number IS NULL
    OR (early_supporter_number BETWEEN 1 AND 250)
  );

CREATE UNIQUE INDEX IF NOT EXISTS profiles_founder_number_idx
  ON public.profiles (founder_number)
  WHERE founder_number IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS profiles_early_supporter_number_idx
  ON public.profiles (early_supporter_number)
  WHERE early_supporter_number IS NOT NULL;

CREATE SEQUENCE IF NOT EXISTS public.early_supporter_seq
  START 1
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 250
  CACHE 1;

ALTER SEQUENCE public.early_supporter_seq MAXVALUE 250;

DO $$
DECLARE
  highest_supporter int;
BEGIN
  SELECT MAX(early_supporter_number)
  INTO highest_supporter
  FROM public.profiles
  WHERE early_supporter_number BETWEEN 1 AND 250;

  IF highest_supporter IS NULL THEN
    PERFORM setval('public.early_supporter_seq', 1, false);
  ELSE
    PERFORM setval('public.early_supporter_seq', highest_supporter, true);
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.assign_early_supporter_number()
RETURNS TRIGGER AS $$
DECLARE
  n int;
BEGIN
  IF NEW.email ILIKE '%@asmodeus.email' THEN
    NEW.is_internal := true;
  END IF;

  IF COALESCE(NEW.is_internal, false) THEN
    RETURN NEW;
  END IF;

  IF NEW.early_supporter_number IS NOT NULL THEN
    RETURN NEW;
  END IF;

  BEGIN
    n := nextval('public.early_supporter_seq');
  EXCEPTION WHEN others THEN
    RETURN NEW;
  END;

  NEW.early_supporter_number := n;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
