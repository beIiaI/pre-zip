-- ============================================
-- Referral refreshes + founder unlimited invites
-- ============================================

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS invite_refresh_count integer;

UPDATE public.profiles
SET invite_refresh_count = 0
WHERE invite_refresh_count IS NULL OR invite_refresh_count < 0;

ALTER TABLE public.profiles
  ALTER COLUMN invite_refresh_count SET DEFAULT 0;

ALTER TABLE public.profiles
  ALTER COLUMN invite_refresh_count SET NOT NULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'profiles_invite_refresh_count_nonnegative'
      AND conrelid = 'public.profiles'::regclass
  ) THEN
    ALTER TABLE public.profiles
      ADD CONSTRAINT profiles_invite_refresh_count_nonnegative
      CHECK (invite_refresh_count >= 0);
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.enforce_access_invite_limit()
RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  used_slots integer;
  inviter_is_founder boolean;
  inviter_refresh_count integer;
  max_slots integer;
BEGIN
  SELECT COALESCE(is_founder, false), GREATEST(COALESCE(invite_refresh_count, 0), 0)
    INTO inviter_is_founder, inviter_refresh_count
  FROM public.profiles
  WHERE id = NEW.inviter_id;

  IF inviter_is_founder THEN
    RETURN NEW;
  END IF;

  max_slots := 5 * (inviter_refresh_count + 1);

  SELECT count(*)
    INTO used_slots
  FROM public.access_invites
  WHERE inviter_id = NEW.inviter_id
    AND (
      status = 'accepted'
      OR (
        status = 'pending'
        AND (expires_at IS NULL OR expires_at > now())
      )
    );

  IF used_slots >= max_slots THEN
    RAISE EXCEPTION 'invite_limit_reached';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS access_invites_limit_trigger ON public.access_invites;
CREATE TRIGGER access_invites_limit_trigger
  BEFORE INSERT ON public.access_invites
  FOR EACH ROW
  EXECUTE FUNCTION public.enforce_access_invite_limit();
