-- ============================================
-- Exclusive access + member invitations
-- ============================================

CREATE TABLE IF NOT EXISTS public.access_invites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  inviter_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  invitee_email text NOT NULL,
  invitee_name text,
  invite_code text NOT NULL UNIQUE,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'revoked', 'expired')),
  accepted_user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  accepted_at timestamptz,
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '30 days'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS access_invites_inviter_id_idx
  ON public.access_invites (inviter_id);

CREATE INDEX IF NOT EXISTS access_invites_invitee_email_idx
  ON public.access_invites (invitee_email);

CREATE INDEX IF NOT EXISTS access_invites_status_idx
  ON public.access_invites (status);

CREATE INDEX IF NOT EXISTS access_invites_expires_at_idx
  ON public.access_invites (expires_at);

ALTER TABLE public.access_invites ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS access_invites_select ON public.access_invites;
CREATE POLICY access_invites_select ON public.access_invites
  FOR SELECT TO authenticated
  USING (inviter_id = auth.uid() OR accepted_user_id = auth.uid());

DROP POLICY IF EXISTS access_invites_insert ON public.access_invites;
CREATE POLICY access_invites_insert ON public.access_invites
  FOR INSERT TO authenticated
  WITH CHECK (inviter_id = auth.uid());

DROP POLICY IF EXISTS access_invites_update ON public.access_invites;
CREATE POLICY access_invites_update ON public.access_invites
  FOR UPDATE TO authenticated
  USING (inviter_id = auth.uid())
  WITH CHECK (inviter_id = auth.uid());

CREATE TABLE IF NOT EXISTS public.access_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  full_name text,
  note text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  reviewed_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS access_applications_email_idx
  ON public.access_applications (email);

CREATE INDEX IF NOT EXISTS access_applications_status_idx
  ON public.access_applications (status);

ALTER TABLE public.access_applications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS access_applications_internal_select ON public.access_applications;
CREATE POLICY access_applications_internal_select ON public.access_applications
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM public.profiles p
      WHERE p.id = auth.uid()
        AND p.is_internal = true
    )
  );
