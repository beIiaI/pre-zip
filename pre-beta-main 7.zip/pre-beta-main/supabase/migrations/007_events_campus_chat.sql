-- ============================================
-- Events: campus-only visibility + event chat
-- ============================================

-- Campus-only flag
ALTER TABLE public.events
  ADD COLUMN IF NOT EXISTS is_campus_only boolean NOT NULL DEFAULT false;

UPDATE public.events
SET is_campus_only = false
WHERE is_campus_only IS NULL;

-- Event chat messages
CREATE TABLE IF NOT EXISTS public.event_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.event_messages
  ADD COLUMN IF NOT EXISTS id uuid,
  ADD COLUMN IF NOT EXISTS event_id uuid,
  ADD COLUMN IF NOT EXISTS sender_id uuid,
  ADD COLUMN IF NOT EXISTS content text,
  ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();

ALTER TABLE public.event_messages
  ALTER COLUMN id SET DEFAULT gen_random_uuid(),
  ALTER COLUMN created_at SET DEFAULT now();

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = 'public.event_messages'::regclass
      AND contype = 'p'
  ) THEN
    ALTER TABLE public.event_messages ADD CONSTRAINT event_messages_pkey PRIMARY KEY (id);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS event_messages_event_id_idx ON public.event_messages (event_id);
CREATE INDEX IF NOT EXISTS event_messages_created_at_idx ON public.event_messages (created_at);

ALTER TABLE public.event_messages ENABLE ROW LEVEL SECURITY;

-- Update event visibility policies to include campus-only for verified users
DROP POLICY IF EXISTS events_select ON public.events;
CREATE POLICY events_select ON public.events
  FOR SELECT TO authenticated
  USING (
    is_public
    OR host_id = auth.uid()
    OR (
      is_campus_only AND EXISTS (
        SELECT 1 FROM public.profiles p
        WHERE p.id = auth.uid()
          AND p.is_verified = true
      )
    )
  );

DROP POLICY IF EXISTS events_insert ON public.events;
CREATE POLICY events_insert ON public.events
  FOR INSERT TO authenticated
  WITH CHECK (
    host_id = auth.uid()
    AND (
      NOT is_campus_only OR EXISTS (
        SELECT 1 FROM public.profiles p
        WHERE p.id = auth.uid()
          AND p.is_verified = true
      )
    )
  );

DROP POLICY IF EXISTS events_update ON public.events;
CREATE POLICY events_update ON public.events
  FOR UPDATE TO authenticated
  USING (host_id = auth.uid())
  WITH CHECK (
    host_id = auth.uid()
    AND (
      NOT is_campus_only OR EXISTS (
        SELECT 1 FROM public.profiles p
        WHERE p.id = auth.uid()
          AND p.is_verified = true
      )
    )
  );

-- Event chat policies
DROP POLICY IF EXISTS event_messages_select ON public.event_messages;
CREATE POLICY event_messages_select ON public.event_messages
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.events e
      WHERE e.id = event_id
        AND (
          e.is_public
          OR e.host_id = auth.uid()
          OR (
            e.is_campus_only AND EXISTS (
              SELECT 1 FROM public.profiles p
              WHERE p.id = auth.uid()
                AND p.is_verified = true
            )
          )
        )
    )
  );

DROP POLICY IF EXISTS event_messages_insert ON public.event_messages;
CREATE POLICY event_messages_insert ON public.event_messages
  FOR INSERT TO authenticated
  WITH CHECK (
    sender_id = auth.uid()
    AND EXISTS (
      SELECT 1 FROM public.events e
      WHERE e.id = event_id
        AND (
          e.is_public
          OR e.host_id = auth.uid()
          OR (
            e.is_campus_only AND EXISTS (
              SELECT 1 FROM public.profiles p
              WHERE p.id = auth.uid()
                AND p.is_verified = true
            )
          )
        )
    )
  );
