-- ============================================
-- University email verification tokens + fields
-- ============================================

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS university_email text,
  ADD COLUMN IF NOT EXISTS university_name text,
  ADD COLUMN IF NOT EXISTS university_domain text,
  ADD COLUMN IF NOT EXISTS university_verified boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS university_verified_at timestamptz;

CREATE INDEX IF NOT EXISTS profiles_university_email_idx
  ON public.profiles (university_email);

CREATE INDEX IF NOT EXISTS profiles_university_name_idx
  ON public.profiles (university_name);

CREATE TABLE IF NOT EXISTS public.university_verifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  email text NOT NULL,
  token_hash text NOT NULL,
  expires_at timestamptz NOT NULL,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS university_verifications_user_id_idx
  ON public.university_verifications (user_id);

CREATE INDEX IF NOT EXISTS university_verifications_email_idx
  ON public.university_verifications (email);

CREATE INDEX IF NOT EXISTS university_verifications_expires_at_idx
  ON public.university_verifications (expires_at);

CREATE INDEX IF NOT EXISTS university_verifications_used_at_idx
  ON public.university_verifications (used_at);

ALTER TABLE public.university_verifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS university_verifications_select ON public.university_verifications;
CREATE POLICY university_verifications_select ON public.university_verifications
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

DROP POLICY IF EXISTS university_verifications_insert ON public.university_verifications;
CREATE POLICY university_verifications_insert ON public.university_verifications
  FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
