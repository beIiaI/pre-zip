-- Allow users to see blocks they are involved in (as blocker or blocked)
DROP POLICY IF EXISTS "Users can view their blocks" ON public.blocks;
DROP POLICY IF EXISTS blocks_select ON public.blocks;

CREATE POLICY blocks_select ON public.blocks
  FOR SELECT TO authenticated
  USING (auth.uid() = blocker_id OR auth.uid() = blocked_id);
