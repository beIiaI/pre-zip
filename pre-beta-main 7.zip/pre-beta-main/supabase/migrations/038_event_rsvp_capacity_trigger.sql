-- ============================================
-- Enforce event capacity at the DB level to prevent
-- TOCTOU race conditions in the RSVP API route.
-- The trigger runs BEFORE INSERT/UPDATE on event_rsvps
-- and raises an exception if the event is full.
-- ============================================

CREATE OR REPLACE FUNCTION public.enforce_event_capacity()
RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  v_max_attendees integer;
  v_current_count integer;
BEGIN
  -- Only enforce when the new status is 'going'
  IF NEW.status <> 'going' THEN
    RETURN NEW;
  END IF;

  -- On UPDATE, skip re-counting if the row was already 'going'
  IF TG_OP = 'UPDATE' AND OLD.status = 'going' THEN
    RETURN NEW;
  END IF;

  SELECT max_attendees
    INTO v_max_attendees
  FROM public.events
  WHERE id = NEW.event_id;

  -- No capacity limit set, allow the insert/update
  IF v_max_attendees IS NULL THEN
    RETURN NEW;
  END IF;

  SELECT count(*)
    INTO v_current_count
  FROM public.event_rsvps
  WHERE event_id = NEW.event_id
    AND status = 'going';

  IF v_current_count >= v_max_attendees THEN
    RAISE EXCEPTION 'event_full';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS event_rsvps_capacity_trigger ON public.event_rsvps;
CREATE TRIGGER event_rsvps_capacity_trigger
  BEFORE INSERT OR UPDATE ON public.event_rsvps
  FOR EACH ROW
  EXECUTE FUNCTION public.enforce_event_capacity();
