-- ============================================
-- University verification locking + annual graduation check
-- ============================================

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS university_graduation_year integer,
  ADD COLUMN IF NOT EXISTS university_grad_year_confirmed_at timestamptz,
  ADD COLUMN IF NOT EXISTS university_graduated_at timestamptz;

DO $$
BEGIN
  ALTER TABLE public.profiles
    ADD CONSTRAINT profiles_university_graduation_year_check
    CHECK (
      university_graduation_year IS NULL
      OR (university_graduation_year >= 1900 AND university_graduation_year <= 2300)
    );
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

CREATE INDEX IF NOT EXISTS profiles_university_graduation_year_idx
  ON public.profiles (university_graduation_year);
