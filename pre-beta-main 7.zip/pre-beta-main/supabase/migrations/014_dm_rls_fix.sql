-- ============================================
-- Fix DM RLS recursion + align schema
-- ============================================

-- Threads
CREATE TABLE IF NOT EXISTS public.dm_threads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.dm_threads
  ADD COLUMN IF NOT EXISTS id uuid,
  ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now(),
  ADD COLUMN IF NOT EXISTS user_a uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS user_b uuid REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.dm_threads
  ALTER COLUMN id SET DEFAULT gen_random_uuid(),
  ALTER COLUMN created_at SET DEFAULT now();

-- Participants
CREATE TABLE IF NOT EXISTS public.dm_participants (
  thread_id uuid NOT NULL REFERENCES public.dm_threads(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  last_read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (thread_id, user_id)
);

ALTER TABLE public.dm_participants
  ADD COLUMN IF NOT EXISTS thread_id uuid,
  ADD COLUMN IF NOT EXISTS user_id uuid,
  ADD COLUMN IF NOT EXISTS last_read_at timestamptz,
  ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();

-- Messages
CREATE TABLE IF NOT EXISTS public.dm_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id uuid NOT NULL REFERENCES public.dm_threads(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  body text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.dm_messages
  ADD COLUMN IF NOT EXISTS id uuid,
  ADD COLUMN IF NOT EXISTS thread_id uuid,
  ADD COLUMN IF NOT EXISTS sender_id uuid,
  ADD COLUMN IF NOT EXISTS body text,
  ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();

ALTER TABLE public.dm_messages
  ALTER COLUMN id SET DEFAULT gen_random_uuid(),
  ALTER COLUMN created_at SET DEFAULT now();

-- If legacy content column exists, migrate it to body.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'dm_messages'
      AND column_name = 'content'
  ) THEN
    UPDATE public.dm_messages
    SET body = content
    WHERE body IS NULL;

    ALTER TABLE public.dm_messages
      ALTER COLUMN body SET NOT NULL;

    ALTER TABLE public.dm_messages
      DROP COLUMN content;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS dm_participants_user_id_idx ON public.dm_participants (user_id);
CREATE INDEX IF NOT EXISTS dm_participants_thread_id_idx ON public.dm_participants (thread_id);
CREATE INDEX IF NOT EXISTS dm_messages_thread_id_idx ON public.dm_messages (thread_id);
CREATE INDEX IF NOT EXISTS dm_messages_created_at_idx ON public.dm_messages (created_at);

-- Backfill dm_threads.user_a/user_b when possible
WITH participants AS (
  SELECT thread_id, array_agg(user_id ORDER BY created_at) AS users
  FROM public.dm_participants
  GROUP BY thread_id
)
UPDATE public.dm_threads t
SET user_a = COALESCE(t.user_a, participants.users[1]),
    user_b = COALESCE(t.user_b, participants.users[2])
FROM participants
WHERE t.id = participants.thread_id;

-- Enable RLS
ALTER TABLE public.dm_threads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dm_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dm_messages ENABLE ROW LEVEL SECURITY;

-- Drop old policies (avoid recursion)
DROP POLICY IF EXISTS dm_threads_select ON public.dm_threads;
DROP POLICY IF EXISTS dm_threads_insert ON public.dm_threads;

DROP POLICY IF EXISTS dm_participants_select ON public.dm_participants;
DROP POLICY IF EXISTS dm_participants_insert ON public.dm_participants;
DROP POLICY IF EXISTS dm_participants_update ON public.dm_participants;
DROP POLICY IF EXISTS dm_participants_update_self ON public.dm_participants;
DROP POLICY IF EXISTS dm_participants_delete ON public.dm_participants;

DROP POLICY IF EXISTS dm_messages_select ON public.dm_messages;
DROP POLICY IF EXISTS dm_messages_insert ON public.dm_messages;

-- Threads: only participants (via user_a/user_b) can view
CREATE POLICY dm_threads_select ON public.dm_threads
  FOR SELECT TO authenticated
  USING (user_a = auth.uid() OR user_b = auth.uid());

CREATE POLICY dm_threads_insert ON public.dm_threads
  FOR INSERT TO authenticated
  WITH CHECK (true);

-- Participants: only the user can read/insert/update/delete their own row
CREATE POLICY dm_participants_select ON public.dm_participants
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY dm_participants_insert ON public.dm_participants
  FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY dm_participants_update ON public.dm_participants
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY dm_participants_delete ON public.dm_participants
  FOR DELETE TO authenticated
  USING (user_id = auth.uid());

-- Messages: only participants can read/insert
CREATE POLICY dm_messages_select ON public.dm_messages
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM public.dm_participants p
      WHERE p.thread_id = dm_messages.thread_id
        AND p.user_id = auth.uid()
    )
  );

CREATE POLICY dm_messages_insert ON public.dm_messages
  FOR INSERT TO authenticated
  WITH CHECK (
    sender_id = auth.uid()
    AND EXISTS (
      SELECT 1
      FROM public.dm_participants p
      WHERE p.thread_id = dm_messages.thread_id
        AND p.user_id = auth.uid()
    )
  );

-- Security definer helper: find or create thread between two users
CREATE OR REPLACE FUNCTION public.dm_get_or_create_thread(target_id uuid)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  existing_id uuid;
  new_id uuid;
BEGIN
  IF target_id IS NULL OR target_id = auth.uid() THEN
    RAISE EXCEPTION 'Invalid target user';
  END IF;

  SELECT p1.thread_id
  INTO existing_id
  FROM public.dm_participants p1
  JOIN public.dm_participants p2
    ON p1.thread_id = p2.thread_id
  WHERE p1.user_id = auth.uid()
    AND p2.user_id = target_id
  LIMIT 1;

  IF existing_id IS NOT NULL THEN
    RETURN existing_id;
  END IF;

  INSERT INTO public.dm_threads (user_a, user_b)
  VALUES (auth.uid(), target_id)
  RETURNING id INTO new_id;

  INSERT INTO public.dm_participants (thread_id, user_id)
  VALUES (new_id, auth.uid()), (new_id, target_id)
  ON CONFLICT DO NOTHING;

  RETURN new_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.dm_get_or_create_thread(uuid) TO authenticated;

-- Helper to fetch other participant read time (for read receipts)
CREATE OR REPLACE FUNCTION public.dm_get_other_read_at(thread_id uuid)
RETURNS timestamptz
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  other_read timestamptz;
BEGIN
  SELECT last_read_at
  INTO other_read
  FROM public.dm_participants
  WHERE thread_id = dm_get_other_read_at.thread_id
    AND user_id <> auth.uid()
  LIMIT 1;

  RETURN other_read;
END;
$$;

GRANT EXECUTE ON FUNCTION public.dm_get_other_read_at(uuid) TO authenticated;
