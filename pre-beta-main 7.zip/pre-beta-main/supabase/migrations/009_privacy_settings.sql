-- ============================================
-- Privacy settings on profiles
-- ============================================

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS profile_visibility text DEFAULT 'public',
  ADD COLUMN IF NOT EXISTS message_requests text DEFAULT 'everyone',
  ADD COLUMN IF NOT EXISTS show_activity_status boolean DEFAULT true,
  ADD COLUMN IF NOT EXISTS show_read_receipts boolean DEFAULT true,
  ADD COLUMN IF NOT EXISTS show_location boolean DEFAULT true,
  ADD COLUMN IF NOT EXISTS discoverable boolean DEFAULT true;

UPDATE public.profiles
SET profile_visibility = COALESCE(profile_visibility, 'public'),
    message_requests = COALESCE(message_requests, 'everyone'),
    show_activity_status = COALESCE(show_activity_status, true),
    show_read_receipts = COALESCE(show_read_receipts, true),
    show_location = COALESCE(show_location, true),
    discoverable = COALESCE(discoverable, true)
WHERE profile_visibility IS NULL
   OR message_requests IS NULL
   OR show_activity_status IS NULL
   OR show_read_receipts IS NULL
   OR show_location IS NULL
   OR discoverable IS NULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'profiles_profile_visibility_check'
  ) THEN
    ALTER TABLE public.profiles
      ADD CONSTRAINT profiles_profile_visibility_check
      CHECK (profile_visibility IN ('public', 'friends', 'private'));
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'profiles_message_requests_check'
  ) THEN
    ALTER TABLE public.profiles
      ADD CONSTRAINT profiles_message_requests_check
      CHECK (message_requests IN ('everyone', 'friends', 'off'));
  END IF;
END $$;
