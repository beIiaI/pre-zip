-- ============================================
-- Access invites: slot usage should ignore revoked/expired pending
-- ============================================

CREATE OR REPLACE FUNCTION public.enforce_access_invite_limit()
RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  used_slots integer;
BEGIN
  SELECT count(*)
    INTO used_slots
  FROM public.access_invites
  WHERE inviter_id = NEW.inviter_id
    AND (
      status = 'accepted'
      OR (
        status = 'pending'
        AND (expires_at IS NULL OR expires_at > now())
      )
    );

  IF used_slots >= 5 THEN
    RAISE EXCEPTION 'invite_limit_reached';
  END IF;

  RETURN NEW;
END;
$$;

DROP INDEX IF EXISTS access_invites_pending_unique_per_email_idx;
CREATE UNIQUE INDEX IF NOT EXISTS access_invites_pending_unique_per_email_idx
  ON public.access_invites (inviter_id, lower(invitee_email))
  WHERE status = 'pending' AND invitee_email IS NOT NULL;
