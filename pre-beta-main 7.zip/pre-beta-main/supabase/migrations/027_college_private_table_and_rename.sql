-- ============================================
-- College self-report privacy hardening
-- ============================================

-- Backward-compatible rename if 026 was applied with `college_verified`.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'profiles'
      AND column_name = 'college_verified'
  ) AND NOT EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'profiles'
      AND column_name = 'college_self_reported'
  ) THEN
    ALTER TABLE public.profiles RENAME COLUMN college_verified TO college_self_reported;
  END IF;
END $$;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS college_name text,
  ADD COLUMN IF NOT EXISTS college_self_reported boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS college_updated_at timestamptz;

CREATE TABLE IF NOT EXISTS public.profile_college (
  user_id uuid PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  college_name text,
  college_self_reported boolean NOT NULL DEFAULT false,
  college_updated_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO public.profile_college (
  user_id,
  college_name,
  college_self_reported,
  college_updated_at,
  created_at,
  updated_at
)
SELECT
  p.id,
  NULLIF(btrim(p.college_name), ''),
  CASE
    WHEN NULLIF(btrim(p.college_name), '') IS NOT NULL THEN true
    ELSE COALESCE(p.college_self_reported, false)
  END,
  p.college_updated_at,
  now(),
  now()
FROM public.profiles p
WHERE p.college_name IS NOT NULL
   OR p.college_updated_at IS NOT NULL
   OR p.college_self_reported = true
ON CONFLICT (user_id) DO UPDATE
SET
  college_name = EXCLUDED.college_name,
  college_self_reported = EXCLUDED.college_self_reported,
  college_updated_at = EXCLUDED.college_updated_at,
  updated_at = now();

CREATE OR REPLACE FUNCTION public.touch_profile_college_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS profile_college_touch_updated_at_trigger ON public.profile_college;
CREATE TRIGGER profile_college_touch_updated_at_trigger
  BEFORE UPDATE ON public.profile_college
  FOR EACH ROW
  EXECUTE FUNCTION public.touch_profile_college_updated_at();

CREATE OR REPLACE FUNCTION public.set_profile_college_name_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.college_name IS DISTINCT FROM OLD.college_name THEN
    NEW.college_updated_at := now();
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS profile_college_name_updated_at_trigger ON public.profile_college;
CREATE TRIGGER profile_college_name_updated_at_trigger
  BEFORE UPDATE OF college_name ON public.profile_college
  FOR EACH ROW
  EXECUTE FUNCTION public.set_profile_college_name_updated_at();

ALTER TABLE public.profile_college ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profile_college FORCE ROW LEVEL SECURITY;

REVOKE ALL ON TABLE public.profile_college FROM anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.profile_college TO authenticated;

DROP POLICY IF EXISTS profile_college_select_self ON public.profile_college;
CREATE POLICY profile_college_select_self
  ON public.profile_college
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

DROP POLICY IF EXISTS profile_college_insert_self ON public.profile_college;
CREATE POLICY profile_college_insert_self
  ON public.profile_college
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS profile_college_update_self ON public.profile_college;
CREATE POLICY profile_college_update_self
  ON public.profile_college
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS profile_college_delete_self ON public.profile_college;
CREATE POLICY profile_college_delete_self
  ON public.profile_college
  FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());

-- Remove public exposure by dropping college fields from the public profiles row.
DROP TRIGGER IF EXISTS profiles_college_updated_at_trigger ON public.profiles;
DROP FUNCTION IF EXISTS public.set_profiles_college_updated_at();

ALTER TABLE public.profiles
  DROP COLUMN IF EXISTS college_name,
  DROP COLUMN IF EXISTS college_self_reported,
  DROP COLUMN IF EXISTS college_updated_at,
  DROP COLUMN IF EXISTS college_verified;
