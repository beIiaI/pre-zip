-- ============================================
-- Limit college self-report edits
-- Allows initial save + one final edit
-- ============================================

ALTER TABLE public.profile_college
  ADD COLUMN IF NOT EXISTS college_change_count integer NOT NULL DEFAULT 0;

UPDATE public.profile_college
SET college_change_count = CASE
  WHEN college_name IS NOT NULL AND btrim(college_name) <> '' THEN GREATEST(college_change_count, 1)
  ELSE GREATEST(college_change_count, 0)
END;
