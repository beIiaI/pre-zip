BEGIN;

ALTER TABLE public.dm_messages
  ADD COLUMN IF NOT EXISTS edited_at timestamptz,
  ADD COLUMN IF NOT EXISTS deleted_at timestamptz;

DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'dm_messages_body_non_empty'
      AND conrelid = 'public.dm_messages'::regclass
  ) THEN
    ALTER TABLE public.dm_messages
      DROP CONSTRAINT dm_messages_body_non_empty;
  END IF;
END $$;

ALTER TABLE public.dm_messages
  ADD CONSTRAINT dm_messages_body_non_empty
  CHECK (
    (
      deleted_at IS NULL
      AND length(btrim(body)) > 0
      AND length(body) <= 4000
    )
    OR (
      deleted_at IS NOT NULL
      AND length(body) <= 4000
    )
  );

DROP POLICY IF EXISTS dm_messages_update ON public.dm_messages;

CREATE POLICY dm_messages_update ON public.dm_messages
  FOR UPDATE TO authenticated
  USING (
    sender_id = auth.uid()
    AND EXISTS (
      SELECT 1
      FROM public.dm_participants p
      WHERE p.thread_id = dm_messages.thread_id
        AND p.user_id = auth.uid()
    )
  )
  WITH CHECK (
    sender_id = auth.uid()
    AND EXISTS (
      SELECT 1
      FROM public.dm_participants p
      WHERE p.thread_id = dm_messages.thread_id
        AND p.user_id = auth.uid()
    )
  );

CREATE INDEX IF NOT EXISTS dm_messages_thread_deleted_idx
  ON public.dm_messages (thread_id, deleted_at);

COMMIT;
