-- ============================================
-- Event RSVP policies + badge award helpers
-- ============================================

ALTER TABLE public.event_rsvps ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS event_rsvps_select ON public.event_rsvps;
CREATE POLICY event_rsvps_select ON public.event_rsvps
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.events e
      WHERE e.id = event_rsvps.event_id
        AND (
          e.is_public
          OR e.host_id = auth.uid()
          OR (
            e.is_campus_only AND EXISTS (
              SELECT 1 FROM public.profiles p
              WHERE p.id = auth.uid()
                AND p.university_verified = true
            )
          )
        )
    )
  );

DROP POLICY IF EXISTS event_rsvps_insert ON public.event_rsvps;
CREATE POLICY event_rsvps_insert ON public.event_rsvps
  FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    AND EXISTS (
      SELECT 1 FROM public.events e
      WHERE e.id = event_rsvps.event_id
        AND (
          e.is_public
          OR e.host_id = auth.uid()
          OR (
            e.is_campus_only AND EXISTS (
              SELECT 1 FROM public.profiles p
              WHERE p.id = auth.uid()
                AND p.university_verified = true
            )
          )
        )
    )
  );

DROP POLICY IF EXISTS event_rsvps_update ON public.event_rsvps;
CREATE POLICY event_rsvps_update ON public.event_rsvps
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS event_rsvps_delete ON public.event_rsvps;
CREATE POLICY event_rsvps_delete ON public.event_rsvps
  FOR DELETE TO authenticated
  USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.award_initiator_if_eligible(event_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
SET row_security = off
AS $$
DECLARE
  v_host uuid;
  v_badge uuid;
  v_attendee_count integer;
  v_inserted integer;
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN false;
  END IF;

  SELECT host_id INTO v_host
  FROM public.events
  WHERE id = event_id;

  IF v_host IS NULL THEN
    RETURN false;
  END IF;

  IF auth.uid() <> v_host THEN
    IF NOT EXISTS (
      SELECT 1 FROM public.event_rsvps r
      WHERE r.event_id = event_id
        AND r.user_id = auth.uid()
        AND r.status = 'going'
    ) THEN
      RETURN false;
    END IF;
  END IF;

  SELECT COUNT(*) INTO v_attendee_count
  FROM public.event_rsvps r
  WHERE r.event_id = event_id
    AND r.status = 'going'
    AND r.user_id <> v_host;

  IF v_attendee_count < 1 THEN
    RETURN false;
  END IF;

  SELECT id INTO v_badge
  FROM public.badges
  WHERE name = 'Initiator'
  LIMIT 1;

  IF v_badge IS NULL THEN
    RETURN false;
  END IF;

  INSERT INTO public.user_badges (user_id, badge_id)
  VALUES (v_host, v_badge)
  ON CONFLICT (user_id, badge_id) DO NOTHING;

  GET DIAGNOSTICS v_inserted = ROW_COUNT;
  RETURN v_inserted > 0;
END;
$$;

CREATE OR REPLACE FUNCTION public.award_social_butterfly_if_eligible(target_user uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
SET row_security = off
AS $$
DECLARE
  v_badge uuid;
  v_count integer;
  v_inserted integer;
BEGIN
  IF auth.uid() IS NULL OR auth.uid() <> target_user THEN
    RETURN false;
  END IF;

  SELECT id INTO v_badge
  FROM public.badges
  WHERE name = 'Social Butterfly'
  LIMIT 1;

  IF v_badge IS NULL THEN
    RETURN false;
  END IF;

  SELECT COUNT(*) INTO v_count
  FROM public.event_rsvps r
  WHERE r.user_id = target_user
    AND r.status = 'going'
    AND r.created_at >= (now() - interval '30 days');

  IF v_count < 5 THEN
    RETURN false;
  END IF;

  INSERT INTO public.user_badges (user_id, badge_id)
  VALUES (target_user, v_badge)
  ON CONFLICT (user_id, badge_id) DO NOTHING;

  GET DIAGNOSTICS v_inserted = ROW_COUNT;
  RETURN v_inserted > 0;
END;
$$;
