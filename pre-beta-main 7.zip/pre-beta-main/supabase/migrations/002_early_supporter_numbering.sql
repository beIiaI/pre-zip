-- ============================================
-- Early supporter numbering (idempotent)
-- ============================================

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS early_supporter_number INTEGER;

ALTER TABLE public.profiles
  DROP CONSTRAINT IF EXISTS profiles_early_supporter_range;

ALTER TABLE public.profiles
  ADD CONSTRAINT profiles_early_supporter_range
  CHECK (
    early_supporter_number IS NULL
    OR (early_supporter_number BETWEEN 0 AND 250)
  );

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes
    WHERE schemaname='public'
      AND indexname='profiles_early_supporter_number_idx'
  ) THEN
    CREATE UNIQUE INDEX profiles_early_supporter_number_idx
      ON public.profiles (early_supporter_number)
      WHERE early_supporter_number IS NOT NULL;
  END IF;
END $$;

CREATE SEQUENCE IF NOT EXISTS public.early_supporter_seq
  START 1 INCREMENT 1 MINVALUE 1 MAXVALUE 250 CACHE 1;

ALTER SEQUENCE public.early_supporter_seq MAXVALUE 250;

DO $$
DECLARE m int;
BEGIN
  SELECT MAX(early_supporter_number) INTO m
  FROM public.profiles
  WHERE early_supporter_number BETWEEN 1 AND 250;

  IF m IS NULL THEN
    PERFORM setval('public.early_supporter_seq', 1, false);
  ELSE
    PERFORM setval('public.early_supporter_seq', m, true);
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.assign_early_supporter_number()
RETURNS TRIGGER AS $$
DECLARE n int;
BEGIN
  IF NEW.early_supporter_number IS NOT NULL THEN
    RETURN NEW;
  END IF;

  IF NEW.id = 'fb04c13f-9c1d-4584-ad01-778f9874908b' THEN
    NEW.early_supporter_number := 0;
    RETURN NEW;
  END IF;

  IF NEW.email ILIKE '%@asmodeus.email' THEN
    RETURN NEW;
  END IF;

  BEGIN
    n := nextval('public.early_supporter_seq');
  EXCEPTION WHEN others THEN
    RETURN NEW;
  END;

  NEW.early_supporter_number := n;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS profiles_assign_early_supporter ON public.profiles;
CREATE TRIGGER profiles_assign_early_supporter
  BEFORE INSERT ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.assign_early_supporter_number();

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email)
  VALUES (NEW.id, NEW.email)
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- reserve #000 for founder
UPDATE public.profiles
SET early_supporter_number = 0
WHERE id = 'fb04c13f-9c1d-4584-ad01-778f9874908b';

DO $$
DECLARE existing_count int;
BEGIN
  SELECT COUNT(*) INTO existing_count
  FROM public.profiles
  WHERE early_supporter_number BETWEEN 1 AND 250;

  IF existing_count < 250 THEN
    WITH ranked AS (
      SELECT id, row_number() OVER (ORDER BY created_at ASC) AS rn
      FROM public.profiles
      WHERE id <> 'fb04c13f-9c1d-4584-ad01-778f9874908b'
        AND early_supporter_number IS NULL
        AND (email IS NULL OR email NOT ILIKE '%@asmodeus.email')
    )
    UPDATE public.profiles p
    SET early_supporter_number = ranked.rn + existing_count
    FROM ranked
    WHERE p.id = ranked.id
      AND (ranked.rn + existing_count) <= 250;
  END IF;

  PERFORM (
    SELECT CASE
      WHEN MAX(early_supporter_number) FILTER (WHERE early_supporter_number BETWEEN 1 AND 250) IS NULL
        THEN setval('public.early_supporter_seq', 1, false)
      ELSE
        setval('public.early_supporter_seq',
               MAX(early_supporter_number) FILTER (WHERE early_supporter_number BETWEEN 1 AND 250),
               true)
    END
    FROM public.profiles
  );
END $$;
