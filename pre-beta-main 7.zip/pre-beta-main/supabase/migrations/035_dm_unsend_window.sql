BEGIN;

-- Product rule: no message edits; sender can unsend only within 5 minutes.
DROP POLICY IF EXISTS dm_messages_update ON public.dm_messages;

CREATE POLICY dm_messages_update ON public.dm_messages
  FOR UPDATE TO authenticated
  USING (
    sender_id = auth.uid()
    AND deleted_at IS NULL
    AND created_at >= (now() - interval '5 minutes')
    AND EXISTS (
      SELECT 1
      FROM public.dm_participants p
      WHERE p.thread_id = dm_messages.thread_id
        AND p.user_id = auth.uid()
    )
  )
  WITH CHECK (
    sender_id = auth.uid()
    AND deleted_at IS NOT NULL
    AND edited_at IS NULL
    AND body = ''
    AND EXISTS (
      SELECT 1
      FROM public.dm_participants p
      WHERE p.thread_id = dm_messages.thread_id
        AND p.user_id = auth.uid()
    )
  );

COMMIT;
