-- ============================================
-- Emergency contacts: external phone support
-- ============================================

ALTER TABLE public.emergency_contacts
  ALTER COLUMN contact_user_id DROP NOT NULL,
  ADD COLUMN IF NOT EXISTS external_name text,
  ADD COLUMN IF NOT EXISTS external_phone text;

UPDATE public.emergency_contacts
SET
  external_name = NULLIF(btrim(external_name), ''),
  external_phone = NULLIF(regexp_replace(external_phone, '[^0-9+]', '', 'g'), '')
WHERE external_name IS NOT NULL
   OR external_phone IS NOT NULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'emergency_contacts_target_check'
  ) THEN
    ALTER TABLE public.emergency_contacts
      ADD CONSTRAINT emergency_contacts_target_check
      CHECK (
        (contact_user_id IS NOT NULL AND external_phone IS NULL)
        OR (contact_user_id IS NULL AND external_phone IS NOT NULL)
      );
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'emergency_contacts_external_phone_format'
  ) THEN
    ALTER TABLE public.emergency_contacts
      ADD CONSTRAINT emergency_contacts_external_phone_format
      CHECK (external_phone IS NULL OR external_phone ~ '^\+?[0-9]{7,15}$');
  END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS emergency_contacts_owner_external_phone_key
  ON public.emergency_contacts(owner_id, external_phone)
  WHERE external_phone IS NOT NULL;

CREATE OR REPLACE FUNCTION public.create_panic_event(lat double precision, lng double precision)
RETURNS TABLE(event_id uuid, notified_count integer)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
SET row_security = off
AS $$
DECLARE
  v_owner uuid;
  v_event_id uuid;
  v_count integer := 0;
BEGIN
  v_owner := auth.uid();
  IF v_owner IS NULL THEN
    RETURN;
  END IF;

  INSERT INTO public.panic_events (owner_id, lat, lng)
  VALUES (v_owner, lat, lng)
  RETURNING id INTO v_event_id;

  INSERT INTO public.notifications (user_id, type, title, body, data)
  SELECT
    c.contact_user_id,
    'panic_alert',
    'Emergency alert',
    'A contact triggered an alert. Tap to view location.',
    jsonb_build_object(
      'event_id', v_event_id,
      'owner_id', v_owner,
      'lat', lat,
      'lng', lng
    )
  FROM public.emergency_contacts c
  WHERE c.owner_id = v_owner
    AND c.contact_user_id IS NOT NULL;

  GET DIAGNOSTICS v_count = ROW_COUNT;

  RETURN QUERY SELECT v_event_id, v_count;
END;
$$;
