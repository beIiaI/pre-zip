-- ============================================
-- Circles + circle members policies
-- ============================================

ALTER TABLE public.circles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.circle_members ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS circles_select ON public.circles;
CREATE POLICY circles_select ON public.circles
  FOR SELECT TO authenticated
  USING (
    is_public = true
    OR creator_id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM public.circle_members cm
      WHERE cm.circle_id = circles.id
        AND cm.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS circles_insert ON public.circles;
CREATE POLICY circles_insert ON public.circles
  FOR INSERT TO authenticated
  WITH CHECK (creator_id = auth.uid());

DROP POLICY IF EXISTS circles_update ON public.circles;
CREATE POLICY circles_update ON public.circles
  FOR UPDATE TO authenticated
  USING (creator_id = auth.uid())
  WITH CHECK (creator_id = auth.uid());

DROP POLICY IF EXISTS circle_members_select ON public.circle_members;
CREATE POLICY circle_members_select ON public.circle_members
  FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM public.circles c
      WHERE c.id = circle_members.circle_id
        AND c.is_public = true
    )
  );

DROP POLICY IF EXISTS circle_members_insert ON public.circle_members;
CREATE POLICY circle_members_insert ON public.circle_members
  FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS circle_members_delete ON public.circle_members;
CREATE POLICY circle_members_delete ON public.circle_members
  FOR DELETE TO authenticated
  USING (user_id = auth.uid());
