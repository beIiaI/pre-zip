-- ============================================
-- Founder/internal flags + supporter assignment rules
-- ============================================

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS is_founder boolean NOT NULL DEFAULT false;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS is_internal boolean NOT NULL DEFAULT false;

CREATE OR REPLACE FUNCTION public.assign_early_supporter_number()
RETURNS TRIGGER AS $$
DECLARE n int;
BEGIN
  -- Mark internal accounts by email domain
  IF NEW.email ILIKE '%@asmodeus.email' THEN
    NEW.is_internal := true;
  END IF;

  -- Founder override
  IF NEW.id = 'fb04c13f-9c1d-4584-ad01-778f9874908b' THEN
    NEW.is_founder := true;
    NEW.early_supporter_number := 0;
    RETURN NEW;
  END IF;

  -- Skip numbering for internal accounts
  IF NEW.is_internal THEN
    RETURN NEW;
  END IF;

  IF NEW.early_supporter_number IS NOT NULL THEN
    RETURN NEW;
  END IF;

  BEGIN
    n := nextval('public.early_supporter_seq');
  EXCEPTION WHEN others THEN
    RETURN NEW;
  END;

  NEW.early_supporter_number := n;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Backfill: founder + internal, then reassign early supporter numbers excluding internal accounts
UPDATE public.profiles
SET is_founder = true,
    early_supporter_number = 0
WHERE id = 'fb04c13f-9c1d-4584-ad01-778f9874908b';

UPDATE public.profiles
SET is_internal = true
WHERE email ILIKE '%@asmodeus.email';

UPDATE public.profiles
SET early_supporter_number = NULL
WHERE is_internal = true
  AND id <> 'fb04c13f-9c1d-4584-ad01-778f9874908b';

UPDATE public.profiles
SET early_supporter_number = NULL
WHERE id <> 'fb04c13f-9c1d-4584-ad01-778f9874908b'
  AND (email IS NULL OR email NOT ILIKE '%@asmodeus.email');

WITH ranked AS (
  SELECT id, row_number() OVER (ORDER BY created_at ASC) AS rn
  FROM public.profiles
  WHERE id <> 'fb04c13f-9c1d-4584-ad01-778f9874908b'
    AND (email IS NULL OR email NOT ILIKE '%@asmodeus.email')
)
UPDATE public.profiles p
SET early_supporter_number = ranked.rn
FROM ranked
WHERE p.id = ranked.id
  AND ranked.rn <= 250;

DO $$
DECLARE m int;
BEGIN
  SELECT MAX(early_supporter_number) INTO m
  FROM public.profiles
  WHERE early_supporter_number BETWEEN 1 AND 250;

  IF m IS NULL THEN
    PERFORM setval('public.early_supporter_seq', 1, false);
  ELSE
    PERFORM setval('public.early_supporter_seq', m, true);
  END IF;
END $$;
