-- Push tokens for Expo push notifications
-- One row per user (upserted on every sign-in from the client).

CREATE TABLE IF NOT EXISTS push_tokens (
  user_id   UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  token     TEXT        NOT NULL,
  platform  TEXT        NOT NULL CHECK (platform IN ('ios', 'android')),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE push_tokens ENABLE ROW LEVEL SECURITY;

-- Users can only read/write their own token
CREATE POLICY "users manage own push token"
  ON push_tokens
  FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Service role (used by edge functions) can read all tokens to fan out notifications
-- No additional policy needed — service role bypasses RLS by default.
