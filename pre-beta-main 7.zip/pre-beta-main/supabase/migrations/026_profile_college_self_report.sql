-- ============================================
-- Profile college self-reporting
-- ============================================

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS college_name text,
  ADD COLUMN IF NOT EXISTS college_verified boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS college_updated_at timestamptz;

-- Backfill consistency for existing data, if any.
UPDATE public.profiles
SET college_verified = true
WHERE college_name IS NOT NULL
  AND btrim(college_name) <> ''
  AND college_verified = false;

CREATE OR REPLACE FUNCTION public.set_profiles_college_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.college_name IS DISTINCT FROM OLD.college_name THEN
    NEW.college_updated_at := now();
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS profiles_college_updated_at_trigger ON public.profiles;
CREATE TRIGGER profiles_college_updated_at_trigger
  BEFORE UPDATE OF college_name ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.set_profiles_college_updated_at();
