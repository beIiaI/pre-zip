-- ============================================
-- Emergency contacts + panic events
-- ============================================

CREATE TABLE IF NOT EXISTS public.emergency_contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  contact_user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(owner_id, contact_user_id)
);

ALTER TABLE public.emergency_contacts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS emergency_contacts_select ON public.emergency_contacts;
CREATE POLICY emergency_contacts_select ON public.emergency_contacts
  FOR SELECT TO authenticated
  USING (owner_id = auth.uid());

DROP POLICY IF EXISTS emergency_contacts_insert ON public.emergency_contacts;
CREATE POLICY emergency_contacts_insert ON public.emergency_contacts
  FOR INSERT TO authenticated
  WITH CHECK (owner_id = auth.uid());

DROP POLICY IF EXISTS emergency_contacts_delete ON public.emergency_contacts;
CREATE POLICY emergency_contacts_delete ON public.emergency_contacts
  FOR DELETE TO authenticated
  USING (owner_id = auth.uid());

CREATE TABLE IF NOT EXISTS public.panic_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  lat double precision,
  lng double precision,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'resolved')),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.panic_events ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS panic_events_select ON public.panic_events;
CREATE POLICY panic_events_select ON public.panic_events
  FOR SELECT TO authenticated
  USING (
    owner_id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM public.emergency_contacts c
      WHERE c.owner_id = panic_events.owner_id
        AND c.contact_user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS panic_events_insert ON public.panic_events;
CREATE POLICY panic_events_insert ON public.panic_events
  FOR INSERT TO authenticated
  WITH CHECK (owner_id = auth.uid());

DROP POLICY IF EXISTS panic_events_update ON public.panic_events;
CREATE POLICY panic_events_update ON public.panic_events
  FOR UPDATE TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

ALTER TABLE public.notifications
  ADD COLUMN IF NOT EXISTS read_at timestamptz;
