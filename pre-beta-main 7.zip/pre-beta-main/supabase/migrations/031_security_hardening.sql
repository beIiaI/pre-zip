-- ============================================
-- Security hardening pass:
-- - DM RLS non-recursive participant-only access
-- - Sensitive verification table protections
-- - Core constraints + index coverage
-- - Updated-at audit triggers
-- ============================================

-- ---------- DM tables ----------
ALTER TABLE public.dm_threads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dm_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dm_messages ENABLE ROW LEVEL SECURITY;

ALTER TABLE public.dm_threads FORCE ROW LEVEL SECURITY;
ALTER TABLE public.dm_participants FORCE ROW LEVEL SECURITY;
ALTER TABLE public.dm_messages FORCE ROW LEVEL SECURITY;

REVOKE ALL ON TABLE public.dm_threads FROM anon;
REVOKE ALL ON TABLE public.dm_participants FROM anon;
REVOKE ALL ON TABLE public.dm_messages FROM anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.dm_threads TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.dm_participants TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.dm_messages TO authenticated;

DROP POLICY IF EXISTS dm_threads_select ON public.dm_threads;
DROP POLICY IF EXISTS dm_threads_insert ON public.dm_threads;
DROP POLICY IF EXISTS dm_threads_update ON public.dm_threads;
DROP POLICY IF EXISTS dm_threads_delete ON public.dm_threads;
DROP POLICY IF EXISTS "Users can view dm threads" ON public.dm_threads;
DROP POLICY IF EXISTS "Users can insert dm threads" ON public.dm_threads;

DROP POLICY IF EXISTS dm_participants_select ON public.dm_participants;
DROP POLICY IF EXISTS dm_participants_insert ON public.dm_participants;
DROP POLICY IF EXISTS dm_participants_update ON public.dm_participants;
DROP POLICY IF EXISTS dm_participants_update_self ON public.dm_participants;
DROP POLICY IF EXISTS dm_participants_delete ON public.dm_participants;
DROP POLICY IF EXISTS "Users can view dm participants" ON public.dm_participants;
DROP POLICY IF EXISTS "Users can insert dm participants" ON public.dm_participants;

DROP POLICY IF EXISTS dm_messages_select ON public.dm_messages;
DROP POLICY IF EXISTS dm_messages_insert ON public.dm_messages;
DROP POLICY IF EXISTS dm_messages_update ON public.dm_messages;
DROP POLICY IF EXISTS dm_messages_delete ON public.dm_messages;
DROP POLICY IF EXISTS "Users can view dm messages" ON public.dm_messages;
DROP POLICY IF EXISTS "Users can insert dm messages" ON public.dm_messages;

-- Threads are visible only if requester is a participant.
CREATE POLICY dm_threads_select ON public.dm_threads
  FOR SELECT TO authenticated
  USING (
    user_a = auth.uid()
    OR user_b = auth.uid()
    OR EXISTS (
      SELECT 1
      FROM public.dm_participants p
      WHERE p.thread_id = dm_threads.id
        AND p.user_id = auth.uid()
    )
  );

-- Client inserts must include requester as one side of the thread.
CREATE POLICY dm_threads_insert ON public.dm_threads
  FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() IS NOT NULL
    AND (user_a = auth.uid() OR user_b = auth.uid())
  );

CREATE POLICY dm_threads_update ON public.dm_threads
  FOR UPDATE TO authenticated
  USING (user_a = auth.uid() OR user_b = auth.uid())
  WITH CHECK (user_a = auth.uid() OR user_b = auth.uid());

-- Participant rows are self-owned only (non-recursive).
CREATE POLICY dm_participants_select ON public.dm_participants
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY dm_participants_insert ON public.dm_participants
  FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY dm_participants_update ON public.dm_participants
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY dm_participants_delete ON public.dm_participants
  FOR DELETE TO authenticated
  USING (user_id = auth.uid());

-- Messages are visible/insertable only by participants.
CREATE POLICY dm_messages_select ON public.dm_messages
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM public.dm_participants p
      WHERE p.thread_id = dm_messages.thread_id
        AND p.user_id = auth.uid()
    )
  );

CREATE POLICY dm_messages_insert ON public.dm_messages
  FOR INSERT TO authenticated
  WITH CHECK (
    sender_id = auth.uid()
    AND EXISTS (
      SELECT 1
      FROM public.dm_participants p
      WHERE p.thread_id = dm_messages.thread_id
        AND p.user_id = auth.uid()
    )
  );

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'dm_messages_body_non_empty'
      AND conrelid = 'public.dm_messages'::regclass
  ) THEN
    ALTER TABLE public.dm_messages
      ADD CONSTRAINT dm_messages_body_non_empty
      CHECK (length(btrim(body)) > 0 AND length(body) <= 4000);
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'dm_threads_distinct_users'
      AND conrelid = 'public.dm_threads'::regclass
  ) THEN
    ALTER TABLE public.dm_threads
      ADD CONSTRAINT dm_threads_distinct_users
      CHECK (
        user_a IS NULL
        OR user_b IS NULL
        OR user_a <> user_b
      );
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS dm_threads_user_a_idx ON public.dm_threads (user_a);
CREATE INDEX IF NOT EXISTS dm_threads_user_b_idx ON public.dm_threads (user_b);
CREATE INDEX IF NOT EXISTS dm_messages_sender_id_idx ON public.dm_messages (sender_id);
CREATE INDEX IF NOT EXISTS dm_messages_thread_sender_created_idx
  ON public.dm_messages (thread_id, sender_id, created_at DESC);

-- ---------- Verification/privacy tables ----------
ALTER TABLE public.university_verifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.university_verifications FORCE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.university_verifications FROM anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.university_verifications TO authenticated;

DROP POLICY IF EXISTS university_verifications_select ON public.university_verifications;
DROP POLICY IF EXISTS university_verifications_insert ON public.university_verifications;
DROP POLICY IF EXISTS university_verifications_update ON public.university_verifications;
DROP POLICY IF EXISTS university_verifications_delete ON public.university_verifications;

CREATE POLICY university_verifications_select ON public.university_verifications
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY university_verifications_insert ON public.university_verifications
  FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE UNIQUE INDEX IF NOT EXISTS university_verifications_token_hash_unused_idx
  ON public.university_verifications (token_hash)
  WHERE used_at IS NULL;

CREATE INDEX IF NOT EXISTS university_verifications_user_created_idx
  ON public.university_verifications (user_id, created_at DESC);

ALTER TABLE public.profile_college ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profile_college FORCE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.profile_college FROM anon;

-- ---------- Additional FK / lookup indexes ----------
CREATE INDEX IF NOT EXISTS events_creator_id_idx ON public.events (creator_id);
CREATE INDEX IF NOT EXISTS events_host_id_idx ON public.events (host_id);
CREATE INDEX IF NOT EXISTS events_circle_id_idx ON public.events (circle_id);
CREATE INDEX IF NOT EXISTS event_messages_event_sender_idx
  ON public.event_messages (event_id, sender_id, created_at DESC);
CREATE INDEX IF NOT EXISTS emergency_contacts_owner_id_idx ON public.emergency_contacts (owner_id);
CREATE INDEX IF NOT EXISTS emergency_contacts_contact_user_id_idx ON public.emergency_contacts (contact_user_id);
CREATE INDEX IF NOT EXISTS panic_events_owner_id_idx ON public.panic_events (owner_id);
CREATE INDEX IF NOT EXISTS notifications_user_id_created_at_idx
  ON public.notifications (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS access_invites_inviter_status_expires_idx
  ON public.access_invites (inviter_id, status, expires_at DESC);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'events_max_attendees_positive'
      AND conrelid = 'public.events'::regclass
  ) THEN
    ALTER TABLE public.events
      ADD CONSTRAINT events_max_attendees_positive
      CHECK (max_attendees IS NULL OR (max_attendees > 0 AND max_attendees <= 5000));
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'events_ends_after_starts'
      AND conrelid = 'public.events'::regclass
  ) THEN
    ALTER TABLE public.events
      ADD CONSTRAINT events_ends_after_starts
      CHECK (ends_at IS NULL OR ends_at >= starts_at);
  END IF;
END $$;

-- ---------- updated_at trigger coverage ----------
CREATE OR REPLACE FUNCTION public.touch_updated_at_column()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS profiles_touch_updated_at_trigger ON public.profiles;
CREATE TRIGGER profiles_touch_updated_at_trigger
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.touch_updated_at_column();

DROP TRIGGER IF EXISTS events_touch_updated_at_trigger ON public.events;
CREATE TRIGGER events_touch_updated_at_trigger
  BEFORE UPDATE ON public.events
  FOR EACH ROW
  EXECUTE FUNCTION public.touch_updated_at_column();

DROP TRIGGER IF EXISTS circles_touch_updated_at_trigger ON public.circles;
CREATE TRIGGER circles_touch_updated_at_trigger
  BEFORE UPDATE ON public.circles
  FOR EACH ROW
  EXECUTE FUNCTION public.touch_updated_at_column();

