// supabase/functions/send-push/index.ts
// Supabase Edge Function — sends push notifications via the Expo Push API.
//
// Expects a JSON body:
//   { user_id: string, title: string, body: string, data?: Record<string, any> }
//
// The function looks up the user's Expo push token from the `push_tokens` table
// and forwards the notification through https://exp.host/--/api/v2/push/send.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const EXPO_PUSH_URL = "https://exp.host/--/api/v2/push/send";

interface PushPayload {
  user_id: string;
  title: string;
  body: string;
  data?: Record<string, any>;
}

Deno.serve(async (req) => {
  // Only allow POST
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { "Content-Type": "application/json" },
    });
  }

  // Verify the request comes from an authenticated source
  const authHeader = req.headers.get("Authorization");
  if (!authHeader) {
    return new Response(JSON.stringify({ error: "Missing authorization" }), {
      status: 401,
      headers: { "Content-Type": "application/json" },
    });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

  const supabase = createClient(supabaseUrl, serviceRoleKey);

  let payload: PushPayload;
  try {
    payload = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON body" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  const { user_id, title, body, data } = payload;

  if (!user_id || !title || !body) {
    return new Response(
      JSON.stringify({ error: "user_id, title, and body are required" }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }

  // Look up the user's push token
  const { data: tokenRow, error: tokenError } = await supabase
    .from("push_tokens")
    .select("token")
    .eq("user_id", user_id)
    .single();

  if (tokenError || !tokenRow?.token) {
    return new Response(
      JSON.stringify({ error: "No push token found for user", user_id }),
      { status: 404, headers: { "Content-Type": "application/json" } }
    );
  }

  // Send via Expo Push API
  const expoPushBody = {
    to: tokenRow.token,
    title,
    body,
    sound: "default",
    data: data ?? {},
  };

  const expoRes = await fetch(EXPO_PUSH_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify(expoPushBody),
  });

  const expoResult = await expoRes.json();

  if (!expoRes.ok) {
    return new Response(
      JSON.stringify({ error: "Expo Push API error", details: expoResult }),
      { status: 502, headers: { "Content-Type": "application/json" } }
    );
  }

  return new Response(
    JSON.stringify({ success: true, ticket: expoResult.data }),
    { status: 200, headers: { "Content-Type": "application/json" } }
  );
});
