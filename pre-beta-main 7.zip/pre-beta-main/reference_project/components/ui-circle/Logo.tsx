import { useLogo } from "../LogoContext";

interface LogoProps {
  variant?: "full" | "icon" | "wordmark";
  size?: "small" | "medium" | "large";
  className?: string;
  forceImageUrl?: string; // Allow overriding the logo URL (useful for preview)
}

export function Logo({ variant = "full", size = "medium", className = "", forceImageUrl }: LogoProps) {
  const { currentLogo } = useLogo();
  
  const sizes = {
    small: {
      container: "w-10 h-10",
      text: "text-xl",
    },
    medium: {
      container: "w-16 h-16",
      text: "text-3xl",
    },
    large: {
      container: "w-24 h-24",
      text: "text-5xl",
    }
  };

  const currentSize = sizes[size];

  // Use imported image logo if available
  const logoImageUrl = forceImageUrl || currentLogo.imageUrl;

  // Icon variant using imported image
  const Icon = () => (
    <div className={`${currentSize.container} rounded-[28%] flex items-center justify-center flex-shrink-0 overflow-hidden ${className}`}>
      <img 
        src={logoImageUrl} 
        alt="pre logo" 
        className="w-full h-full object-cover"
      />
    </div>
  );

  // Wordmark - "pre" in Pacifico (standalone text)
  const Wordmark = () => (
    <span 
      className={`${currentSize.text} text-[#1A1A1A] dark:text-white leading-none`}
      style={{ fontFamily: "'Pacifico', cursive", fontWeight: 400 }}
    >
      pre
    </span>
  );

  if (variant === "icon") {
    return <Icon />;
  }

  if (variant === "wordmark") {
    return <Wordmark />;
  }

  // Full variant just shows the icon (since text is already inside)
  return <Icon />;
}