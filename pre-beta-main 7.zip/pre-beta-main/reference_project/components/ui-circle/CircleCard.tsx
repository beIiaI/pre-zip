import { Facepile } from "./Facepile";
import { StatusChip } from "./StatusChip";
import { Button } from "./Button";

interface CircleCardProps {
  title: string;
  description: string;
  memberCount: number;
  members: { id: string; initials: string }[];
  verified?: boolean;
  limited?: boolean;
  inviteOnly?: boolean;
  category?: string;
  ctaLabel?: string;
  onCta?: () => void;
  onPass?: () => void;
  onClick?: () => void;
}

export function CircleCard({
  title,
  description,
  memberCount,
  members,
  verified,
  limited,
  inviteOnly,
  category,
  ctaLabel = "Join",
  onCta,
  onPass,
  onClick
}: CircleCardProps) {
  return (
    <div 
      className="bg-white dark:bg-[#1A1A1A] rounded-xl border border-[#1A1A1A]/10 dark:border-white/10 p-5 cursor-pointer active:opacity-95 transition-opacity"
      onClick={onClick}
    >
      {/* Title */}
      <h3 className="text-[22px] leading-tight text-[#1A1A1A] dark:text-white mb-3">{title}</h3>
      
      {/* Status Chips */}
      <div className="flex items-center gap-2 mb-3">
        {category && <StatusChip>{category}</StatusChip>}
        {verified && <StatusChip variant="verified">Verified</StatusChip>}
        {inviteOnly && <StatusChip variant="limited">Invite only</StatusChip>}
        {limited && <StatusChip variant="limited">Limited seats</StatusChip>}
      </div>

      {/* Description */}
      <p className="text-[#666666] dark:text-[#999999] text-base leading-relaxed mb-4 line-clamp-2">
        {description}
      </p>

      {/* Members Facepile */}
      <div className="flex items-center justify-between mb-4 pb-4 border-b border-[#1A1A1A]/5 dark:border-white/5">
        <Facepile avatars={members} max={5} size={28} overlap={8} />
        <span className="text-xs text-[#999999] dark:text-[#888888]">{memberCount} members</span>
      </div>

      {/* Actions - ONE primary CTA per Dorsia rules */}
      <div className="flex gap-2">
        {onPass && (
          <Button
            variant="secondary"
            onClick={(e) => {
              e.stopPropagation();
              onPass();
            }}
          >
            Pass
          </Button>
        )}
        {onCta && (
          <Button
            variant="primary"
            fullWidth={!onPass}
            onClick={(e) => {
              e.stopPropagation();
              onCta();
            }}
          >
            {ctaLabel}
          </Button>
        )}
      </div>
    </div>
  );
}