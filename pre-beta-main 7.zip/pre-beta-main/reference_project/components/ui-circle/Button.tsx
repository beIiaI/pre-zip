import { ReactNode, ButtonHTMLAttributes } from "react";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost";
  size?: "default" | "large";
  fullWidth?: boolean;
  loading?: boolean;
  children: ReactNode;
}

export function Button({
  variant = "primary",
  size = "default",
  fullWidth = false,
  loading = false,
  disabled,
  children,
  className = "",
  ...props
}: ButtonProps) {
  const baseStyles = "inline-flex items-center justify-center transition-all rounded-full";
  
  const variantStyles = {
    primary: "bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] active:bg-[#333333] dark:active:bg-[#E5E5E5] disabled:opacity-30",
    secondary: "bg-transparent border border-[#1A1A1A]/10 dark:border-white/10 text-[#1A1A1A] dark:text-white active:bg-[#F5F5F5] dark:active:bg-[#1A1A1A] disabled:opacity-30",
    ghost: "bg-transparent text-[#1A1A1A] dark:text-white active:bg-[#F5F5F5] dark:active:bg-[#1A1A1A] disabled:opacity-30"
  };
  
  const sizeStyles = {
    default: "px-6 py-3 text-[15px]",
    large: "px-8 py-4 text-base"
  };
  
  const widthStyle = fullWidth ? "w-full" : "";
  
  return (
    <button
      className={`${baseStyles} ${variantStyles[variant]} ${sizeStyles[size]} ${widthStyle} ${className}`}
      disabled={disabled || loading}
      {...props}
    >
      {loading ? (
        <span className="inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
      ) : (
        children
      )}
    </button>
  );
}