import { ReactNode } from "react";

interface AppBarProps {
  title?: string;
  left?: ReactNode;
  right?: ReactNode;
  subtitle?: string;
}

export function AppBar({ title, left, right, subtitle }: AppBarProps) {
  return (
    <div className="bg-[#FAFAFA] border-b border-[#1A1A1A]/10">
      <div className="px-6 pt-14 pb-4 bg-[rgba(0,0,0,0.9)]">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            {left}
            {title && <h1 className="text-[32px] leading-tight text-[#1A1A1A]">{title}</h1>}
          </div>
          {right}
        </div>
        {subtitle && <p className="text-sm text-[#666666]">{subtitle}</p>}
      </div>
    </div>
  );
}
