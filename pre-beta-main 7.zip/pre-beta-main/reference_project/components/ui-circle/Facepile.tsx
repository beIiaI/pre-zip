interface FacepileProps {
  avatars: { id: string; initials: string; image?: string }[];
  max?: number;
  size?: number;
  overlap?: number;
}

export function Facepile({ avatars, max = 4, size = 28, overlap = 8 }: FacepileProps) {
  const displayAvatars = avatars.slice(0, max);
  const remaining = avatars.length - max;

  return (
    <div className="flex items-center">
      {displayAvatars.map((avatar, index) => (
        <div
          key={avatar.id}
          className="rounded-full bg-[#1A1A1A] dark:bg-white border-2 border-white dark:border-[#1A1A1A] flex items-center justify-center text-white dark:text-[#1A1A1A]"
          style={{
            width: size,
            height: size,
            marginLeft: index > 0 ? -overlap : 0,
            zIndex: displayAvatars.length - index,
            fontSize: size * 0.4
          }}
        >
          {avatar.image ? (
            <img src={avatar.image} alt="" className="w-full h-full rounded-full object-cover" />
          ) : (
            <span>{avatar.initials}</span>
          )}
        </div>
      ))}
      {remaining > 0 && (
        <div
          className="rounded-full bg-[#F0F0F0] dark:bg-[#2A2A2A] border-2 border-white dark:border-[#1A1A1A] flex items-center justify-center text-[#666666] dark:text-[#999999]"
          style={{
            width: size,
            height: size,
            marginLeft: -overlap,
            fontSize: size * 0.35
          }}
        >
          +{remaining}
        </div>
      )}
    </div>
  );
}