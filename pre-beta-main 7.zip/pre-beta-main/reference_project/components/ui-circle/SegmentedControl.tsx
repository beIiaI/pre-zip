interface SegmentedControlProps {
  options: string[];
  value: string;
  onChange: (value: string) => void;
}

export function SegmentedControl({ options, value, onChange }: SegmentedControlProps) {
  return (
    <div className="inline-flex bg-[#F5F5F5] dark:bg-[#2A2A2A] rounded-full p-1">
      {options.map((option) => (
        <button
          key={option}
          onClick={() => onChange(option)}
          className={`px-5 py-2 rounded-full text-sm transition-all ${
            value === option
              ? "bg-white dark:bg-[#1A1A1A] text-[#1A1A1A] dark:text-white shadow-sm"
              : "text-[#999999] dark:text-[#888888]"
          }`}
        >
          {option}
        </button>
      ))}
    </div>
  );
}