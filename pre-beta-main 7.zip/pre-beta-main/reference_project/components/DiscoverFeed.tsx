import { motion } from "motion/react";
import { Search, Plus, MapPin, Users, Calendar, Circle } from "lucide-react";
import { useRef } from "react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const circleData = [
  {
    id: 1,
    name: "Coffee Enthusiasts",
    members: 24,
    category: "Food & Drink",
    image: "https://images.unsplash.com/photo-1633114129669-78b1ff09902b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2ZmZWUlMjBzaG9wJTIwbWVldGluZ3xlbnwxfHx8fDE3NjA1Mjk2NDF8MA&ixlib=rb-4.1.0&q=80&w=1080",
    nextEvent: "Tomorrow, 10:00 AM",
    location: "Downtown Café"
  },
  {
    id: 2,
    name: "Weekend Hikers",
    members: 18,
    category: "Outdoors",
    image: "https://images.unsplash.com/photo-1608972601286-f8efa720c1d4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaWtpbmclMjBncm91cCUyMGFkdmVudHVyZXxlbnwxfHx8fDE3NjA1OTg4NTh8MA&ixlib=rb-4.1.0&q=80&w=1080",
    nextEvent: "Saturday, 7:00 AM",
    location: "Trailhead Park"
  },
  {
    id: 3,
    name: "Book Club",
    members: 32,
    category: "Literature",
    image: "https://images.unsplash.com/photo-1638644074459-9067407b72a3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmllbmRzJTIwbGF1Z2hpbmclMjB0b2dldGhlcnxlbnwxfHx8fDE3NjA1MzQwNDJ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    nextEvent: "Friday, 6:00 PM",
    location: "Central Library"
  },
  {
    id: 4,
    name: "Urban Photographers",
    members: 15,
    category: "Photography",
    image: "https://images.unsplash.com/photo-1679001976050-1c49846db5e0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMGFkdWx0cyUyMG91dGRvb3J8ZW58MXx8fHwxNzYwNTk4ODU4fDA&ixlib=rb-4.1.0&q=80&w=1080",
    nextEvent: "Sunday, 3:00 PM",
    location: "Arts District"
  },
  {
    id: 5,
    name: "Social Mixers",
    members: 42,
    category: "Networking",
    image: "https://images.unsplash.com/photo-1491438590914-bc09fcaaf77a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMHBlb3BsZSUyMHNvY2lhbHxlbnwxfHx8fDE3NjA1OTg4NTd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    nextEvent: "Thursday, 7:00 PM",
    location: "The Rooftop Bar"
  }
];

export function DiscoverFeed({ onCircleClick, onCreateClick, onProfileClick }: { 
  onCircleClick: () => void;
  onCreateClick: () => void;
  onProfileClick: () => void;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);

  return (
    <div className="relative h-screen w-full overflow-hidden bg-[#FAFAFA]">
      {/* Top Navigation Bar */}
      <div className="px-6 pt-14 pb-6 bg-white border-b border-[#F0F0F0]">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-[#1A1A1A]">Discover</h2>
          <button
            onClick={onProfileClick}
            className="w-10 h-10 rounded-full bg-[#1A1A1A] flex items-center justify-center text-white"
          >
            <span className="text-sm">JD</span>
          </button>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#999999]" />
          <input
            type="text"
            placeholder="Search circles or activities..."
            className="w-full pl-12 pr-4 py-3 bg-[#F5F5F5] rounded-xl outline-none text-[#1A1A1A] placeholder:text-[#999999]"
          />
        </div>
      </div>

      {/* Scrollable Content */}
      <div ref={scrollRef} className="h-full overflow-y-auto pb-32 px-6 pt-6">
        <div className="space-y-6">
          {circleData.map((circle, index) => (
            <motion.div
              key={circle.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              onClick={onCircleClick}
              className="bg-white rounded-2xl overflow-hidden border border-[#F0F0F0] shadow-sm cursor-pointer active:scale-[0.98] transition-transform"
            >
              {/* Card Image */}
              <div className="relative h-48 overflow-hidden bg-[#F5F5F5]">
                <ImageWithFallback
                  src={circle.image}
                  alt={circle.name}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Card Content */}
              <div className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="mb-2 text-[#1A1A1A]">{circle.name}</h3>
                    <div className="flex items-center gap-2 mb-4">
                      <span className="text-sm text-[#999999]">{circle.category}</span>
                      <span className="text-[#E0E0E0]">•</span>
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4 text-[#999999]" />
                        <span className="text-sm text-[#999999]">{circle.members}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Next Event */}
                <div className="p-4 rounded-xl bg-[#FAFAFA] mb-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar className="w-4 h-4 text-[#1A1A1A]" />
                    <span className="text-sm text-[#1A1A1A]">{circle.nextEvent}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-[#999999]" />
                    <span className="text-sm text-[#999999]">{circle.location}</span>
                  </div>
                </div>

                {/* Join Button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                  }}
                  className="w-full px-6 py-3 bg-[#1A1A1A] text-white rounded-xl transition-opacity hover:opacity-90 active:opacity-80"
                >
                  Join Circle
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Floating Action Button */}
      <button
        onClick={onCreateClick}
        className="fixed bottom-24 right-6 w-14 h-14 rounded-full bg-[#1A1A1A] shadow-lg flex items-center justify-center z-40 active:scale-95 transition-transform"
      >
        <Plus className="w-6 h-6 text-white" />
      </button>

      {/* Bottom Tab Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[#F0F0F0] px-6 py-4 flex items-center justify-around z-40">
        <TabBarItem icon={<Search className="w-6 h-6" />} label="Discover" active />
        <TabBarItem icon={<Users className="w-6 h-6" />} label="Circles" />
        <TabBarItem icon={<Calendar className="w-6 h-6" />} label="Events" />
        <TabBarItem icon={<Circle className="w-6 h-6" />} label="Profile" />
      </div>
    </div>
  );
}

function TabBarItem({ icon, label, active }: { icon: React.ReactNode; label: string; active?: boolean }) {
  return (
    <button className="flex flex-col items-center gap-1 min-w-[60px]">
      <div className={active ? 'text-[#1A1A1A]' : 'text-[#CCCCCC]'}>
        {icon}
      </div>
      <span className={`text-xs ${active ? 'text-[#1A1A1A]' : 'text-[#CCCCCC]'}`}>{label}</span>
    </button>
  );
}
