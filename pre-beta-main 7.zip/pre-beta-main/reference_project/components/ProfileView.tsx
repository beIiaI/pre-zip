import { motion } from "motion/react";
import { ArrowLeft, Settings, MapPin, Calendar, Users } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const joinedCircles = [
  {
    id: 1,
    name: "Coffee Enthusiasts",
    members: 24,
    image: "https://images.unsplash.com/photo-1633114129669-78b1ff09902b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2ZmZWUlMjBzaG9wJTIwbWVldGluZ3xlbnwxfHx8fDE3NjA1Mjk2NDF8MA&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    id: 2,
    name: "Weekend Hikers",
    members: 18,
    image: "https://images.unsplash.com/photo-1608972601286-f8efa720c1d4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaWtpbmclMjBncm91cCUyMGFkdmVudHVyZXxlbnwxfHx8fDE3NjA1OTg4NTh8MA&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    id: 3,
    name: "Book Club",
    members: 32,
    image: "https://images.unsplash.com/photo-1638644074459-9067407b72a3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmllbmRzJTIwbGF1Z2hpbmclMjB0b2dldGhlcnxlbnwxfHx8fDE3NjA1MzQwNDJ8MA&ixlib=rb-4.1.0&q=80&w=1080"
  }
];

const upcomingEvents = [
  { id: 1, title: "Sunday Morning Brew", date: "Tomorrow, 10:00 AM", circle: "Coffee Enthusiasts" },
  { id: 2, title: "Mountain Trail Hike", date: "Saturday, 7:00 AM", circle: "Weekend Hikers" }
];

const badges = [
  { id: 1, name: "Early Bird", icon: "🌅" },
  { id: 2, name: "Social", icon: "🦋" },
  { id: 3, name: "Explorer", icon: "🗺️" }
];

const stats = [
  { label: "Circles", value: "3" },
  { label: "Events", value: "12" },
  { label: "Friends", value: "47" }
];

export function ProfileView({ onBack }: { onBack: () => void }) {
  return (
    <div className="relative h-screen w-full overflow-hidden bg-white">
      {/* Header */}
      <div className="px-6 pt-14 pb-6 border-b border-[#F0F0F0]">
        <div className="flex items-center justify-between">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-[#F5F5F5] flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-[#1A1A1A]" />
          </button>
          <h2 className="text-[#1A1A1A]">Profile</h2>
          <button className="w-10 h-10 rounded-full bg-[#F5F5F5] flex items-center justify-center">
            <Settings className="w-5 h-5 text-[#1A1A1A]" />
          </button>
        </div>
      </div>

      {/* Scrollable Content */}
      <div className="h-full overflow-y-auto pb-16 px-6">
        {/* Profile Header */}
        <div className="py-8 text-center border-b border-[#F0F0F0]">
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", bounce: 0.4 }}
            className="w-24 h-24 mx-auto mb-4 rounded-full bg-[#1A1A1A] flex items-center justify-center text-white shadow-sm"
          >
            <span className="text-2xl">JD</span>
          </motion.div>

          <h2 className="mb-2 text-[#1A1A1A]">Jordan Davis</h2>
          <div className="flex items-center justify-center gap-2 mb-4">
            <MapPin className="w-4 h-4 text-[#999999]" />
            <span className="text-sm text-[#999999]">San Francisco, CA</span>
          </div>

          <p className="text-[#6B6B6B] leading-relaxed max-w-sm mx-auto mb-6">
            Coffee lover, weekend explorer, and book enthusiast. Always up for meeting new people and trying new things.
          </p>

          {/* Stats */}
          <div className="flex items-center justify-center gap-8">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <p className="text-2xl text-[#1A1A1A] mb-1">{stat.value}</p>
                <p className="text-xs text-[#999999]">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Joined Circles */}
        <div className="py-6 border-b border-[#F0F0F0]">
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-[#1A1A1A]">My Circles</h3>
            <button className="text-sm text-[#1A1A1A]">See All</button>
          </div>

          <div className="space-y-3">
            {joinedCircles.map((circle, index) => (
              <motion.div
                key={circle.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="p-4 rounded-xl bg-[#FAFAFA] border border-[#F0F0F0] cursor-pointer active:scale-[0.98] transition-transform"
              >
                <div className="flex items-center gap-4">
                  <div className="relative w-14 h-14 rounded-xl overflow-hidden bg-[#F5F5F5] flex-shrink-0">
                    <ImageWithFallback
                      src={circle.image}
                      alt={circle.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h4 className="mb-1 text-[#1A1A1A]">{circle.name}</h4>
                    <div className="flex items-center gap-1">
                      <Users className="w-3.5 h-3.5 text-[#999999]" />
                      <span className="text-sm text-[#999999]">{circle.members} members</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Upcoming Events */}
        <div className="py-6 border-b border-[#F0F0F0]">
          <h3 className="mb-5 text-[#1A1A1A]">Upcoming Events</h3>

          <div className="space-y-3">
            {upcomingEvents.map((event, index) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="p-4 rounded-xl bg-[#FAFAFA] border border-[#F0F0F0] cursor-pointer active:scale-[0.98] transition-transform"
              >
                <h4 className="mb-2 text-[#1A1A1A]">{event.title}</h4>
                <div className="flex items-center gap-4 text-sm text-[#6B6B6B]">
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-4 h-4 text-[#999999]" />
                    <span>{event.date}</span>
                  </div>
                  <span className="text-[#E0E0E0]">•</span>
                  <span>{event.circle}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Badges */}
        <div className="py-6">
          <h3 className="mb-5 text-[#1A1A1A]">Achievements</h3>

          <div className="grid grid-cols-3 gap-3">
            {badges.map((badge, index) => (
              <motion.div
                key={badge.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                className="p-4 rounded-xl bg-[#FAFAFA] border border-[#F0F0F0] text-center cursor-pointer active:scale-95 transition-transform"
              >
                <div className="text-3xl mb-2">{badge.icon}</div>
                <p className="text-xs text-[#1A1A1A]">{badge.name}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
