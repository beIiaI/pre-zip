import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import defaultLogo from "figma:asset/b589069c787cae69559cb65aa0e5119f4771a650.png";
import oceanDepthLogo from "figma:asset/9a847af90b199de59049afe9bc24544a4797cc05.png";

// Logo configuration
export type LogoId = "default" | "ocean-depth";

export interface LogoConfig {
  id: LogoId;
  name: string;
  description: string;
  imageUrl: string;
  isPremium?: boolean;
}

export const AVAILABLE_LOGOS: LogoConfig[] = [
  {
    id: "default",
    name: "Sky Blue",
    description: "Classic Malibu vibes",
    imageUrl: defaultLogo,
  },
  {
    id: "ocean-depth",
    name: "Ocean Depth",
    description: "Deep wave layers",
    imageUrl: oceanDepthLogo,
  },
];

interface LogoContextType {
  selectedLogoId: LogoId;
  setSelectedLogoId: (id: LogoId) => void;
  currentLogo: LogoConfig;
}

const LogoContext = createContext<LogoContextType | undefined>(undefined);

export function LogoProvider({ children }: { children: ReactNode }) {
  const [selectedLogoId, setSelectedLogoIdState] = useState<LogoId>("default");

  // Load saved logo preference on mount
  useEffect(() => {
    const savedLogoId = localStorage.getItem("pre-app-logo") as LogoId;
    if (savedLogoId && AVAILABLE_LOGOS.some(logo => logo.id === savedLogoId)) {
      setSelectedLogoIdState(savedLogoId);
    }
  }, []);

  // Save logo preference when it changes
  const setSelectedLogoId = (id: LogoId) => {
    setSelectedLogoIdState(id);
    localStorage.setItem("pre-app-logo", id);
  };

  const currentLogo = AVAILABLE_LOGOS.find(logo => logo.id === selectedLogoId) || AVAILABLE_LOGOS[0];

  return (
    <LogoContext.Provider value={{ selectedLogoId, setSelectedLogoId, currentLogo }}>
      {children}
    </LogoContext.Provider>
  );
}

export function useLogo() {
  const context = useContext(LogoContext);
  if (context === undefined) {
    throw new Error("useLogo must be used within a LogoProvider");
  }
  return context;
}