import { motion } from "motion/react";
import { ArrowLeft, MapPin, Calendar, Users, Share2, Bell } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const members = [
  { id: 1, name: "Sarah Chen", initials: "SC" },
  { id: 2, name: "Michael Ross", initials: "MR" },
  { id: 3, name: "Emma Davis", initials: "ED" },
  { id: 4, name: "James Wilson", initials: "JW" },
  { id: 5, name: "Lisa Park", initials: "LP" },
  { id: 6, name: "Tom Anderson", initials: "TA" }
];

const upcomingEvents = [
  {
    id: 1,
    title: "Sunday Morning Brew",
    date: "Oct 20, 10:00 AM",
    location: "Downtown Café",
    attendees: 12
  },
  {
    id: 2,
    title: "Coffee Tasting Workshop",
    date: "Oct 27, 2:00 PM",
    location: "Bean & Leaf",
    attendees: 8
  },
  {
    id: 3,
    title: "Espresso Masterclass",
    date: "Nov 3, 11:00 AM",
    location: "Roastery Studio",
    attendees: 15
  }
];

export function CircleDetail({ onBack }: { onBack: () => void }) {
  return (
    <div className="relative h-screen w-full overflow-hidden bg-white">
      {/* Hero Image */}
      <div className="relative h-64 overflow-hidden bg-[#F5F5F5]">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1633114129669-78b1ff09902b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2ZmZWUlMjBzaG9wJTIwbWVldGluZ3xlbnwxfHx8fDE3NjA1Mjk2NDF8MA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Coffee Enthusiasts"
          className="w-full h-full object-cover"
        />
        
        {/* Top Bar */}
        <div className="absolute top-0 left-0 right-0 px-6 pt-14 pb-4 flex items-center justify-between">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-[#1A1A1A]" />
          </button>
          <button className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center">
            <Share2 className="w-5 h-5 text-[#1A1A1A]" />
          </button>
        </div>
      </div>

      {/* Scrollable Content */}
      <div className="h-full overflow-y-auto pb-32">
        {/* Header Section */}
        <div className="px-6 py-6 border-b border-[#F0F0F0]">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <h2 className="mb-3 text-[#1A1A1A]">Coffee Enthusiasts</h2>
              <div className="flex items-center gap-4 mb-4">
                <span className="text-sm text-[#999999]">Food & Drink</span>
                <span className="text-[#E0E0E0]">•</span>
                <div className="flex items-center gap-1">
                  <Users className="w-4 h-4 text-[#999999]" />
                  <span className="text-sm text-[#999999]">24 members</span>
                </div>
              </div>
            </div>
            <button className="w-10 h-10 rounded-full bg-[#F5F5F5] flex items-center justify-center">
              <Bell className="w-5 h-5 text-[#1A1A1A]" />
            </button>
          </div>

          <p className="text-[#6B6B6B] leading-relaxed">
            A community of coffee lovers exploring the best cafés, learning about brewing techniques, and sharing our passion for the perfect cup.
          </p>
        </div>

        {/* Members Section */}
        <div className="px-6 py-6 border-b border-[#F0F0F0]">
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-[#1A1A1A]">Members</h3>
            <button className="text-sm text-[#1A1A1A]">See All</button>
          </div>

          <div className="flex items-center gap-3 overflow-x-auto pb-2">
            {members.map((member, index) => (
              <motion.div
                key={member.id}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className="flex-shrink-0"
              >
                <div className="w-14 h-14 rounded-full bg-[#1A1A1A] flex items-center justify-center text-white border-2 border-white shadow-sm">
                  <span className="text-sm">{member.initials}</span>
                </div>
              </motion.div>
            ))}
            <div className="flex-shrink-0 w-14 h-14 rounded-full bg-[#F5F5F5] flex items-center justify-center border-2 border-white shadow-sm">
              <span className="text-sm text-[#999999]">+18</span>
            </div>
          </div>
        </div>

        {/* Upcoming Events */}
        <div className="px-6 py-6">
          <h3 className="mb-5 text-[#1A1A1A]">Upcoming Events</h3>
          <div className="space-y-4">
            {upcomingEvents.map((event, index) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="p-5 rounded-xl bg-[#FAFAFA] border border-[#F0F0F0] cursor-pointer active:scale-[0.98] transition-transform"
              >
                <h4 className="mb-3 text-[#1A1A1A]">{event.title}</h4>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-[#999999]" />
                    <span className="text-sm text-[#6B6B6B]">{event.date}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-[#999999]" />
                    <span className="text-sm text-[#6B6B6B]">{event.location}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-[#999999]" />
                    <span className="text-sm text-[#6B6B6B]">{event.attendees} going</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 p-6 bg-white border-t border-[#F0F0F0] z-40">
        <button className="w-full px-6 py-4 bg-[#1A1A1A] text-white rounded-xl transition-opacity hover:opacity-90 active:opacity-80">
          Join Circle
        </button>
      </div>
    </div>
  );
}
