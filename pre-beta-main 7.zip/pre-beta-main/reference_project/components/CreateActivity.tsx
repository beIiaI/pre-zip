import { motion } from "motion/react";
import { X, Calendar, MapPin, Users, Clock, Tag } from "lucide-react";
import { useState } from "react";

export function CreateActivity({ onClose }: { onClose: () => void }) {
  const [formData, setFormData] = useState({
    title: "",
    date: "",
    time: "",
    location: "",
    maxAttendees: "",
    category: ""
  });

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-end bg-black/20"
      onClick={onClose}
    >
      <motion.div
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        transition={{ type: "spring", damping: 30, stiffness: 300 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-h-[90vh] rounded-t-3xl bg-white shadow-2xl overflow-hidden"
      >
        {/* Handle Bar */}
        <div className="flex justify-center pt-3 pb-2">
          <div className="w-10 h-1 rounded-full bg-[#E0E0E0]" />
        </div>

        {/* Header */}
        <div className="px-6 py-5 border-b border-[#F0F0F0] flex items-center justify-between">
          <h2 className="text-[#1A1A1A]">Create Activity</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#F5F5F5] flex items-center justify-center active:scale-95 transition-transform"
          >
            <X className="w-4 h-4 text-[#1A1A1A]" />
          </button>
        </div>

        {/* Form Content */}
        <div className="overflow-y-auto px-6 py-6 space-y-6" style={{ maxHeight: 'calc(90vh - 180px)' }}>
          {/* Title Input */}
          <div>
            <label className="block mb-3 text-sm text-[#6B6B6B]">Activity Title</label>
            <input
              type="text"
              placeholder="e.g., Weekend Coffee Meetup"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-4 py-4 rounded-xl bg-[#F5F5F5] border border-transparent focus:border-[#1A1A1A] outline-none transition-colors text-[#1A1A1A] placeholder:text-[#999999]"
            />
          </div>

          {/* Category */}
          <div>
            <label className="block mb-3 text-sm text-[#6B6B6B]">Category</label>
            <div className="relative">
              <Tag className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#999999]" />
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full pl-12 pr-4 py-4 rounded-xl bg-[#F5F5F5] border border-transparent focus:border-[#1A1A1A] outline-none transition-colors text-[#1A1A1A] appearance-none"
              >
                <option value="">Select a category</option>
                <option value="food">Food & Drink</option>
                <option value="outdoors">Outdoors</option>
                <option value="sports">Sports & Fitness</option>
                <option value="arts">Arts & Culture</option>
                <option value="tech">Technology</option>
                <option value="social">Social</option>
              </select>
            </div>
          </div>

          {/* Date and Time */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block mb-3 text-sm text-[#6B6B6B]">Date</label>
              <div className="relative">
                <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#999999]" />
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="w-full pl-11 pr-4 py-4 rounded-xl bg-[#F5F5F5] border border-transparent focus:border-[#1A1A1A] outline-none transition-colors text-[#1A1A1A] text-sm"
                />
              </div>
            </div>
            <div>
              <label className="block mb-3 text-sm text-[#6B6B6B]">Time</label>
              <div className="relative">
                <Clock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#999999]" />
                <input
                  type="time"
                  value={formData.time}
                  onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                  className="w-full pl-11 pr-4 py-4 rounded-xl bg-[#F5F5F5] border border-transparent focus:border-[#1A1A1A] outline-none transition-colors text-[#1A1A1A] text-sm"
                />
              </div>
            </div>
          </div>

          {/* Location */}
          <div>
            <label className="block mb-3 text-sm text-[#6B6B6B]">Location</label>
            <div className="relative">
              <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#999999]" />
              <input
                type="text"
                placeholder="Where will this happen?"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="w-full pl-12 pr-4 py-4 rounded-xl bg-[#F5F5F5] border border-transparent focus:border-[#1A1A1A] outline-none transition-colors text-[#1A1A1A] placeholder:text-[#999999]"
              />
            </div>
          </div>

          {/* Max Attendees */}
          <div>
            <label className="block mb-3 text-sm text-[#6B6B6B]">Max Attendees</label>
            <div className="relative">
              <Users className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#999999]" />
              <input
                type="number"
                placeholder="How many people can join?"
                value={formData.maxAttendees}
                onChange={(e) => setFormData({ ...formData, maxAttendees: e.target.value })}
                className="w-full pl-12 pr-4 py-4 rounded-xl bg-[#F5F5F5] border border-transparent focus:border-[#1A1A1A] outline-none transition-colors text-[#1A1A1A] placeholder:text-[#999999]"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block mb-3 text-sm text-[#6B6B6B]">Description (Optional)</label>
            <textarea
              placeholder="Tell people what to expect..."
              rows={4}
              className="w-full px-4 py-4 rounded-xl bg-[#F5F5F5] border border-transparent focus:border-[#1A1A1A] outline-none transition-colors text-[#1A1A1A] placeholder:text-[#999999] resize-none"
            />
          </div>

          {/* Circle Selection */}
          <div>
            <label className="block mb-3 text-sm text-[#6B6B6B]">Share with Circle</label>
            <div className="space-y-3">
              {[
                { name: "Coffee Enthusiasts", members: 24 },
                { name: "Weekend Hikers", members: 18 },
                { name: "Book Club", members: 32 }
              ].map((circle, index) => (
                <div
                  key={index}
                  className="p-4 rounded-xl bg-[#F5F5F5] border border-transparent hover:border-[#E0E0E0] cursor-pointer flex items-center justify-between active:scale-[0.98] transition-transform"
                >
                  <div>
                    <p className="text-sm text-[#1A1A1A] mb-1">{circle.name}</p>
                    <p className="text-xs text-[#999999]">{circle.members} members</p>
                  </div>
                  <div className="w-5 h-5 rounded-full border-2 border-[#CCCCCC]" />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Action */}
        <div className="px-6 py-5 border-t border-[#F0F0F0] bg-white">
          <button className="w-full px-6 py-4 bg-[#1A1A1A] text-white rounded-xl transition-opacity hover:opacity-90 active:opacity-80">
            Create Activity
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}
