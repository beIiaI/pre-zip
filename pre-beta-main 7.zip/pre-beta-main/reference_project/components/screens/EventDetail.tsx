import { ArrowLeft, Share2, Calendar, MapPin, Users } from "lucide-react";
import { AppBar } from "../ui-circle/AppBar";
import { NavBar } from "../ui-circle/NavBar";
import { Divider } from "../ui-circle/Divider";
import { Facepile } from "../ui-circle/Facepile";
import { useTheme } from "../ThemeContext";

interface EventDetailProps {
  onBack: () => void;
}

export function EventDetail({ onBack }: EventDetailProps) {
  const { getBackgroundClass } = useTheme();

  return (
    <div className={`h-screen ${getBackgroundClass()} flex flex-col`}>
      {/* ORIENTATION */}
      <AppBar
        left={
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#2A2A2A] flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-[#1A1A1A] dark:text-white" strokeWidth={1.5} />
          </button>
        }
        right={
          <button className="w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#2A2A2A] flex items-center justify-center">
            <Share2 className="w-5 h-5 text-[#1A1A1A] dark:text-white" strokeWidth={1.5} />
          </button>
        }
      />

      {/* CONTENT */}
      <div className="flex-1 overflow-y-auto pb-32">
        {/* Hero Image with Skrim */}
        <div className="relative h-64 bg-gradient-to-br from-[#F5F5F5] to-[#E5E5E5]">
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
        </div>

        {/* Event Info */}
        <div className="px-6 py-6">
          <h1 className="text-[32px] leading-tight text-[#1A1A1A] mb-3">
            Sunday Morning Brew
          </h1>

          <div className="flex items-center gap-2 mb-6">
            <StatusChip>Coffee Enthusiasts</StatusChip>
            <StatusChip variant="limited">8 spots left</StatusChip>
          </div>

          {/* Details Grid */}
          <div className="space-y-4 mb-6">
            <div className="flex items-center gap-3">
              <Calendar className="w-5 h-5 text-[#666666]" strokeWidth={1.5} />
              <div>
                <p className="text-base text-[#1A1A1A]">Tomorrow, October 20</p>
                <p className="text-sm text-[#666666]">10:00 AM - 12:00 PM</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <MapPin className="w-5 h-5 text-[#666666]" strokeWidth={1.5} />
              <div>
                <p className="text-base text-[#1A1A1A]">Downtown Café</p>
                <p className="text-sm text-[#666666]">123 Market St, San Francisco</p>
              </div>
            </div>
          </div>

          {/* Description */}
          <p className="text-base text-[#666666] leading-relaxed">
            Join us for our weekly coffee meetup! Great conversations, amazing espresso, and a chance to connect with fellow coffee enthusiasts. All skill levels welcome.
          </p>
        </div>

        <Divider spacing="none" />

        {/* Host Section (Bento compartment) */}
        <div className="px-6 py-6 bg-[#FAFAFA]">
          <h2 className="text-[22px] leading-tight text-[#1A1A1A] mb-4">Hosted by</h2>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-[#1A1A1A] text-white flex items-center justify-center relative">
              <span>{host.initials}</span>
              <span className="absolute -bottom-1 -right-1 text-base">{host.badge}</span>
            </div>
            <div>
              <p className="text-base text-[#1A1A1A]">{host.name}</p>
              <p className="text-sm text-[#666666]">Initiator Badge</p>
            </div>
          </div>
        </div>

        <Divider spacing="none" />

        {/* Attendees */}
        <div className="px-6 py-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-[22px] leading-tight text-[#1A1A1A]">Attendees</h2>
            <span className="text-sm text-[#666666]">{attendees.length} going</span>
          </div>
          <Facepile avatars={attendees} max={8} size={36} overlap={12} />
        </div>
      </div>

      {/* ACTION */}
      <ActionBar>
        <Button variant="primary" size="large" fullWidth>
          Join Event
        </Button>
      </ActionBar>

      {/* NAVIGATION */}
      <NavBar
        items={[
          { icon: <Users className="w-6 h-6" strokeWidth={1.5} />, label: "Discover" },
          { icon: <Users className="w-6 h-6" strokeWidth={1.5} />, label: "Circles" },
          { icon: <Calendar className="w-6 h-6" strokeWidth={1.5} />, label: "Events", active: true },
          { icon: <Users className="w-6 h-6" strokeWidth={1.5} />, label: "Profile" }
        ]}
      />
    </div>
  );
}