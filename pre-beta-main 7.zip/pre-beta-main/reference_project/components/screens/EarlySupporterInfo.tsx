import { ArrowLeft } from "lucide-react";
import { useTheme } from "../ThemeContext";

interface EarlySupporterInfoProps {
  onBack: () => void;
  supporterNumber: number;
}

export function EarlySupporterInfo({ onBack, supporterNumber }: EarlySupporterInfoProps) {
  const { getBackgroundClass } = useTheme();
  
  return (
    <div className={`h-screen ${getBackgroundClass()} flex flex-col`}>
      {/* Header */}
      <div className="px-6 pt-14 pb-4 border-b border-[#1A1A1A]/10 dark:border-white/10">
        <div className="flex items-center gap-4">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#2A2A2A] flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-[#1A1A1A] dark:text-white" strokeWidth={1.5} />
          </button>
          <h2 className="text-[#1A1A1A] dark:text-white">Early Supporter</h2>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-6 py-12">
        <div className="max-w-md mx-auto text-center">
          {/* Large Number Display with Limited Edition Frame */}
          <div className="mb-8">
            <div className="inline-flex flex-col items-center justify-center px-8 py-10 rounded-2xl border-2 border-[#1A1A1A]/20 dark:border-white/20 bg-gradient-to-br from-[#FAFAFA] via-white to-[#F5F5F5] dark:from-[#1A1A1A] dark:via-[#0A0A0A] dark:to-[#000000] shadow-lg mb-6">
              <p className="text-[9px] tracking-[0.2em] font-medium text-[#999999] dark:text-[#666666] mb-3">
                USER NUMBER
              </p>
              <div className="font-mono text-5xl text-[#1A1A1A] dark:text-white mb-3 tracking-tight">
                #{String(supporterNumber).padStart(3, '0')}
              </div>
              <div className="w-16 h-[1px] bg-[#1A1A1A]/20 dark:bg-white/20 mb-3" />
              <p className="text-[9px] tracking-[0.2em] font-medium text-[#999999] dark:text-[#666666]">
                OF 250
              </p>
            </div>
          </div>

          {/* Title */}
          <h3 className="mb-3 text-[#1A1A1A] dark:text-white">Early Supporter</h3>
          
          {/* Description */}
          <p className="text-[#666666] dark:text-[#AAAAAA] leading-relaxed mb-8">
            You're one of the first 250 people to join pre. This exclusive badge and your member number are permanent and will never change.
          </p>

          {/* Rarity Info Box */}
          <div className="p-6 rounded-xl border border-[#1A1A1A]/10 dark:border-white/10 bg-white dark:bg-[#1A1A1A] mb-8">
            <div className="flex items-center justify-center gap-2 mb-3">
              <span className="text-lg">✦</span>
              <h4 className="text-sm text-[#1A1A1A] dark:text-white">Founding Member</h4>
            </div>
            <p className="text-sm text-[#666666] dark:text-[#AAAAAA] leading-relaxed">
              As an early supporter, you helped shape the future of pre. This badge represents your place in our founding community.
            </p>
          </div>

          {/* Exclusivity Message */}
          <p className="text-xs text-[#999999] dark:text-[#666666] italic">
            Only {supporterNumber} of 250 badges have been claimed
          </p>
        </div>
      </div>
    </div>
  );
}