import { ArrowLeft, Sun, Moon, Monitor, Smartphone, Palette } from "lucide-react";
import { AppBar } from "../ui-circle/AppBar";
import { NavBar } from "../ui-circle/NavBar";
import { Divider } from "../ui-circle/Divider";
import { useTheme } from "../ThemeContext";
import { useLogo, AVAILABLE_LOGOS } from "../LogoContext";
import { Logo } from "../ui-circle/Logo";
import { Check } from "lucide-react";

interface SettingsScreenProps {
  onBack: () => void;
}

export function SettingsScreen({ onBack }: SettingsScreenProps) {
  const { themeMode, setThemeMode, amoledMode, setAmoledMode, getBackgroundClass } = useTheme();
  const { selectedLogoId, setSelectedLogoId } = useLogo();

  return (
    <div className={`h-screen ${getBackgroundClass()} flex flex-col`}>
      {/* ORIENTATION */}
      <AppBar
        title="Settings"
        subtitle="Manage your preferences"
        left={
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#2A2A2A] flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-[#1A1A1A] dark:text-white" strokeWidth={1.5} />
          </button>
        }
      />

      {/* CONTENT */}
      <div className="flex-1 overflow-y-auto pb-24">
        {/* App Icon Section */}
        <div className="px-6 py-6">
          <h2 className="text-[22px] leading-tight text-[#1A1A1A] dark:text-white mb-4">
            App Icon
          </h2>

          <div className="space-y-3">
            {AVAILABLE_LOGOS.map((logo) => (
              <button
                key={logo.id}
                onClick={() => setSelectedLogoId(logo.id)}
                className={`w-full p-5 rounded-xl border text-left transition-colors ${
                  selectedLogoId === logo.id
                    ? "border-[#1A1A1A] dark:border-white bg-[#FAFAFA] dark:bg-[#2A2A2A]"
                    : "border-[#1A1A1A]/10 dark:border-white/10"
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-4">
                    <div className="w-14 h-14 flex-shrink-0">
                      <Logo size="small" className="!w-14 !h-14" forceImageUrl={logo.imageUrl} />
                    </div>
                    <div className="flex-1">
                      <h4 className="mb-1 text-[#1A1A1A] dark:text-white">{logo.name}</h4>
                      <p className="text-sm text-[#666666] dark:text-[#999999]">{logo.description}</p>
                    </div>
                  </div>
                  {selectedLogoId === logo.id && (
                    <Check className="w-5 h-5 text-[#1A1A1A] dark:text-white flex-shrink-0 mt-0.5" strokeWidth={2} />
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>

        <Divider spacing="none" />

        {/* Appearance Section */}
        <div className="px-6 py-6">
          <h2 className="text-[22px] leading-tight text-[#1A1A1A] dark:text-white mb-4">
            Appearance
          </h2>

          <div className="space-y-3">
            {/* Light Mode */}
            <button
              onClick={() => setThemeMode("light")}
              className={`w-full p-5 rounded-xl border text-left transition-colors ${
                themeMode === "light"
                  ? "border-[#1A1A1A] dark:border-white bg-[#FAFAFA] dark:bg-[#2A2A2A]"
                  : "border-[#1A1A1A]/10 dark:border-white/10"
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-white border border-[#1A1A1A]/10 flex items-center justify-center flex-shrink-0">
                    <Sun className="w-6 h-6 text-[#1A1A1A]" />
                  </div>
                  <div className="flex-1">
                    <h4 className="mb-1 text-[#1A1A1A] dark:text-white">Light</h4>
                    <p className="text-sm text-[#666666] dark:text-[#999999]">Bright and clean interface</p>
                  </div>
                </div>
                {themeMode === "light" && (
                  <Check className="w-5 h-5 text-[#1A1A1A] dark:text-white flex-shrink-0 mt-0.5" strokeWidth={2} />
                )}
              </div>
            </button>

            {/* Dark Mode */}
            <button
              onClick={() => setThemeMode("dark")}
              className={`w-full p-5 rounded-xl border text-left transition-colors ${
                themeMode === "dark"
                  ? "border-[#1A1A1A] dark:border-white bg-[#FAFAFA] dark:bg-[#2A2A2A]"
                  : "border-[#1A1A1A]/10 dark:border-white/10"
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-[#1A1A1A] flex items-center justify-center flex-shrink-0">
                    <Moon className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="mb-1 text-[#1A1A1A] dark:text-white">Dark</h4>
                    <p className="text-sm text-[#666666] dark:text-[#999999]">Easy on the eyes in low light</p>
                  </div>
                </div>
                {themeMode === "dark" && (
                  <Check className="w-5 h-5 text-[#1A1A1A] dark:text-white flex-shrink-0 mt-0.5" strokeWidth={2} />
                )}
              </div>
            </button>

            {/* AMOLED Dark Mode - Only show when dark mode is active */}
            {themeMode === "dark" && (
              <div className="ml-6 pl-6 border-l-2 border-[#1A1A1A]/10 dark:border-white/10">
                <button
                  onClick={() => setAmoledMode(!amoledMode)}
                  className={`w-full p-4 rounded-xl border text-left transition-colors ${
                    amoledMode
                      ? "border-[#1A1A1A] dark:border-white bg-[#FAFAFA] dark:bg-[#000000]"
                      : "border-[#1A1A1A]/10 dark:border-white/10"
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-xl bg-[#000000] flex items-center justify-center flex-shrink-0">
                        <Smartphone className="w-5 h-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <h4 className="mb-1 text-[#1A1A1A] dark:text-white">AMOLED Dark</h4>
                        <p className="text-sm text-[#666666] dark:text-[#999999]">Pure black for OLED screens</p>
                      </div>
                    </div>
                    {amoledMode && (
                      <Check className="w-5 h-5 text-[#1A1A1A] dark:text-white flex-shrink-0 mt-0.5" strokeWidth={2} />
                    )}
                  </div>
                </button>
              </div>
            )}

            {/* System Mode */}
            <button
              onClick={() => setThemeMode("system")}
              className={`w-full p-5 rounded-xl border text-left transition-colors ${
                themeMode === "system"
                  ? "border-[#1A1A1A] dark:border-white bg-[#FAFAFA] dark:bg-[#2A2A2A]"
                  : "border-[#1A1A1A]/10 dark:border-white/10"
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#F5F5F5] to-[#1A1A1A] flex items-center justify-center flex-shrink-0">
                    <Monitor className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="mb-1 text-[#1A1A1A] dark:text-white">System</h4>
                    <p className="text-sm text-[#666666] dark:text-[#999999]">Match your device settings</p>
                  </div>
                </div>
                {themeMode === "system" && (
                  <Check className="w-5 h-5 text-[#1A1A1A] dark:text-white flex-shrink-0 mt-0.5" strokeWidth={2} />
                )}
              </div>
            </button>
          </div>
        </div>

        <Divider spacing="none" />

        {/* Other Settings Sections */}
        <div className="px-6 py-6">
          <h2 className="text-[22px] leading-tight text-[#1A1A1A] dark:text-white mb-4">
            Account
          </h2>
          <div className="space-y-3">
            <button className="w-full p-4 rounded-xl border border-[#1A1A1A]/10 dark:border-white/10 text-left">
              <p className="text-[#1A1A1A] dark:text-white">Edit Profile</p>
            </button>
            <button className="w-full p-4 rounded-xl border border-[#1A1A1A]/10 dark:border-white/10 text-left">
              <p className="text-[#1A1A1A] dark:text-white">Change Password</p>
            </button>
          </div>
        </div>

        <Divider spacing="none" />

        <div className="px-6 py-6">
          <h2 className="text-[22px] leading-tight text-[#1A1A1A] dark:text-white mb-4">
            About
          </h2>
          <div className="space-y-3">
            <button className="w-full p-4 rounded-xl border border-[#1A1A1A]/10 dark:border-white/10 text-left">
              <p className="text-[#1A1A1A] dark:text-white">Privacy Policy</p>
            </button>
            <button className="w-full p-4 rounded-xl border border-[#1A1A1A]/10 dark:border-white/10 text-left">
              <p className="text-[#1A1A1A] dark:text-white">Terms of Service</p>
            </button>
            <button className="w-full p-4 rounded-xl border border-[#1A1A1A]/10 dark:border-white/10 text-left">
              <p className="text-[#1A1A1A] dark:text-white">Version 1.0.0</p>
            </button>
          </div>
        </div>
      </div>

      {/* NAVIGATION */}
      <NavBar
        items={[
          { icon: <Sun className="w-6 h-6" strokeWidth={1.5} />, label: "Discover" },
          { icon: <Sun className="w-6 h-6" strokeWidth={1.5} />, label: "Circles" },
          { icon: <Sun className="w-6 h-6" strokeWidth={1.5} />, label: "Events" },
          { icon: <Sun className="w-6 h-6" strokeWidth={1.5} />, label: "Profile", active: true }
        ]}
      />
    </div>
  );
}