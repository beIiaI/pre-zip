import { ArrowLeft, Share2, Users, Calendar, MessageCircle } from "lucide-react";
import { useState } from "react";
import { Facepile } from "../ui-circle/Facepile";
import { StatusChip } from "../ui-circle/StatusChip";
import { SegmentedControl } from "../ui-circle/SegmentedControl";

interface CircleProfileProps {
  onBack: () => void;
}

const members = Array.from({ length: 24 }, (_, i) => ({
  id: `${i}`,
  initials: ["SC", "MR", "ED", "JW", "LP", "TA"][i % 6]
}));

const events = [
  {
    id: "1",
    title: "Sunday Morning Brew",
    date: "Tomorrow, 10:00 AM",
    location: "Downtown Café",
    attendees: 12
  },
  {
    id: "2",
    title: "Coffee Tasting Workshop",
    date: "Oct 27, 2:00 PM",
    location: "Bean & Leaf",
    attendees: 8
  }
];

export function CircleProfile({ onBack }: CircleProfileProps) {
  const [activeTab, setActiveTab] = useState("Chat");

  return (
    <div className="h-screen bg-white flex flex-col">
      {/* Header with back button */}
      <div className="px-6 pt-14 pb-4 flex items-center justify-between border-b border-[#1A1A1A]/10">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-[#F5F5F5] flex items-center justify-center"
        >
          <ArrowLeft className="w-5 h-5" strokeWidth={1.5} />
        </button>
        <button className="w-10 h-10 rounded-full bg-[#F5F5F5] flex items-center justify-center">
          <Share2 className="w-5 h-5" strokeWidth={1.5} />
        </button>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto">
        {/* Cover */}
        <div className="h-48 bg-gradient-to-br from-[#F5F5F5] to-[#E5E5E5]" />

        {/* Info */}
        <div className="px-6 py-6 border-b border-[#1A1A1A]/10">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <h2 className="mb-3 text-[#1A1A1A]">Coffee Enthusiasts</h2>
              <div className="flex items-center gap-2 mb-4">
                <StatusChip>Food & Drink</StatusChip>
                <StatusChip variant="verified">Verified</StatusChip>
              </div>
              <div className="flex items-center gap-1 text-sm text-[#666666]">
                <Users className="w-4 h-4" strokeWidth={1.5} />
                <span>24 members</span>
              </div>
            </div>
          </div>

          <p className="text-[#666666] leading-relaxed mb-6">
            A community of coffee lovers exploring the best cafés, learning about brewing techniques, and sharing our passion for the perfect cup.
          </p>

          {/* Rules */}
          <div className="p-4 rounded-xl bg-[#FAFAFA] border border-[#1A1A1A]/5 mb-6">
            <h4 className="mb-3 text-[#1A1A1A]">Circle Rules</h4>
            <ul className="space-y-2 text-sm text-[#666666]">
              <li>• Be respectful and welcoming to all members</li>
              <li>• Share coffee recommendations and tips freely</li>
              <li>• RSVP to events and show up on time</li>
            </ul>
          </div>

          {/* Members Grid */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-[#1A1A1A]">Members</h4>
              <button className="text-sm text-[#1A1A1A]">See all</button>
            </div>
            <Facepile avatars={members} max={8} size={32} overlap={10} />
          </div>
        </div>

        {/* Tabs */}
        <div className="px-6 py-4 border-b border-[#1A1A1A]/10">
          <SegmentedControl
            options={["Chat", "Events"]}
            value={activeTab}
            onChange={setActiveTab}
          />
        </div>

        {/* Tab Content */}
        <div className="px-6 py-6">
          {activeTab === "Chat" ? (
            <div className="text-center py-12">
              <MessageCircle className="w-12 h-12 text-[#CCCCCC] mx-auto mb-4" strokeWidth={1.5} />
              <h4 className="mb-2 text-[#1A1A1A]">Join to see chat</h4>
              <p className="text-sm text-[#666666] mb-6">
                Connect with members and join the conversation
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {events.map((event) => (
                <div
                  key={event.id}
                  className="p-5 rounded-xl border border-[#1A1A1A]/10"
                >
                  <h4 className="mb-3 text-[#1A1A1A]">{event.title}</h4>
                  <div className="space-y-2 text-sm text-[#666666]">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" strokeWidth={1.5} />
                      <span>{event.date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4" strokeWidth={1.5} />
                      <span>{event.attendees} going</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Bottom CTA */}
      <div className="p-6 border-t border-[#1A1A1A]/10">
        <button className="w-full px-6 py-4 bg-[#1A1A1A] text-white rounded-full">
          Request to Join
        </button>
      </div>
    </div>
  );
}
