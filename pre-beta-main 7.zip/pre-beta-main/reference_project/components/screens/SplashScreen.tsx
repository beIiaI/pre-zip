import { motion } from "motion/react";
import { useTheme } from "../ThemeContext";
import { useState, useEffect } from "react";

interface SplashScreenProps {
  onGetStarted: () => void;
  onSignIn: () => void;
}

export function SplashScreen({ onGetStarted, onSignIn }: SplashScreenProps) {
  const { getBackgroundClass } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const circles = [
    { size: '280px', x: '20%', y: '30%', duration: 8, delay: 0 },
    { size: '240px', x: '75%', y: '45%', duration: 10, delay: 1 },
    { size: '200px', x: '50%', y: '60%', duration: 12, delay: 0.5 },
  ];

  const accents = [
    { size: '120px', x: '25%', y: '70%', delay: 2 },
    { size: '90px', x: '80%', y: '25%', delay: 3 },
  ];

  return (
    <div className={`relative h-screen ${getBackgroundClass()} overflow-hidden`}>
      {/* Overlapping Circle Animation */}
      <div className="absolute inset-0 overflow-hidden">
        {circles.map((circle, index) => (
          <motion.div
            key={`circle-${index}`}
            className="absolute rounded-full"
            initial={{ opacity: 0, scale: 0.7 }}
            animate={mounted ? {
              opacity: [0, 0.35, 0.35],
              scale: [0.7, 1.05, 1],
              y: [0, -12, 0]
            } : {}}
            transition={{
              duration: circle.duration,
              repeat: Infinity,
              ease: "easeInOut",
              delay: circle.delay,
              times: [0, 0.5, 1]
            }}
            style={{
              width: circle.size,
              height: circle.size,
              left: circle.x,
              top: circle.y,
              transform: 'translate(-50%, -50%)',
              border: '3px solid #C7E5FF'
            }}
            className="dark:!border-[#3A7CAF]"
          />
        ))}
        
        {accents.map((accent, index) => (
          <motion.div
            key={`accent-${index}`}
            className="absolute rounded-full"
            initial={{ opacity: 0, scale: 0.6 }}
            animate={mounted ? {
              opacity: [0, 0.4, 0.4, 0],
              scale: [0.6, 1.1, 1.3, 1.5]
            } : {}}
            transition={{
              duration: 6,
              repeat: Infinity,
              ease: "easeInOut",
              delay: accent.delay,
              times: [0, 0.3, 0.6, 1]
            }}
            style={{
              width: accent.size,
              height: accent.size,
              left: accent.x,
              top: accent.y,
              transform: 'translate(-50%, -50%)',
              border: '3px solid #C7E5FF'
            }}
            className="dark:!border-[#3A7CAF]"
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col h-full px-6">
        {/* Wordmark */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.3 }}
          className="pt-14"
        >
          <p 
            className="text-center text-[28px] text-[#1A1A1A] dark:text-white opacity-90" 
            style={{ fontFamily: "'Pacifico', cursive", fontWeight: 400 }}
          >
            pre
          </p>
        </motion.div>

        {/* Main content area */}
        <div className="flex-1 flex flex-col justify-end pb-10">
          {/* Small tagline */}
          <motion.div
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="mb-3"
          >
            <p className="text-center text-[10px] tracking-[0.3em] uppercase text-[#666666] dark:text-[#AAAAAA]" style={{ fontWeight: 500 }}>
              The prelude to great friendships
            </p>
          </motion.div>

          {/* Main headline */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="mb-12 px-4"
          >
            <h2 
              className="text-center text-[38px] leading-[1.12] text-[#1A1A1A] dark:text-white"
              style={{ fontFamily: "'Fraunces', serif", fontWeight: 600 }}
            >
              Find your people.<br />Build your community.
            </h2>
          </motion.div>

          {/* CTA Button - Premium Design */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1 }}
            className="mb-5"
          >
            <button
              onClick={onGetStarted}
              className="w-full bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] transition-all active:scale-[0.98] flex items-center justify-center"
              style={{ 
                height: '52px',
                fontSize: '15px',
                fontWeight: 500,
                letterSpacing: '0.01em',
                borderRadius: '26px'
              }}
            >
              Get started
            </button>
          </motion.div>

          {/* Sign in link */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 1.2 }}
            className="pb-2"
          >
            <p className="text-center text-[15px] text-[#666666] dark:text-[#AAAAAA]">
              Already have an account?{" "}
              <button onClick={onSignIn} className="text-[#1A1A1A] dark:text-white">
                Sign in
              </button>
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
