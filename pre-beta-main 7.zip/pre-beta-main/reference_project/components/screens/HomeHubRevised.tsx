import { useState } from "react";
import { Users, Calendar, MapPin, Bell, SlidersHorizontal, User2, TrendingUp, Search, Compass } from "lucide-react";
import { Facepile } from "../ui-circle/Facepile";
import { StatusChip } from "../ui-circle/StatusChip";
import { AppBar } from "../ui-circle/AppBar";
import { NavBar } from "../ui-circle/NavBar";
import { Divider } from "../ui-circle/Divider";
import { SegmentedControl } from "../ui-circle/SegmentedControl";
import { CircleCard } from "../ui-circle/CircleCard";
import { useTheme } from "../ThemeContext";

interface HomeHubRevisedProps {
  onCircleClick: () => void;
  onEventClick: () => void;
  onProfileClick: () => void;
}

const circlesData = [
  {
    id: "1",
    title: "Coffee Enthusiasts",
    description: "A community of coffee lovers exploring the best cafés and brewing techniques. Weekly meetups downtown.",
    memberCount: 24,
    members: [
      { id: "1", initials: "SC" },
      { id: "2", initials: "MR" },
      { id: "3", initials: "ED" },
      { id: "4", initials: "JW" },
      { id: "5", initials: "LP" }
    ],
    category: "Food & Drink",
    verified: true,
    inviteOnly: false
  },
  {
    id: "2",
    title: "Weekend Hikers",
    description: "Exploring local trails every Saturday morning. All skill levels welcome for outdoor adventures.",
    memberCount: 18,
    members: [
      { id: "5", initials: "LP" },
      { id: "6", initials: "TA" },
      { id: "7", initials: "KM" },
      { id: "8", initials: "RJ" }
    ],
    category: "Outdoors",
    limited: true,
    inviteOnly: false
  },
  {
    id: "3",
    title: "Tech Founders Circle",
    description: "Private community for early-stage founders. Monthly dinners, quarterly retreats, and ongoing support.",
    memberCount: 12,
    members: [
      { id: "9", initials: "AM" },
      { id: "10", initials: "BK" },
      { id: "11", initials: "CL" }
    ],
    category: "Technology",
    verified: true,
    inviteOnly: true
  }
];

const peopleData = [
  {
    id: "1",
    title: "Sarah Chen",
    description: "Coffee addict, weekend photographer. Looking for friends to explore new cafés around SF.",
    memberCount: 3,
    members: [
      { id: "1", initials: "CE" },
      { id: "2", initials: "WH" },
      { id: "3", initials: "BK" }
    ],
    category: "Pacific Heights"
  }
];

const eventsData = [
  {
    id: "1",
    title: "Sunday Morning Brew",
    description: "Join us for our weekly coffee meetup. Great conversations and amazing espresso at Downtown Café.",
    memberCount: 12,
    members: [
      { id: "1", initials: "SC" },
      { id: "2", initials: "MR" },
      { id: "3", initials: "ED" },
      { id: "4", initials: "JW" }
    ],
    category: "Tomorrow, 10AM",
    limited: true
  }
];

export function HomeHubRevised({ onCircleClick, onEventClick, onProfileClick }: HomeHubRevisedProps) {
  const [activeTab, setActiveTab] = useState("Circles");
  const [activeNav, setActiveNav] = useState("discover");
  const { getBackgroundClass } = useTheme();

  const getData = () => {
    switch (activeTab) {
      case "Circles":
        return circlesData;
      case "People":
        return peopleData;
      case "Events":
        return eventsData;
      default:
        return circlesData;
    }
  };

  const getCtaLabel = () => {
    switch (activeTab) {
      case "Circles":
        return "Join";
      case "People":
        return "Connect";
      case "Events":
        return "Join";
      default:
        return "Join";
    }
  };

  return (
    <div className={`h-screen ${getBackgroundClass()} flex flex-col`}>
      {/* ORIENTATION: App Bar (top) */}
      <AppBar
        title="Discover"
        subtitle="Find circles, people, and events near you"
        right={
          <button
            onClick={onProfileClick}
            className="w-10 h-10 rounded-full bg-[#1A1A1A] dark:bg-white flex items-center justify-center text-white dark:text-[#1A1A1A] text-sm"
          >
            JD
          </button>
        }
      />

      {/* CONTENT: Scrollable middle section */}
      <div className="flex-1 overflow-y-auto pb-24">
        {/* Search */}
        <div className="px-6 pt-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#999999] dark:text-[#888888]" strokeWidth={1.5} />
            <input
              type="text"
              placeholder="Search circles, people, or events"
              className="w-full pl-12 pr-4 py-3 rounded-xl border border-[#1A1A1A]/10 dark:border-white/10 outline-none focus:border-[#1A1A1A]/30 dark:focus:border-white/30 transition-colors text-base bg-white dark:bg-[#222222] text-[#1A1A1A] dark:text-white placeholder:text-[#999999] dark:placeholder:text-[#888888]"
            />
          </div>
        </div>

        <Divider />

        {/* Filter Bar */}
        <div className="px-6 flex items-center justify-between mb-4">
          <SegmentedControl
            options={["Circles", "People", "Events"]}
            value={activeTab}
            onChange={setActiveTab}
          />
          <button className="w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#2A2A2A] flex items-center justify-center">
            <SlidersHorizontal className="w-5 h-5 text-[#1A1A1A] dark:text-white" strokeWidth={1.5} />
          </button>
        </div>

        {/* Cards List */}
        <div className="px-6 space-y-4 pb-6">
          {getData().map((item) => (
            <CircleCard
              key={item.id}
              title={item.title}
              description={item.description}
              memberCount={item.memberCount}
              members={item.members}
              verified={item.verified}
              limited={item.limited}
              inviteOnly={item.inviteOnly}
              category={item.category}
              ctaLabel={getCtaLabel()}
              onCta={() => {
                if (activeTab === "Events") onEventClick();
                else onCircleClick();
              }}
              onPass={activeTab === "People" ? () => {} : undefined}
              onClick={() => {
                if (activeTab === "Events") onEventClick();
                else onCircleClick();
              }}
            />
          ))}
        </div>
      </div>

      {/* NAVIGATION: Bottom Nav Bar */}
      <NavBar
        items={[
          {
            icon: <Compass className="w-6 h-6" strokeWidth={1.5} />,
            label: "Discover",
            active: activeNav === "discover",
            onClick: () => setActiveNav("discover")
          },
          {
            icon: <Users className="w-6 h-6" strokeWidth={1.5} />,
            label: "Circles",
            active: activeNav === "circles",
            onClick: () => setActiveNav("circles")
          },
          {
            icon: <Calendar className="w-6 h-6" strokeWidth={1.5} />,
            label: "Events",
            active: activeNav === "events",
            onClick: () => setActiveNav("events")
          },
          {
            icon: <Users className="w-6 h-6" strokeWidth={1.5} />,
            label: "Profile",
            active: activeNav === "profile",
            onClick: () => {
              setActiveNav("profile");
              onProfileClick();
            }
          }
        ]}
      />
    </div>
  );
}