import { useState, useRef } from "react";
import { motion, AnimatePresence, useMotionValue, useTransform, PanInfo } from "motion/react";
import { ChevronLeft, Check, MapPin, SunMedium, MoonStar, Laptop } from "lucide-react";
import { BottomSheet } from "../ui-circle/BottomSheet";
import { Button } from "../ui-circle/Button";
import { Logo } from "../ui-circle/Logo";
import { useTheme } from "../ThemeContext";

interface OnboardingFlowProps {
  onComplete: () => void;
  mode?: "signup" | "signin";
}

export function OnboardingFlow({ onComplete, mode = "signup" }: OnboardingFlowProps) {
  const [step, setStep] = useState(0);
  const [userTypes, setUserTypes] = useState<string[]>([]);
  const [interests, setInterests] = useState<string[]>([]);
  const [location, setLocation] = useState("");
  const [showLocationSheet, setShowLocationSheet] = useState(false);
  const [dateOfBirth, setDateOfBirth] = useState({ month: "", day: "", year: "" });
  const { themeMode, setThemeMode, getBackgroundClass } = useTheme();
  
  // Sign-in form state
  const [signInSubStep, setSignInSubStep] = useState<"email" | "password">("email");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [accountExists, setAccountExists] = useState(false);
  const [isCheckingEmail, setIsCheckingEmail] = useState(false);
  
  // Social sign-in state
  const [showAppleSheet, setShowAppleSheet] = useState(false);
  const [showGoogleSheet, setShowGoogleSheet] = useState(false);
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  
  // Auth flow state
  const [showModePrompt, setShowModePrompt] = useState(false);
  const [promptType, setPromptType] = useState<"switch-signin" | "switch-signup" | "auto-signin" | null>(null);
  const [currentMode, setCurrentMode] = useState(mode);
  
  // Swipe state
  const x = useMotionValue(0);
  const opacity = useTransform(x, [0, 150], [1, 0.5]);
  
  // Mock database of existing accounts
  const mockAccounts = [
    { email: "john@example.com", password: "Password123" },
    { email: "sarah@example.com", password: "Welcome123" },
    { email: "alex@example.com", password: "Circle2024" },
  ];

  const handleDragEnd = (event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    if (info.offset.x > 150 && step > 0) {
      // Swipe right to go back
      if (step === 1 && signInSubStep === "password") {
        handleBackFromPassword();
      } else {
        goBack();
      }
    }
    x.set(0);
  };

  const goBack = () => {
    if (step > 0) {
      setStep(step - 1);
    }
  };

  // Email validation
  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  // Password validation
  const validatePassword = (password: string) => {
    const hasMinLength = password.length >= 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumber = /\d/.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    
    return {
      isValid: hasMinLength && hasUpperCase && hasLowerCase && hasNumber,
      hasMinLength,
      hasUpperCase,
      hasLowerCase,
      hasNumber,
      hasSpecialChar
    };
  };

  const handleEmailChange = (value: string) => {
    setEmail(value);
    if (emailError && value) {
      if (validateEmail(value)) {
        setEmailError("");
      }
    }
  };

  const handlePasswordChange = (value: string) => {
    setPassword(value);
    if (passwordError && value) {
      const validation = validatePassword(value);
      if (validation.isValid) {
        setPasswordError("");
      }
    }
  };

  const handleContinueFromEmail = async () => {
    // Validate email
    if (!email) {
      setEmailError("Email is required");
      return;
    }
    
    if (!validateEmail(email)) {
      setEmailError("Please enter a valid email address");
      return;
    }

    setEmailError("");
    setIsCheckingEmail(true);

    // Simulate API call to check if email exists
    await new Promise(resolve => setTimeout(resolve, 500));

    // Check if account exists in mock database
    const existingAccount = mockAccounts.find(acc => acc.email.toLowerCase() === email.toLowerCase());
    const emailExists = !!existingAccount;
    
    setAccountExists(emailExists);
    setIsCheckingEmail(false);
    setSignInSubStep("password");
  };

  const handleContinueFromPassword = async () => {
    // Validate password
    if (!password) {
      setPasswordError("Password is required");
      return;
    }

    // Check if account exists in mock database
    const existingAccount = mockAccounts.find(acc => acc.email.toLowerCase() === email.toLowerCase());
    
    // SIGNUP MODE
    if (currentMode === "signup") {
      if (existingAccount) {
        // Account exists - check if password matches
        if (existingAccount.password === password) {
          // Correct credentials - auto sign in with message
          setPromptType("auto-signin");
          setShowModePrompt(true);
          return;
        } else {
          // Wrong password - prompt to sign in instead
          setPromptType("switch-signin");
          setShowModePrompt(true);
          return;
        }
      } else {
        // New account - validate password for signup
        const validation = validatePassword(password);
        if (!validation.isValid) {
          const errors = [];
          if (!validation.hasMinLength) errors.push("at least 8 characters");
          if (!validation.hasUpperCase) errors.push("one uppercase letter");
          if (!validation.hasLowerCase) errors.push("one lowercase letter");
          if (!validation.hasNumber) errors.push("one number");
          setPasswordError(`Password must contain ${errors.join(", ")}`);
          return;
        }
        // Valid new signup
        setPasswordError("");
        setStep(2);
      }
    }
    
    // SIGNIN MODE
    if (currentMode === "signin") {
      if (!existingAccount) {
        // Account doesn't exist - prompt to sign up
        setPromptType("switch-signup");
        setShowModePrompt(true);
        return;
      } else {
        // Account exists - check password
        if (existingAccount.password === password) {
          // Correct credentials - sign in
          setPasswordError("");
          // Skip to home (complete onboarding)
          onComplete();
          return;
        } else {
          // Wrong password
          setPasswordError("Incorrect password. Please try again.");
          return;
        }
      }
    }
  };

  const handleBackFromPassword = () => {
    setSignInSubStep("email");
    setPassword("");
    setPasswordError("");
  };

  const handleAppleSignIn = async () => {
    setIsAuthenticating(true);
    // Simulate Face ID/Touch ID authentication
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsAuthenticating(false);
    setShowAppleSheet(false);
    // Proceed to next step after successful authentication
    setStep(2);
  };

  const handleGoogleSignIn = async () => {
    setIsAuthenticating(true);
    // Simulate account selection and authentication
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsAuthenticating(false);
    setShowGoogleSheet(false);
    // Proceed to next step after successful authentication
    setStep(2);
  };
  
  const handleSwitchToSignIn = () => {
    setShowModePrompt(false);
    setCurrentMode("signin");
    setSignInSubStep("email");
    setPassword("");
    setPasswordError("");
    setEmailError("");
  };
  
  const handleSwitchToSignUp = () => {
    setShowModePrompt(false);
    setCurrentMode("signup");
    setSignInSubStep("email");
    setPassword("");
    setPasswordError("");
    setEmailError("");
  };
  
  const handleAutoSignIn = () => {
    setShowModePrompt(false);
    // Skip onboarding and go straight to app
    onComplete();
  };
  
  const handleStayOnCurrentMode = () => {
    setShowModePrompt(false);
    setPassword("");
    setPasswordError("");
  };

  const interestOptions = [
    "Coffee & Cafés",
    "Outdoor Activities",
    "Books & Reading",
    "Arts & Culture",
    "Technology",
    "Sports & Fitness",
    "Food & Dining",
    "Photography",
    "Music",
    "Travel"
  ];

  const toggleInterest = (interest: string) => {
    setInterests(prev =>
      prev.includes(interest)
        ? prev.filter(i => i !== interest)
        : [...prev, interest]
    );
  };

  const steps = [
    // Step 0: Value Prop
    <div key="value" className="relative flex flex-col items-center justify-center h-full px-8 text-center overflow-hidden">
      {/* Abstract Jellyfish-like Animation Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Organic Blob 1 */}
        <motion.div
          className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-gradient-to-br from-[#C7E5FF]/30 to-[#A8D8FF]/20 dark:from-[#1A3A52]/40 dark:to-[#0D2535]/30 blur-3xl"
          animate={{
            x: [0, 30, 0],
            y: [0, 40, 0],
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        
        {/* Organic Blob 2 */}
        <motion.div
          className="absolute -bottom-32 -left-20 w-80 h-80 rounded-full bg-gradient-to-tr from-[#FFE5C7]/25 to-[#FFD8A8]/15 dark:from-[#523A1A]/35 dark:to-[#352D0D]/25 blur-3xl"
          animate={{
            x: [0, -40, 0],
            y: [0, -30, 0],
            scale: [1, 1.15, 1],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        
        {/* Organic Blob 3 */}
        <motion.div
          className="absolute top-1/3 left-1/4 w-48 h-48 rounded-full bg-gradient-to-bl from-[#E5C7FF]/20 to-[#D8A8FF]/10 dark:from-[#3A1A52]/30 dark:to-[#2D0D35]/20 blur-2xl"
          animate={{
            x: [0, 20, 0],
            y: [0, -25, 0],
            scale: [1, 1.2, 1],
            rotate: [0, 90, 0],
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        
        {/* Floating Tendril 1 */}
        <motion.div
          className="absolute top-1/4 right-1/3 w-32 h-64 rounded-full bg-gradient-to-b from-[#C7FFE5]/15 to-transparent dark:from-[#1A5239]/25 dark:to-transparent blur-xl"
          animate={{
            x: [0, 15, 0],
            y: [0, 30, 0],
            scaleY: [1, 1.3, 1],
            rotate: [0, 10, 0],
          }}
          transition={{
            duration: 9,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        
        {/* Floating Tendril 2 */}
        <motion.div
          className="absolute bottom-1/4 left-1/3 w-40 h-56 rounded-full bg-gradient-to-t from-[#FFC7E5]/12 to-transparent dark:from-[#521A3A]/20 dark:to-transparent blur-xl"
          animate={{
            x: [0, -20, 0],
            y: [0, -35, 0],
            scaleY: [1, 1.25, 1],
            rotate: [0, -15, 0],
          }}
          transition={{
            duration: 11,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      </div>
      
      {/* Content */}
      <div className="relative z-10">
        <h1 
          className="mb-4 text-[#1A1A1A] dark:text-white"
          style={{ fontFamily: "'Pacifico', cursive", fontSize: '42px', fontWeight: 400 }}
        >
          pre
        </h1>
        <p className="text-[#666666] dark:text-[#999999] leading-relaxed max-w-sm mb-12">
          Connect with people who share your interests. Build authentic friendships through meaningful experiences.
        </p>
        <button
          onClick={() => setStep(1)}
          className="w-full max-w-xs px-6 py-4 bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] rounded-full active:bg-[#333333] dark:active:bg-[#E5E5E5] transition-colors"
        >
          Continue
        </button>
      </div>
    </div>,

    // Step 1: Sign In/Sign Up
    <div key="signin" className="flex flex-col h-full px-6 pt-16">
      {signInSubStep === "password" && (
        <button 
          onClick={handleBackFromPassword}
          className="mb-8 w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#1A1A1A] flex items-center justify-center"
        >
          <ChevronLeft className="w-5 h-5 dark:text-white" />
        </button>
      )}
      {signInSubStep === "email" && (
        <button 
          onClick={() => setStep(0)}
          className="mb-8 w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#1A1A1A] flex items-center justify-center"
        >
          <ChevronLeft className="w-5 h-5 dark:text-white" />
        </button>
      )}

      {signInSubStep === "email" ? (
        // Email Entry Step
        <>
          <h2 className="mb-2 text-[#1A1A1A] dark:text-white">{currentMode === "signup" ? "Sign up" : "Sign in"}</h2>
          <p className="text-[#666666] dark:text-[#999999] mb-8">Connect with people who share your interests</p>
          
          <div className="flex-1 overflow-y-auto mb-4">
            {/* Social Sign In Options */}
            <div className="space-y-3 mb-6">
              <button 
                onClick={() => setShowAppleSheet(true)}
                className="w-full px-6 py-4 rounded-xl border border-[#1A1A1A]/10 dark:border-white/10 flex items-center justify-center gap-3 bg-white dark:bg-[#1A1A1A] active:bg-[#F5F5F5] dark:active:bg-[#2A2A2A] transition-colors"
              >
                <svg className="w-5 h-5 dark:text-white" viewBox="0 0 24 24">
                  <path fill="currentColor" d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09l.01-.01zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/>
                </svg>
                <span className="text-base text-[#1A1A1A] dark:text-white">Continue with Apple</span>
              </button>

              <button 
                onClick={() => setShowGoogleSheet(true)}
                className="w-full px-6 py-4 rounded-xl border border-[#1A1A1A]/10 dark:border-white/10 flex items-center justify-center gap-3 bg-white dark:bg-[#1A1A1A] active:bg-[#F5F5F5] dark:active:bg-[#2A2A2A] transition-colors"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                <span className="text-base text-[#1A1A1A] dark:text-white">Continue with Google</span>
              </button>
            </div>

            {/* Divider */}
            <div className="flex items-center gap-4 mb-6">
              <div className="flex-1 h-px bg-[#1A1A1A]/10 dark:bg-white/10" />
              <span className="text-sm text-[#999999] dark:text-[#666666]">or</span>
              <div className="flex-1 h-px bg-[#1A1A1A]/10 dark:bg-white/10" />
            </div>

            {/* Email Input */}
            <div className="space-y-2">
              <input
                type="email"
                placeholder="Email address"
                value={email}
                onChange={(e) => handleEmailChange(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    handleContinueFromEmail();
                  }
                }}
                onBlur={() => {
                  if (email && !validateEmail(email)) {
                    setEmailError("Please enter a valid email address");
                  }
                }}
                className={`w-full px-4 py-4 rounded-xl border outline-none transition-colors text-base bg-white dark:bg-[#1A1A1A] text-[#1A1A1A] dark:text-white placeholder:text-[#999999] dark:placeholder:text-[#666666] ${
                  emailError
                    ? "border-red-500 focus:border-red-500"
                    : "border-[#1A1A1A]/10 dark:border-white/10 focus:border-[#1A1A1A]/30 dark:focus:border-white/30"
                }`}
              />
              {emailError && (
                <p className="text-sm text-red-500">{emailError}</p>
              )}
            </div>
          </div>

          <div className="pb-8">
            <button
              onClick={handleContinueFromEmail}
              disabled={isCheckingEmail}
              className="w-full px-6 py-4 bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] rounded-full active:bg-[#000000] dark:active:bg-[#E5E5E5] transition-colors disabled:opacity-50"
            >
              {isCheckingEmail ? "Checking..." : "Continue"}
            </button>
          </div>
        </>
      ) : (
        // Password Entry Step
        <>
          <h2 className="mb-2 text-[#1A1A1A] dark:text-white">
            {currentMode === "signin" ? "Welcome back" : (accountExists ? "Welcome back" : "Create your account")}
          </h2>
          <p className="text-[#666666] dark:text-[#999999] mb-2">{email}</p>
          <button 
            onClick={handleBackFromPassword}
            className="text-sm text-[#1A1A1A] dark:text-white mb-6 text-left hover:underline"
          >
            Change email
          </button>
          
          <div className="flex-1 overflow-y-auto mb-4">
            {/* Password Input */}
            <div className="space-y-2 mb-4">
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Password"
                  value={password}
                  autoFocus
                  onChange={(e) => handlePasswordChange(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      handleContinueFromPassword();
                    }
                  }}
                  className={`w-full px-4 py-4 pr-12 rounded-xl border outline-none transition-colors text-base bg-white dark:bg-[#1A1A1A] text-[#1A1A1A] dark:text-white placeholder:text-[#999999] dark:placeholder:text-[#666666] ${
                    passwordError
                      ? "border-red-500 focus:border-red-500"
                      : "border-[#1A1A1A]/10 dark:border-white/10 focus:border-[#1A1A1A]/30 dark:focus:border-white/30"
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-[#999999] dark:text-[#666666] text-sm"
                >
                  {showPassword ? "Hide" : "Show"}
                </button>
              </div>
              {passwordError && (
                <p className="text-sm text-red-500 dark:text-red-400">{passwordError}</p>
              )}
            </div>

            {/* Password Requirements (only for new signups) */}
            {currentMode === "signup" && !accountExists && password && (
              <div className="p-4 rounded-xl bg-[#FAFAFA] dark:bg-[#1A1A1A] border border-transparent dark:border-white/10">
                <p className="text-xs text-[#666666] dark:text-[#999999] mb-2">Password must contain:</p>
                <div className="space-y-1">
                  <PasswordRequirement
                    met={validatePassword(password).hasMinLength}
                    text="At least 8 characters"
                  />
                  <PasswordRequirement
                    met={validatePassword(password).hasUpperCase}
                    text="One uppercase letter"
                  />
                  <PasswordRequirement
                    met={validatePassword(password).hasLowerCase}
                    text="One lowercase letter"
                  />
                  <PasswordRequirement
                    met={validatePassword(password).hasNumber}
                    text="One number"
                  />
                </div>
              </div>
            )}

            {/* Forgot password link for sign in mode or existing accounts */}
            {(currentMode === "signin" || accountExists) && (
              <button className="text-sm text-[#1A1A1A] dark:text-white hover:underline">
                Forgot password?
              </button>
            )}
          </div>

          <div className="pb-8">
            <button
              onClick={handleContinueFromPassword}
              className="w-full px-6 py-4 bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] rounded-full active:bg-[#333333] dark:active:bg-[#E5E5E5] transition-colors"
            >
              {currentMode === "signin" ? "Sign in" : (accountExists ? "Sign in" : "Create account")}
            </button>
          </div>
        </>
      )}
    </div>,

    // Step 2: Choose Type
    <div key="type" className="flex flex-col h-full px-6 pt-16">
      <button onClick={() => setStep(1)} className="mb-8 w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#1A1A1A] flex items-center justify-center">
        <ChevronLeft className="w-5 h-5 dark:text-white" />
      </button>
      <h2 className="mb-2 text-[#1A1A1A] dark:text-white">I'm here to</h2>
      <p className="text-[#666666] dark:text-[#999999] mb-8">Select all that apply</p>

      <div className="flex-1 overflow-y-auto mb-4">
        <div className="space-y-3">
          {[
            {
              id: "meet-people",
              title: "Meet new people",
              description: "Make friends with similar interests and values"
            },
            {
              id: "build-community",
              title: "Build a community",
              description: "Create and organize circles for others to join"
            },
            {
              id: "find-partners",
              title: "Find activity partners",
              description: "Connect for sports, hobbies, and shared activities"
            },
            {
              id: "attend-events",
              title: "Attend local events",
              description: "Discover and join social gatherings in your area"
            },
            {
              id: "network",
              title: "Network professionally",
              description: "Build meaningful professional relationships"
            },
            {
              id: "expand-circle",
              title: "Expand my social circle",
              description: "Branch out and meet people outside my usual groups"
            }
          ].map((option) => (
            <button
              key={option.id}
              onClick={() => {
                setUserTypes(prev =>
                  prev.includes(option.id)
                    ? prev.filter(t => t !== option.id)
                    : [...prev, option.id]
                );
              }}
              className={`w-full p-5 rounded-xl border text-left transition-colors ${
                userTypes.includes(option.id)
                  ? "border-[#1A1A1A] dark:border-white bg-[#FAFAFA] dark:bg-[#1A1A1A]"
                  : "border-[#1A1A1A]/10 dark:border-white/10"
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <h4 className="mb-1 text-[#1A1A1A] dark:text-white">{option.title}</h4>
                  <p className="text-sm text-[#666666] dark:text-[#999999]">{option.description}</p>
                </div>
                {userTypes.includes(option.id) && (
                  <Check className="w-5 h-5 text-[#1A1A1A] dark:text-white flex-shrink-0 mt-0.5" strokeWidth={2} />
                )}
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="pb-8">
        <button
          onClick={() => setStep(3)}
          disabled={userTypes.length === 0}
          className="w-full px-6 py-4 bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] rounded-full disabled:opacity-30 active:bg-[#333333] dark:active:bg-[#E5E5E5] transition-colors"
        >
          Continue
        </button>
      </div>
    </div>,

    // Step 3: Interests
    <div key="interests" className="flex flex-col h-full px-6 pt-16">
      <button onClick={() => setStep(2)} className="mb-8 w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#1A1A1A] flex items-center justify-center">
        <ChevronLeft className="w-5 h-5 dark:text-white" />
      </button>
      <h2 className="mb-2 text-[#1A1A1A] dark:text-white">Your Interests</h2>
      <p className="text-[#666666] dark:text-[#999999] mb-8">Select at least 3 interests</p>

      <div className="flex-1 overflow-y-auto mb-4">
        <div className="grid grid-cols-2 gap-3">
          {interestOptions.map((interest) => (
            <button
              key={interest}
              onClick={() => toggleInterest(interest)}
              className={`px-4 py-4 rounded-xl border text-sm text-left transition-colors ${
                interests.includes(interest)
                  ? "border-[#1A1A1A] dark:border-white bg-[#FAFAFA] dark:bg-[#1A1A1A]"
                  : "border-[#1A1A1A]/10 dark:border-white/10"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[#1A1A1A] dark:text-white">{interest}</span>
                {interests.includes(interest) && (
                  <Check className="w-4 h-4 text-[#1A1A1A] dark:text-white" />
                )}
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="pb-8">
        <button
          onClick={() => setStep(4)}
          disabled={interests.length < 3}
          className="w-full px-6 py-4 bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] rounded-full disabled:opacity-30 active:bg-[#333333] dark:active:bg-[#E5E5E5] transition-colors"
        >
          Continue
        </button>
      </div>
    </div>,

    // Step 4: Date of Birth
    <div key="dob" className="flex flex-col h-full px-6 pt-16">
      <button onClick={() => setStep(3)} className="mb-8 w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#1A1A1A] flex items-center justify-center">
        <ChevronLeft className="w-5 h-5 dark:text-white" />
      </button>
      <h2 className="mb-2 text-[#1A1A1A] dark:text-white">When's your birthday?</h2>
      <p className="text-[#666666] dark:text-[#999999] mb-8">You must be 18 or older to use pre</p>

      <div className="flex-1 mb-4">
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-3">
            {/* Month */}
            <div className="col-span-1">
              <label className="block text-xs text-[#666666] dark:text-[#999999] mb-2">Month</label>
              <input
                type="number"
                placeholder="MM"
                value={dateOfBirth.month}
                onChange={(e) => {
                  const value = e.target.value;
                  if (value.length <= 2 && (value === '' || (parseInt(value) >= 1 && parseInt(value) <= 12))) {
                    setDateOfBirth({ ...dateOfBirth, month: value });
                  }
                }}
                maxLength={2}
                className="w-full px-4 py-4 rounded-xl border border-[#1A1A1A]/10 dark:border-white/10 outline-none focus:border-[#1A1A1A]/30 dark:focus:border-white/30 transition-colors text-base bg-white dark:bg-[#1A1A1A] text-[#1A1A1A] dark:text-white placeholder:text-[#999999] dark:placeholder:text-[#666666] text-center"
              />
            </div>

            {/* Day */}
            <div className="col-span-1">
              <label className="block text-xs text-[#666666] dark:text-[#999999] mb-2">Day</label>
              <input
                type="number"
                placeholder="DD"
                value={dateOfBirth.day}
                onChange={(e) => {
                  const value = e.target.value;
                  if (value.length <= 2 && (value === '' || (parseInt(value) >= 1 && parseInt(value) <= 31))) {
                    setDateOfBirth({ ...dateOfBirth, day: value });
                  }
                }}
                maxLength={2}
                className="w-full px-4 py-4 rounded-xl border border-[#1A1A1A]/10 dark:border-white/10 outline-none focus:border-[#1A1A1A]/30 dark:focus:border-white/30 transition-colors text-base bg-white dark:bg-[#1A1A1A] text-[#1A1A1A] dark:text-white placeholder:text-[#999999] dark:placeholder:text-[#666666] text-center"
              />
            </div>

            {/* Year */}
            <div className="col-span-1">
              <label className="block text-xs text-[#666666] dark:text-[#999999] mb-2">Year</label>
              <input
                type="number"
                placeholder="YYYY"
                value={dateOfBirth.year}
                onChange={(e) => {
                  const value = e.target.value;
                  if (value.length <= 4) {
                    setDateOfBirth({ ...dateOfBirth, year: value });
                  }
                }}
                maxLength={4}
                className="w-full px-4 py-4 rounded-xl border border-[#1A1A1A]/10 dark:border-white/10 outline-none focus:border-[#1A1A1A]/30 dark:focus:border-white/30 transition-colors text-base bg-white dark:bg-[#1A1A1A] text-[#1A1A1A] dark:text-white placeholder:text-[#999999] dark:placeholder:text-[#666666] text-center"
              />
            </div>
          </div>

          <p className="text-xs text-[#999999] dark:text-[#666666] mt-4">
            Your age will only be visible to you and won't be shown on your profile. This helps us ensure our community is age-appropriate.
          </p>
        </div>
      </div>

      <div className="pb-8">
        <button
          onClick={() => setStep(5)}
          disabled={!dateOfBirth.month || !dateOfBirth.day || !dateOfBirth.year || dateOfBirth.year.length !== 4}
          className="w-full px-6 py-4 bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] rounded-full disabled:opacity-30 active:bg-[#333333] dark:active:bg-[#E5E5E5] transition-colors"
        >
          Continue
        </button>
      </div>
    </div>,

    // Step 5: Location
    <div key="location" className="flex flex-col h-full px-6 pt-16">
      <button onClick={() => setStep(4)} className="mb-8 w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#1A1A1A] flex items-center justify-center">
        <ChevronLeft className="w-5 h-5 dark:text-white" />
      </button>
      <h2 className="mb-2 text-[#1A1A1A] dark:text-white">Your Location</h2>
      <p className="text-[#666666] dark:text-[#999999] mb-8">Help us find circles near you</p>

      <div className="space-y-4 mb-auto">
        <input
          type="text"
          placeholder="City or ZIP code"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          className="w-full px-4 py-4 rounded-xl border border-[#1A1A1A]/10 dark:border-white/10 outline-none focus:border-[#1A1A1A]/30 dark:focus:border-white/30 transition-colors text-base bg-white dark:bg-[#1A1A1A] text-[#1A1A1A] dark:text-white placeholder:text-[#999999] dark:placeholder:text-[#666666]"
        />
        <button 
          onClick={() => setShowLocationSheet(true)}
          className="text-sm text-[#1A1A1A] dark:text-white flex items-center gap-2 hover:underline"
        >
          <MapPin className="w-4 h-4" strokeWidth={1.5} />
          Use current location
        </button>
      </div>

      <div className="pb-8">
        <button
          onClick={() => setStep(6)}
          disabled={!location}
          className="w-full px-6 py-4 bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] rounded-full disabled:opacity-30 active:bg-[#333333] dark:active:bg-[#E5E5E5] transition-colors"
        >
          Continue
        </button>
      </div>

      {/* Location Permission Bottom Sheet */}
      <BottomSheet
        isOpen={showLocationSheet}
        onClose={() => setShowLocationSheet(false)}
        title="Enable Location Services"
      >
        <div className="px-6 py-6">
          <div className="flex flex-col items-center text-center mb-6">
            <div className="w-16 h-16 rounded-full bg-[#F5F5F5] dark:bg-[#2A2A2A] flex items-center justify-center mb-4">
              <MapPin className="w-8 h-8 text-[#1A1A1A] dark:text-white" strokeWidth={1.5} />
            </div>
            <h3 className="text-[22px] leading-tight text-[#1A1A1A] dark:text-white mb-3">
              Allow Location Access
            </h3>
            <p className="text-base text-[#666666] dark:text-[#999999] leading-relaxed max-w-sm">
              pre uses your location to show you nearby circles, events, and people in your area. You can change this anytime in settings.
            </p>
          </div>

          <div className="space-y-3">
            <Button
              variant="primary"
              size="large"
              fullWidth
              onClick={() => {
                // Simulate getting location
                setLocation("San Francisco, CA");
                setShowLocationSheet(false);
              }}
            >
              Allow Location Access
            </Button>
            <Button
              variant="secondary"
              size="large"
              fullWidth
              onClick={() => setShowLocationSheet(false)}
            >
              Not Now
            </Button>
          </div>

          <p className="text-xs text-[#999999] dark:text-[#666666] text-center mt-4">
            Your location is only used to enhance your experience and is never shared without your permission.
          </p>
        </div>
      </BottomSheet>
    </div>,

    // Step 6: Theme Selection
    <div key="theme" className="flex flex-col h-full px-6 pt-16">
      <button onClick={() => setStep(5)} className="mb-8 w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#1A1A1A] flex items-center justify-center">
        <ChevronLeft className="w-5 h-5 dark:text-white" />
      </button>
      <h2 className="mb-2 text-[#1A1A1A] dark:text-white">Choose Your Theme</h2>
      <p className="text-[#666666] dark:text-[#999999] mb-8">Pick your preferred appearance</p>

      <div className="flex-1 overflow-y-auto mb-4">
        <div className="space-y-3">
          {/* Light Mode */}
          <button
            onClick={() => setThemeMode("light")}
            className={`w-full p-5 rounded-xl border text-left transition-colors ${
              themeMode === "light"
                ? "border-[#1A1A1A] dark:border-white bg-[#FAFAFA] dark:bg-[#1A1A1A]"
                : "border-[#1A1A1A]/10 dark:border-white/10"
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-white dark:bg-[#2A2A2A] border border-[#1A1A1A]/10 dark:border-white/10 flex items-center justify-center flex-shrink-0">
                  <SunMedium className="w-6 h-6 text-[#1A1A1A] dark:text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="mb-1 text-[#1A1A1A] dark:text-white">Light</h4>
                  <p className="text-sm text-[#666666] dark:text-[#999999]">Bright and clean interface</p>
                </div>
              </div>
              {themeMode === "light" && (
                <Check className="w-5 h-5 text-[#1A1A1A] dark:text-white flex-shrink-0 mt-0.5" strokeWidth={2} />
              )}
            </div>
          </button>

          {/* Dark Mode */}
          <button
            onClick={() => setThemeMode("dark")}
            className={`w-full p-5 rounded-xl border text-left transition-colors ${
              themeMode === "dark"
                ? "border-[#1A1A1A] dark:border-white bg-[#FAFAFA] dark:bg-[#1A1A1A]"
                : "border-[#1A1A1A]/10 dark:border-white/10"
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-[#1A1A1A] dark:bg-[#3A3A3A] flex items-center justify-center flex-shrink-0">
                  <MoonStar className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="mb-1 text-[#1A1A1A] dark:text-white">Dark</h4>
                  <p className="text-sm text-[#666666] dark:text-[#999999]">Easy on the eyes in low light</p>
                </div>
              </div>
              {themeMode === "dark" && (
                <Check className="w-5 h-5 text-[#1A1A1A] dark:text-white flex-shrink-0 mt-0.5" strokeWidth={2} />
              )}
            </div>
          </button>

          {/* System Mode */}
          <button
            onClick={() => setThemeMode("system")}
            className={`w-full p-5 rounded-xl border text-left transition-colors ${
              themeMode === "system"
                ? "border-[#1A1A1A] dark:border-white bg-[#FAFAFA] dark:bg-[#1A1A1A]"
                : "border-[#1A1A1A]/10 dark:border-white/10"
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#F5F5F5] to-[#1A1A1A] dark:from-[#3A3A3A] dark:to-[#0A0A0A] flex items-center justify-center flex-shrink-0">
                  <Laptop className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="mb-1 text-[#1A1A1A] dark:text-white">System</h4>
                  <p className="text-sm text-[#666666] dark:text-[#999999]">Match your device settings</p>
                </div>
              </div>
              {themeMode === "system" && (
                <Check className="w-5 h-5 text-[#1A1A1A] dark:text-white flex-shrink-0 mt-0.5" strokeWidth={2} />
              )}
            </div>
          </button>
        </div>
      </div>

      <div className="pb-8">
        <button
          onClick={() => setStep(7)}
          className="w-full px-6 py-4 bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] rounded-full active:bg-[#333333] dark:active:bg-[#E5E5E5] transition-colors"
        >
          Continue
        </button>
      </div>
    </div>,

    // Step 7: Guidelines
    <div key="guidelines" className="flex flex-col h-full px-6 pt-16">
      <button onClick={() => setStep(6)} className="mb-8 w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#1A1A1A] flex items-center justify-center">
        <ChevronLeft className="w-5 h-5 dark:text-white" />
      </button>
      <h2 className="mb-2 text-[#1A1A1A] dark:text-white">Community Guidelines</h2>
      <p className="text-[#666666] dark:text-[#999999] mb-8">A few simple rules to keep pre safe</p>

      <div className="flex-1 overflow-y-auto mb-4 space-y-6">
        <div>
          <h4 className="mb-2 text-[#1A1A1A] dark:text-white">Be respectful</h4>
          <p className="text-sm text-[#666666] dark:text-[#999999]">Treat others with kindness and respect</p>
        </div>
        <div>
          <h4 className="mb-2 text-[#1A1A1A] dark:text-white">Stay authentic</h4>
          <p className="text-sm text-[#666666] dark:text-[#999999]">Use your real name and photos</p>
        </div>
        <div>
          <h4 className="mb-2 text-[#1A1A1A] dark:text-white">Keep it friendly</h4>
          <p className="text-sm text-[#666666] dark:text-[#999999]">No harassment, hate speech, or inappropriate content</p>
        </div>
        <div>
          <h4 className="mb-2 text-[#1A1A1A] dark:text-white">Report concerns</h4>
          <p className="text-sm text-[#666666] dark:text-[#999999]">Help us keep the community safe by reporting issues</p>
        </div>
      </div>

      <div className="pb-8">
        <button
          onClick={onComplete}
          className="w-full px-6 py-4 bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] rounded-full active:bg-[#333333] dark:active:bg-[#E5E5E5] transition-colors"
        >
          Get Started
        </button>
      </div>
    </div>
  ];

  return (
    <div className={`h-screen ${getBackgroundClass()}`}>
      <AnimatePresence mode="wait">
        <motion.div
          key={step}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.25 }}
          className="h-full"
          drag="x"
          dragConstraints={{ left: 0, right: 0 }}
          dragElastic={0.2}
          onDragEnd={handleDragEnd}
          style={{ x, opacity: step > 0 ? opacity : 1 }}
        >
          {steps[step]}
        </motion.div>
      </AnimatePresence>

      {/* Apple Sign In Bottom Sheet */}
      <BottomSheet
        isOpen={showAppleSheet}
        onClose={() => setShowAppleSheet(false)}
        title=""
      >
        <div className="px-6 py-6">
          <div className="flex flex-col items-center text-center mb-8">
            <div className="w-16 h-16 rounded-full bg-[#000000] dark:bg-white flex items-center justify-center mb-6">
              <svg className="w-10 h-10 text-white dark:text-[#000000]" viewBox="0 0 24 24">
                <path fill="currentColor" d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09l.01-.01zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/>
              </svg>
            </div>
            <h3 className="mb-3 text-[#1A1A1A] dark:text-white">
              {currentMode === "signup" ? "Sign Up with Apple" : "Sign In with Apple"}
            </h3>
            <p className="text-base text-[#666666] dark:text-[#999999] leading-relaxed max-w-sm mb-8">
              {isAuthenticating 
                ? "Authenticating..." 
                : "Use Face ID or Touch ID to continue with your Apple account"
              }
            </p>
          </div>

          {!isAuthenticating && (
            <div className="space-y-3">
              <Button
                variant="primary"
                size="large"
                fullWidth
                onClick={handleAppleSignIn}
              >
                Continue with Face ID
              </Button>
              <Button
                variant="secondary"
                size="large"
                fullWidth
                onClick={() => setShowAppleSheet(false)}
              >
                Cancel
              </Button>
            </div>
          )}

          {isAuthenticating && (
            <div className="flex justify-center py-8">
              <div className="w-12 h-12 border-4 border-[#1A1A1A]/20 dark:border-white/20 border-t-[#1A1A1A] dark:border-t-white rounded-full animate-spin" />
            </div>
          )}
        </div>
      </BottomSheet>

      {/* Google Sign In Bottom Sheet */}
      <BottomSheet
        isOpen={showGoogleSheet}
        onClose={() => setShowGoogleSheet(false)}
        title=""
      >
        <div className="px-6 py-6">
          <div className="flex flex-col items-center text-center mb-8">
            <div className="w-16 h-16 rounded-full bg-white dark:bg-[#2A2A2A] border border-[#1A1A1A]/10 dark:border-white/10 flex items-center justify-center mb-6">
              <svg className="w-10 h-10" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
            </div>
            <h3 className="mb-3 text-[#1A1A1A] dark:text-white">
              {currentMode === "signup" ? "Sign Up with Google" : "Sign In with Google"}
            </h3>
            {!isAuthenticating ? (
              <>
                <p className="text-base text-[#666666] dark:text-[#999999] leading-relaxed max-w-sm mb-8">
                  Choose an account to continue with pre
                </p>
                
                {/* Mock Google Account Selection */}
                <div className="w-full space-y-2 mb-6">
                  <button 
                    onClick={handleGoogleSignIn}
                    className="w-full p-4 rounded-xl border border-[#1A1A1A]/10 dark:border-white/10 flex items-center gap-4 bg-white dark:bg-[#1A1A1A] hover:bg-[#F5F5F5] dark:hover:bg-[#2A2A2A] transition-colors"
                  >
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white">
                      JD
                    </div>
                    <div className="flex-1 text-left">
                      <p className="text-sm text-[#1A1A1A] dark:text-white">John Doe</p>
                      <p className="text-xs text-[#666666] dark:text-[#999999]">john.doe@gmail.com</p>
                    </div>
                  </button>
                  
                  <button 
                    onClick={handleGoogleSignIn}
                    className="w-full p-4 rounded-xl border border-[#1A1A1A]/10 dark:border-white/10 flex items-center gap-4 bg-white dark:bg-[#1A1A1A] hover:bg-[#F5F5F5] dark:hover:bg-[#2A2A2A] transition-colors"
                  >
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-500 to-teal-500 flex items-center justify-center text-white">
                      AS
                    </div>
                    <div className="flex-1 text-left">
                      <p className="text-sm text-[#1A1A1A] dark:text-white">Alex Smith</p>
                      <p className="text-xs text-[#666666] dark:text-[#999999]">alex.smith@gmail.com</p>
                    </div>
                  </button>
                </div>
              </>
            ) : (
              <p className="text-base text-[#666666] dark:text-[#999999] leading-relaxed max-w-sm mb-8">
                Signing in with Google...
              </p>
            )}
          </div>

          {!isAuthenticating && (
            <Button
              variant="secondary"
              size="large"
              fullWidth
              onClick={() => setShowGoogleSheet(false)}
            >
              Cancel
            </Button>
          )}

          {isAuthenticating && (
            <div className="flex justify-center py-4">
              <div className="w-12 h-12 border-4 border-[#1A1A1A]/20 dark:border-white/20 border-t-[#1A1A1A] dark:border-t-white rounded-full animate-spin" />
            </div>
          )}
        </div>
      </BottomSheet>

      {/* Auth Mode Prompt Bottom Sheet */}
      <BottomSheet
        isOpen={showModePrompt}
        onClose={handleStayOnCurrentMode}
        title=""
      >
        <div className="px-6 py-6">
          {promptType === "switch-signin" && (
            <>
              <div className="flex flex-col items-center text-center mb-8">
                <div className="w-16 h-16 rounded-full bg-[#FFF4E6] dark:bg-[#4A3810] flex items-center justify-center mb-6">
                  <svg className="w-8 h-8 text-[#F59E0B]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="mb-3 text-[#1A1A1A] dark:text-white">Account Already Exists</h3>
                <p className="text-base text-[#666666] dark:text-[#999999] leading-relaxed max-w-sm mb-8">
                  An account with <span className="text-[#1A1A1A] dark:text-white">{email}</span> already exists. Would you like to sign in instead?
                </p>
              </div>
              <div className="space-y-3">
                <Button
                  variant="primary"
                  size="large"
                  fullWidth
                  onClick={handleSwitchToSignIn}
                >
                  Switch to Sign In
                </Button>
                <Button
                  variant="secondary"
                  size="large"
                  fullWidth
                  onClick={handleStayOnCurrentMode}
                >
                  Cancel
                </Button>
              </div>
            </>
          )}

          {promptType === "switch-signup" && (
            <>
              <div className="flex flex-col items-center text-center mb-8">
                <div className="w-16 h-16 rounded-full bg-[#F0F9FF] dark:bg-[#1A3A52] flex items-center justify-center mb-6">
                  <svg className="w-8 h-8 text-[#3B82F6]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
                  </svg>
                </div>
                <h3 className="mb-3 text-[#1A1A1A] dark:text-white">No Account Found</h3>
                <p className="text-base text-[#666666] dark:text-[#999999] leading-relaxed max-w-sm mb-8">
                  We couldn't find an account with <span className="text-[#1A1A1A] dark:text-white">{email}</span>. Would you like to create a new account?
                </p>
              </div>
              <div className="space-y-3">
                <Button
                  variant="primary"
                  size="large"
                  fullWidth
                  onClick={handleSwitchToSignUp}
                >
                  Create Account
                </Button>
                <Button
                  variant="secondary"
                  size="large"
                  fullWidth
                  onClick={handleStayOnCurrentMode}
                >
                  Cancel
                </Button>
              </div>
            </>
          )}

          {promptType === "auto-signin" && (
            <>
              <div className="flex flex-col items-center text-center mb-8">
                <div className="w-16 h-16 rounded-full bg-[#DCFCE7] dark:bg-[#1A3A2A] flex items-center justify-center mb-6">
                  <svg className="w-8 h-8 text-[#22C55E]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="mb-3 text-[#1A1A1A] dark:text-white">Welcome Back!</h3>
                <p className="text-base text-[#666666] dark:text-[#999999] leading-relaxed max-w-sm mb-8">
                  We found your account with <span className="text-[#1A1A1A] dark:text-white">{email}</span>. We'll sign you in instead of creating a new account.
                </p>
              </div>
              <div className="space-y-3">
                <Button
                  variant="primary"
                  size="large"
                  fullWidth
                  onClick={handleAutoSignIn}
                >
                  Continue to pre
                </Button>
                <Button
                  variant="secondary"
                  size="large"
                  fullWidth
                  onClick={handleStayOnCurrentMode}
                >
                  Cancel
                </Button>
              </div>
            </>
          )}
        </div>
      </BottomSheet>
    </div>
  );
}

// Helper component for password requirements
function PasswordRequirement({ met, text }: { met: boolean; text: string }) {
  return (
    <div className="flex items-center gap-2">
      <div className={`w-4 h-4 rounded-full flex items-center justify-center ${
        met ? "bg-green-500" : "bg-[#E0E0E0]"
      }`}>
        {met && <Check className="w-3 h-3 text-white" strokeWidth={2.5} />}
      </div>
      <span className={`text-xs ${met ? "text-green-600" : "text-[#999999]"}`}>
        {text}
      </span>
    </div>
  );
}