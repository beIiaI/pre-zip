import { Sun, Moon } from "lucide-react";
import { useTheme } from "./ThemeContext";

export function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();

  return (
    <button
      onClick={toggleTheme}
      className="flex items-center gap-3 w-full py-4 px-6 bg-white dark:bg-[#222222] rounded-xl border border-[#1A1A1A]/10 dark:border-white/10 active:bg-[#F5F5F5] dark:active:bg-[#2A2A2A] transition-colors"
      aria-label="Toggle theme"
    >
      <div className="w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#2A2A2A] flex items-center justify-center">
        {theme === "light" ? (
          <Sun className="w-5 h-5 text-[#1A1A1A] dark:text-white" strokeWidth={1.5} />
        ) : (
          <Moon className="w-5 h-5 text-[#1A1A1A] dark:text-white" strokeWidth={1.5} />
        )}
      </div>
      <div className="flex-1 text-left">
        <h4 className="text-[#1A1A1A] dark:text-white">Appearance</h4>
        <p className="text-sm text-[#666666] dark:text-[#AAAAAA]">
          {theme === "light" ? "Light mode" : "Dark mode"}
        </p>
      </div>
      <div className="flex items-center gap-2">
        <span className="text-sm text-[#999999] dark:text-[#888888]">
          {theme === "light" ? "Light" : "Dark"}
        </span>
      </div>
    </button>
  );
}
