import { motion } from "motion/react";
import { Circle } from "lucide-react";

export function WelcomeScreen({ onGetStarted }: { onGetStarted: () => void }) {
  return (
    <div className="relative h-screen w-full overflow-hidden bg-white dark:bg-[#000000]">
      {/* Content */}
      <div className="relative z-10 h-full flex flex-col items-center justify-between px-8 py-16">
        <div className="flex-1 flex flex-col items-center justify-center">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mb-12"
          >
            <Circle className="w-20 h-20 text-[#1A1A1A] dark:text-white" strokeWidth={1.5} />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="mb-4 text-center text-[#1A1A1A] dark:text-white"
            style={{ fontFamily: "'Pacifico', cursive", fontSize: '42px', fontWeight: 400 }}
          >
            pre
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="mb-12 text-center text-[#666666] dark:text-[#999999] max-w-xs leading-relaxed"
          >
            Connect with people who share your interests and build authentic friendships.
          </motion.p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="w-full space-y-4"
        >
          <button
            onClick={onGetStarted}
            className="w-full px-8 py-4 bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] rounded-xl transition-opacity hover:opacity-90 active:opacity-80"
          >
            Get Started
          </button>
          
          <p className="text-center text-sm text-[#999999] dark:text-[#666666]">
            Join your first circle in minutes
          </p>
        </motion.div>
      </div>
    </div>
  );
}