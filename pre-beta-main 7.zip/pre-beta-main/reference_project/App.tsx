import { useState } from "react";
import { AnimatePresence } from "motion/react";
import { ThemeProvider, useTheme } from "./components/ThemeContext";
import { LogoProvider } from "./components/LogoContext";
import { SplashScreen } from "./components/screens/SplashScreen";
import { OnboardingFlow } from "./components/screens/OnboardingFlow";
import { OnboardingProfile } from "./components/screens/OnboardingProfile";
import { HomeHubRevised } from "./components/screens/HomeHubRevised";
import { CircleProfileRevised } from "./components/screens/CircleProfileRevised";
import { EventDetail } from "./components/screens/EventDetail";
import { ProfileScreen } from "./components/screens/ProfileScreen";
import { BadgesScreen } from "./components/screens/BadgesScreen";
import { SafetyVerification } from "./components/screens/SafetyVerification";
import { SettingsScreen } from "./components/screens/SettingsScreen";
import { EarlySupporterInfo } from "./components/screens/EarlySupporterInfo";
import { EditProfile } from "./components/screens/EditProfile";

type Screen = "splash" | "signup" | "signin" | "onboarding-profile" | "home" | "circle" | "event" | "profile" | "badges" | "safety" | "settings" | "early-supporter" | "edit-profile";

function AppContent() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("splash");
  const { getBackgroundClass, getSecondaryBackgroundClass } = useTheme();
  
  // User data state
  const [userData, setUserData] = useState({
    name: "",
    username: null as string | null,
    bio: "",
    location: "",
    initials: "?",
    earlySupporterNumber: 37
  });

  const generateInitials = (fullName: string): string => {
    if (!fullName.trim()) return "?";
    const parts = fullName.trim().split(/[\s-]+/).filter(Boolean);
    if (parts.length === 0) return "?";
    if (parts.length === 1) return parts[0][0].toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  };

  const handleProfileCreate = (data: { name: string; username: string }) => {
    setUserData(prev => ({
      ...prev,
      name: data.name,
      username: data.username,
      initials: generateInitials(data.name)
    }));
    setCurrentScreen("home");
  };

  const handleProfileComplete = (data: { name: string; username: string | null; bio: string; location: string }) => {
    setUserData(prev => ({
      ...prev,
      name: data.name,
      username: data.username,
      bio: data.bio,
      location: data.location,
      initials: generateInitials(data.name)
    }));
    setCurrentScreen("home");
  };
  
  const renderScreen = () => {
    switch (currentScreen) {
      case "splash":
        return (
          <SplashScreen 
            key="splash" 
            onGetStarted={() => setCurrentScreen("signup")}
            onSignIn={() => setCurrentScreen("signin")}
          />
        );
      case "signup":
        return <OnboardingFlow key="signup" mode="signup" onComplete={() => setCurrentScreen("onboarding-profile")} />;
      case "signin":
        return <OnboardingFlow key="signin" mode="signin" onComplete={() => setCurrentScreen("onboarding-profile")} />;
      case "onboarding-profile":
        return (
          <OnboardingProfile
            key="onboarding-profile"
            onContinue={handleProfileCreate}
            onBack={() => setCurrentScreen("signup")}
          />
        );
      case "home":
        return (
          <HomeHubRevised
            key="home"
            onCircleClick={() => setCurrentScreen("circle")}
            onEventClick={() => setCurrentScreen("event")}
            onProfileClick={() => setCurrentScreen("profile")}
          />
        );
      case "circle":
        return <CircleProfileRevised key="circle" onBack={() => setCurrentScreen("home")} />;
      case "event":
        return <EventDetail key="event" onBack={() => setCurrentScreen("home")} />;
      case "profile":
        return (
          <ProfileScreen
            key="profile"
            onBack={() => setCurrentScreen("home")}
            onBadgesClick={() => setCurrentScreen("badges")}
            onSafetyClick={() => setCurrentScreen("safety")}
            onSettingsClick={() => setCurrentScreen("settings")}
            onEditProfileClick={() => setCurrentScreen("edit-profile")}
            onEarlySupporterClick={() => setCurrentScreen("early-supporter")}
            earlySupporterNumber={userData.earlySupporterNumber}
            userName={userData.name}
            userInitials={userData.initials}
            userUsername={userData.username}
            userLocation={userData.location}
            userBio={userData.bio}
          />
        );
      case "badges":
        return <BadgesScreen key="badges" onBack={() => setCurrentScreen("profile")} earlySupporterNumber={userData.earlySupporterNumber} />;
      case "safety":
        return <SafetyVerification key="safety" onBack={() => setCurrentScreen("profile")} />;
      case "settings":
        return <SettingsScreen key="settings" onBack={() => setCurrentScreen("profile")} />;
      case "early-supporter":
        return (
          <EarlySupporterInfo 
            key="early-supporter" 
            onBack={() => setCurrentScreen("profile")} 
            supporterNumber={userData.earlySupporterNumber}
          />
        );
      case "edit-profile":
        return (
          <EditProfile 
            key="edit-profile" 
            onBack={() => setCurrentScreen("profile")}
            onSave={handleProfileComplete}
            initialData={{
              name: userData.name,
              username: userData.username,
              bio: userData.bio,
              location: userData.location,
              initials: userData.initials
            }}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className={`relative w-full h-screen overflow-hidden ${getSecondaryBackgroundClass()}`}>
      <div className={`mx-auto max-w-md h-full relative ${getBackgroundClass()} shadow-lg`}>
        <AnimatePresence mode="wait">
          {renderScreen()}
        </AnimatePresence>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <LogoProvider>
        <AppContent />
      </LogoProvider>
    </ThemeProvider>
  );
}