# pre - Refined Friendship & Social Connection App

## Overview

**pre** (formerly Circle) is a refined friendship and social connection app with Dorsia-level polish and design discipline. The app emphasizes intentional social connections through curated groups, event planning, and university communities with a focus on safety and verification.

---

## 🎨 Design Philosophy

### Core Principles

pre follows strict design principles that create a premium, iOS-native aesthetic:

1. **Monochrome-First UI** - Black and white as primary colors with minimal accent use
2. **Editorial Whitespace** - Generous spacing that creates breathing room and hierarchy
3. **Hairline Dividers** - Subtle separation using 1px dividers at 10% opacity
4. **iOS-Native Components** - Familiar iOS patterns and interactions
5. **App Anatomy Structure** - Standard iOS architecture with AppBar, Navigation, and Modals

### Bento Principles

- Separation via **borders and whitespace** rather than heavy shadows
- No glass morphism or heavy blur effects
- Clean, flat surfaces with rounded corners
- Corners signal interactivity (more rounded = more interactive)

### Typography

- **System Font**: SF Pro (iOS system font)
- **Brand Font**: Pacifico (cursive, used for "pre" wordmark)
- **Typography Hierarchy**:
  - Headlines: 24-32pt
  - Body: 16-18pt
  - Captions: 12-14pt
  - Labels: 10-12pt

### Spacing System

**12/16pt Grid System**
- Base unit: 12pt and 16pt
- Component padding: 16pt or 24pt
- Section spacing: 24pt or 32pt
- Screen margins: 16pt horizontal

### Color System

#### Light Mode
- **Background**: `#FFFFFF` (white)
- **Secondary Background**: `#F5F5F5` (light gray)
- **Primary Text**: `#1A1A1A` (near black)
- **Secondary Text**: `#999999` (medium gray)
- **Dividers**: `#1A1A1A/10` (10% black)

#### Dark Mode (Standard)
- **Background**: `#1A1A1A` (dark gray)
- **Secondary Background**: `#0A0A0A` (darker gray)
- **Primary Text**: `#FFFFFF` (white)
- **Secondary Text**: `#999999` (medium gray)
- **Dividers**: `#FFFFFF/10` (10% white)

#### AMOLED Mode
- **Background**: `#000000` (pure black)
- **Secondary Background**: `#0A0A0A` (near black)
- **Button Backgrounds**: `#1A1A1A` (dark gray)
- Optimized for OLED screens with true black

### Malibu Aesthetic

The "pre" brand embraces a **Malibu-style aesthetic**:
- Lowercase "pre" wordmark in Pacifico cursive font
- Ocean-inspired logo variations (Sky Blue, Ocean Depth)
- Relaxed, coastal California vibes
- Premium but approachable design language

---

## 🏗️ Architecture

### Tech Stack

- **Framework**: React 18+
- **Language**: TypeScript
- **Styling**: Tailwind CSS v4
- **Animations**: Motion (formerly Framer Motion)
- **State Management**: React Context API
- **Build Tool**: Vite

### Project Structure

```
/
├── App.tsx                          # Main app component with screen routing
├── components/
│   ├── screens/                     # Full-screen views
│   │   ├── SplashScreen.tsx         # Landing/splash screen
│   │   ├── OnboardingFlow.tsx       # Sign up/sign in flows
│   │   ├── HomeHubRevised.tsx       # Main feed/home screen
│   │   ├── CircleProfileRevised.tsx # Group profile view
│   │   ├── EventDetail.tsx          # Event details screen
│   │   ├── ProfileScreen.tsx        # User profile screen
│   │   ├── BadgesScreen.tsx         # Badges & achievements
│   │   ├── SafetyVerification.tsx   # ID/Face verification
│   │   └── SettingsScreen.tsx       # App settings
│   ├── ui-circle/                   # Custom UI components
│   │   ├── ActionBar.tsx            # Bottom action bars
│   │   ├── AppBar.tsx               # Top navigation bar
│   │   ├── BottomSheet.tsx          # iOS-style bottom sheets
│   │   ├── Button.tsx               # Primary button component
│   │   ├── CircleCard.tsx           # Group/circle cards
│   │   ├── Divider.tsx              # Hairline dividers
│   │   ├── Facepile.tsx             # Stacked avatar displays
│   │   ├── Logo.tsx                 # pre logo component
│   │   ├── NavBar.tsx               # Bottom tab navigation
│   │   ├── SegmentedControl.tsx     # iOS segmented controls
│   │   └── StatusChip.tsx           # Status indicators
│   ├── ui/                          # Generic UI components (shadcn/ui)
│   ├── ThemeContext.tsx             # Theme management
│   ├── LogoContext.tsx              # Logo variant management
│   ├── ThemeToggle.tsx              # Theme switching UI
│   └── WelcomeScreen.tsx            # Welcome/onboarding
├── styles/
│   └── globals.css                  # Global styles & Tailwind
└── README.md                        # This file
```

---

## 🌓 Theme System

### Three Theme Modes

pre supports **three distinct theme preferences**:

1. **Light Mode** - Always light regardless of system settings
2. **Dark Mode** - Always dark regardless of system settings  
3. **System** - Follows device system preference automatically

### AMOLED Mode

For users with OLED displays, **AMOLED mode** provides:
- True black (`#000000`) backgrounds to save battery
- Deeper contrast for better visibility
- Can be toggled independently of theme mode

### Implementation

The theme system is managed through `ThemeContext.tsx`:

```tsx
// Theme utilities available throughout the app
const { 
  theme,                        // Current effective theme: "light" | "dark"
  themeMode,                    // User preference: "light" | "dark" | "system"
  amoledMode,                   // AMOLED enabled: boolean
  toggleTheme,                  // Cycle through modes
  setThemeMode,                 // Set specific mode
  setAmoledMode,                // Toggle AMOLED
  getBackgroundClass,           // Main background color class
  getSecondaryBackgroundClass,  // Secondary background color class
  getButtonBackgroundClass      // Button background color class
} = useTheme();
```

### Persistence

- Theme preferences stored in `localStorage` as `pre-theme-mode`
- AMOLED preference stored as `pre-amoled-mode`
- Settings persist across sessions

---

## 🎭 Logo System

### Logo Variants

pre includes a **premium app icon feature** similar to Snapchat's Bitmoji logo selection:

| Logo ID | Name | Description | Premium |
|---------|------|-------------|---------|
| `default` | Sky Blue | Classic Malibu vibes | No |
| `ocean-depth` | Ocean Depth | Deep wave layers | No |

### Implementation

Logo management through `LogoContext.tsx`:

```tsx
// Logo utilities
const { 
  selectedLogoId,     // Current logo: LogoId
  setSelectedLogoId,  // Change logo variant
  currentLogo         // Full logo config object
} = useLogo();
```

### Adding New Logos

1. Import logo asset: `import newLogo from "figma:asset/[hash].png"`
2. Add to `AVAILABLE_LOGOS` array in `LogoContext.tsx`:
   ```tsx
   {
     id: "new-logo-id",
     name: "Display Name",
     description: "Short description",
     imageUrl: newLogo,
     isPremium: true // Optional
   }
   ```
3. Update `LogoId` type to include new variant

### Persistence

- Selected logo stored in `localStorage` as `pre-app-logo`
- Defaults to "default" (Sky Blue) if not set

---

## 🧩 Features & Components

### Core Features

#### 1. Friendship Matching
- Discover compatible friends based on interests and university
- Smart matching algorithm (backend)
- Profile browsing and connection requests

#### 2. Group Profiles (Circles)
- Create and join curated friend groups
- Group activities and shared calendars
- Member management and invitations
- Facepile displays for member avatars

#### 3. Events Planning
- Create group events with RSVP
- Calendar integration
- Event details with location and time
- Attendee management

#### 4. Points & Badges System
- Earn points for app engagement
- Unlock achievement badges
- Leaderboards and challenges
- Visual badge displays

#### 5. Public Group Chats
- Real-time messaging within circles
- Thread-based conversations
- Message reactions and replies

#### 6. Safety Features
- **Panic Button** - Emergency alert system
- **ID Verification** - Government ID checks
- **Face Verification** - Liveness detection
- **Report & Block** - User safety controls

#### 7. University Verification
- `.edu` email verification
- University-specific campus hubs
- Access to university circles and events

#### 8. Referrals System
- Invite friends with unique codes
- Referral rewards and bonuses
- Track invited users

#### 9. Campus Hubs
- University-specific landing pages
- Campus events and groups
- Local connections

---

## 🎯 Complete Feature List

### Authentication & Onboarding
- **Splash Screen** - Premium landing screen with "Get Started" and "Sign In" options
- **Email/Password Sign Up** - Secure account creation with validation
- **Email/Password Sign In** - Returning user authentication with "Remember me" option
- **Password Reset** - Forgot password recovery flow
- **Email Verification** - Verify email address during onboarding
- **Profile Creation** - Combined name and username selection (single step)
  - Real-time username availability checking
  - Username validation (3-20 chars, lowercase, must start with letter)
  - Full name input with character validation
  - Live validation feedback with checkmarks
- **User Type Selection** - "I'm here to" multi-select (meet people, build community, find partners, attend events)
- **Interest Selection** - Choose from curated interest tags for better matching
- **Welcome Tutorial** - First-time user guidance and app introduction

### Profile & Identity
- **User Profile Display** - Full profile with avatar, name, username, bio, location, stats
- **Profile Editing** - Edit name, username, bio, location, and avatar
  - Real-time character counter for bio (150 chars)
  - Location picker with bottom sheet selector
  - Avatar upload with camera/gallery options
  - Remove avatar option
  - Save state management (disabled until changes made)
  - Loading state with "Saving…" feedback
  - Success toast notification
- **Username System** - Unique @username handles with real-time availability checking
- **Early Supporter Badge** - Premium badge for first 250 users
  - Member number display (#001-#250, 3-digit padded format)
  - Badge detail screen with explanation
  - Visible on profile and badges screen
  - Permanent member number indicator
  - Subtle ✦ sparkle icon
- **Avatar/Initials Display** - Circular avatars with fallback initials
- **Profile Stats** - Display circles joined, events attended, points earned
- **Bio & Location** - Editable personal information display
- **Verification Badges** - Visual indicators for ID verified, face verified, university verified users

### Groups (Circles)
- **Circle Discovery** - Browse and discover new circles based on interests
- **Circle Cards** - Visual cards showing circle name, description, member count, tags
- **Circle Profiles** - Detailed circle pages with:
  - Circle name, description, and cover image
  - Member count and facepile
  - Admin and member roles
  - Upcoming events list
  - Recent activity feed
  - Join/Leave buttons
- **Create Circle** - Form to create new circles with name, description, image, privacy settings
- **Circle Membership** - Join public circles or request to join private ones
- **Member Management** - View all members, invite new members, remove members (admin)
- **Circle Settings** - Edit circle details, manage members, delete circle (admin only)
- **Circle Tags** - Categorize circles by interests and activities
- **My Circles List** - View all circles you're a member of on profile screen

### Events
- **Event Discovery** - Browse upcoming events across all circles
- **Event Cards** - Preview cards with event name, date, location, attendee count
- **Event Detail Screen** - Full event information:
  - Event header image
  - Event title and description
  - Date, time, and duration
  - Location with map integration (ready for backend)
  - Host information
  - Attendee list with facepile
  - RSVP count (Going/Interested/Can't Go)
  - Share event option
- **Create Event** - Form to create new events with:
  - Event title and description
  - Date and time picker
  - Location input
  - Circle association (optional)
  - Public/Private toggle
  - Max attendee limit
  - Event image upload
- **RSVP System** - RSVP to events (Going/Interested/Can't Go)
- **Event Calendar** - Calendar view of upcoming events
- **Event Reminders** - Notifications before events start
- **My Events** - View events you're attending on profile screen
- **Cancel Event** - Host can cancel or delete events
- **Edit Event** - Host can modify event details

### Points & Gamification
- **Points System** - Earn points for:
  - Creating circles
  - Joining circles
  - Attending events
  - Hosting events
  - Referring friends
  - Completing profile
  - Verifying ID/face/university
  - Daily app usage
  - Engaging in chats
- **Total Points Display** - View total points on profile and badges screen
- **Points Widget** - Gradient card showing current points and progress
- **Level System** - Level up based on points earned
- **Leaderboards** - Compare points with friends and community (ready for backend)

### Badges & Achievements
- **Badge System** - Unlock badges for accomplishments:
  - **Initiator** 🚀 - Create your first circle
  - **Social Butterfly** 🦋 - Join 5 different circles
  - **Community Pillar** 🏛️ - Be a member for 6 months
  - **Event Enthusiast** 🎉 - Attend 10 events
  - **Host with the Most** 🌟 - Host 3 successful events
  - **Ambassador** 💫 - Refer 5 friends
  - **Early Supporter** 🏅 - One of the first 250 members
- **Badges Screen** - View all earned and locked badges
- **Badge Progress** - Progress bars showing completion toward locked badges
- **Badge Details** - Tap badges to see requirements and descriptions
- **Badges on Profile** - Showcase top 3 earned badges on profile
- **Badge Notifications** - Celebrate when new badges are unlocked

### Safety & Verification
- **ID Verification** - Government-issued ID upload and verification
  - ID document photo upload
  - Verification status tracking
  - "Verified" badge on profile
- **Face Verification** - Selfie liveness detection
  - Front-facing camera interface
  - Liveness checks to prevent fraud
  - Face verification badge
- **University Verification** - .edu email verification
  - Email input and verification code
  - University domain validation
  - University badge on profile
  - Access to university-specific circles and campus hubs
- **Safety Verification Screen** - Combined interface for all verification types
- **Verification Status Indicators** - Visual badges showing verification status
- **Panic Button** - Emergency alert system to notify authorities and trusted contacts
- **Report User** - Report inappropriate behavior or content
- **Block User** - Block users from contacting you
- **Blocked Users List** - Manage blocked users in settings
- **Privacy Controls** - Control who can see your profile and contact you
- **Content Moderation** - Report inappropriate circle/event content

### Messaging & Communication
- **Circle Chat Rooms** - Real-time group chat for each circle
- **Direct Messages** - One-on-one messaging (ready for backend)
- **Message Threads** - Thread replies within group chats
- **Message Reactions** - React to messages with emoji
- **Typing Indicators** - See when someone is typing
- **Read Receipts** - See when messages are read
- **Message Notifications** - Push notifications for new messages
- **Chat History** - Access past messages and conversations
- **Media Sharing** - Share photos and files in chats (ready for backend)
- **Link Previews** - Rich previews for shared links

### Social Features
- **Friend Requests** - Send and receive friend requests (ready for backend)
- **Friends List** - View all your connections
- **Friend Suggestions** - Algorithm-based friend recommendations
- **Mutual Friends** - See shared connections
- **Share Profile** - Share your profile link with others
- **Invite Friends** - Invite people to join pre via link or code
- **Referral Codes** - Unique referral codes with tracking
- **Referral Rewards** - Earn points and badges for successful referrals
- **Social Graph** - Visual network of connections (planned)

### Campus & University
- **Campus Hubs** - University-specific landing pages
- **University Circles** - Campus-only circles and communities
- **Campus Events** - University-hosted events
- **Student Directory** - Browse verified students at your university (privacy-controlled)
- **University Leaderboards** - Points rankings per campus
- **Campus Announcements** - Official university updates
- **.edu Email Verification** - Required for campus access

### Settings & Customization
- **Theme Mode Selector** - Choose Light, Dark, or System theme
- **AMOLED Mode Toggle** - Enable true black for OLED screens
- **Logo Variant Selector** - Choose from multiple app logo designs:
  - Sky Blue (default)
  - Ocean Depth
  - Additional premium logos (expandable)
- **Logo Preview Grid** - Visual grid of available logos
- **Account Settings** - Edit email, password, account details
- **Privacy Settings** - Control profile visibility and contact permissions
- **Notification Settings** - Manage push notifications and email preferences
- **Notification Preferences** - Granular controls for:
  - Event reminders
  - Circle invites
  - Friend requests
  - Messages
  - Points and badges
- **Language Settings** - App language selection (ready for i18n)
- **Data Export** - Download your data (GDPR compliance)
- **Delete Account** - Permanently delete account and data
- **Logout** - Sign out of current session

### Navigation & UI
- **Bottom Tab Navigation** - 5-tab navigation (Home, Discover, Events, Messages, Profile)
- **Tab Bar Icons** - Clean, iOS-native icons with active states
- **Screen Transitions** - Smooth animations between screens
- **Pull to Refresh** - Refresh content on main screens
- **Infinite Scroll** - Load more content as you scroll
- **Search** - Search circles, events, and users
- **Filters** - Filter content by category, date, location
- **Sort Options** - Sort by relevance, date, popularity
- **Empty States** - Helpful messages when no content available
- **Loading States** - Skeleton screens and spinners
- **Error States** - User-friendly error messages with retry options

### Design System Features
- **iOS Bottom Sheets** - Native-feeling modal sheets for actions
- **Action Bars** - Fixed bottom bars with primary CTAs
- **Segmented Controls** - iOS-style segment pickers
- **Status Chips** - Small pills for status indicators (Active, Verified, Admin, etc.)
- **Facepile Components** - Stacked avatar displays for members
- **Dividers** - Hairline 1px dividers at 10% opacity
- **Gradient Cards** - Subtle gradients for important information
- **Toast Notifications** - Brief success/error messages
- **Confirmation Dialogs** - iOS-style alerts for destructive actions
- **Date Pickers** - Native date and time selection
- **Image Upload** - Drag-and-drop and click-to-upload interfaces
- **Avatar Components** - Circular avatars with fallback initials
- **Logo Component** - Responsive pre logo with size variants

### Accessibility
- **Dark Mode Support** - Full dark mode implementation across all screens
- **AMOLED Mode** - True black backgrounds for OLED battery savings
- **System Theme Detection** - Automatically follow device theme preference
- **High Contrast** - Sufficient contrast ratios for readability
- **Keyboard Navigation** - Full keyboard accessibility (ready for enhancement)
- **Screen Reader Support** - ARIA labels and semantic HTML (ready for enhancement)
- **Focus Indicators** - Clear focus states for interactive elements
- **Text Scaling** - Respects user font size preferences

### Data & Persistence
- **Local Storage** - Persist theme and logo preferences
- **Session Management** - Maintain login sessions
- **Offline Support** - Cache critical data for offline viewing (planned)
- **State Management** - React Context for global state
- **Form Validation** - Real-time validation for all form inputs
- **Error Handling** - Graceful error handling with user feedback

### Performance
- **Code Splitting** - Lazy load screens and components
- **Image Optimization** - Responsive images with lazy loading
- **Animation Performance** - 60fps animations with Motion
- **Bundle Size Optimization** - Tree shaking and minification
- **First Paint** - Fast initial load times
- **Responsive Design** - Optimized for all mobile screen sizes

### Branding & Identity
- **Malibu Aesthetic** - Coastal California vibes
- **Lowercase "pre" Wordmark** - Pacifico cursive font
- **Ocean-Inspired Colors** - Sky blue and ocean depth palette
- **Premium Logo Variants** - Multiple app icons to choose from
- **Splash Screen Branding** - Branded landing experience
- **Consistent Typography** - SF Pro system font hierarchy
- **Monochrome-First** - Black and white primary colors
- **Editorial Whitespace** - Generous breathing room in layouts

---

## 📱 Screens & Flows

### Authentication Flow

1. **SplashScreen** - Landing screen with "Get Started" and "Sign In"
2. **OnboardingFlow** (Sign Up)
   - Welcome message
   - Email/password collection
   - Profile setup (name, photo)
   - University verification
   - Interest selection
3. **OnboardingFlow** (Sign In)
   - Email/password input
   - Remember me option
   - Forgot password link

### Main Navigation

1. **HomeHubRevised** - Main feed
   - Discover new circles
   - Event recommendations
   - Activity feed
   - Bottom tab navigation

2. **CircleProfileRevised** - Group details
   - Group info and description
   - Member list with facepile
   - Upcoming events
   - Group chat access
   - Join/Leave actions

3. **EventDetail** - Event information
   - Event header with image
   - Date, time, and location
   - RSVP status and attendee count
   - Event description
   - RSVP and share actions

4. **ProfileScreen** - User profile
   - Profile photo and bio
   - Points and level display
   - Badges showcase
   - Settings access
   - Safety verification status

### Secondary Screens

5. **BadgesScreen** - Achievements
   - Earned badges grid
   - Locked badges (grayed out)
   - Badge details and requirements

6. **SafetyVerification** - ID/Face checks
   - ID upload interface
   - Face verification camera
   - Verification status
   - University email verification

7. **SettingsScreen** - App preferences
   - Theme mode selector (Light/Dark/System)
   - AMOLED mode toggle
   - Logo variant selector
   - Account settings
   - Privacy controls
   - Notification preferences

---

## 🔧 Development

### Getting Started

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

### Code Style

- **TypeScript**: Strict mode enabled
- **Components**: Functional components with hooks
- **Props**: Interface definitions for all props
- **Naming**: PascalCase for components, camelCase for functions/variables

### Component Guidelines

1. **Use Context APIs** for cross-component state (theme, logo)
2. **Prefer composition** over prop drilling
3. **Keep components focused** - single responsibility
4. **Use Tailwind utilities** instead of custom CSS
5. **Follow iOS patterns** for interactions and animations

---

## 🐛 Known Issues

### NavBar Dark Mode Styling

**Issue**: Parent container (line 14 in `NavBar.tsx`) has white background in dark mode

**Current Code**:
```tsx
<div className="fixed bottom-0 left-0 right-0 bg-[#FAFAFA] border-t border-[#1A1A1A]/10">
```

**Fix Required**:
Add dark mode classes to line 14:
```tsx
<div className="fixed bottom-0 left-0 right-0 bg-[#FAFAFA] dark:bg-[#1A1A1A] border-t border-[#1A1A1A]/10 dark:border-white/10">
```

**Why**: The parent container needs explicit dark mode background and border colors to match the app's dark theme. Currently it shows a light background in dark mode.

---

## 📊 Data Models (Frontend)

### User Profile
```typescript
interface UserProfile {
  id: string;
  name: string;
  email: string;
  photoUrl?: string;
  bio?: string;
  university?: string;
  universityVerified: boolean;
  points: number;
  level: number;
  badges: Badge[];
  joinedAt: Date;
  idVerified: boolean;
  faceVerified: boolean;
}
```

### Circle (Group)
```typescript
interface Circle {
  id: string;
  name: string;
  description: string;
  imageUrl?: string;
  memberCount: number;
  members: UserProfile[];
  createdAt: Date;
  isPrivate: boolean;
  tags: string[];
}
```

### Event
```typescript
interface Event {
  id: string;
  title: string;
  description: string;
  imageUrl?: string;
  date: Date;
  time: string;
  location: string;
  circleId?: string;
  hostId: string;
  attendees: string[]; // User IDs
  maxAttendees?: number;
  isPublic: boolean;
}
```

### Badge
```typescript
interface Badge {
  id: string;
  name: string;
  description: string;
  iconUrl: string;
  category: "social" | "events" | "verification" | "special";
  earnedAt?: Date; // undefined if not earned
  requirement: string;
}
```

---

## 🔌 API Integration (Backend Required)

### Authentication Endpoints
- `POST /auth/signup` - Create new user account
- `POST /auth/signin` - User login
- `POST /auth/signout` - User logout
- `POST /auth/reset-password` - Password reset
- `GET /auth/verify-email` - Email verification

### User Endpoints
- `GET /users/me` - Get current user profile
- `PATCH /users/me` - Update user profile
- `GET /users/:id` - Get user by ID
- `POST /users/verify-id` - Upload ID for verification
- `POST /users/verify-face` - Face verification
- `POST /users/verify-university` - University email verification

### Circle Endpoints
- `GET /circles` - List circles (with filters)
- `GET /circles/:id` - Get circle details
- `POST /circles` - Create new circle
- `PATCH /circles/:id` - Update circle
- `DELETE /circles/:id` - Delete circle
- `POST /circles/:id/join` - Join circle
- `POST /circles/:id/leave` - Leave circle
- `GET /circles/:id/members` - Get circle members

### Event Endpoints
- `GET /events` - List events (with filters)
- `GET /events/:id` - Get event details
- `POST /events` - Create new event
- `PATCH /events/:id` - Update event
- `DELETE /events/:id` - Delete event
- `POST /events/:id/rsvp` - RSVP to event
- `DELETE /events/:id/rsvp` - Cancel RSVP

### Points & Badges Endpoints
- `GET /points` - Get user points
- `POST /points` - Award points (internal)
- `GET /badges` - List all badges
- `GET /badges/earned` - Get user's earned badges
- `POST /badges/:id/award` - Award badge to user

### Safety Endpoints
- `POST /safety/panic` - Trigger panic alert
- `POST /safety/report` - Report user/content
- `POST /safety/block` - Block user
- `GET /safety/blocked` - Get blocked users list

### Chat Endpoints (Real-time)
- `GET /chats/:circleId/messages` - Get chat messages
- `POST /chats/:circleId/messages` - Send message
- `WebSocket /chats/:circleId` - Real-time chat connection

---

## 🚀 Deployment Considerations

### Environment Variables
```env
VITE_API_BASE_URL=https://api.pre.app
VITE_WEBSOCKET_URL=wss://ws.pre.app
VITE_UNSPLASH_ACCESS_KEY=your_key_here
```

### Build Optimization
- Code splitting by route
- Image optimization with lazy loading
- Tree shaking for unused dependencies
- Minification and compression

### Performance Targets
- First Contentful Paint: < 1.5s
- Time to Interactive: < 3s
- Lighthouse Score: > 90

---

## 🎯 Future Enhancements

### Planned Features
- [ ] Video calls within circles
- [ ] Stories/ephemeral content
- [ ] Map view for nearby events
- [ ] Advanced matching algorithm
- [ ] Push notifications
- [ ] Deep linking for shares
- [ ] Progressive Web App (PWA) support
- [ ] Offline mode with sync

### Design Enhancements
- [ ] Additional logo variants (premium)
- [ ] Custom theme color accents
- [ ] Advanced typography controls
- [ ] Accessibility improvements (WCAG AAA)

---

## 📄 License

Proprietary - All rights reserved

---

## 👥 Contact

For questions or support, contact the pre team.

---

## 📚 Additional Documentation

- [Figma Design Files](#) - Design system and mockups
- [API Documentation](#) - Backend API reference (when available)
- [Brand Guidelines](#) - Logo usage and brand assets
- [Contributing Guide](#) - How to contribute to pre

---

**Last Updated**: January 26, 2026  
**Version**: 2.0.0 (post-rebrand from Circle to pre)