import type { Config } from 'tailwindcss'

const config: Config = {
  darkMode: 'class',
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: [
          'var(--font-ui)',
          'Sailec',
          'Avenir Next',
          'Helvetica Neue',
          '-apple-system',
          'BlinkMacSystemFont',
          'Arial',
          'sans-serif',
        ],
      },
      fontSize: {
        'display': ['34px', { lineHeight: '1.35', letterSpacing: '0em', fontWeight: '600' }],
        'title': ['26px', { lineHeight: '1.35', letterSpacing: '0em', fontWeight: '600' }],
        'headline': ['20px', { lineHeight: '1.5', letterSpacing: '0em', fontWeight: '400' }],
        'eyebrow': ['12px', { lineHeight: '1.5', letterSpacing: '0.15em', fontWeight: '600' }],
        'body': ['16px', { lineHeight: '1.5', letterSpacing: '0em', fontWeight: '400' }],
        'callout': ['14px', { lineHeight: '1.5', letterSpacing: '0em', fontWeight: '400' }],
        'caption': ['12px', { lineHeight: '1.5', letterSpacing: '0.02em', fontWeight: '400' }],
      },
      colors: {
        // Light mode surfaces
        surface: {
          primary: 'var(--surface-primary)',
          secondary: 'var(--surface-secondary)',
          tertiary: 'var(--surface-tertiary)',
          elevated: 'var(--surface-elevated)',
        },
        // Text colors
        content: {
          primary: 'var(--content-primary)',
          secondary: 'var(--content-secondary)',
          tertiary: 'var(--content-tertiary)',
          inverse: 'var(--content-inverse)',
        },
        // Border colors
        border: {
          primary: 'var(--border-primary)',
          secondary: 'var(--border-secondary)',
          focus: 'var(--border-focus)',
        },
        // Accent colors (minimal)
        accent: {
          primary: 'var(--accent-primary)',
          muted: 'var(--accent-muted)',
        },
        // Semantic colors
        success: 'var(--success)',
        error: 'var(--error)',
        warning: 'var(--warning)',
      },
      spacing: {
        '4.5': '18px',
        '13': '52px',
        '15': '60px',
        '18': '72px',
      },
      borderRadius: {
        'pill': '9999px',
        'card': '20px',
        'button': '16px',
        'input': '14px',
        'chip': '12px',
      },
      boxShadow: {
        'subtle': '0 1px 2px rgba(0, 0, 0, 0.04)',
        'card': '0 2px 8px rgba(0, 0, 0, 0.04)',
        'elevated': '0 4px 16px rgba(0, 0, 0, 0.08)',
      },
      animation: {
        'fade-in': 'fadeIn 0.3s ease-out',
        'slide-up': 'slideUp 0.3s ease-out',
        'scale-in': 'scaleIn 0.2s ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        scaleIn: {
          '0%': { opacity: '0', transform: 'scale(0.95)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
      },
    },
  },
  plugins: [],
}
export default config
