# pre (beta)

`pre` is an invite-gated social app focused on real-world connection: people discovery, follows, private messaging, circles, events, campus verification, and safety tooling.

This repo uses **Next.js App Router + Supabase** with production-style RLS and API routes.

## Current Scope (V1)

- Invite-only access with nomination links and access requests
- Email/OAuth auth flows with OTP signup confirmation
- Onboarding + profile editing
- Public profiles (`/profile/[username]`, `/u/[username]`)
- Followers/following lists for self and other users
- Direct messages with thread/message participant security
- Events (create/list/detail/chat/RSVP)
- Circles (create/list/join/leave)
- University verification via JetBrains SWoT + email ownership confirmation
- College selection as **self-reported** (private table)
- Safety tools: blocked users, emergency contacts, panic alerts
- Badges/plaque system and founder override endpoint

## Tech Stack

- Framework: Next.js `16.1.x` (App Router)
- Language: TypeScript
- Styling: Tailwind CSS + design tokens
- Backend: Supabase (Auth + Postgres + RLS + Storage)
- Verification dataset: JetBrains SWoT (`data/swot` git submodule)
- Moderation dataset: Restricted words list (`src/data/restricted-words` git submodule)
- Transactional email: Resend API (for university verification emails)
- Shared brand wordmark: SVG component (`src/components/ui/pre-wordmark.tsx`)

## Monorepo Notes

- Active app code lives in `src/`.
- Database migrations live in `supabase/migrations/`.
- SWoT lives in `data/swot/` and is server-only.
- Restricted words list lives in `src/data/restricted-words/` as a git submodule.
- Use `src/components/ui/pre-wordmark.tsx` for every rendered `pre` logo/wordmark surface.
- Folders `pre/` and `pre_backup/` are legacy artifacts and not the active Next.js app.

## Prerequisites

- Node.js `20+` (recommended for Next 16)
- npm `10+`
- Supabase project
- Resend account (if using university verification email flow)

## Local Setup

### 1) Install dependencies

```bash
npm install
```

### 2) Pull submodules (required for SWoT + restricted words)

```bash
git submodule update --init --recursive
```

To pull latest upstream data for both datasets:

```bash
git submodule update --remote --merge data/swot src/data/restricted-words
```

### 3) Create `.env.local`

There is no `.env.local.example` in this repo. Create `.env.local` manually:

```bash
touch .env.local
```

Use these variables:

```env
# Required
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
NEXT_PUBLIC_SITE_URL=http://localhost:3000

# Optional fallback for URL generation
NEXT_PUBLIC_APP_URL=http://localhost:3000

# Required for university verification email sending
RESEND_API_KEY=
EMAIL_FROM="pre <no-reply@yourdomain.com>"

# Optional (location autocomplete)
GEOAPIFY_API_KEY=
NEXT_PUBLIC_GEOAPIFY_API_KEY=
```

### 4) Apply database migrations

If you are applying manually in Supabase SQL editor, run files in this exact order:

1. `001_initial_schema.sql`
2. `001_phase1_schema.sql`
3. `002_early_supporter_numbering.sql`
4. `003_follows.sql`
5. `004_profile_flags_and_supporter_rules.sql`
6. `005_avatar_storage.sql`
7. `006_events.sql`
8. `007_events_campus_chat.sql`
9. `008_direct_messages.sql`
10. `009_privacy_settings.sql`
11. `010_blocks_policy.sql`
12. `011_presence.sql`
13. `012_dm_participants_update_policy.sql`
14. `014_dm_rls_fix.sql`
15. `015_university_verification.sql`
16. `016_emergency_contacts.sql`
17. `017_circles_policies.sql`
18. `018_event_badges_and_rsvp_policies.sql`
19. `019_panic_functions.sql`
20. `020_university_email_verification.sql`
21. `021_exclusive_invites.sql`
22. `022_exclusive_invites_hardening.sql`
23. `023_university_verification_locking.sql`
24. `024_access_invites_open_links.sql`
25. `025_access_invites_slot_count_fix.sql`
26. `026_profile_college_self_report.sql`
27. `027_college_private_table_and_rename.sql`
28. `028_emergency_contacts_external_phone.sql`
29. `029_profile_show_college_preference.sql`
30. `030_profile_college_edit_limit.sql`
31. `031_security_hardening.sql`
32. `032_profile_show_university_preference.sql`
33. `033_fix_circles_rls_recursion.sql`

Notes:
- `026` is still part of migration history; do not skip/delete it.
- `027` supersedes college-in-`profiles` by moving college fields into private table `profile_college`.

### 5) Supabase Auth settings

Configure Supabase Auth to match app expectations:

- Email signup enabled
- Email OTP verification for signup
- OTP length: **8 digits**
- OTP expiry: **900 seconds**
- Redirect URL includes: `http://localhost:3000/auth/callback`
- Optional OAuth providers: Google and Apple (signin path supports both)

### 6) Run app

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## NPM Scripts

- `npm run dev` - dev server on port `3000` (Turbopack disabled)
- `npm run build` - production build (`next build --webpack`)
- `npm run start` - serve production build on port `3000`
- `npm run lint` - lint project

## Route Map (User-Facing)

- `/` - splash/auth gate + branded boot loader
- `/auth` - signin/signup/OTP/forgot password
- `/auth/reset` - reset password
- `/onboarding` - onboarding flow
- `/home` - primary hub
- `/messages` and `/messages/[id]` - DM list and conversation
- `/events`, `/events/new`, `/events/[id]`, `/events/[id]/chat`
- `/circles/new` (plus circles surfaces in home APIs)
- `/profile`, `/profile/edit`
- `/profile/[username]` and `/u/[username]`
- `/profile/[username]/followers`, `/profile/[username]/following`
- `/settings`, `/settings/privacy`, `/settings/safety-verification`, `/settings/help`, `/settings/invites`, `/settings/password`
- `/badges`, `/badges/early-supporter`

## API Surface (Selected)

- Auth and profile
  - `/api/auth/sign-up`
  - `/api/auth/sign-in`
  - `/api/auth/otp/verify`
  - `/api/auth/otp/resend`
  - `/api/auth/2fa/status`
  - `/api/profile/ensure`
  - `/api/profile/update`
  - `/api/onboarding/complete`
  - `/api/auth/password/forgot`
  - `/api/auth/password/update`

- Social graph
  - `/api/follow`
  - `/api/unfollow`
  - `/api/followers`
  - `/api/following`
  - `/api/users/search`
  - `/api/users/preview`

- Messaging
  - `/api/dms`
  - `/api/dms/[id]`
  - `/api/dms/[id]/messages`
  - `/api/presence`

- Events and circles
  - `/api/events`
  - `/api/events/[id]`
  - `/api/events/[id]/chat`
  - `/api/events/rsvp`
  - `/api/circles`
  - `/api/circles/members`

- Verification and safety
  - `/api/verification/university/request`
  - `/api/verification/university/confirm`
  - `/api/verification/university/unlock`
  - `/api/verification/university/graduation-year`
  - `/api/verification/college`
  - `/api/emergency-contacts`
  - `/api/panic`
  - `/api/panic/alerts`
  - `/api/blocks` and `/api/blocks/[id]`

- Access/invites
  - `/api/access/apply`
  - `/api/invites/create`
  - `/api/invites/list`
  - `/api/invites/validate`
  - `/api/invites/claim`
  - `/api/invites/revoke`

## University Verification Design

University verification is **not** based on auth email alone.

Flow:
1. User enters university email in settings.
2. Server extracts domain and checks SWoT allowlist + stoplist.
3. One-time token is created (hashed server-side), expires in 15 minutes, single-use.
4. Verification email is sent via Resend.
5. Confirm route validates token and marks university fields on `profiles`.

College flow:
- College is self-reported and stored in private table `profile_college`.
- API enforces `university_verified = true`.
- College selection is enabled only when SWoT lists subdivisions for the verified university domain.
- 30-day cooldown enforced by `college_updated_at`.
- UI wording is explicitly **“College (self-reported)”**.
- Public profile display is opt-in:
  - `profiles.show_university` controls whether university appears on profile.
  - `profiles.show_college` controls whether selected subdivision appears (only when university is shown).

## Branding Notes

- The `pre` wordmark should always render via `PreWordmark` (SVG), not text glyphs.
- This avoids clipping and font fallback artifacts (especially the left side of `p`).
- Use `PreLogotype` (`src/components/ui/pre-logotype.tsx`) for placement and sizing consistency:
  - default monochrome treatment only (black in light, white in dark)
  - built-in clearspace around the mark
  - size presets (`micro`, `small`, `medium`, `large`, `hero`) to keep mark subordinate to content
- Color system uses a ceramic/obsidian base with restrained tints:
  - core tokens in `src/app/globals.css` (`--surface-*`, `--content-*`, `--accent-*`)
  - tint tokens (`--tint-*`) for selective compartment highlights
  - bento tint classes (`.bento-tint-rose|peach|honey|sage|mist|lilac`) are intentionally sparse
- Bento visual system is implemented via reusable primitives:
  - `src/components/ui/bento.tsx`
  - global classes in `src/app/globals.css` (`.bento-frame`, `.bento-grid`, `.bento-cell`, `.bento-label`)
  - currently applied across Home tab surfaces, Messages list/search, Events list/detail, and self/public profile sections.
- Typography system follows a compact Sailec-inspired scale:
  - headings/active states target medium weight (`600`) and `1.35` line-height
  - body/callout text target regular weight (`400`) with `1.45–1.5` line-height
  - labels/taglines use small-caps utilities (`.text-label-caps` / `.type-eyebrow`)
  - alignment rule of thumb: left-align body text by default; reserve centered text for short headings/hero moments.
- Information hierarchy system (pre adaptation):
  - section emphasis uses tints + borders first, not heavy shadows
  - primary and secondary separators are tokenized (`--divider-strong`, `--divider-soft`)
  - reusable utilities include `.hierarchy-section`, `.hierarchy-hero`, `.hierarchy-divider`, `.hierarchy-divider-soft`
  - shadows are reserved for graphic emphasis (`.graphic-elevation`) rather than default section separation.
- Imagery system (pre adaptation):
  - reusable visual primitive: `src/components/ui/visual-surface.tsx`
  - supported presentation modes: `fullBleed`, `fullWidth`, `thumb`, `door` (arch mask `1:1.25`)
  - text-over-image always uses scrims (`.media-overlay-top` / `.media-overlay-bottom`) for legibility
  - photo/attachment containers use `media-frame` treatment (rounded + bordered + constrained)
  - iconography remains monochrome line-icons; avoid solid fills and visual noise.

## Security and RLS Notes

- DMs use participant-based RLS (non-recursive) so only participants can read/write thread data.
- API mutating endpoints (`auth`, `verification`, `invites`, `dms`, `events`) enforce:
  - same-origin checks
  - request validation
  - server-side ownership checks
  - rate limits + auth backoff
- `profile_college` is private:
  - owner-only select/insert/update/delete via RLS
  - forced RLS enabled
  - anon table privileges revoked
- `university_verifications` is forced-RLS and owner-scoped.
- Global app headers include CSP, frame denial, MIME sniffing protection, referrer policy, and permissions policy.
- Public profile data remains on `profiles` per product needs, while private verification details are scoped or separated.
- See `/docs/security.md` for full hardening details and a manual verification plan.

## Production Deploy Checklist

Use this before each production release:

1. Environment variables
   - Set `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`.
   - Set `NEXT_PUBLIC_SITE_URL` to your production domain.
   - Set `NEXT_PUBLIC_APP_URL` to your fallback app origin (optional, e.g. Vercel default domain).
   - Set `RESEND_API_KEY` and `EMAIL_FROM` (verified sender identity).
   - Set Geoapify keys only if location autocomplete is enabled.
2. SWoT dataset
   - Ensure `data/swot` submodule is initialized in deploy/CI.
   - Run `git submodule update --init --recursive` as part of build.
3. Database migrations
   - Apply all migrations through `033_fix_circles_rls_recursion.sql`.
   - Verify `profile_college` exists and RLS is active.
   - Verify DM tables/policies and event/circle policies are present.
   - Verify circles create/join no longer fails with `infinite recursion detected in policy for relation "circles"`.
   - Verify `university_verifications` and DM tables have forced RLS and expected indexes.
4. Supabase Auth configuration
   - Signup enabled with email OTP verification.
   - OTP length `8`, OTP expiry `900s`.
   - Site URL set to production domain.
   - Redirect URLs include (for every supported domain):
     - `https://<your-domain>/auth/callback`
     - `https://<your-domain>/auth/reset`
   - If you support both custom domain and Vercel default domain, include both:
     - `https://app.presocial.app/auth/callback`
     - `https://app.presocial.app/auth/reset`
     - `https://<project>.vercel.app/auth/callback`
     - `https://<project>.vercel.app/auth/reset`
   - OAuth providers (if used) have matching production callback URLs.
5. Email delivery (Resend)
   - Sending domain is verified.
   - `EMAIL_FROM` uses verified domain.
   - University verification links in emails resolve to production `NEXT_PUBLIC_SITE_URL`.
6. Runtime and build sanity
   - `npm run build` passes.
   - Node runtime supports Next.js 16.
   - Vercel project root directory points to repository root (`.`), not `apps/mobile`.
   - `vercel.json` at repo root pins Next.js root build commands.
   - Confirm `/api/verification/university/request` and `/api/verification/college` run in production without 500s.
7. Post-deploy smoke tests
   - Auth: signup/signin/forgot password/reset password.
   - Verification: university request -> email confirm -> persisted verified state.
   - Safety: add external emergency phone contact -> panic opens pre-drafted SMS.
   - Messaging/events: DM send/receive and RSVP flow still work.
   - Profile routes and followers/following for non-self users.

## README Maintenance

- Update this README when major product flows, schema migrations, auth requirements, or deployment settings change.
- Minor UI-only tweaks can be grouped and documented in the next major README refresh.

## Troubleshooting

### `GET /api/verification/college` returns 500

Most common causes:
- `027_college_private_table_and_rename.sql` not applied
- Missing RLS policies or grants on `profile_college`
- Not authenticated (should be `401` with `reason: unauthenticated`)

Run the SQL checks from your migration notes after applying `026` then `027`.

### `Unable to send verification email`

Check:
- `RESEND_API_KEY` is valid
- `EMAIL_FROM` is verified in Resend
- `NEXT_PUBLIC_SITE_URL` is set correctly

### University verification always fails

Check:
- SWoT submodule exists: `data/swot/lib/...`
- You ran `git submodule update --init --recursive`
- Domain is academic and not stoplisted

### Restricted words filtering missing entries

Check:
- Restricted words submodule exists: `src/data/restricted-words/en`
- You ran `git submodule update --init --recursive`

### OAuth signin shows provider error

Enable provider in Supabase Auth settings and add correct callback URLs.

## Manual QA Checklist

1. Signup requires a valid invite code and confirms via 8-digit OTP.
2. Signin supports email/password and optional Google/Apple.
3. Forgot password sends reset email and `/auth/reset` updates password.
4. Onboarding completion redirects to `/home`.
5. Search -> profile opens full profile route, not modal-only popup.
6. Followers/following pages load the target user, not always current user.
7. DMs create thread, send messages, and thread is visible only to participants.
8. University verification email arrives, confirm link verifies, state persists after refresh.
9. College selection saves as self-reported and enforces 30-day cooldown.
10. Campus-only event gating respects university verification.
11. Panic alert creates event and sends notifications to emergency contacts.
12. Emergency contacts support external phone numbers and panic opens a pre-drafted SMS in the device messaging app.
13. Wordmark appears crisp and unclipped in loading/auth/splash/home across light/dark/amoled themes.

## License

Private repository. All rights reserved.
