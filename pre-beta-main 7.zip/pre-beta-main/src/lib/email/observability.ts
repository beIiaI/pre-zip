import { logServerError } from '@/lib/security/api'

export type EmailProvider = 'supabase-auth' | 'resend'

export type EmailEventStatus = 'queued' | 'sent' | 'failed'

type LogEmailEventInput = {
  requestId: string
  provider: EmailProvider
  emailType: string
  recipient: string
  status: EmailEventStatus
  messageId?: string | null
  meta?: Record<string, unknown>
  error?: unknown
}

export function getRecipientDomain(recipient: string): string {
  const normalized = recipient.trim().toLowerCase()
  const atIndex = normalized.lastIndexOf('@')
  if (atIndex < 0) return 'unknown'
  const domain = normalized.slice(atIndex + 1)
  return domain || 'unknown'
}

export function logEmailEvent({
  requestId,
  provider,
  emailType,
  recipient,
  status,
  messageId = null,
  meta,
  error,
}: LogEmailEventInput) {
  const payload = {
    provider,
    emailType,
    recipientDomain: getRecipientDomain(recipient),
    messageId,
    status,
    ...(meta ?? {}),
  }

  if (status === 'failed' && error) {
    logServerError('email.dispatch', requestId, error, payload)
    return
  }

  console.info(`[email.dispatch] request_id=${requestId}`, payload)
}
