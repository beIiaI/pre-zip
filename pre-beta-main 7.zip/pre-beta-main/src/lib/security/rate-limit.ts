type RateLimitBucket = {
  hits: number[]
  blockedUntil: number
  violations: number
}

type AuthBackoffEntry = {
  failures: number
  blockedUntil: number
}

type RateLimitConfig = {
  key: string
  limit: number
  windowMs: number
  baseBlockMs?: number
}

type RateLimitResult = {
  ok: boolean
  remaining: number
  retryAfterMs: number
}

type AuthBackoffConfig = {
  key: string
  baseBlockMs?: number
  maxBlockMs?: number
}

const globalRateLimitStore = globalThis as typeof globalThis & {
  __preRateLimitStore?: Map<string, RateLimitBucket>
  __preAuthBackoffStore?: Map<string, AuthBackoffEntry>
  __preRateLimitProdWarning?: boolean
}

const rateLimitStore = globalRateLimitStore.__preRateLimitStore ?? new Map<string, RateLimitBucket>()
if (!globalRateLimitStore.__preRateLimitStore) {
  globalRateLimitStore.__preRateLimitStore = rateLimitStore
}

const authBackoffStore =
  globalRateLimitStore.__preAuthBackoffStore ?? new Map<string, AuthBackoffEntry>()
if (!globalRateLimitStore.__preAuthBackoffStore) {
  globalRateLimitStore.__preAuthBackoffStore = authBackoffStore
}

if (process.env.NODE_ENV === 'production' && !globalRateLimitStore.__preRateLimitProdWarning) {
  globalRateLimitStore.__preRateLimitProdWarning = true
  console.warn(
    '[security] Using in-memory rate limiter. Configure an external store (e.g. Redis) for multi-instance production.'
  )
}

function pruneEntries(store: Map<string, { blockedUntil: number }>, now: number) {
  for (const [key, value] of store.entries()) {
    if (value.blockedUntil !== 0 && value.blockedUntil <= now) {
      store.delete(key)
    }
  }
}

export function resolveRateLimitIdentity(
  request: Request,
  options?: { userId?: string | null; email?: string | null }
) {
  const forwardedFor = request.headers.get('x-forwarded-for')
  const ip = forwardedFor?.split(',')[0]?.trim() || request.headers.get('x-real-ip') || 'unknown'
  const userId = options?.userId?.trim() || ''
  const email = options?.email?.trim().toLowerCase() || ''
  if (userId) return `uid:${userId}`
  if (email) return `email:${email}`
  return `ip:${ip}`
}

export function rateLimit(config: RateLimitConfig): RateLimitResult {
  const now = Date.now()
  pruneEntries(rateLimitStore, now)

  const key = config.key
  const windowMs = Math.max(1_000, config.windowMs)
  const limit = Math.max(1, config.limit)
  const baseBlockMs = Math.max(5_000, config.baseBlockMs ?? 15_000)

  const bucket = rateLimitStore.get(key) ?? { hits: [], blockedUntil: 0, violations: 0 }
  if (bucket.blockedUntil > now) {
    return {
      ok: false,
      remaining: 0,
      retryAfterMs: bucket.blockedUntil - now,
    }
  }

  bucket.hits = bucket.hits.filter((ts) => now - ts < windowMs)
  if (bucket.hits.length >= limit) {
    bucket.violations += 1
    const blockMs = Math.min(baseBlockMs * 2 ** Math.max(0, bucket.violations - 1), 60 * 60 * 1000)
    bucket.blockedUntil = now + blockMs
    rateLimitStore.set(key, bucket)
    return {
      ok: false,
      remaining: 0,
      retryAfterMs: blockMs,
    }
  }

  bucket.hits.push(now)
  bucket.blockedUntil = 0
  rateLimitStore.set(key, bucket)

  return {
    ok: true,
    remaining: Math.max(0, limit - bucket.hits.length),
    retryAfterMs: 0,
  }
}

export function getAuthBackoff(config: AuthBackoffConfig): { ok: boolean; retryAfterMs: number } {
  const now = Date.now()
  pruneEntries(authBackoffStore, now)

  const entry = authBackoffStore.get(config.key)
  if (!entry || entry.blockedUntil <= now) {
    return { ok: true, retryAfterMs: 0 }
  }

  return {
    ok: false,
    retryAfterMs: entry.blockedUntil - now,
  }
}

export function registerAuthFailure(config: AuthBackoffConfig) {
  const now = Date.now()
  const baseBlockMs = Math.max(2_000, config.baseBlockMs ?? 3_000)
  const maxBlockMs = Math.max(baseBlockMs, config.maxBlockMs ?? 15 * 60 * 1000)
  const entry = authBackoffStore.get(config.key) ?? { failures: 0, blockedUntil: 0 }
  entry.failures += 1
  const blockMs = Math.min(baseBlockMs * 2 ** Math.max(0, entry.failures - 1), maxBlockMs)
  entry.blockedUntil = now + blockMs
  authBackoffStore.set(config.key, entry)
  return blockMs
}

export function clearAuthFailures(key: string) {
  authBackoffStore.delete(key)
}

