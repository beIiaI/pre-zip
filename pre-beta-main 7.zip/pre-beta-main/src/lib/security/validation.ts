export class ValidationError extends Error {
  status: number

  constructor(message: string, status = 400) {
    super(message)
    this.name = 'ValidationError'
    this.status = status
  }
}

export async function parseJsonObject(request: Request): Promise<Record<string, unknown>> {
  let payload: unknown
  try {
    payload = await request.json()
  } catch {
    throw new ValidationError('Invalid request body.')
  }

  if (!payload || Array.isArray(payload) || typeof payload !== 'object') {
    throw new ValidationError('Invalid request body.')
  }

  return payload as Record<string, unknown>
}

export function readString(
  source: Record<string, unknown>,
  key: string,
  options?: {
    required?: boolean
    min?: number
    max?: number
    trim?: boolean
    toLowerCase?: boolean
  }
) {
  const required = options?.required ?? false
  const trim = options?.trim ?? true

  const raw = source[key]
  if (raw === undefined || raw === null) {
    if (required) throw new ValidationError(`${key} is required.`)
    return ''
  }

  if (typeof raw !== 'string') {
    throw new ValidationError(`${key} must be a string.`)
  }

  let value = trim ? raw.trim() : raw
  if (options?.toLowerCase) value = value.toLowerCase()

  if (options?.min !== undefined && value.length < options.min) {
    throw new ValidationError(`${key} is too short.`)
  }
  if (options?.max !== undefined && value.length > options.max) {
    throw new ValidationError(`${key} is too long.`)
  }

  return value
}

export function readBoolean(
  source: Record<string, unknown>,
  key: string,
  options?: { defaultValue?: boolean }
) {
  const raw = source[key]
  if (raw === undefined || raw === null) {
    return options?.defaultValue ?? false
  }

  if (typeof raw !== 'boolean') {
    throw new ValidationError(`${key} must be a boolean.`)
  }

  return raw
}

export function readOptionalNumber(
  source: Record<string, unknown>,
  key: string,
  options?: { min?: number; max?: number; integer?: boolean }
) {
  const raw = source[key]
  if (raw === undefined || raw === null || raw === '') {
    return null
  }

  const parsed = Number(raw)
  if (!Number.isFinite(parsed)) {
    throw new ValidationError(`${key} must be a number.`)
  }

  if (options?.integer && !Number.isInteger(parsed)) {
    throw new ValidationError(`${key} must be an integer.`)
  }

  if (options?.min !== undefined && parsed < options.min) {
    throw new ValidationError(`${key} is too low.`)
  }
  if (options?.max !== undefined && parsed > options.max) {
    throw new ValidationError(`${key} is too high.`)
  }

  return parsed
}

