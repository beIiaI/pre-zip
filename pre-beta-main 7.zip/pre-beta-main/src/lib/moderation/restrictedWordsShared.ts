export const RESERVED_WORDS = [
  'pre',
  'preapp',
  'pre-beta',
  'prebeta',
  'admin',
  'administrator',
  'moderator',
  'mod',
  'support',
  'help',
  'staff',
  'team',
  'official',
  'founder',
  'founders',
  'founding',
  'early',
  'owner',
  'root',
  'system',
  'security',
  'api',
  'null',
  'undefined',
  'test',
  'user',
  'users',
  'member',
  'members',
  'account',
  'billing',
  'payment',
  'payments',
  'legal',
  'terms',
  'privacy',
  'contact',
  'about',
  'careers',
  'jobs',
  'press',
  'blog',
  'status',
  'settings',
  'notifications',
  'home',
  'auth',
  'signup',
  'signin',
  'login',
  'logout',
  'profile',
  'profiles',
  'onboarding',
  'report',
  'reports',
  'safety',
  'trust',
  'community',
  'guidelines',
  'circle',
  'circles',
  'event',
  'events',
  'message',
  'messages',
  'chat',
  'chats',
] as const

const WHITESPACE_REGEX = /\s+/g
const SEPARATOR_REGEX = /[.\-_ ]+/g

export interface NormalizedVariants {
  base: string
  joined: string
  leet: string[]
  joinedLeet: string[]
}

export function normalizeBase(value: string): string {
  return value.toLowerCase().trim().replace(WHITESPACE_REGEX, ' ')
}

export function stripSeparators(value: string): string {
  return value.replace(SEPARATOR_REGEX, '')
}

export function applyLeetVariants(value: string): string[] {
  const base = value
    .replace(/0/g, 'o')
    .replace(/3/g, 'e')
    .replace(/4/g, 'a')
    .replace(/5/g, 's')
    .replace(/7/g, 't')

  const withL = base.replace(/1/g, 'l')
  const withI = base.replace(/1/g, 'i')
  return Array.from(new Set([withL, withI]))
}

export function getNormalizedVariants(value: string): NormalizedVariants {
  const base = normalizeBase(value)
  const joined = stripSeparators(base)
  const leet = applyLeetVariants(base)
  const joinedLeet = leet.map(stripSeparators)
  return { base, joined, leet, joinedLeet }
}
