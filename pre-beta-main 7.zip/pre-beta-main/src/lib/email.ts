import { createHash } from 'crypto'
import { logEmailEvent } from '@/lib/email/observability'

const RESEND_API_URL = 'https://api.resend.com/emails'

type EmailContext = {
  requestId?: string
}

type UniversityVerifyEmailParams = EmailContext & {
  to: string
  link: string
  domain: string
  schoolName?: string | null
}

type AccessApplicationNotificationParams = EmailContext & {
  to: string
  applicationId: string
  email: string
  fullName?: string | null
  note?: string | null
  submittedAt?: string | null
}

type ResendEmailType = 'university_verification' | 'access_application_notification'

const PRE_WORDMARK_PATH =
  'M 104.639999 687 C 147.360214 687 179.759888 655.875732 201.839996 593.62616 C 223.920105 531.376648 238.079971 453.866333 244.319992 361.092926 C 274.08017 360.612244 302.639862 351.479218 330 333.693665 C 345.840088 351.95993 366.479889 361.092926 391.919983 361.092926 C 422.160156 361.092926 449.159882 352.921295 472.920013 336.577789 C 482.953552 329.676178 492.708832 321.960297 502.185913 313.430084 C 503.599579 320.559723 505.393494 326.859314 507.480011 332.251587 C 514.920044 351.479218 527.759888 361.092926 546 361.092926 C 560.880066 361.092926 571.799927 357.127258 578.76001 349.195892 C 585.720032 341.264465 591.839966 326.002747 597.119995 303.410248 C 604.320007 274.088074 613.679932 246.208405 625.200012 219.770386 C 636.720032 193.332336 648.359924 172.062073 660.119995 155.958923 C 671.880066 139.855774 681.359924 131.804321 688.559998 131.804321 C 693.840027 131.804321 696.480042 135.64978 696.480042 143.340881 C 696.480042 146.705688 696 153.194946 695.039978 162.808777 C 693.600037 170.019104 692.880005 177.22937 692.880005 184.439758 C 692.880005 206.551544 699.47998 224.096527 712.679993 237.075165 C 725.880066 250.053833 745.199829 256.54306 770.640015 256.54306 C 786.190308 256.54306 801.097839 253.611664 815.362915 247.74881 C 820.594116 276.453979 832.13739 300.400269 849.840027 319.633484 C 875.28009 347.273224 911.039795 361.092926 957.119995 361.092926 C 987.360168 361.092926 1013.399841 355.324707 1035.23999 343.788116 C 1057.080078 332.251526 1074.719971 316.148621 1088.160034 295.478882 C 1096.319946 282.980896 1100.400024 268.079712 1100.400024 250.774811 C 1100.400024 240.680298 1098.599976 232.749023 1095 226.980713 C 1091.400024 221.212433 1086.47998 218.328308 1080.23999 218.328308 C 1073.039917 218.328308 1066.560059 221.933441 1060.799927 229.143799 C 1043.999878 250.774902 1029.240112 266.156799 1016.519958 275.289948 C 1003.799927 284.423065 987.600098 288.989594 967.919983 288.989594 C 940.559814 288.989594 921.120056 277.933868 909.600037 255.822052 C 966.720276 241.881989 1007.159912 223.015137 1030.919922 199.220917 C 1054.680054 175.426697 1066.559937 146.946167 1066.559937 113.778442 C 1066.559937 85.417664 1058.160034 62.945679 1041.359985 46.361877 C 1024.559937 29.778015 1002.240173 21.486206 974.399963 21.486206 C 943.199829 21.486206 915.240112 29.898132 890.519958 46.722351 C 865.799866 63.546509 846.480042 86.258911 832.559998 114.860046 C 823.986084 132.476685 818.052673 150.959351 814.759827 170.308289 L 815.070313 170.445313 C 808.819275 173.525635 803.129944 175.066284 798 175.066284 C 785.999939 175.066284 780 166.654358 780 149.830139 C 780 145.023193 781.919983 133.006165 785.76001 113.778442 C 790.080017 89.743896 792.23999 74.602356 792.23999 68.353333 C 792.23999 37.108459 776.640198 21.486206 745.440063 21.486206 C 729.599976 21.486206 712.200073 27.014099 693.23999 38.069946 C 674.279968 49.125854 654.960083 67.632263 635.279968 93.589539 C 615.599915 119.546875 597.840088 153.194763 582 194.53418 C 583.919983 173.383789 586.320007 155.59845 589.200012 141.177734 C 592.080017 126.757019 595.919983 109.933044 600.720032 90.705444 C 607.920044 63.786682 611.52002 46.482056 611.52002 38.791016 C 611.52002 32.061279 609.599976 27.494812 605.76001 25.09137 C 601.919983 22.687927 595.200012 21.486206 585.600037 21.486206 C 567.839905 21.486206 554.040039 24.730774 544.200012 31.220154 C 534.359924 37.709473 527.280029 47.924072 522.959961 61.864014 C 506.480804 114.048706 497.647095 168.922607 496.458588 226.487183 C 481.53775 243.355316 468.746399 255.993195 458.160004 264.474457 C 443.759918 276.011047 428.640106 281.779236 412.800018 281.779236 C 406.079987 281.779236 397.680054 280.337189 387.600006 277.453033 C 402.000061 257.74472 413.279968 235.873566 421.440002 211.83902 C 429.600037 187.804443 433.679993 163.049194 433.679993 137.572571 C 433.679993 102.482117 425.160065 74.121765 408.119995 52.490662 C 391.079926 30.859497 369.120117 20.044128 342.240021 20.044128 C 325.439911 20.044128 309.600067 24.250122 294.720001 32.662231 C 279.839935 41.074341 264.720093 54.893982 249.360016 74.121643 C 248.880005 68.353333 248.639999 59.460693 248.639999 47.443359 C 248.159988 35.426147 245.640015 27.374695 241.079987 23.288757 C 236.519974 19.202942 229.200058 17.159973 219.12001 17.159973 C 201.83992 17.159973 187.440063 21.245789 175.920013 29.417542 C 164.399948 37.589294 158.87999 48.64502 159.360001 62.585083 C 160.320007 89.984497 160.800003 138.773926 160.800003 208.954895 C 115.679779 284.423401 82.320107 353.521759 60.720001 416.251984 C 39.119892 478.982178 28.319996 533.90033 28.319996 581.008118 C 28.319996 614.175781 34.55994 640.132751 47.040001 658.8797 C 59.520061 677.626648 78.719872 687 104.639999 687 Z'

type LayoutDetail = {
  label: string
  value: string
}

type RenderEmailLayoutParams = {
  sectionLabel: string
  title: string
  intro: string
  action?: {
    label: string
    href: string
  }
  details?: LayoutDetail[]
  bodyNote?: string
  fallbackLink?: string
  closingNote?: string
}

export function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex')
}

function escapeHtml(input: string) {
  return input
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;')
}

function getEmailConfig() {
  const apiKey = process.env.RESEND_API_KEY
  const from = process.env.EMAIL_FROM
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL

  if (!apiKey || !from || !siteUrl) {
    throw new Error(
      'Email sending is not configured. Ensure RESEND_API_KEY, EMAIL_FROM, and NEXT_PUBLIC_SITE_URL are set.'
    )
  }

  return { apiKey, from, siteUrl }
}

function renderEmailLayout({
  sectionLabel,
  title,
  intro,
  action,
  details = [],
  bodyNote,
  fallbackLink,
  closingNote = 'If you didn’t request this, you can safely ignore this email.',
}: RenderEmailLayoutParams) {
  const safeSectionLabel = escapeHtml(sectionLabel)
  const safeTitle = escapeHtml(title)
  const safeIntro = escapeHtml(intro)
  const safeBodyNote = bodyNote ? escapeHtml(bodyNote) : null
  const safeFallbackLink = fallbackLink ? escapeHtml(fallbackLink) : null
  const safeClosingNote = escapeHtml(closingNote)
  const siteUrl = escapeHtml(process.env.NEXT_PUBLIC_SITE_URL || '')
  const safeActionHref = action ? escapeHtml(action.href) : null
  const safeActionLabel = action ? escapeHtml(action.label) : null

  const detailsHtml = details
    .map((detail) => {
      return `<div class="pill"><span class="pill-label">${escapeHtml(detail.label)}:</span> <strong>${escapeHtml(detail.value)}</strong></div>`
    })
    .join('')

  return `<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <meta name="color-scheme" content="light dark" />
    <meta name="supported-color-schemes" content="light dark" />
    <style>
      body { margin:0; padding:0; background:#f6f7fb; }
      .wrap { width:100%; background:#f6f7fb; padding:36px 16px; }
      .card {
        max-width:520px;
        margin:0 auto;
        background:#ffffff;
        border:1px solid #e8e9ee;
        border-radius:18px;
        overflow:hidden;
      }
      .inner {
        padding:26px 22px;
        font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;
        color:#111113;
      }
      .sub { margin-top:6px; font-size:12px; color:#6b6b75; }
      h2 { margin:18px 0 10px 0; font-size:20px; letter-spacing:-0.02em; line-height:1.2; }
      p { margin:0 0 14px 0; font-size:14px; line-height:1.65; color:#2a2a31; }
      .btn {
        display:inline-block;
        padding:12px 18px;
        background:#111113;
        color:#ffffff !important;
        text-decoration:none;
        border-radius:14px;
        font-weight:650;
        font-size:14px;
      }
      .muted { font-size:12px; color:#6b6b75; }
      .mono {
        margin-top:10px;
        padding:12px;
        background:#f2f3f7;
        border:1px solid #e6e7ee;
        border-radius:12px;
        font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,'Liberation Mono','Courier New',monospace;
        font-size:12px;
        color:#1a1a20;
        word-break:break-all;
      }
      .pill {
        display:inline-block;
        margin-top:10px;
        margin-right:8px;
        padding:6px 10px;
        border-radius:999px;
        border:1px solid #e6e7ee;
        background:#f6f7fb;
        font-size:12px;
        color:#2a2a31;
      }
      .pill-label { color:#6b6b75; }
      .hr { border:none; border-top:1px solid #ececf2; margin:18px 0; }
      @media (prefers-color-scheme: dark) {
        body { background:#0b0b0c !important; }
        .wrap { background:#0b0b0c !important; }
        .card { background:#111113 !important; border-color:#1f1f22 !important; }
        .inner { color:#ffffff !important; }
        p { color:#c9c9cf !important; }
        .sub, .muted, .pill-label { color:#9a9aa0 !important; }
        .btn { background:#ffffff !important; color:#0b0b0c !important; }
        .mono { background:#0d0d0f !important; border-color:#232327 !important; color:#cfcfd6 !important; }
        .pill { background:#0d0d0f !important; border-color:#232327 !important; color:#cfcfd6 !important; }
        .hr { border-top-color:#232327 !important; }
      }
    </style>
  </head>
  <body>
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" class="wrap">
      <tr>
        <td align="center">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" class="card">
            <tr>
              <td class="inner">
                <svg width="60" height="40" viewBox="0 0 1125 705" xmlns="http://www.w3.org/2000/svg" aria-label="pre">
                  <path fill="currentColor" stroke="none" d="${PRE_WORDMARK_PATH}" />
                </svg>
                <div class="sub">${safeSectionLabel}</div>
                <h2>${safeTitle}</h2>
                <p>${safeIntro}</p>
                ${detailsHtml}
                ${safeActionHref && safeActionLabel
      ? `<div style="margin:18px 0 16px 0;"><a class="btn" href="${safeActionHref}">${safeActionLabel}</a></div>`
      : ''}
                ${safeBodyNote ? `<p class="muted">${safeBodyNote}</p>` : ''}
                ${safeFallbackLink
      ? `<p class="muted" style="margin-top:14px;">If the button doesn’t work, paste this link into your browser:</p><div class="mono">${safeFallbackLink}</div>`
      : ''}
                <hr class="hr" />
                <p class="muted">${safeClosingNote}</p>
              </td>
            </tr>
            <tr>
              <td class="inner" style="padding-top:0;">
                <p class="muted" style="margin:10px 0 0 0;">© pre · ${siteUrl}</p>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>`
}

function renderUniversityVerificationHtml({
  link,
  domain,
  schoolName,
}: {
  link: string
  domain: string
  schoolName?: string | null
}) {
  const title = schoolName
    ? `Verify your ${schoolName} email`
    : 'Verify your university email'

  return renderEmailLayout({
    sectionLabel: 'Safety & Verification',
    title,
    intro: 'Confirm you own this email to unlock campus-only features.',
    action: {
      label: 'Verify university email',
      href: link,
    },
    details: [
      {
        label: 'University',
        value: schoolName || 'Academic institution',
      },
      {
        label: 'Domain',
        value: domain,
      },
    ],
    bodyNote: 'This link expires in 15 minutes and can only be used once.',
    fallbackLink: link,
  })
}

function renderAccessApplicationNotificationHtml({
  applicationId,
  email,
  fullName,
  note,
  submittedAt,
}: {
  applicationId: string
  email: string
  fullName?: string | null
  note?: string | null
  submittedAt?: string | null
}) {
  return renderEmailLayout({
    sectionLabel: 'Membership Review',
    title: 'New vetted access request',
    intro: 'A new request was added to the access review queue.',
    details: [
      { label: 'Application ID', value: applicationId },
      { label: 'Email', value: email },
      { label: 'Full name', value: fullName || 'Not provided' },
      { label: 'Submitted at', value: submittedAt || new Date().toISOString() },
    ],
    bodyNote: `Applicant note: ${note || 'Not provided'}`,
    closingNote: 'Review this request in your admin workflow.',
  })
}

async function sendResendEmail({
  requestId = 'server',
  emailType,
  to,
  subject,
  text,
  html,
}: {
  requestId?: string
  emailType: ResendEmailType
  to: string
  subject: string
  text: string
  html: string
}) {
  const { apiKey, from } = getEmailConfig()

  logEmailEvent({
    requestId,
    provider: 'resend',
    emailType,
    recipient: to,
    status: 'queued',
  })

  let messageId: string | null = null
  try {
    const response = await fetch(RESEND_API_URL, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from,
        to: [to],
        subject,
        text,
        html,
      }),
    })

    const responseText = await response.text().catch(() => '')
    let parsed: Record<string, unknown> | null = null
    if (responseText) {
      try {
        parsed = JSON.parse(responseText) as Record<string, unknown>
      } catch {
        parsed = null
      }
    }

    if (!response.ok) {
      const errorMessage =
        (parsed?.message as string | undefined) ||
        (parsed?.error as string | undefined) ||
        responseText ||
        'Failed to send email'
      throw new Error(errorMessage)
    }

    messageId = typeof parsed?.id === 'string' ? parsed.id : null

    logEmailEvent({
      requestId,
      provider: 'resend',
      emailType,
      recipient: to,
      status: 'sent',
      messageId,
    })
  } catch (error) {
    logEmailEvent({
      requestId,
      provider: 'resend',
      emailType,
      recipient: to,
      status: 'failed',
      messageId,
      error,
    })
    throw error
  }

  return { messageId }
}

export async function sendUniversityVerificationEmail({
  requestId,
  to,
  link,
  domain,
  schoolName,
}: UniversityVerifyEmailParams) {
  const subject = schoolName
    ? `Verify your ${schoolName} email`
    : 'Verify your university email'

  const text = [
    'Your pre university verification link is below.',
    '',
    link,
    '',
    'This link expires in 15 minutes and can only be used once.',
    '',
    `University: ${schoolName || domain}`,
    `Domain: ${domain}`,
    '',
    'If you did not request this, you can ignore this email.',
  ].join('\n')

  const html = renderUniversityVerificationHtml({ link, domain, schoolName })

  return sendResendEmail({
    requestId,
    emailType: 'university_verification',
    to,
    subject,
    text,
    html,
  })
}

export async function sendAccessApplicationNotification({
  requestId,
  to,
  applicationId,
  email,
  fullName,
  note,
  submittedAt,
}: AccessApplicationNotificationParams) {
  const subject = `New pre vetted access request: ${email}`
  const text = [
    'A new vetted access request was submitted.',
    '',
    `Application ID: ${applicationId}`,
    `Email: ${email}`,
    `Full name: ${fullName || 'Not provided'}`,
    `Submitted at: ${submittedAt || new Date().toISOString()}`,
    '',
    'Applicant note:',
    note || 'Not provided',
  ].join('\n')

  const html = renderAccessApplicationNotificationHtml({
    applicationId,
    email,
    fullName,
    note,
    submittedAt,
  })

  return sendResendEmail({
    requestId,
    emailType: 'access_application_notification',
    to,
    subject,
    text,
    html,
  })
}
