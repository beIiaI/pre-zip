const LOCAL_ORIGIN_PATTERN = /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/i

const parseOrigin = (value: string | null | undefined): string | null => {
  if (!value) return null
  try {
    return new URL(value).origin
  } catch {
    return null
  }
}

const getVercelOrigin = () => {
  const projectUrl = parseOrigin(
    process.env.VERCEL_PROJECT_PRODUCTION_URL
      ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`
      : null
  )
  if (projectUrl) return projectUrl
  return parseOrigin(process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : null)
}

export const isLocalOrigin = (origin: string | null | undefined) =>
  Boolean(origin && LOCAL_ORIGIN_PATTERN.test(origin))

export function buildAuthOriginCandidates(request: Request): string[] {
  const candidates = new Set<string>()

  const requestOrigin = parseOrigin(request.url)
  if (requestOrigin) candidates.add(requestOrigin)

  const originHeader = parseOrigin(request.headers.get('origin'))
  if (originHeader) candidates.add(originHeader)

  const siteOrigin = parseOrigin(process.env.NEXT_PUBLIC_SITE_URL)
  if (siteOrigin) candidates.add(siteOrigin)

  const appOrigin = parseOrigin(process.env.NEXT_PUBLIC_APP_URL)
  if (appOrigin) candidates.add(appOrigin)

  const vercelOrigin = getVercelOrigin()
  if (vercelOrigin) candidates.add(vercelOrigin)

  if (process.env.NODE_ENV !== 'production') {
    // Keep LAN/device testing stable by only injecting localhost fallback
    // when we are already on a local origin.
    const shouldAddLocalFallback =
      !requestOrigin || isLocalOrigin(requestOrigin) || isLocalOrigin(originHeader)
    if (shouldAddLocalFallback) {
      candidates.add('http://localhost:3000')
      candidates.add('http://127.0.0.1:3000')
    }
  }

  if (candidates.size === 0) {
    candidates.add(parseOrigin(process.env.NEXT_PUBLIC_SITE_URL) || 'http://localhost:3000')
  }

  return Array.from(candidates)
}

export function getPreferredAuthOrigin(request: Request): string {
  const origins = buildAuthOriginCandidates(request)
  return origins[0] || process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'
}

export function buildAuthCallbackUrl(origin: string, nextPath: string): string {
  return `${origin}/auth/callback?next=${encodeURIComponent(nextPath)}`
}
