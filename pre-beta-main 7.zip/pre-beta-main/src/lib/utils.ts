import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'
import { validatePasswordPolicy } from '@/lib/security/password-policy'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatEarlySupporterNumber(num: number): string {
  return `#${num}`
}

export function formatFounderNumber(num: number): string {
  return `#${String(num).padStart(3, '0')}`
}

export function isCoordinateString(value: string): boolean {
  return /^-?\d+(\.\d+)?\s*,\s*-?\d+(\.\d+)?$/.test(value.trim())
}

export function getLocationDisplay(value?: string | null): string | null {
  if (!value) return null
  const trimmed = value.trim()
  if (!trimmed) return null
  if (isCoordinateString(trimmed)) return null
  return trimmed
}

export function calculateAge(dateString: string): number {
  const today = new Date()
  const birthDate = new Date(dateString)
  let age = today.getFullYear() - birthDate.getFullYear()
  const monthDiff = today.getMonth() - birthDate.getMonth()
  
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--
  }
  
  return age
}

export function isOver18(dateString: string): boolean {
  return calculateAge(dateString) >= 18
}

export function validateUsername(username: string): { valid: boolean; error?: string } {
  if (!username) {
    return { valid: false, error: 'Username is required' }
  }
  if (username.length < 3) {
    return { valid: false, error: 'Username must be at least 3 characters' }
  }
  if (username.length > 20) {
    return { valid: false, error: 'Username must be 20 characters or less' }
  }
  if (!/^[a-z]/.test(username)) {
    return { valid: false, error: 'Username must start with a letter' }
  }
  if (!/^[a-z0-9_]+$/.test(username)) {
    return { valid: false, error: 'Only lowercase letters, numbers, and underscores allowed' }
  }
  return { valid: true }
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

export function validatePassword(
  password: string,
  options?: { email?: string | null }
): { valid: boolean; error?: string } {
  const result = validatePasswordPolicy(password, options)
  return {
    valid: result.valid,
    error: result.error,
  }
}

export function formatDate(dateString: string): string {
  return new Date(dateString).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  })
}

export function formatTime(dateString: string): string {
  return new Date(dateString).toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
  })
}

export function getInitials(name: string | null | undefined): string {
  if (!name || !name.trim()) return '?'
  
  const parts = name.trim().split(/\s+/)
  if (parts.length === 1) {
    return parts[0].charAt(0).toUpperCase()
  }
  return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase()
}
