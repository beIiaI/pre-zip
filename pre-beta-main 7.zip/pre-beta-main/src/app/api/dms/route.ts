import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import {
  enforceRateLimit,
  enforceSameOrigin,
  serverFailure,
  unauthorized,
  validationFailed,
} from '@/lib/security/guards'
import { parseJsonObject, readString, ValidationError } from '@/lib/security/validation'

const PROFILE_FIELDS =
  'id, username, full_name, avatar_url, last_active_at, show_activity_status'

type ThreadListItem = {
  id: string
  other_user: {
    id: string
    username: string | null
    full_name: string | null
    avatar_url: string | null
    is_online: boolean
    last_active_at: string | null
  } | null
  last_message: {
    id: string
    content: string
    created_at: string
    sender_id: string
  } | null
  unread_count: number
}

export const runtime = 'nodejs'

export async function GET(request: Request) {
  const requestId = createRequestId()
  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'dms:list',
    request,
    requestId,
    userId: user.id,
    limit: 60,
    windowMs: 15 * 60 * 1000,
  })
  if (rateLimitResponse) return rateLimitResponse

  const { data: participantRows, error } = await supabase
    .from('dm_participants')
    .select('thread_id, last_read_at')
    .eq('user_id', user.id)

  if (error) {
    logServerError('dms.list.participants', requestId, error, { userId: user.id })
    return serverFailure(requestId)
  }

  const threadIds = (participantRows ?? []).map((row) => row.thread_id)
  if (threadIds.length === 0) {
    return successResponse(requestId, { threads: [] })
  }

  const { data: threadsData, error: threadsError } = await supabase
    .from('dm_threads')
    .select('id, user_a, user_b')
    .in('id', threadIds)

  if (threadsError) {
    logServerError('dms.list.threads', requestId, threadsError, { userId: user.id })
    return serverFailure(requestId)
  }

  const { data: messages, error: messagesError } = await supabase
    .from('dm_messages')
    .select('id, thread_id, body, created_at, sender_id, deleted_at')
    .in('thread_id', threadIds)
    .order('created_at', { ascending: false })

  if (messagesError) {
    logServerError('dms.list.messages', requestId, messagesError, { userId: user.id })
    return serverFailure(requestId)
  }

  const latestByThread = new Map<string, any>()
  for (const message of messages ?? []) {
    if (!latestByThread.has(message.thread_id)) {
      latestByThread.set(message.thread_id, message)
    }
  }

  const threadById = new Map<string, { user_a: string | null; user_b: string | null }>()
  for (const row of threadsData ?? []) {
    threadById.set(row.id, { user_a: row.user_a ?? null, user_b: row.user_b ?? null })
  }

  const blockedSet = new Set<string>()
  const { data: blockedByMe, error: blockedByMeError } = await supabase
    .from('blocks')
    .select('blocked_id')
    .eq('blocker_id', user.id)

  if (blockedByMeError) {
    logServerError('dms.list.blocked_by_me', requestId, blockedByMeError, { userId: user.id })
    return serverFailure(requestId)
  }

  for (const row of blockedByMe ?? []) {
    if (row.blocked_id) blockedSet.add(row.blocked_id)
  }

  const { data: blockedMe, error: blockedMeError } = await supabase
    .from('blocks')
    .select('blocker_id')
    .eq('blocked_id', user.id)

  if (blockedMeError) {
    logServerError('dms.list.blocked_me', requestId, blockedMeError, { userId: user.id })
    return serverFailure(requestId)
  }

  for (const row of blockedMe ?? []) {
    if (row.blocker_id) blockedSet.add(row.blocker_id)
  }

  const lastReadByThread = new Map<string, string | null>()
  for (const row of participantRows ?? []) {
    lastReadByThread.set(row.thread_id, row.last_read_at ?? null)
  }

  const now = Date.now()

  const otherIds = new Set<string>()
  for (const threadId of threadIds) {
    const thread = threadById.get(threadId)
    const otherId = thread?.user_a === user.id ? thread?.user_b : thread?.user_a
    if (otherId) otherIds.add(otherId)
  }

  const admin = createAdminClient() as any
  const { data: otherProfiles, error: profilesError } = await admin
    .from('profiles')
    .select(PROFILE_FIELDS)
    .in('id', Array.from(otherIds))

  if (profilesError) {
    logServerError('dms.list.other_profiles', requestId, profilesError, {
      userId: user.id,
    })
    return serverFailure(requestId)
  }

  const profileById = new Map<string, any>()
  for (const row of otherProfiles ?? []) {
    profileById.set(row.id, row)
  }

  const mappedThreads = threadIds.map((threadId): ThreadListItem | null => {
    const thread = threadById.get(threadId)
    const otherId = thread?.user_a === user.id ? thread?.user_b : thread?.user_a
    const other = otherId ? profileById.get(otherId) ?? null : null
    const latest = latestByThread.get(threadId) ?? null
    if (other?.id && blockedSet.has(other.id)) {
      return null
    }
    const lastActive = other?.last_active_at ? new Date(other.last_active_at).getTime() : null
    const isOnline = Boolean(
      other?.show_activity_status !== false &&
      lastActive &&
      now - lastActive < 2 * 60 * 1000
    )
    return {
      id: threadId,
      other_user: other
        ? {
            id: other.id,
            username: other.username,
            full_name: other.full_name,
            avatar_url: other.avatar_url,
            is_online: isOnline,
            last_active_at: other.last_active_at ?? null,
          }
        : null,
      last_message: latest
        ? {
            id: latest.id,
            content: latest.deleted_at ? 'Message unsent' : latest.body,
            created_at: latest.created_at,
            sender_id: latest.sender_id,
          }
        : null,
      unread_count: 0,
    }
  })

  const threads = mappedThreads
    .filter((thread): thread is ThreadListItem => thread !== null)
    .sort((a, b) => {
      const aTime = a.last_message?.created_at ? new Date(a.last_message.created_at).getTime() : 0
      const bTime = b.last_message?.created_at ? new Date(b.last_message.created_at).getTime() : 0
      return bTime - aTime
    })

  const unreadCounts = await Promise.all(
    threads.map(async (thread) => {
      const lastReadAt = lastReadByThread.get(thread.id)
      let query = supabase
        .from('dm_messages')
        .select('id', { count: 'exact', head: true })
        .eq('thread_id', thread.id)
        .neq('sender_id', user.id)

      if (lastReadAt) {
        query = query.gt('created_at', lastReadAt)
      }

      const { count, error: countError } = await query
      if (countError) {
        logServerError('dms.list.unread_count', requestId, countError, {
          userId: user.id,
          threadId: thread.id,
        })
        return { threadId: thread.id, count: 0 }
      }
      return { threadId: thread.id, count: count ?? 0 }
    })
  )

  const countMap = new Map(unreadCounts.map((row) => [row.threadId, row.count]))
  const response = threads.map((thread) => ({
    ...thread,
    unread_count: countMap.get(thread.id) ?? 0,
  }))

  return successResponse(requestId, { threads: response })
}

export async function POST(request: Request) {
  const requestId = createRequestId()
  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'dms:create_thread',
    request,
    requestId,
    userId: user.id,
    limit: 25,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 60_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  let payload: Record<string, unknown>
  try {
    payload = await parseJsonObject(request)
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid DM payload.')
    }
    return validationFailed(requestId, 'Invalid DM payload.')
  }

  let targetId = ''
  try {
    targetId = readString(payload, 'user_id', { required: true })
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Missing recipient.')
    }
    return validationFailed(requestId, 'Missing recipient.')
  }

  if (targetId === user.id) {
    return validationFailed(requestId, 'Cannot message yourself.')
  }

  const { data: blockRows, error: blockError } = await supabase
    .from('blocks')
    .select('id')
    .or(`and(blocker_id.eq.${user.id},blocked_id.eq.${targetId}),and(blocker_id.eq.${targetId},blocked_id.eq.${user.id})`)
    .limit(1)

  if (blockError) {
    logServerError('dms.create_thread.block_check', requestId, blockError, {
      userId: user.id,
      targetId,
    })
    return serverFailure(requestId)
  }

  if (blockRows && blockRows.length > 0) {
    return validationFailed(requestId, 'Cannot message this user.')
  }

  const admin = createAdminClient() as any
  const { data: targetProfile, error: targetError } = await admin
    .from('profiles')
    .select('id, message_requests')
    .eq('id', targetId)
    .maybeSingle()

  if (targetError) {
    logServerError('dms.create_thread.target_profile', requestId, targetError, {
      userId: user.id,
      targetId,
    })
    return serverFailure(requestId)
  }

  if (!targetProfile) {
    return validationFailed(requestId, 'User not found.')
  }

  const messageSetting = targetProfile.message_requests ?? 'everyone'
  if (messageSetting === 'off') {
    return validationFailed(requestId, 'Message requests are off.')
  }
  if (messageSetting === 'friends') {
    const { data: viewerFollows, error: viewerFollowsError } = await supabase
      .from('follows')
      .select('follower_id')
      .eq('follower_id', user.id)
      .eq('following_id', targetId)
      .maybeSingle()

    const { data: targetFollows, error: targetFollowsError } = await supabase
      .from('follows')
      .select('follower_id')
      .eq('follower_id', targetId)
      .eq('following_id', user.id)
      .maybeSingle()

    if (viewerFollowsError || targetFollowsError) {
      logServerError('dms.create_thread.friend_check', requestId, viewerFollowsError || targetFollowsError, {
        userId: user.id,
        targetId,
      })
      return serverFailure(requestId)
    }

    if (!viewerFollows || !targetFollows) {
      return validationFailed(requestId, 'Message requests are friends-only.')
    }
  }

  const { data: threadId, error: threadError } = await supabase
    .rpc('dm_get_or_create_thread', { target_id: targetId })

  if (threadError || !threadId) {
    logServerError('dms.create_thread.rpc', requestId, threadError, {
      userId: user.id,
      targetId,
    })
    return serverFailure(requestId)
  }

  return successResponse(requestId, { thread_id: threadId })
}
