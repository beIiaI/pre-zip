import { NextRequest } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import {
  enforceRateLimit,
  enforceSameOrigin,
  serverFailure,
  unauthorized,
  validationFailed,
} from '@/lib/security/guards'
import { parseJsonObject, readString, ValidationError } from '@/lib/security/validation'

const MESSAGE_SELECT =
  'id, body, created_at, edited_at, deleted_at, sender_id, sender:profiles!dm_messages_sender_id_fkey(id, username, full_name, avatar_url)'
const UNSEND_WINDOW_MS = 5 * 60 * 1000

export const runtime = 'nodejs'

type MessageRow = {
  id: string
  body: string
  created_at: string
  edited_at: string | null
  deleted_at: string | null
  sender_id: string
  sender: {
    id: string
    username: string | null
    full_name: string | null
    avatar_url: string | null
  } | null
}

const mapMessageResponse = (message: MessageRow) => ({
  id: message.id,
  content: message.deleted_at ? '' : message.body,
  created_at: message.created_at,
  edited_at: message.edited_at ?? null,
  deleted_at: message.deleted_at ?? null,
  sender_id: message.sender_id,
  sender: message.sender ?? null,
  status: 'sent' as const,
})

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const requestId = createRequestId()
  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'dms:messages:create',
    request,
    requestId,
    userId: user.id,
    limit: 100,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 30_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  const { id: threadId } = await context.params
  if (!threadId) {
    return validationFailed(requestId, 'Missing thread id.')
  }

  let payload: Record<string, unknown>
  try {
    payload = await parseJsonObject(request)
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid message payload.')
    }
    return validationFailed(requestId, 'Invalid message payload.')
  }

  let content = ''
  try {
    content = readString(payload, 'content', { required: true, max: 4000 })
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Message cannot be empty.')
    }
    return validationFailed(requestId, 'Message cannot be empty.')
  }

  if (!content.trim()) {
    return validationFailed(requestId, 'Message cannot be empty.')
  }

  const trimmedContent = content.trim()

  const { data: thread, error: threadError } = await supabase
    .from('dm_threads')
    .select('user_a, user_b')
    .eq('id', threadId)
    .maybeSingle()

  if (threadError) {
    logServerError('dms.message.thread_lookup', requestId, threadError, { userId: user.id, threadId })
    return serverFailure(requestId)
  }

  if (!thread) {
    return validationFailed(requestId, 'Thread not found.')
  }

  const otherId = thread.user_a === user.id ? thread.user_b : thread.user_a
  if (otherId) {
    const { data: blockRows, error: blockError } = await supabase
      .from('blocks')
      .select('id')
      .or(`and(blocker_id.eq.${user.id},blocked_id.eq.${otherId}),and(blocker_id.eq.${otherId},blocked_id.eq.${user.id})`)
      .limit(1)

    if (blockError) {
      logServerError('dms.message.block_check', requestId, blockError, {
        userId: user.id,
        threadId,
        otherId,
      })
      return serverFailure(requestId)
    }

    if (blockRows && blockRows.length > 0) {
      return validationFailed(requestId, 'Cannot message this user.')
    }
  }

  const { data: message, error } = await supabase
    .from('dm_messages')
    .insert({
      thread_id: threadId,
      sender_id: user.id,
      body: trimmedContent,
    })
    .select(MESSAGE_SELECT)
    .single<MessageRow>()

  if (error) {
    logServerError('dms.message.insert', requestId, error, { userId: user.id, threadId })
    return serverFailure(requestId)
  }

  return successResponse(requestId, {
    message: mapMessageResponse(message),
  })
}

export async function DELETE(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const requestId = createRequestId()
  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'dms:messages:unsend',
    request,
    requestId,
    userId: user.id,
    limit: 50,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 30_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  const { id: threadId } = await context.params
  if (!threadId) {
    return validationFailed(requestId, 'Missing thread id.')
  }

  let payload: Record<string, unknown>
  try {
    payload = await parseJsonObject(request)
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid message payload.')
    }
    return validationFailed(requestId, 'Invalid message payload.')
  }

  let messageId = ''
  try {
    messageId = readString(payload, 'message_id', { required: true })
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Message id is required.')
    }
    return validationFailed(requestId, 'Message id is required.')
  }

  const { data: existingMessage, error: existingError } = await supabase
    .from('dm_messages')
    .select('id, sender_id, created_at, deleted_at')
    .eq('id', messageId)
    .eq('thread_id', threadId)
    .maybeSingle()

  if (existingError) {
    logServerError('dms.message.unsend.lookup', requestId, existingError, {
      userId: user.id,
      threadId,
      messageId,
    })
    return serverFailure(requestId)
  }

  if (!existingMessage || existingMessage.sender_id !== user.id) {
    return validationFailed(requestId, 'Message not found.')
  }

  const createdAtMs = new Date(existingMessage.created_at).getTime()
  if (Number.isNaN(createdAtMs) || Date.now() - createdAtMs > UNSEND_WINDOW_MS) {
    return validationFailed(requestId, 'Messages can only be unsent within 5 minutes.')
  }

  let responseMessage: MessageRow | null = null

  if (existingMessage.deleted_at) {
    const { data: currentMessage, error: currentError } = await supabase
      .from('dm_messages')
      .select(MESSAGE_SELECT)
      .eq('id', messageId)
      .eq('thread_id', threadId)
      .maybeSingle<MessageRow>()

    if (currentError || !currentMessage) {
      logServerError('dms.message.unsend.fetch_current', requestId, currentError, {
        userId: user.id,
        threadId,
        messageId,
      })
      return serverFailure(requestId)
    }

    responseMessage = currentMessage
  } else {
    const { data: updatedMessage, error: updateError } = await supabase
      .from('dm_messages')
      .update({
        body: '',
        edited_at: null,
        deleted_at: new Date().toISOString(),
      })
      .eq('id', messageId)
      .eq('thread_id', threadId)
      .eq('sender_id', user.id)
      .gte('created_at', new Date(Date.now() - UNSEND_WINDOW_MS).toISOString())
      .is('deleted_at', null)
      .select(MESSAGE_SELECT)
      .maybeSingle<MessageRow>()

    if (updateError || !updatedMessage) {
      logServerError('dms.message.unsend.update', requestId, updateError, {
        userId: user.id,
        threadId,
        messageId,
      })
      return serverFailure(requestId)
    }

    responseMessage = updatedMessage
  }

  return successResponse(requestId, {
    action: 'unsent',
    message: mapMessageResponse(responseMessage),
  })
}
