import { NextRequest } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import { enforceRateLimit, serverFailure, unauthorized, validationFailed } from '@/lib/security/guards'

const MESSAGE_SELECT =
  'id, body, created_at, edited_at, deleted_at, sender_id, sender:profiles!dm_messages_sender_id_fkey(id, username, full_name, avatar_url)'

export const runtime = 'nodejs'

export async function GET(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const requestId = createRequestId()
  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'dms:thread:get',
    request,
    requestId,
    userId: user.id,
    limit: 80,
    windowMs: 15 * 60 * 1000,
  })
  if (rateLimitResponse) return rateLimitResponse

  const { id: threadId } = await context.params
  if (!threadId) {
    return validationFailed(requestId, 'Missing thread id.')
  }

  const { data: thread, error: threadError } = await supabase
    .from('dm_threads')
    .select('id, created_at, user_a, user_b')
    .eq('id', threadId)
    .maybeSingle()

  if (threadError) {
    logServerError('dms.thread.get.thread', requestId, threadError, { userId: user.id, threadId })
    return serverFailure(requestId)
  }

  if (!thread) {
    return validationFailed(requestId, 'Thread not found.')
  }

  const otherUserId = thread.user_a === user.id ? thread.user_b : thread.user_a
  if (!otherUserId) {
    return validationFailed(requestId, 'Thread not found.')
  }

  const admin = createAdminClient() as any
  const { data: otherProfile, error: otherProfileError } = await admin
    .from('profiles')
    .select('id, username, full_name, avatar_url, last_active_at, show_activity_status, show_read_receipts')
    .eq('id', otherUserId)
    .maybeSingle()

  if (otherProfileError) {
    logServerError('dms.thread.get.other_profile', requestId, otherProfileError, {
      userId: user.id,
      otherUserId,
      threadId,
    })
    return serverFailure(requestId)
  }

  const { data: otherReadAt, error: otherReadError } = await supabase
    .rpc('dm_get_other_read_at', { thread_id: threadId })

  if (otherReadError) {
    logServerError('dms.thread.get.read_receipt', requestId, otherReadError, {
      userId: user.id,
      threadId,
    })
  }

  const otherLastActive = otherProfile?.last_active_at ? new Date(otherProfile.last_active_at).getTime() : null
  const isOnline = Boolean(
    otherProfile?.show_activity_status !== false &&
    otherLastActive &&
    Date.now() - otherLastActive < 2 * 60 * 1000
  )

  if (otherProfile?.id) {
    const { data: blockRows, error: blockError } = await supabase
      .from('blocks')
      .select('id')
      .or(`and(blocker_id.eq.${user.id},blocked_id.eq.${otherProfile.id}),and(blocker_id.eq.${otherProfile.id},blocked_id.eq.${user.id})`)
      .limit(1)

    if (blockError) {
      logServerError('dms.thread.get.block_check', requestId, blockError, {
        userId: user.id,
        threadId,
      })
      return serverFailure(requestId)
    }

    if (blockRows && blockRows.length > 0) {
      return validationFailed(requestId, 'Thread not found.')
    }
  }

  const { data: messages, error: messagesError } = await supabase
    .from('dm_messages')
    .select(MESSAGE_SELECT)
    .eq('thread_id', threadId)
    .order('created_at', { ascending: true })
    .limit(200)

  if (messagesError) {
    logServerError('dms.thread.get.messages', requestId, messagesError, {
      userId: user.id,
      threadId,
    })
    return serverFailure(requestId)
  }

  const { error: lastReadError } = await supabase
    .from('dm_participants')
    .update({ last_read_at: new Date().toISOString() })
    .eq('thread_id', threadId)
    .eq('user_id', user.id)

  if (lastReadError) {
    logServerError('dms.thread.get.mark_read', requestId, lastReadError, {
      userId: user.id,
      threadId,
    })
  }

  return successResponse(requestId, {
    thread,
    other_user: otherProfile
      ? {
          id: otherProfile.id,
          username: otherProfile.username,
          full_name: otherProfile.full_name,
          avatar_url: otherProfile.avatar_url,
          is_online: isOnline,
          last_active_at: otherProfile.last_active_at ?? null,
          show_read_receipts: otherProfile.show_read_receipts ?? true,
        }
      : null,
    messages: (messages ?? []).map((row) => {
      let status: 'sent' | 'delivered' | 'read' | null = null
      if (row.sender_id === user.id) {
        if (!otherReadAt) {
          status = 'sent'
        } else {
          const isRead =
            otherProfile?.show_read_receipts !== false &&
            new Date(otherReadAt).getTime() >= new Date(row.created_at).getTime()
          status = isRead ? 'read' : 'delivered'
        }
      }
      return {
        id: row.id,
        content: row.deleted_at ? '' : row.body,
        created_at: row.created_at,
        edited_at: row.edited_at ?? null,
        deleted_at: row.deleted_at ?? null,
        sender_id: row.sender_id,
        sender: row.sender ?? null,
        status,
      }
    }),
  })
}
