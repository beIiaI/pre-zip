import { createAdminClient } from '@/lib/supabase/admin'
import { normalizeInviteCode, normalizeInviteEmail } from '@/lib/invites'
import { validateEmail } from '@/lib/utils'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import { enforceRateLimit, enforceSameOrigin, serverFailure, validationFailed } from '@/lib/security/guards'
import { parseJsonObject, readString, ValidationError } from '@/lib/security/validation'

type ValidateInviteBody = {
  code?: string
  email?: string
}

export const runtime = 'nodejs'

export async function POST(request: Request) {
  const requestId = createRequestId()
  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  const rateLimitResponse = enforceRateLimit({
    namespace: 'invites:validate',
    request,
    requestId,
    limit: 25,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 45_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  let body: ValidateInviteBody
  try {
    body = (await parseJsonObject(request)) as ValidateInviteBody
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid invite payload.')
    }
    return validationFailed(requestId, 'Invalid invite payload.')
  }

  let codeInput = ''
  let emailInput = ''
  try {
    codeInput = readString(body as Record<string, unknown>, 'code', { required: true })
    emailInput = readString(body as Record<string, unknown>, 'email')
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid invite payload.')
    }
    return validationFailed(requestId, 'Invalid invite payload.')
  }

  const code = normalizeInviteCode(codeInput)
  if (code.length < 6) {
    return validationFailed(requestId, 'Invalid invite code.')
  }

  const email = normalizeInviteEmail(emailInput)
  if (email && !validateEmail(email)) {
    return validationFailed(requestId, 'Invalid email address.')
  }

  const admin = createAdminClient() as any
  const { data: invite, error: inviteError } = await admin
    .from('access_invites')
    .select('id,inviter_id,invitee_email,invitee_name,invite_code,status,expires_at')
    .eq('invite_code', code)
    .maybeSingle()

  if (inviteError) {
    logServerError('invites.validate.lookup', requestId, inviteError)
    return serverFailure(requestId)
  }

  if (!invite || invite.status !== 'pending') {
    return validationFailed(requestId, 'Invite code is invalid or no longer active.')
  }

  if (invite.expires_at && invite.expires_at <= new Date().toISOString()) {
    return validationFailed(requestId, 'Invite code has expired.')
  }

  const reservedEmail = invite.invitee_email ? normalizeInviteEmail(invite.invitee_email) : ''
  const isOpenInvite = !reservedEmail
  if (email && !isOpenInvite && reservedEmail !== email) {
    return validationFailed(requestId, 'This invite is reserved for a different email.')
  }

  const { data: inviterProfile, error: inviterError } = await admin
    .from('profiles')
    .select('full_name,username')
    .eq('id', invite.inviter_id)
    .maybeSingle()

  if (inviterError) {
    logServerError('invites.validate.inviter', requestId, inviterError, {
      inviterId: invite.inviter_id,
    })
    return serverFailure(requestId)
  }

  return successResponse(requestId, {
    ok: true,
    invite: {
      code: invite.invite_code,
      inviteeEmail: invite.invitee_email,
      isOpenInvite,
      inviteeName: invite.invitee_name,
      inviterName:
        inviterProfile?.full_name ||
        (inviterProfile?.username ? `@${inviterProfile.username}` : 'A member'),
      expiresAt: invite.expires_at,
    },
  })
}

