import { createAdminClient } from '@/lib/supabase/admin'
import {
  MAX_ACTIVE_INVITES,
  getInviteLimit,
  getInviteRefreshCount,
  getRemainingInviteSlots,
} from '@/lib/invites'
import { reconcileInvitesForInviter } from '@/lib/invites/reconcile'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import {
  enforceRateLimit,
  enforceSameOrigin,
  serverFailure,
  unauthorized,
  validationFailed,
} from '@/lib/security/guards'
import { createClient } from '@/lib/supabase/server'

export const runtime = 'nodejs'

export async function POST(request: Request) {
  const requestId = createRequestId()
  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  const supabase = await createClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'invites:refresh',
    request,
    requestId,
    userId: user.id,
    limit: 6,
    windowMs: 60 * 60 * 1000,
    baseBlockMs: 60_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  const admin = createAdminClient() as any

  await reconcileInvitesForInviter({
    admin,
    inviterId: user.id,
    requestId,
  })

  const { data: inviter, error: inviterError } = await admin
    .from('profiles')
    .select('id,is_founder,invite_refresh_count')
    .eq('id', user.id)
    .maybeSingle()

  if (inviterError || !inviter) {
    if (inviterError) {
      logServerError('invites.refresh.inviter_profile', requestId, inviterError, { userId: user.id })
    }
    return serverFailure(requestId)
  }

  const isFounder = !!inviter.is_founder
  const refreshCount = getInviteRefreshCount(inviter.invite_refresh_count)

  if (isFounder) {
    return successResponse(requestId, {
      refreshed: false,
      isFounder: true,
      max: null,
      baseMax: MAX_ACTIVE_INVITES,
      refreshCount,
      remaining: null,
      message: 'Founders have unlimited referrals.',
    })
  }

  const { data: invites, error: invitesError } = await admin
    .from('access_invites')
    .select('status,expires_at')
    .eq('inviter_id', user.id)

  if (invitesError) {
    logServerError('invites.refresh.quota_lookup', requestId, invitesError, { userId: user.id })
    return serverFailure(requestId)
  }

  const nowMs = Date.now()
  const activePending = (invites ?? []).filter((invite: { status: string; expires_at: string | null }) => {
    if (invite.status !== 'pending') return false
    if (!invite.expires_at) return true
    return new Date(invite.expires_at).getTime() > nowMs
  }).length
  const acceptedCount = (invites ?? []).filter(
    (invite: { status: string }) => invite.status === 'accepted'
  ).length
  const usedNominations = activePending + acceptedCount

  const currentMax = getInviteLimit({ isFounder, refreshCount })
  if (currentMax === null) {
    return successResponse(requestId, {
      refreshed: false,
      isFounder: true,
      max: null,
      baseMax: MAX_ACTIVE_INVITES,
      refreshCount,
      remaining: null,
      message: 'Founders have unlimited referrals.',
    })
  }

  if (activePending > 0) {
    return validationFailed(requestId, 'You still have pending referrals. Use or revoke them before refreshing.')
  }

  if (acceptedCount < currentMax) {
    return validationFailed(
      requestId,
      `Refresh unlocks after all ${currentMax} referrals are accepted.`
    )
  }

  const { data: updatedProfile, error: updateError } = await admin
    .from('profiles')
    .update({
      invite_refresh_count: refreshCount + 1,
      updated_at: new Date().toISOString(),
    })
    .eq('id', user.id)
    .eq('invite_refresh_count', refreshCount)
    .select('invite_refresh_count')
    .maybeSingle()

  if (updateError) {
    logServerError('invites.refresh.update', requestId, updateError, { userId: user.id })
    return serverFailure(requestId)
  }

  let updatedRefreshCount = getInviteRefreshCount(updatedProfile?.invite_refresh_count)
  if (!updatedProfile) {
    const { data: latestProfile, error: latestProfileError } = await admin
      .from('profiles')
      .select('invite_refresh_count')
      .eq('id', user.id)
      .maybeSingle()

    if (latestProfileError || !latestProfile) {
      if (latestProfileError) {
        logServerError('invites.refresh.latest_profile', requestId, latestProfileError, { userId: user.id })
      }
      return serverFailure(requestId)
    }

    updatedRefreshCount = getInviteRefreshCount(latestProfile.invite_refresh_count)
    if (updatedRefreshCount <= refreshCount) {
      return validationFailed(requestId, 'Unable to refresh referrals right now. Please try again.')
    }
  }

  const nextMax = getInviteLimit({ isFounder, refreshCount: updatedRefreshCount })

  return successResponse(requestId, {
    refreshed: true,
    isFounder: false,
    max: nextMax,
    baseMax: MAX_ACTIVE_INVITES,
    refreshCount: updatedRefreshCount,
    used: usedNominations,
    remaining: getRemainingInviteSlots({
      isFounder,
      refreshCount: updatedRefreshCount,
      usedNominations,
    }),
    message: `Referrals refreshed. ${MAX_ACTIVE_INVITES} new invite slots unlocked.`,
  })
}
