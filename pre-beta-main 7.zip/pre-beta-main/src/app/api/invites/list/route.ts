import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'
import {
  MAX_ACTIVE_INVITES,
  getInviteLimit,
  getInviteRefreshCount,
  getRemainingInviteSlots,
} from '@/lib/invites'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import { enforceRateLimit, unauthorized, serverFailure } from '@/lib/security/guards'
import { buildAcceptedMemberLabel, reconcileInvitesForInviter } from '@/lib/invites/reconcile'

export const runtime = 'nodejs'

export async function GET(request: Request) {
  const requestId = createRequestId()

  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'invites:list',
    request,
    requestId,
    userId: user.id,
    limit: 30,
    windowMs: 15 * 60 * 1000,
  })
  if (rateLimitResponse) return rateLimitResponse

  const admin = createAdminClient() as any
  const nowIso = new Date().toISOString()

  await reconcileInvitesForInviter({
    admin,
    inviterId: user.id,
    requestId,
  })

  const { data: inviterProfile, error: inviterProfileError } = await admin
    .from('profiles')
    .select('id,is_founder,invite_refresh_count')
    .eq('id', user.id)
    .maybeSingle()

  if (inviterProfileError || !inviterProfile) {
    if (inviterProfileError) {
      logServerError('invites.list.inviter_profile', requestId, inviterProfileError, { userId: user.id })
    }
    return serverFailure(requestId)
  }

  const { data: invites, error: invitesError } = await admin
    .from('access_invites')
    .select('id,invitee_email,invitee_name,invite_code,status,accepted_user_id,created_at,expires_at,accepted_at')
    .eq('inviter_id', user.id)
    .order('created_at', { ascending: false })

  if (invitesError) {
    logServerError('invites.list', requestId, invitesError, { userId: user.id })
    return serverFailure(requestId)
  }

  const inviteRows = invites ?? []

  const acceptedUserIds = Array.from(
    new Set(
      inviteRows
        .map((invite: { accepted_user_id?: string | null }) => invite.accepted_user_id || null)
        .filter((id: string | null): id is string => !!id)
    )
  )

  const usernameByUserId = new Map<string, string | null>()
  if (acceptedUserIds.length) {
    const { data: acceptedProfiles, error: acceptedProfilesError } = await admin
      .from('profiles')
      .select('id,username')
      .in('id', acceptedUserIds)

    if (acceptedProfilesError) {
      logServerError('invites.list.accepted_profiles', requestId, acceptedProfilesError, {
        userId: user.id,
      })
    } else {
      for (const profile of acceptedProfiles ?? []) {
        usernameByUserId.set(profile.id, profile.username ?? null)
      }
    }
  }

  const enrichedInvites = inviteRows.map((invite: {
    id: string
    invitee_email: string | null
    invitee_name: string | null
    invite_code: string
    status: 'pending' | 'accepted' | 'revoked' | 'expired'
    accepted_user_id: string | null
    created_at: string
    expires_at: string | null
    accepted_at: string | null
  }) => {
    const acceptedMemberLabel = invite.status === 'accepted' && invite.accepted_user_id
      ? buildAcceptedMemberLabel({
          acceptedUserId: invite.accepted_user_id,
          username: usernameByUserId.get(invite.accepted_user_id) ?? null,
        })
      : null

    return {
      ...invite,
      invitee_email: invite.status === 'accepted' ? null : invite.invitee_email,
      accepted_member_label: acceptedMemberLabel,
      signed_up: invite.status === 'accepted',
    }
  })

  const activePending = (enrichedInvites ?? []).filter(
    (invite: { status: string; expires_at: string | null }) =>
      invite.status === 'pending' && (!invite.expires_at || invite.expires_at > nowIso)
  ).length

  const acceptedCount = (enrichedInvites ?? []).filter(
    (invite: { status: string }) => invite.status === 'accepted'
  ).length
  const usedNominations = activePending + acceptedCount
  const isFounder = !!inviterProfile.is_founder
  const refreshCount = getInviteRefreshCount(inviterProfile.invite_refresh_count)
  const maxSlots = getInviteLimit({ isFounder, refreshCount })
  const canRefresh = !isFounder && maxSlots !== null && activePending === 0 && acceptedCount >= maxSlots

  return successResponse(requestId, {
    invites: enrichedInvites,
    remaining: getRemainingInviteSlots({
      isFounder,
      refreshCount,
      usedNominations,
    }),
    used: usedNominations,
    pending: activePending,
    acceptedCount,
    max: maxSlots,
    baseMax: MAX_ACTIVE_INVITES,
    refreshCount,
    isFounder,
    canRefresh,
  })
}
