import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'
import {
  MAX_ACTIVE_INVITES,
  generateInviteCode,
  getInviteLimit,
  getInviteRefreshCount,
  getRemainingInviteSlots,
  normalizeInviteEmail,
} from '@/lib/invites'
import { validateEmail } from '@/lib/utils'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import {
  enforceRateLimit,
  enforceSameOrigin,
  serverFailure,
  unauthorized,
  validationFailed,
} from '@/lib/security/guards'
import { parseJsonObject, readString, ValidationError } from '@/lib/security/validation'

type CreateInviteBody = {
  email?: string
  name?: string
}

export const runtime = 'nodejs'

export async function POST(request: Request) {
  const requestId = createRequestId()
  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'invites:create',
    request,
    requestId,
    userId: user.id,
    email: user.email ?? null,
    limit: 8,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 60_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  let body: CreateInviteBody = {}
  try {
    body = (await parseJsonObject(request)) as CreateInviteBody
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid invite payload.')
    }
    return validationFailed(requestId, 'Invalid invite payload.')
  }

  let rawEmail = ''
  let inviteeName = ''
  try {
    rawEmail = readString(body as Record<string, unknown>, 'email')
    inviteeName = readString(body as Record<string, unknown>, 'name', { max: 80 })
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid invite payload.')
    }
    return validationFailed(requestId, 'Invalid invite payload.')
  }

  const hasTargetEmail = rawEmail.length > 0
  const normalizedEmail = hasTargetEmail ? normalizeInviteEmail(rawEmail) : ''
  if (hasTargetEmail && !validateEmail(normalizedEmail)) {
    return validationFailed(requestId, 'Please enter a valid email address.')
  }

  const admin = createAdminClient() as any
  const nowIso = new Date().toISOString()

  const { error: expireError } = await admin
    .from('access_invites')
    .update({
      status: 'expired',
      updated_at: nowIso,
    })
    .eq('inviter_id', user.id)
    .eq('status', 'pending')
    .lte('expires_at', nowIso)

  if (expireError) {
    logServerError('invites.create.expire_pending', requestId, expireError, { userId: user.id })
    return serverFailure(requestId)
  }

  const { data: inviter, error: inviterError } = await admin
    .from('profiles')
    .select('id,email,is_founder,invite_refresh_count')
    .eq('id', user.id)
    .maybeSingle()

  if (inviterError || !inviter) {
    if (inviterError) {
      logServerError('invites.create.inviter_profile', requestId, inviterError, { userId: user.id })
    }
    return validationFailed(requestId, 'Unable to validate inviter profile.')
  }

  const inviterEmail = (inviter.email || user.email || '').toLowerCase()
  const isFounder = !!inviter.is_founder
  const refreshCount = getInviteRefreshCount(inviter.invite_refresh_count)
  const maxSlots = getInviteLimit({ isFounder, refreshCount })

  if (hasTargetEmail && inviterEmail === normalizedEmail) {
    return validationFailed(requestId, 'You cannot invite your own email.')
  }

  let existingInvite: any = null
  if (hasTargetEmail) {
    const { data: existing, error: existingError } = await admin
      .from('access_invites')
      .select('id,invite_code,status,invitee_email,invitee_name,created_at,expires_at')
      .eq('inviter_id', user.id)
      .eq('invitee_email', normalizedEmail)
      .eq('status', 'pending')
      .gt('expires_at', nowIso)
      .order('created_at', { ascending: false })
      .maybeSingle()

    if (existingError) {
      logServerError('invites.create.existing_lookup', requestId, existingError, { userId: user.id })
      return serverFailure(requestId)
    }
    existingInvite = existing
  }

  const { data: invitesForQuota, error: quotaError } = await admin
    .from('access_invites')
    .select('id,status,expires_at')
    .eq('inviter_id', user.id)

  if (quotaError) {
    logServerError('invites.create.quota_lookup', requestId, quotaError, { userId: user.id })
    return serverFailure(requestId)
  }

  const nowMs = Date.now()
  const activePendingCount = (invitesForQuota ?? []).filter((invite: { status: string; expires_at: string | null }) => {
    if (invite.status !== 'pending') return false
    if (!invite.expires_at) return true
    return new Date(invite.expires_at).getTime() > nowMs
  }).length
  const acceptedCount = (invitesForQuota ?? []).filter(
    (invite: { status: string }) => invite.status === 'accepted'
  ).length
  const usedNominations = activePendingCount + acceptedCount

  const origin = new URL(request.url).origin

  if (existingInvite) {
    return successResponse(requestId, {
      invite: existingInvite,
      inviteUrl: `${origin}/auth?mode=signup&invite=${encodeURIComponent(existingInvite.invite_code)}`,
      remaining: getRemainingInviteSlots({
        isFounder,
        refreshCount,
        usedNominations,
      }),
      used: usedNominations,
      max: maxSlots,
      isFounder,
      refreshCount,
      reused: true,
    })
  }

  if (!isFounder && maxSlots !== null && usedNominations >= maxSlots) {
    const canRefresh = activePendingCount === 0 && acceptedCount >= maxSlots
    if (canRefresh) {
      return validationFailed(
        requestId,
        `Nomination limit reached. Refresh referrals to unlock ${MAX_ACTIVE_INVITES} more invites.`
      )
    }
    return validationFailed(
      requestId,
      `Nomination limit reached. You can nominate up to ${maxSlots} people right now.`
    )
  }

  for (let attempt = 0; attempt < 6; attempt += 1) {
    const code = generateInviteCode(10)
    const expiresAt = new Date(Date.now() + 1000 * 60 * 60 * 24 * 30).toISOString()

    const { data: inserted, error: insertError } = await admin
      .from('access_invites')
      .insert({
        inviter_id: user.id,
        invitee_email: hasTargetEmail ? normalizedEmail : null,
        invitee_name: inviteeName || null,
        invite_code: code,
        status: 'pending',
        expires_at: expiresAt,
      })
      .select('id,invite_code,status,invitee_email,invitee_name,created_at,expires_at')
      .maybeSingle()

    if (!insertError && inserted) {
      const usedAfterInsert = usedNominations + 1
      return successResponse(requestId, {
        invite: inserted,
        inviteUrl: `${origin}/auth?mode=signup&invite=${encodeURIComponent(inserted.invite_code)}`,
        remaining: getRemainingInviteSlots({
          isFounder,
          refreshCount,
          usedNominations: usedAfterInsert,
        }),
        used: usedAfterInsert,
        max: maxSlots,
        isFounder,
        refreshCount,
      })
    }

    if (insertError) {
      if (insertError.message?.includes('invite_limit_reached')) {
        const canRefresh = maxSlots !== null && activePendingCount === 0 && acceptedCount >= maxSlots
        if (canRefresh) {
          return validationFailed(
            requestId,
            `Nomination limit reached. Refresh referrals to unlock ${MAX_ACTIVE_INVITES} more invites.`
          )
        }
        return validationFailed(
          requestId,
          `Nomination limit reached. You can nominate up to ${maxSlots ?? MAX_ACTIVE_INVITES} people right now.`
        )
      }

      if (insertError.code === '23505' && hasTargetEmail) {
        const { data: pendingDuplicate, error: duplicateLookupError } = await admin
          .from('access_invites')
          .select('id,invite_code,status,invitee_email,invitee_name,created_at,expires_at')
          .eq('inviter_id', user.id)
          .eq('invitee_email', normalizedEmail)
          .eq('status', 'pending')
          .gt('expires_at', nowIso)
          .order('created_at', { ascending: false })
          .maybeSingle()

        if (duplicateLookupError) {
          logServerError('invites.create.duplicate_lookup', requestId, duplicateLookupError, {
            userId: user.id,
          })
          return serverFailure(requestId)
        }

        if (pendingDuplicate) {
          return successResponse(requestId, {
            invite: pendingDuplicate,
            inviteUrl: `${origin}/auth?mode=signup&invite=${encodeURIComponent(pendingDuplicate.invite_code)}`,
            remaining: getRemainingInviteSlots({
              isFounder,
              refreshCount,
              usedNominations,
            }),
            used: usedNominations,
            max: maxSlots,
            isFounder,
            refreshCount,
            reused: true,
          })
        }

        continue
      }

      logServerError('invites.create.insert', requestId, insertError, { userId: user.id })
      return serverFailure(requestId)
    }
  }

  return validationFailed(requestId, 'Unable to generate invite code. Please try again.')
}
