import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST(request: Request) {
  const supabase = await createClient()

  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  let payload: { following_id?: string } = {}
  try {
    payload = (await request.json()) as { following_id?: string }
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload' }, { status: 400 })
  }

  const followingId = payload.following_id
  if (!followingId) {
    return NextResponse.json({ error: 'Missing following_id' }, { status: 400 })
  }

  const { error } = await supabase
    .from('follows')
    .delete()
    .eq('follower_id', user.id)
    .eq('following_id', followingId)

  if (error) {
    return NextResponse.json({ error: 'Unfollow failed' }, { status: 500 })
  }

  return NextResponse.json({ success: true })
}
