import { NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { extractDomain, isAcademicDomain } from '@/lib/verification/swot'
import { getNormalizedUniversityName } from '@/lib/verification/university'
import { hashToken } from '@/lib/email'
import { createRequestId, logServerError } from '@/lib/security/api'
import { enforceRateLimit } from '@/lib/security/guards'
import { getPreferredAuthOrigin } from '@/lib/auth/origin'

export const runtime = 'nodejs'

type UniversityVerificationRecord = {
  id: string
  user_id: string
  email: string
  expires_at: string
  used_at: string | null
}

const getRedirectUrl = (request: Request, status: string, message?: string) => {
  const origin = getPreferredAuthOrigin(request)
  const base = origin ? `${origin}/settings/safety-verification` : '/settings/safety-verification'
  const params = new URLSearchParams({ status })
  if (message) {
    params.set('message', message)
  }
  return `${base}?${params.toString()}`
}

export async function GET(request: Request) {
  const requestId = createRequestId()
  const rateLimitResponse = enforceRateLimit({
    namespace: 'verification:university:confirm',
    request,
    requestId,
    limit: 20,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 30_000,
  })
  if (rateLimitResponse) {
    return NextResponse.redirect(getRedirectUrl(request, 'error', 'too_many_requests'))
  }

  const { searchParams } = new URL(request.url)
  const token = searchParams.get('token')

  if (!token) {
    return NextResponse.redirect(getRedirectUrl(request, 'error', 'missing_token'))
  }

  const admin = createAdminClient() as any
  const tokenHash = hashToken(token)

  const { data: recordData, error: recordError } = await admin
    .from('university_verifications')
    .select('id, user_id, email, expires_at, used_at')
    .eq('token_hash', tokenHash)
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle()

  const record = (recordData ?? null) as UniversityVerificationRecord | null

  if (recordError) {
    logServerError('verification.university.confirm.lookup', requestId, recordError)
    return NextResponse.redirect(getRedirectUrl(request, 'error', 'invalid_token'))
  }

  if (!record) {
    return NextResponse.redirect(getRedirectUrl(request, 'error', 'invalid_token'))
  }

  if (record.used_at) {
    return NextResponse.redirect(getRedirectUrl(request, 'error', 'token_used'))
  }

  if (record.expires_at && new Date(record.expires_at).getTime() < Date.now()) {
    return NextResponse.redirect(getRedirectUrl(request, 'error', 'token_expired'))
  }

  const domain = extractDomain(record.email)
  if (!domain) {
    return NextResponse.redirect(getRedirectUrl(request, 'error', 'invalid_email'))
  }

  const swot = isAcademicDomain(domain)
  if (!swot.ok) {
    const message = swot.reason === 'stoplisted' ? 'domain_stoplisted' : 'domain_not_academic'
    return NextResponse.redirect(getRedirectUrl(request, 'error', message))
  }

  const now = new Date().toISOString()
  const universityDomain = swot.domain ?? domain
  const universityName = getNormalizedUniversityName(universityDomain, swot.schoolName)

  const { error: profileError } = await admin
    .from('profiles')
    .update({
      university_email: record.email,
      university_domain: universityDomain,
      university_name: universityName,
      university_verified: true,
      university_verified_at: now,
      university_grad_year_confirmed_at: now,
      university_graduated_at: null,
      is_verified: true,
      verification_type: 'university_email',
      updated_at: now,
    })
    .eq('id', record.user_id)

  if (profileError) {
    logServerError('verification.university.confirm.profile_update', requestId, profileError, {
      userId: record.user_id,
    })
    return NextResponse.redirect(getRedirectUrl(request, 'error', 'profile_update_failed'))
  }

  const { error: usedError } = await admin
    .from('university_verifications')
    .update({ used_at: now })
    .eq('id', record.id)

  if (usedError) {
    logServerError('verification.university.confirm.mark_used', requestId, usedError, {
      verificationId: record.id,
    })
    return NextResponse.redirect(getRedirectUrl(request, 'error', 'verification_failed'))
  }

  return NextResponse.redirect(getRedirectUrl(request, 'verified'))
}
