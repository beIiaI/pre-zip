import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { getAcademicDomainSchools } from '@/lib/verification/swot'
import { deriveCollegeOptionsFromSwot, getNormalizedUniversityName } from '@/lib/verification/university'
import { createRequestId } from '@/lib/security/api'
import { enforceRateLimit, enforceSameOrigin } from '@/lib/security/guards'

const MAX_COLLEGE_NAME_LENGTH = 120
const MAX_COLLEGE_SAVES = 2
const SUPPORT_EMAIL = 'support@presocial.app'

export const runtime = 'nodejs'

type CollegePayload = {
  collegeName?: string
}

type CollegeState = {
  college_name: string | null
  college_self_reported: boolean
  college_updated_at: string | null
  college_change_count: number
}

type DbErrorLike = {
  code?: string | null
  message?: string | null
}

const defaultCollegeState: CollegeState = {
  college_name: null,
  college_self_reported: false,
  college_updated_at: null,
  college_change_count: 0,
}

function mapDatabaseError(error: DbErrorLike | null | undefined) {
  const code = error?.code ?? null
  const message = (error?.message ?? '').toLowerCase()

  if (code === '42P01' || message.includes('does not exist')) {
    const missingProfiles = message.includes('public.profiles')
    return {
      status: 503,
      reason: missingProfiles ? 'profiles_table_missing' : 'profile_college_table_missing',
      error: missingProfiles
        ? 'Profiles table is missing. Run database migrations.'
        : 'College table is missing. Run database migrations.',
      detectedCause: code ?? 'relation_missing',
      likelyCauses: missingProfiles
        ? ['Core profile migration was not applied.', 'Database is pointed at the wrong Supabase project.']
        : ['Migration 027_college_private_table_and_rename.sql was not applied.', 'Database is pointed at the wrong Supabase project.'],
    }
  }

  if (code === '42703' || message.includes('column') && message.includes('does not exist')) {
    return {
      status: 500,
      reason: 'college_schema_mismatch',
      error: 'College schema is out of date.',
      detectedCause: code ?? 'missing_column',
      likelyCauses: [
        'Migrations were applied partially.',
        'Generated database types do not match the current database schema.',
      ],
    }
  }

  if (code === '42501' || message.includes('permission denied') || message.includes('row-level security')) {
    return {
      status: 500,
      reason: 'college_permissions_misconfigured',
      error: 'College table permissions are misconfigured.',
      detectedCause: code ?? 'permission_or_rls_error',
      likelyCauses: [
        'RLS is missing or policy definitions are incorrect on profile_college.',
        'Table grants for role authenticated are missing.',
      ],
    }
  }

  return {
    status: 500,
    reason: 'college_unknown_db_error',
    error: 'Unexpected database error while reading college data.',
    detectedCause: code ?? 'unknown',
    likelyCauses: ['Transient database outage.', 'Unexpected schema drift.'],
  }
}

function unauthorizedResponse(userError: DbErrorLike | null | undefined) {
  return NextResponse.json(
    {
      ok: false,
      reason: 'unauthenticated',
      error: 'Authentication required.',
      detectedCause: userError ? 'supabase_auth_error' : 'missing_session',
      likelyCauses: [
        'You are signed out or your session expired.',
        'Session cookies are missing in the browser request.',
      ],
      authCode: userError?.code ?? null,
    },
    { status: 401 }
  )
}

function dbErrorResponse(error: DbErrorLike | null | undefined) {
  const mapped = mapDatabaseError(error)
  return NextResponse.json(
    {
      ok: false,
      reason: mapped.reason,
      error: mapped.error,
      detectedCause: mapped.detectedCause,
      likelyCauses: mapped.likelyCauses,
    },
    { status: mapped.status }
  )
}

export async function GET(request: NextRequest) {
  const requestId = createRequestId()
  const rateLimitResponse = enforceRateLimit({
    namespace: 'verification:college:get',
    request,
    requestId,
    limit: 30,
    windowMs: 15 * 60 * 1000,
  })
  if (rateLimitResponse) {
    return NextResponse.json({ ok: false, error: 'Too many requests.', requestId }, { status: 429 })
  }

  const supabase = await createClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return unauthorizedResponse(userError)
  }

  const { data: profileMeta, error: profileMetaError } = await supabase
    .from('profiles')
    .select('university_verified, university_domain, university_name')
    .eq('id', user.id)
    .maybeSingle()

  if (profileMetaError) {
    return dbErrorResponse(profileMetaError)
  }

  const { data: collegeRow, error } = await supabase
    .from('profile_college')
    .select('college_name, college_self_reported, college_updated_at, college_change_count')
    .eq('user_id', user.id)
    .maybeSingle()

  if (error) {
    return dbErrorResponse(error)
  }

  let collegeOptions: string[] = []
  const verifiedDomain = profileMeta?.university_verified ? profileMeta?.university_domain : null
  if (verifiedDomain) {
    const swot = getAcademicDomainSchools(verifiedDomain)
    if (swot.ok) {
      collegeOptions = deriveCollegeOptionsFromSwot({
        domain: swot.domain,
        universityName: getNormalizedUniversityName(swot.domain, profileMeta?.university_name ?? swot.schoolName),
        schoolNames: swot.schoolNames,
      })
    }
  }

  return NextResponse.json({
    ok: true,
    profile: (collegeRow ?? defaultCollegeState) as CollegeState,
    collegeOptions,
    collegeLocked:
      ((collegeRow?.college_name ?? '').trim().length > 0) &&
      (collegeRow?.college_change_count ?? 0) >= MAX_COLLEGE_SAVES,
    changesRemaining: Math.max(0, MAX_COLLEGE_SAVES - (collegeRow?.college_change_count ?? 0)),
  })
}

export async function POST(request: NextRequest) {
  const requestId = createRequestId()
  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  const supabase = await createClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return unauthorizedResponse(userError)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'verification:college:post',
    request,
    requestId,
    userId: user.id,
    limit: 10,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 60_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  let payload: CollegePayload = {}
  try {
    payload = (await request.json()) as CollegePayload
  } catch {
    return NextResponse.json(
      {
        ok: false,
        reason: 'invalid_payload',
        error: 'Invalid JSON payload.',
      },
      { status: 400 }
    )
  }

  const normalizedName = (payload.collegeName ?? '').trim().slice(0, MAX_COLLEGE_NAME_LENGTH)
  if (!normalizedName) {
    return NextResponse.json(
      {
        ok: false,
        reason: 'college_name_required',
        error: 'College name is required.',
      },
      { status: 400 }
    )
  }

  const { data: currentProfile, error: profileError } = await supabase
    .from('profiles')
    .select('id, university_verified, university_domain, university_name')
    .eq('id', user.id)
    .maybeSingle()

  if (profileError || !currentProfile) {
    if (profileError) {
      return dbErrorResponse(profileError)
    }

    return NextResponse.json(
      {
        ok: false,
        reason: 'profile_not_found',
        error: 'Profile not found for the authenticated user.',
        detectedCause: 'missing_profile_row',
        likelyCauses: ['Profile bootstrap has not run yet for this account.'],
      },
      { status: 404 }
    )
  }

  if (currentProfile.university_verified !== true) {
    return NextResponse.json(
      { ok: false, reason: 'university_verification_required', error: 'Verify your university email first.' },
      { status: 403 }
    )
  }

  let collegeOptions: string[] = []
  if (currentProfile.university_domain) {
    const swot = getAcademicDomainSchools(currentProfile.university_domain)
    if (swot.ok) {
      collegeOptions = deriveCollegeOptionsFromSwot({
        domain: swot.domain,
        universityName: getNormalizedUniversityName(swot.domain, currentProfile.university_name ?? swot.schoolName),
        schoolNames: swot.schoolNames,
      })
    }
  }

  if (collegeOptions.length === 0) {
    return NextResponse.json(
      {
        ok: false,
        reason: 'college_subdivisions_unavailable',
        error: 'College self-report is only available when SWoT lists subdivisions for your university domain.',
      },
      { status: 403 }
    )
  }

  const allowedOptions = new Set(collegeOptions.map((option) => option.trim().toLowerCase()))
  if (!allowedOptions.has(normalizedName.toLowerCase())) {
    return NextResponse.json(
      {
        ok: false,
        reason: 'invalid_college_option',
        error: 'Select a valid college option for your university.',
      },
      { status: 400 }
    )
  }

  const { data: existingCollege, error: currentCollegeError } = await supabase
    .from('profile_college')
    .select('college_name, college_self_reported, college_updated_at, college_change_count')
    .eq('user_id', user.id)
    .maybeSingle()

  if (currentCollegeError) {
    return dbErrorResponse(currentCollegeError)
  }

  const currentCollege = (existingCollege?.college_name ?? '').trim()
  const baseChangeCount =
    typeof existingCollege?.college_change_count === 'number'
      ? Math.max(0, existingCollege.college_change_count)
      : currentCollege
        ? 1
        : 0
  const isCollegeLocked = currentCollege.length > 0 && baseChangeCount >= MAX_COLLEGE_SAVES

  if (isCollegeLocked) {
    return NextResponse.json(
      {
        ok: false,
        reason: 'college_locked_support',
        error: 'College is locked. Contact support to change it.',
        supportEmail: SUPPORT_EMAIL,
      },
      { status: 429 }
    )
  }

  if (currentCollege && currentCollege.toLowerCase() === normalizedName.toLowerCase()) {
    return NextResponse.json({
      ok: true,
      noChange: true,
      profile: (existingCollege ?? defaultCollegeState) as CollegeState,
      collegeLocked: isCollegeLocked,
      changesRemaining: Math.max(0, MAX_COLLEGE_SAVES - baseChangeCount),
    })
  }

  const nowIso = new Date().toISOString()
  const nextChangeCount = Math.max(0, baseChangeCount) + 1
  const { data: updatedCollege, error: updateError } = await supabase
    .from('profile_college')
    .upsert(
      {
        user_id: user.id,
        college_name: normalizedName,
        college_self_reported: true,
        college_updated_at: nowIso,
        college_change_count: nextChangeCount,
        updated_at: nowIso,
      },
      { onConflict: 'user_id' }
    )
    .select('college_name, college_self_reported, college_updated_at, college_change_count')
    .maybeSingle()

  if (updateError || !updatedCollege) {
    if (updateError) {
      return dbErrorResponse(updateError)
    }

    return NextResponse.json(
      {
        ok: false,
        reason: 'college_write_failed',
        error: 'College row was not returned after save.',
        detectedCause: 'upsert_returned_no_row',
        likelyCauses: [
          'RLS policy blocked INSERT/UPDATE for this user.',
          'profile_college table grants for authenticated are missing.',
        ],
      },
      { status: 500 }
    )
  }

  return NextResponse.json({
    ok: true,
    profile: updatedCollege as CollegeState,
    collegeLocked:
      ((updatedCollege?.college_name ?? '').trim().length > 0) &&
      (updatedCollege?.college_change_count ?? 0) >= MAX_COLLEGE_SAVES,
    changesRemaining: Math.max(0, MAX_COLLEGE_SAVES - (updatedCollege?.college_change_count ?? 0)),
  })
}
