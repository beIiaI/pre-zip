import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST() {
  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()

  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { data: existing, error: selectError } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .maybeSingle()

  if (selectError) {
    return NextResponse.json({ error: selectError.message }, { status: 500 })
  }

  if (existing) {
    return NextResponse.json({ profile: existing })
  }

  const email = user.email ?? (user.user_metadata?.email as string | undefined)
  if (!email) {
    return NextResponse.json({ error: 'User email not available for profile insert' }, { status: 500 })
  }

  const { data: inserted, error: insertError } = await supabase
    .from('profiles')
    .insert({ id: user.id, email })
    .select()
    .maybeSingle()

  if (insertError) {
    return NextResponse.json({ error: insertError.message }, { status: 500 })
  }

  if (!inserted) {
    return NextResponse.json({ error: 'Profile insert did not return data' }, { status: 500 })
  }

  return NextResponse.json({ profile: inserted })
}
