import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { validateUsername } from '@/lib/utils'
import { isRestrictedBio, isRestrictedDisplayName, isRestrictedUsername } from '@/lib/moderation/restrictedWords'

const ALLOWED_FIELDS = [
  'full_name',
  'username',
  'bio',
  'avatar_url',
  'location',
  'location_lat',
  'location_lng',
  'theme_mode',
  'amoled_enabled',
  'user_intent',
  'interests',
  'date_of_birth',
  'onboarding_step',
  'onboarding_completed',
  'profile_visibility',
  'message_requests',
  'show_activity_status',
  'show_read_receipts',
  'show_location',
  'show_university',
  'show_college',
  'discoverable',
] as const

type AllowedField = (typeof ALLOWED_FIELDS)[number]

export async function POST(request: Request) {
  const supabase = await createClient()

  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  let payload: Record<string, unknown> = {}
  try {
    payload = (await request.json()) as Record<string, unknown>
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload' }, { status: 400 })
  }

  const updatePayload: Record<string, unknown> = {}

  for (const key of ALLOWED_FIELDS) {
    if (key in payload) {
      updatePayload[key as AllowedField] = payload[key]
    }
  }

  if (typeof updatePayload.username === 'string') {
    const normalized = updatePayload.username.trim().toLowerCase()
    const validation = validateUsername(normalized)
    if (!validation.valid) {
      return NextResponse.json({ error: validation.error || 'Invalid username' }, { status: 400 })
    }
    if (isRestrictedUsername(normalized)) {
      return NextResponse.json({ error: "That username isn't available." }, { status: 409 })
    }
    updatePayload.username = normalized
  }

  if (typeof updatePayload.full_name === 'string') {
    const trimmed = updatePayload.full_name.trim().replace(/\s+/g, ' ')
    if (!trimmed) {
      updatePayload.full_name = null
    } else if (isRestrictedDisplayName(trimmed)) {
      return NextResponse.json({ error: "That name isn't available." }, { status: 400 })
    } else {
      updatePayload.full_name = trimmed
    }
  }

  if (typeof updatePayload.bio === 'string') {
    const trimmed = updatePayload.bio.trim()
    if (!trimmed) {
      updatePayload.bio = null
    } else if (isRestrictedBio(trimmed)) {
      return NextResponse.json({ error: 'Bio contains restricted words.' }, { status: 400 })
    } else {
      updatePayload.bio = trimmed
    }
  }

  if (typeof updatePayload.profile_visibility === 'string') {
    const value = updatePayload.profile_visibility
    if (!['public', 'friends', 'private'].includes(value)) {
      return NextResponse.json({ error: 'Invalid profile visibility' }, { status: 400 })
    }
  }

  if (typeof updatePayload.message_requests === 'string') {
    const value = updatePayload.message_requests
    if (!['everyone', 'friends', 'off'].includes(value)) {
      return NextResponse.json({ error: 'Invalid message requests setting' }, { status: 400 })
    }
  }

  const booleanFields = [
    'show_activity_status',
    'show_read_receipts',
    'show_location',
    'show_university',
    'show_college',
    'discoverable',
  ] as const

  for (const key of booleanFields) {
    if (key in updatePayload && typeof updatePayload[key] !== 'boolean') {
      return NextResponse.json({ error: `Invalid value for ${key}` }, { status: 400 })
    }
  }

  if (Object.keys(updatePayload).length === 0) {
    return NextResponse.json({ error: 'No profile fields provided' }, { status: 400 })
  }

  const { data, error } = await supabase
    .from('profiles')
    .update({ ...updatePayload, updated_at: new Date().toISOString() })
    .eq('id', user.id)
    .select()
    .single()

  if (error) {
    const message = error.message || 'Update failed'
    if (message.toLowerCase().includes('duplicate key') || message.toLowerCase().includes('unique')) {
      return NextResponse.json({ error: "That username isn't available." }, { status: 409 })
    }
    return NextResponse.json({ error: message }, { status: 500 })
  }

  return NextResponse.json({ profile: data })
}
