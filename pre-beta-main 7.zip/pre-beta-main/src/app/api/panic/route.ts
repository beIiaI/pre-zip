import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST(request: Request) {
  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  let payload: Record<string, unknown> = {}
  try {
    payload = (await request.json()) as Record<string, unknown>
  } catch {
    payload = {}
  }

  const lat = typeof payload.lat === 'number' ? payload.lat : null
  const lng = typeof payload.lng === 'number' ? payload.lng : null

  const { data, error } = await supabase
    .rpc('create_panic_event', { lat, lng })

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  const result = Array.isArray(data) ? data[0] : data

  return NextResponse.json({
    ok: true,
    event_id: result?.event_id ?? null,
    notified: result?.notified_count ?? 0,
  })
}
