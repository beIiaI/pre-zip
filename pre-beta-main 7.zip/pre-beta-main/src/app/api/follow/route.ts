import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST(request: Request) {
  const supabase = await createClient()

  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  let payload: { following_id?: string } = {}
  try {
    payload = (await request.json()) as { following_id?: string }
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload' }, { status: 400 })
  }

  const followingId = payload.following_id
  if (!followingId) {
    return NextResponse.json({ error: 'Missing following_id' }, { status: 400 })
  }

  if (followingId === user.id) {
    return NextResponse.json({ error: 'Cannot follow yourself' }, { status: 400 })
  }

  const { error } = await supabase
    .from('follows')
    .upsert(
      { follower_id: user.id, following_id: followingId },
      { onConflict: 'follower_id,following_id', ignoreDuplicates: true }
    )

  if (error) {
    return NextResponse.json({ error: 'Follow failed' }, { status: 500 })
  }

  return NextResponse.json({ success: true })
}
