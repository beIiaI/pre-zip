import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import {
  enforceRateLimit,
  enforceSameOrigin,
  forbidden,
  unauthorized,
  validationFailed,
} from '@/lib/security/guards'
import { parseJsonObject, readString, ValidationError } from '@/lib/security/validation'

export const runtime = 'nodejs'

async function assertInternalUser(userId: string) {
  const admin = createAdminClient() as any
  const response = await admin
    .from('profiles')
    .select('is_internal')
    .eq('id', userId)
    .maybeSingle()

  const data = response.data as { is_internal: boolean } | null
  const { error } = response

  if (error || !data) return false
  return data.is_internal === true
}

export async function GET(request: Request) {
  const requestId = createRequestId()
  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  const supabase = await createClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()
  if (userError || !user) return unauthorized(requestId)

  const isInternal = await assertInternalUser(user.id)
  if (!isInternal) return forbidden(requestId)

  const rateLimitResponse = enforceRateLimit({
    namespace: 'access:applications:get',
    request,
    requestId,
    userId: user.id,
    limit: 60,
    windowMs: 60_000,
    baseBlockMs: 30_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  const { searchParams } = new URL(request.url)
  const requestedStatus = (searchParams.get('status') || 'pending').toLowerCase()
  const status = requestedStatus === 'approved' || requestedStatus === 'rejected' ? requestedStatus : 'pending'

  const admin = createAdminClient() as any
  const { data, error } = await admin
    .from('access_applications')
    .select('id,email,full_name,note,status,reviewed_by,reviewed_at,created_at')
    .eq('status', status)
    .order('created_at', { ascending: false })
    .limit(100)

  if (error) {
    logServerError('access.applications.get', requestId, error, { reviewerId: user.id, status })
    return validationFailed(requestId, 'Unable to load access applications.')
  }

  return successResponse(requestId, {
    ok: true,
    applications: data ?? [],
  })
}

export async function PATCH(request: Request) {
  const requestId = createRequestId()
  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  const supabase = await createClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()
  if (userError || !user) return unauthorized(requestId)

  const isInternal = await assertInternalUser(user.id)
  if (!isInternal) return forbidden(requestId)

  const rateLimitResponse = enforceRateLimit({
    namespace: 'access:applications:patch',
    request,
    requestId,
    userId: user.id,
    limit: 30,
    windowMs: 60_000,
    baseBlockMs: 30_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  let payload: Record<string, unknown>
  try {
    payload = await parseJsonObject(request)
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, error.message)
    }
    return validationFailed(requestId)
  }

  let id = ''
  let status = ''
  try {
    id = readString(payload, 'id', { required: true })
    status = readString(payload, 'status', { required: true, toLowerCase: true })
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, error.message)
    }
    return validationFailed(requestId)
  }

  if (status !== 'approved' && status !== 'rejected') {
    return validationFailed(requestId, 'Status must be approved or rejected.')
  }

  const admin = createAdminClient() as any
  const { data, error } = await admin
    .from('access_applications')
    .update({
      status,
      reviewed_by: user.id,
      reviewed_at: new Date().toISOString(),
    })
    .eq('id', id)
    .select('id,email,status,reviewed_by,reviewed_at')
    .maybeSingle()

  if (error || !data) {
    logServerError('access.applications.patch', requestId, error || new Error('application_not_found'), {
      reviewerId: user.id,
      id,
      status,
    })
    return validationFailed(requestId, 'Unable to update access application.')
  }

  return successResponse(requestId, {
    ok: true,
    application: data,
  })
}
