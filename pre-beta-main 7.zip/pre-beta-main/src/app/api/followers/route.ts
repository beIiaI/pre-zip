import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'

const SELECT_FIELDS = 'id, username, full_name, avatar_url, early_supporter_number, founder_number, is_founder'

export const runtime = 'nodejs'

export async function GET(request: Request) {
  const supabase = await createClient()

  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { searchParams } = new URL(request.url)
  const userIdParam = searchParams.get('user_id') || user.id

  const { data: followRows, error: followError } = await supabase
    .from('follows')
    .select('follower_id')
    .eq('following_id', userIdParam)

  if (followError) {
    return NextResponse.json({ error: 'Failed to load followers' }, { status: 500 })
  }

  const followerIds = (followRows ?? []).map((row) => row.follower_id).filter(Boolean)
  if (followerIds.length === 0) {
    return NextResponse.json({ results: [] })
  }

  const admin = createAdminClient() as any
  const { data: profiles, error: profileError } = await admin
    .from('profiles')
    .select(SELECT_FIELDS)
    .in('id', followerIds)

  if (profileError) {
    return NextResponse.json({ error: 'Failed to load profiles' }, { status: 500 })
  }

  const { data: followingRows } = await supabase
    .from('follows')
    .select('following_id')
    .eq('follower_id', user.id)
    .in('following_id', followerIds)

  const followingSet = new Set((followingRows ?? []).map((row) => row.following_id))

  const results = (profiles ?? [])
    .map((profile: any) => ({
      id: profile.id,
      username: profile.username,
      full_name: profile.full_name,
      avatar_url: profile.avatar_url,
      early_supporter_number: profile.early_supporter_number,
      founder_number: profile.founder_number,
      is_founder: profile.is_founder,
      is_following: followingSet.has(profile.id),
    }))
    .sort((a: any, b: any) => (a.username || '').localeCompare(b.username || ''))

  return NextResponse.json({ results })
}
