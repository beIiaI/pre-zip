import { NextRequest, NextResponse } from 'next/server'
import {
  sendAccessApplicationNotification,
  sendUniversityVerificationEmail,
} from '@/lib/email'
import { getMissingServerEnv, getServerEnvStatus } from '@/lib/config/server-env'
import { createRequestId, successResponse } from '@/lib/security/api'
import { parseJsonObject, readBoolean, readString, ValidationError } from '@/lib/security/validation'
import { validationFailed } from '@/lib/security/guards'
import { validateEmail } from '@/lib/utils'

export const runtime = 'nodejs'

const TESTABLE_TEMPLATES = ['university_verification', 'access_application_notification'] as const
type TestableTemplate = (typeof TESTABLE_TEMPLATES)[number]

function isDebugAllowed(request: NextRequest) {
  if (process.env.NODE_ENV !== 'production') return true

  const expectedToken = process.env.INTERNAL_DEBUG_TOKEN
  if (!expectedToken) return false

  const providedToken = request.headers.get('x-debug-token')
  return Boolean(providedToken && providedToken === expectedToken)
}

function forbiddenResponse() {
  return NextResponse.json({ error: 'Not found.' }, { status: 404 })
}

export async function GET(request: NextRequest) {
  if (!isDebugAllowed(request)) return forbiddenResponse()

  const requestId = createRequestId()
  const envStatus = getServerEnvStatus()
  const missingEnv = getMissingServerEnv()

  return successResponse(requestId, {
    ok: true,
    runtime: process.env.NODE_ENV,
    emailProviders: {
      auth: 'supabase-auth-smtp',
      transactional: 'resend',
    },
    templates: {
      supabase_auth: ['signup_verification', 'otp_resend', 'password_recovery', 'magic_link'],
      resend_transactional: [...TESTABLE_TEMPLATES],
    },
    env: {
      required: envStatus,
      missing: missingEnv,
    },
    notes:
      process.env.NODE_ENV === 'production'
        ? 'Production access requires x-debug-token matching INTERNAL_DEBUG_TOKEN.'
        : 'Development mode: endpoint is open for local debugging.',
  })
}

export async function POST(request: NextRequest) {
  if (!isDebugAllowed(request)) return forbiddenResponse()

  const requestId = createRequestId()

  let payload: Record<string, unknown>
  try {
    payload = await parseJsonObject(request)
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, error.message)
    }
    return validationFailed(requestId, 'Invalid debug payload.')
  }

  let to = ''
  let dryRun = false
  let template: TestableTemplate | 'all' = 'all'

  try {
    to = readString(payload, 'to', { required: true, toLowerCase: true })
    dryRun = readBoolean(payload, 'dryRun', { defaultValue: false })
    const rawTemplate = payload.template
    const parsedTemplate =
      typeof rawTemplate === 'string' && rawTemplate.trim().length > 0
        ? rawTemplate.trim()
        : 'all'
    if (parsedTemplate === 'all') {
      template = 'all'
    } else if (TESTABLE_TEMPLATES.includes(parsedTemplate as TestableTemplate)) {
      template = parsedTemplate as TestableTemplate
    } else {
      return validationFailed(
        requestId,
        `Invalid template. Use one of: all, ${TESTABLE_TEMPLATES.join(', ')}.`
      )
    }
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, error.message)
    }
    return validationFailed(requestId, 'Invalid debug payload.')
  }

  if (!validateEmail(to)) {
    return validationFailed(requestId, 'Please provide a valid email address.')
  }

  const testLink = `${process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'}/api/verification/university/confirm?token=debug-token`
  const templates = template === 'all' ? [...TESTABLE_TEMPLATES] : [template]
  const results: Array<{ template: TestableTemplate; ok: boolean; messageId: string | null; error?: string }> = []

  for (const currentTemplate of templates) {
    if (dryRun) {
      results.push({ template: currentTemplate, ok: true, messageId: null })
      continue
    }

    try {
      if (currentTemplate === 'university_verification') {
        const result = await sendUniversityVerificationEmail({
          requestId,
          to,
          link: testLink,
          domain: 'utoronto.ca',
          schoolName: 'University of Toronto',
        })
        results.push({ template: currentTemplate, ok: true, messageId: result.messageId })
      } else {
        const result = await sendAccessApplicationNotification({
          requestId,
          to,
          applicationId: requestId,
          email: 'sample@app.presocial.app',
          fullName: 'Sample Applicant',
          note: 'Debug route test payload.',
          submittedAt: new Date().toISOString(),
        })
        results.push({ template: currentTemplate, ok: true, messageId: result.messageId })
      }
    } catch (error) {
      results.push({
        template: currentTemplate,
        ok: false,
        messageId: null,
        error: error instanceof Error ? error.message : 'Failed to send test email.',
      })
    }
  }

  return successResponse(requestId, {
    ok: results.every((result) => result.ok),
    dryRun,
    results,
  })
}
