import { createClient } from '@/lib/supabase/server'
import { createRequestId, successResponse } from '@/lib/security/api'
import { unauthorized } from '@/lib/security/guards'

export const runtime = 'nodejs'

export async function GET() {
  const requestId = createRequestId()
  const supabase = await createClient()
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()

  if (error || !user) {
    return unauthorized(requestId)
  }

  return successResponse(requestId, {
    ok: true,
    twoFactor: {
      available: false,
      enabled: false,
      methods: [] as string[],
    },
  })
}

