import { createRequestId, successResponse } from '@/lib/security/api'
import { enforceRateLimit, enforceSameOrigin } from '@/lib/security/guards'

export const runtime = 'nodejs'

export async function POST(request: Request) {
  const requestId = createRequestId()
  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError
  const rateLimitResponse = enforceRateLimit({
    namespace: 'verify:university:deprecated',
    request,
    requestId,
    limit: 20,
    windowMs: 15 * 60 * 1000,
  })
  if (rateLimitResponse) return rateLimitResponse

  return successResponse(
    requestId,
    { ok: false, error: 'Deprecated. Use /api/verification/university/request.' },
    410
  )
}
