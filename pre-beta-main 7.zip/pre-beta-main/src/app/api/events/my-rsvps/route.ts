import { createClient } from '@/lib/supabase/server'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import { enforceRateLimit, serverFailure, unauthorized } from '@/lib/security/guards'

export const runtime = 'nodejs'

export async function GET(request: Request) {
  const requestId = createRequestId()
  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'events:my-rsvps',
    request,
    requestId,
    userId: user.id,
    limit: 60,
    windowMs: 15 * 60 * 1000,
  })
  if (rateLimitResponse) return rateLimitResponse

  // Fetch all RSVPs for this user
  const { data: rsvps, error: rsvpError } = await supabase
    .from('event_rsvps')
    .select('event_id, status')
    .eq('user_id', user.id)

  if (rsvpError) {
    logServerError('events.my-rsvps.rsvps', requestId, rsvpError, { userId: user.id })
    return serverFailure(requestId)
  }

  if (!rsvps || rsvps.length === 0) {
    return successResponse(requestId, { events: [] })
  }

  const eventIds = rsvps.map((r: { event_id: string; status: string }) => r.event_id)
  const statusMap: Record<string, string> = {}
  for (const rsvp of rsvps) {
    statusMap[(rsvp as { event_id: string; status: string }).event_id] = (rsvp as { event_id: string; status: string }).status
  }

  const { data: events, error: eventsError } = await supabase
    .from('events')
    .select('id, title, description, starts_at, ends_at, location_text, is_public, is_campus_only')
    .in('id', eventIds)
    .order('starts_at', { ascending: true })

  if (eventsError) {
    logServerError('events.my-rsvps.events', requestId, eventsError, { userId: user.id })
    return serverFailure(requestId)
  }

  // Fetch RSVP counts for each event
  const { data: allRsvps, error: countsError } = await supabase
    .from('event_rsvps')
    .select('event_id, status')
    .in('event_id', eventIds)

  if (countsError) {
    logServerError('events.my-rsvps.counts', requestId, countsError, { userId: user.id })
    return serverFailure(requestId)
  }

  const counts: Record<string, { going: number; interested: number; cant_go: number }> = {}
  for (const id of eventIds) {
    counts[id] = { going: 0, interested: 0, cant_go: 0 }
  }
  for (const rsvp of allRsvps ?? []) {
    const stat = counts[rsvp.event_id]
    if (!stat) continue
    if (rsvp.status === 'going') stat.going += 1
    if (rsvp.status === 'interested') stat.interested += 1
    if (rsvp.status === 'cant_go') stat.cant_go += 1
  }

  const result = (events ?? []).map((event: { id: string; [key: string]: unknown }) => ({
    ...event,
    my_rsvp: statusMap[event.id] ?? null,
    rsvp_counts: counts[event.id] ?? { going: 0, interested: 0, cant_go: 0 },
  }))

  return successResponse(requestId, { events: result })
}
