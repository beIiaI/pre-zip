import { createClient } from '@/lib/supabase/server'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import {
  enforceRateLimit,
  enforceSameOrigin,
  serverFailure,
  unauthorized,
  validationFailed,
} from '@/lib/security/guards'
import {
  parseJsonObject,
  readBoolean,
  readOptionalNumber,
  readString,
  ValidationError,
} from '@/lib/security/validation'

export const runtime = 'nodejs'

export async function GET(request: Request) {
  const requestId = createRequestId()
  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'events:list',
    request,
    requestId,
    userId: user.id,
    limit: 80,
    windowMs: 15 * 60 * 1000,
  })
  if (rateLimitResponse) return rateLimitResponse

  const { searchParams } = new URL(request.url)
  const scope = searchParams.get('scope') ?? 'public'

  const { data: profile, error: profileError } = await supabase
    .from('profiles')
    .select('university_verified')
    .eq('id', user.id)
    .maybeSingle()

  if (profileError) {
    logServerError('events.list.profile', requestId, profileError, { userId: user.id })
    return serverFailure(requestId)
  }

  const isVerified = profile?.university_verified === true

  if (scope === 'campus' && !isVerified) {
    return validationFailed(requestId, 'University verification is required for campus events.')
  }

  let query = supabase
    .from('events')
    .select('*')
    .order('starts_at', { ascending: true })
    .limit(50)

  if (scope === 'campus') {
    query = query.eq('is_campus_only', true)
  } else if (scope === 'public') {
    query = query.eq('is_public', true)
  }

  const { data: events, error } = await query

  if (error) {
    logServerError('events.list.events', requestId, error, { userId: user.id, scope })
    return serverFailure(requestId)
  }

  const ids = (events ?? []).map((event) => event.id)
  if (ids.length === 0) {
    return successResponse(requestId, { events: [] })
  }

  const { data: rsvps, error: rsvpError } = await supabase
    .from('event_rsvps')
    .select('event_id, status, user_id')
    .in('event_id', ids)

  if (rsvpError) {
    logServerError('events.list.rsvps', requestId, rsvpError, { userId: user.id })
    return serverFailure(requestId)
  }

  const counts: Record<string, { going: number; interested: number; cant_go: number; me?: string }> = {}
  for (const event of events ?? []) {
    counts[event.id] = { going: 0, interested: 0, cant_go: 0 }
  }
  for (const rsvp of rsvps ?? []) {
    const stat = counts[rsvp.event_id]
    if (!stat) continue
    if (rsvp.status === 'going') stat.going += 1
    if (rsvp.status === 'interested') stat.interested += 1
    if (rsvp.status === 'cant_go') stat.cant_go += 1
    if (rsvp.user_id === user.id) stat.me = rsvp.status
  }

  const response = (events ?? []).map((event) => ({
    ...event,
    rsvp_counts: counts[event.id] ?? { going: 0, interested: 0, cant_go: 0 },
    my_rsvp: counts[event.id]?.me ?? null,
  }))

  return successResponse(requestId, { events: response })
}

export async function POST(request: Request) {
  const requestId = createRequestId()
  const originError = enforceSameOrigin(request, requestId)
  if (originError) return originError

  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'events:create',
    request,
    requestId,
    userId: user.id,
    limit: 12,
    windowMs: 15 * 60 * 1000,
    baseBlockMs: 90_000,
  })
  if (rateLimitResponse) return rateLimitResponse

  let payload: Record<string, unknown>
  try {
    payload = await parseJsonObject(request)
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid event payload.')
    }
    return validationFailed(requestId, 'Invalid event payload.')
  }

  let title = ''
  let startsAt = ''
  let description = ''
  let locationText = ''
  let endsAt = ''
  let circleId = ''
  let imageUrl = ''
  let isCampusOnly = false
  let isPublic = true
  let maxAttendees: number | null = null
  try {
    title = readString(payload, 'title', { required: true, max: 120 })
    startsAt = readString(payload, 'starts_at', { required: true })
    description = readString(payload, 'description', { max: 2000 })
    locationText = readString(payload, 'location_text', { max: 200 })
    endsAt = readString(payload, 'ends_at')
    circleId = readString(payload, 'circle_id')
    imageUrl = readString(payload, 'image_url')
    isCampusOnly = readBoolean(payload, 'is_campus_only', { defaultValue: false })
    isPublic = readBoolean(payload, 'is_public', { defaultValue: true })
    maxAttendees = readOptionalNumber(payload, 'max_attendees', {
      integer: true,
      min: 1,
      max: 5000,
    })
  } catch (error) {
    if (error instanceof ValidationError) {
      return validationFailed(requestId, 'Invalid event payload.')
    }
    return validationFailed(requestId, 'Invalid event payload.')
  }

  const parsedStartsAt = Date.parse(startsAt)
  if (!Number.isFinite(parsedStartsAt)) {
    return validationFailed(requestId, 'Invalid start time.')
  }

  if (endsAt) {
    const parsedEndsAt = Date.parse(endsAt)
    if (!Number.isFinite(parsedEndsAt) || parsedEndsAt < parsedStartsAt) {
      return validationFailed(requestId, 'End time must be after start time.')
    }
  }

  const { data: profile, error: profileError } = await supabase
    .from('profiles')
    .select('university_verified')
    .eq('id', user.id)
    .maybeSingle()

  if (profileError) {
    logServerError('events.create.profile', requestId, profileError, { userId: user.id })
    return serverFailure(requestId)
  }
  const isVerified = profile?.university_verified === true

  if (isCampusOnly && !isVerified) {
    return validationFailed(requestId, 'University verification is required for campus events.')
  }

  const resolvedPublic = isCampusOnly ? false : isPublic

  const { data, error } = await supabase
    .from('events')
    .insert({
      host_id: user.id,
      title: title.trim(),
      description: description || null,
      starts_at: new Date(parsedStartsAt).toISOString(),
      ends_at: endsAt ? new Date(endsAt).toISOString() : null,
      location_text: locationText || null,
      is_public: resolvedPublic,
      is_campus_only: isCampusOnly,
      circle_id: circleId || null,
      image_url: imageUrl || null,
      max_attendees: maxAttendees,
    })
    .select()
    .single()

  if (error) {
    logServerError('events.create.insert', requestId, error, { userId: user.id })
    return serverFailure(requestId)
  }

  return successResponse(requestId, { event: data }, 201)
}

