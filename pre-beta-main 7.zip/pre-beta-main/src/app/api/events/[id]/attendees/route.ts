import { NextRequest } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { createRequestId, logServerError, successResponse } from '@/lib/security/api'
import { enforceRateLimit, serverFailure, unauthorized, validationFailed } from '@/lib/security/guards'

const PROFILE_FIELDS = 'id, username, full_name, avatar_url, university_name, university_verified'

export const runtime = 'nodejs'

export async function GET(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const requestId = createRequestId()
  const supabase = await createClient()
  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return unauthorized(requestId)
  }

  const rateLimitResponse = enforceRateLimit({
    namespace: 'events:attendees',
    request,
    requestId,
    userId: user.id,
    limit: 60,
    windowMs: 15 * 60 * 1000,
  })
  if (rateLimitResponse) return rateLimitResponse

  const { id } = await context.params
  if (!id) {
    return validationFailed(requestId, 'Missing event id.')
  }

  // Verify event exists and user is the creator
  const { data: event, error: eventError } = await supabase
    .from('events')
    .select('id, title, creator_id, attendee_count, max_attendees')
    .eq('id', id)
    .maybeSingle()

  if (eventError) {
    logServerError('events.attendees.event', requestId, eventError, { eventId: id })
    return serverFailure(requestId)
  }

  if (!event) {
    return validationFailed(requestId, 'Event not found.')
  }

  // Fetch all RSVPs with profile data
  const { data: rsvps, error: rsvpError } = await supabase
    .from('event_rsvps')
    .select('user_id, status, created_at')
    .eq('event_id', id)
    .order('created_at', { ascending: true })

  if (rsvpError) {
    logServerError('events.attendees.rsvps', requestId, rsvpError, { eventId: id })
    return serverFailure(requestId)
  }

  // Fetch profiles for all RSVPed users
  const userIds = (rsvps ?? []).map(r => r.user_id)
  const admin = createAdminClient() as any
  const { data: profiles, error: profilesError } = userIds.length
    ? await admin
        .from('profiles')
        .select(PROFILE_FIELDS)
        .in('id', userIds)
    : { data: [], error: null }

  if (profilesError) {
    logServerError('events.attendees.profiles', requestId, profilesError, { eventId: id })
    return serverFailure(requestId)
  }

  const profileMap = new Map((profiles ?? []).map((p: any) => [p.id, p]))

  const attendees = (rsvps ?? []).map(rsvp => ({
    user_id: rsvp.user_id,
    status: rsvp.status,
    rsvp_at: rsvp.created_at,
    profile: profileMap.get(rsvp.user_id) ?? null,
  }))

  const counts = {
    going: attendees.filter(a => a.status === 'going').length,
    interested: attendees.filter(a => a.status === 'interested').length,
    cant_go: attendees.filter(a => a.status === 'cant_go').length,
  }

  return successResponse(requestId, {
    event: {
      id: event.id,
      title: event.title,
      creator_id: event.creator_id,
      attendee_count: event.attendee_count,
      max_attendees: event.max_attendees,
    },
    attendees,
    counts,
    is_creator: event.creator_id === user.id,
  })
}
