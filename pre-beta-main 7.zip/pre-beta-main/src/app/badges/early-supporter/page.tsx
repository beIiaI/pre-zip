'use client'

import { Suspense, useEffect, useMemo, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { ArrowLeft } from 'lucide-react'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { formatEarlySupporterNumber, formatFounderNumber } from '@/lib/utils'

type TargetProfile = {
  id: string
  early_supporter_number: number | null
  founder_number: number | null
  is_founder?: boolean | null
}

function EarlySupporterContent() {
  const { user, profile, loading, initialized, profileLoaded } = useAuth()
  const router = useRouter()
  const searchParams = useSearchParams()
  const [targetProfile, setTargetProfile] = useState<TargetProfile | null>(null)
  const [targetLoaded, setTargetLoaded] = useState(false)

  const targetId = useMemo(() => searchParams.get('uid'), [searchParams])

  useEffect(() => {
    if (!initialized) return
    if (!user) {
      router.replace('/')
      return
    }
    if (profileLoaded && !profile) {
      router.replace('/onboarding')
      return
    }
    const selfHasEarlySupporter =
      profile?.early_supporter_number !== null && profile?.early_supporter_number !== undefined
    const selfIsFounder = profile?.is_founder === true
    if (profileLoaded && profile && !targetId && !selfIsFounder && !selfHasEarlySupporter) {
      router.replace('/badges')
    }
  }, [initialized, user, profile, profileLoaded, router, targetId])

  useEffect(() => {
    if (!initialized || !user || loading) return
    if (!targetId || targetId === user.id) {
      if (profileLoaded && profile) {
        setTargetProfile({
          id: profile.id,
          early_supporter_number: profile.early_supporter_number,
          founder_number: profile.founder_number,
          is_founder: profile.is_founder,
        })
        setTargetLoaded(true)
      }
      return
    }

    let active = true
    setTargetLoaded(false)
    fetch(`/api/users/preview?id=${encodeURIComponent(targetId)}`)
      .then((res) => res.json())
      .then((data) => {
        if (!active) return
        const next = data?.profile
        if (next) {
          setTargetProfile({
            id: next.id,
            early_supporter_number: next.early_supporter_number,
            founder_number: next.founder_number,
            is_founder: next.is_founder,
          })
        } else {
          setTargetProfile(null)
        }
      })
      .finally(() => {
        if (active) setTargetLoaded(true)
      })
    return () => {
      active = false
    }
  }, [initialized, user, loading, targetId, profileLoaded, profile])

  useEffect(() => {
    if (!targetLoaded) return
    if (!targetProfile) {
      router.replace('/badges')
      return
    }
    const hasFounderBadge = targetProfile.is_founder === true
    const hasEarlySupporter =
      targetProfile.early_supporter_number !== null && targetProfile.early_supporter_number !== undefined
    if (!hasFounderBadge && !hasEarlySupporter) {
      router.replace('/badges')
    }
  }, [targetLoaded, targetProfile, router])

  if (!initialized || loading || !profileLoaded || !targetLoaded || !targetProfile) {
    return <LoadingScreen />
  }

  const isFounder = targetProfile.is_founder === true
  const supporterNumber = targetProfile.early_supporter_number
  const founderNumber = targetProfile.founder_number
  const viewerId = user?.id
  const isSelf = !targetId || (viewerId ? targetId === viewerId : false)
  if (!isFounder && (supporterNumber === null || supporterNumber === undefined)) {
    return <LoadingScreen />
  }
  const numberDisplay = isFounder
    ? founderNumber !== null && founderNumber !== undefined
      ? formatFounderNumber(founderNumber)
      : 'FOUNDER'
    : formatEarlySupporterNumber(supporterNumber!)
  const numberLabel = isFounder ? 'FOUNDER NUMBER' : 'USER NUMBER'
  const numberRangeLabel = isFounder
    ? founderNumber !== null && founderNumber !== undefined
      ? 'OF 999'
      : 'NUMBER OPTIONAL'
    : 'OF 250'

  return (
    <div className="min-h-screen bg-surface-primary safe-top safe-bottom">
      <div className="px-6 pt-14 pb-4 border-b border-[#1A1A1A]/10 dark:border-white/10">
        <div className="flex items-center gap-4">
          <button
            onClick={() => router.back()}
            className="w-10 h-10 rounded-full bg-[#F5F5F5] dark:bg-[#2A2A2A] flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-[#1A1A1A] dark:text-white" strokeWidth={1.5} />
          </button>
          <h2 className="text-[#1A1A1A] dark:text-white">{isFounder ? 'Founder' : 'Early Supporter'}</h2>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-12">
        <div className="max-w-md mx-auto text-center">
          <div className="mb-8">
            <div className="inline-flex flex-col items-center justify-center px-8 py-10 rounded-2xl border-2 border-[#1A1A1A]/20 dark:border-white/20 bg-gradient-to-br from-[#FAFAFA] via-white to-[#F5F5F5] dark:from-[#1A1A1A] dark:via-[#141414] dark:to-[#1A1A1A] shadow-lg mb-6">
              <p className="text-[9px] tracking-[0.2em] font-medium text-[#999999] dark:text-[#666666] mb-3">
                {numberLabel}
              </p>
              <div className="font-mono text-5xl text-[#1A1A1A] dark:text-white mb-3 tracking-tight">
                {numberDisplay}
              </div>
              <div className="w-16 h-[1px] bg-[#1A1A1A]/20 dark:bg-white/20 mb-3" />
              <p className="text-[9px] tracking-[0.2em] font-medium text-[#999999] dark:text-[#666666]">
                {numberRangeLabel}
              </p>
            </div>
          </div>

          <h3 className="mb-3 text-[#1A1A1A] dark:text-white">{isFounder ? 'Founder' : 'Early Supporter'}</h3>

          <p className="text-[#666666] dark:text-[#AAAAAA] leading-relaxed mb-8">
            {isFounder
              ? isSelf
                ? "You're the founder of pre. This founder badge and your member number are permanent and will never change."
                : "This member is the founder of pre. This founder badge and their member number are permanent and will never change."
              : isSelf
                ? "You're one of the first 250 people to join pre. This exclusive badge and your member number are permanent and will never change."
                : "This member is one of the first 250 people to join pre. This exclusive badge and their member number are permanent and will never change."}
          </p>

          <div className="p-6 rounded-xl border border-[#1A1A1A]/10 dark:border-white/10 bg-white dark:bg-[#1A1A1A] mb-8">
            <div className="flex items-center justify-center gap-2 mb-3">
              <span className="text-lg">✦</span>
              <h4 className="text-sm text-[#1A1A1A] dark:text-white">Founding Member</h4>
            </div>
            <p className="text-sm text-[#666666] dark:text-[#AAAAAA] leading-relaxed">
              {isFounder
                ? isSelf
                  ? "As founder, you created the foundation of pre. This badge represents your place at the start of everything."
                  : "As founder, they created the foundation of pre. This badge represents their place at the start of everything."
                : isSelf
                  ? "As an early supporter, you helped shape the future of pre. This badge represents your place in our founding community."
                  : "As an early supporter, they helped shape the future of pre. This badge represents their place in our founding community."}
            </p>
          </div>

          {isFounder && supporterNumber !== null && supporterNumber !== undefined && (
            <p className="text-xs text-[#999999] dark:text-[#666666] mb-6">
              Also holds Early Supporter {formatEarlySupporterNumber(supporterNumber)}.
            </p>
          )}

          <p className="text-xs text-[#999999] dark:text-[#666666] italic">
            {isFounder
              ? 'Founder badge — unique and permanent'
              : `Only ${supporterNumber} of 250 badges have been claimed`}
          </p>
        </div>
      </div>
    </div>
  )
}

export default function EarlySupporterPage() {
  return (
    <Suspense fallback={<LoadingScreen />}>
      <EarlySupporterContent />
    </Suspense>
  )
}
