'use client'

import { useEffect, useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { ArrowLeft, Award, Lock } from 'lucide-react'
import { EarlySupporterBadge } from '@/components/ui/early-supporter-badge'
import { FounderBadge } from '@/components/ui/founder-badge'

// Badge definitions
const BADGES = [
  {
    id: 'early_supporter',
    name: 'Early Supporter',
    description: 'One of the first 250 members to join pre',
    icon: '⭐',
    category: 'special',
    earnable: false,
  },
  {
    id: 'initiator',
    name: 'Initiator',
    description: 'Hosted your first public event',
    icon: '🎯',
    category: 'events',
    earnable: true,
  },
  {
    id: 'social_butterfly',
    name: 'Social Butterfly',
    description: 'Attended 5 events in one month',
    icon: '🦋',
    category: 'events',
    earnable: true,
  },
  {
    id: 'community_pillar',
    name: 'Community Pillar',
    description: 'Hosted 10+ successful events with high attendance',
    icon: '🏛️',
    category: 'events',
    earnable: true,
  },
  {
    id: 'ambassador',
    name: 'Ambassador',
    description: 'Referred 5 friends who completed onboarding',
    icon: '🌟',
    category: 'referrals',
    earnable: true,
  },
  {
    id: 'connector',
    name: 'Connector',
    description: 'Referred 10 friends who completed onboarding',
    icon: '🔗',
    category: 'referrals',
    earnable: true,
  },
  {
    id: 'founder',
    name: 'Founder',
    description: 'Founding member of pre',
    icon: '👑',
    category: 'special',
    earnable: false,
  },
]

export default function BadgesPage() {
  const { user, profile, loading, initialized } = useAuth()
  const router = useRouter()
  const [earnedIds, setEarnedIds] = useState<string[]>([])
  const [loadingBadges, setLoadingBadges] = useState(true)
  const [redirecting, setRedirecting] = useState(false)

  const hasEarlySupporterNumber =
    profile?.early_supporter_number !== null && profile?.early_supporter_number !== undefined
  const isFounder = profile?.is_founder === true
  const earnedBadges = useMemo(() => {
    const ids = new Set<string>(earnedIds)
    if (isFounder) {
      ids.add('founder')
    }
    if (hasEarlySupporterNumber) {
      ids.add('early_supporter')
    }
    return Array.from(ids)
  }, [earnedIds, hasEarlySupporterNumber, isFounder])

  useEffect(() => {
    if (!initialized || loading || !user) return
    let active = true
    setLoadingBadges(true)
    fetch('/api/badges')
      .then((res) => res.json())
      .then((data) => {
        if (!active) return
        const mapping: Record<string, string> = {
          Initiator: 'initiator',
          'Social Butterfly': 'social_butterfly',
          'Community Pillar': 'community_pillar',
          Ambassador: 'ambassador',
          Connector: 'connector',
          'Early Supporter': 'early_supporter',
          Founder: 'founder',
          "Founders' pre": 'founder',
        }
        const mapped = (data.badges ?? [])
          .map((name: string) => mapping[name])
          .filter(Boolean)
        setEarnedIds(mapped)
      })
      .finally(() => {
        if (active) setLoadingBadges(false)
      })
    return () => {
      active = false
    }
  }, [initialized, loading, user])

  useEffect(() => {
    if (!initialized || loading) return
    if (!user) {
      setRedirecting(true)
      router.replace('/')
    }
  }, [initialized, loading, user, router])

  if (!initialized || loading || redirecting) {
    return <LoadingScreen />
  }

  if (!user) {
    return <LoadingScreen />
  }

  if (loadingBadges) {
    return <LoadingScreen />
  }

  return (
    <div className="min-h-screen bg-surface-primary safe-top safe-bottom">
      {/* Header */}
      <header className="px-4 py-4 flex items-center justify-between border-b border-border-secondary">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">Badges</h1>
        <div className="w-9" />
      </header>

      <main className="px-4 py-6">
        <div className="max-w-md mx-auto space-y-6">
          {/* Points Summary */}
          <Card className="bg-gradient-to-br from-[#C7E5FF] to-[#A0D3FF] text-[#1A1A1A] border border-[#1A1A1A]/10 dark:from-[#1A4D7A] dark:to-[#1B3B5A] dark:text-[#C7E5FF] dark:border-white/10">
            <CardContent className="pt-4 flex items-center justify-center gap-4">
              <Award className="h-8 w-8" />
              <div>
                <p className="text-display">{profile?.total_points || 0}</p>
                <p className="text-callout opacity-80">Total Points</p>
              </div>
            </CardContent>
          </Card>

          {/* Earned Badges */}
          {earnedBadges.length > 0 && (
            <section className="space-y-4">
              <h2 className="text-headline text-content-primary">Earned</h2>
              <div className="grid gap-4">
                {BADGES.filter(b => earnedBadges.includes(b.id)).map((badge) => {
                  if (badge.id === 'founder' && isFounder) {
                    return (
                      <Link key={badge.id} href="/badges/early-supporter" data-testid="founder-badge-card">
                        <Card className="bg-gradient-to-br from-[#FADBD0] via-[#EEC3B3] to-[#DDA28F] text-[#3A1914] border border-[#5A2A22]/20 dark:from-[#3E1D1A] dark:via-[#4A2521] dark:to-[#5A2A24] dark:text-[#FFD9CC] dark:border-white/10">
                          <CardHeader>
                            <div className="flex items-center gap-4">
                              <div className="h-12 w-12 rounded-full bg-white/65 flex items-center justify-center text-2xl border border-white/60 dark:bg-white/10 dark:border-white/20">
                                {badge.icon}
                              </div>
                              <div className="flex-1">
                                <CardTitle>{badge.name}</CardTitle>
                                <CardDescription className="text-[#3A1914]/70 dark:text-[#FFD9CC]/70">
                                  {badge.description}
                                </CardDescription>
                              </div>
                              <FounderBadge
                                number={profile?.founder_number}
                                size="sm"
                              />
                            </div>
                          </CardHeader>
                        </Card>
                      </Link>
                    )
                  }

                  if (badge.id === 'early_supporter' && hasEarlySupporterNumber) {
                    return (
                      <Link key={badge.id} href="/badges/early-supporter" data-testid="early-supporter-badge-card">
                        <Card className="bg-gradient-to-br from-[#C7E5FF] to-[#A0D3FF] text-[#1A1A1A] border border-[#1A1A1A]/10 dark:from-[#1A4D7A] dark:to-[#1B3B5A] dark:text-[#C7E5FF] dark:border-white/10">
                          <CardHeader>
                            <div className="flex items-center gap-4">
                              <div className="h-12 w-12 rounded-full bg-white/70 flex items-center justify-center text-2xl border border-white/60 dark:bg-white/10 dark:border-white/20">
                                {badge.icon}
                              </div>
                              <div className="flex-1">
                                <CardTitle>{badge.name}</CardTitle>
                                <CardDescription className="text-[#1A1A1A]/70 dark:text-[#C7E5FF]/70">
                                  {badge.description}
                                </CardDescription>
                              </div>
                              <EarlySupporterBadge
                                number={profile.early_supporter_number!}
                                size="sm"
                              />
                            </div>
                          </CardHeader>
                        </Card>
                      </Link>
                    )
                  }

                  return (
                    <Card key={badge.id} className="bg-surface-secondary">
                      <CardHeader>
                        <div className="flex items-center gap-4">
                          <div className="h-12 w-12 rounded-full bg-surface-primary flex items-center justify-center text-2xl border border-border-secondary">
                            {badge.icon}
                          </div>
                          <div>
                            <CardTitle>{badge.name}</CardTitle>
                            <CardDescription>{badge.description}</CardDescription>
                          </div>
                        </div>
                      </CardHeader>
                    </Card>
                  )
                })}
              </div>
            </section>
          )}

          {/* Available Badges */}
          <section className="space-y-4">
            <h2 className="text-headline text-content-primary">Available</h2>
            <div className="grid gap-4">
              {BADGES.filter(b => !earnedBadges.includes(b.id) && b.earnable).map((badge) => (
                <Card key={badge.id} className="opacity-60">
                  <CardHeader>
                    <div className="flex items-center gap-4">
                      <div className="h-12 w-12 rounded-full bg-surface-tertiary flex items-center justify-center text-2xl border border-border-secondary">
                        {badge.icon}
                      </div>
                      <div className="flex-1">
                        <CardTitle>{badge.name}</CardTitle>
                        <CardDescription>{badge.description}</CardDescription>
                      </div>
                      <Lock className="h-5 w-5 text-content-tertiary" />
                    </div>
                  </CardHeader>
                </Card>
              ))}
            </div>
          </section>

          {/* Special Badges */}
          <section className="space-y-4">
            <h2 className="text-headline text-content-primary">Special</h2>
            <div className="grid gap-4">
              {BADGES.filter(b => !earnedBadges.includes(b.id) && !b.earnable).map((badge) => (
                <Card key={badge.id} className="opacity-40">
                  <CardHeader>
                    <div className="flex items-center gap-4">
                      <div className="h-12 w-12 rounded-full bg-surface-tertiary flex items-center justify-center text-2xl border border-border-secondary">
                        {badge.icon}
                      </div>
                      <div className="flex-1">
                        <CardTitle>{badge.name}</CardTitle>
                        <CardDescription>{badge.description}</CardDescription>
                      </div>
                      <Lock className="h-5 w-5 text-content-tertiary" />
                    </div>
                  </CardHeader>
                </Card>
              ))}
            </div>
          </section>
        </div>
      </main>
    </div>
  )
}
