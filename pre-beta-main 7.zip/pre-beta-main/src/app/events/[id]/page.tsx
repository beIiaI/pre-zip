'use client'

import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Button } from '@/components/ui/button'
import { Avatar } from '@/components/ui/avatar'
import { BentoCell, BentoDivider, BentoFrame, BentoGrid, BentoLabel } from '@/components/ui/bento'
import { VisualSurface } from '@/components/ui/visual-surface'
import { RsvpSheet } from '@/components/events/rsvp-sheet'
import {
  ArrowLeft,
  Calendar,
  MapPin,
  Users,
  MessageCircle,
  CheckCircle2,
  Sparkles,
  XCircle,
  Share2,
} from 'lucide-react'

type EventDetail = {
  id: string
  title: string
  description: string | null
  starts_at: string
  ends_at: string | null
  location_text: string | null
  max_attendees: number | null
  is_campus_only?: boolean
}

type Attendee = {
  id: string
  username: string | null
  full_name: string | null
  avatar_url: string | null
}

type RsvpCounts = {
  going: number
  interested: number
  cant_go: number
}

type RsvpStatus = 'going' | 'interested' | 'cant_go'

const formatDateTime = (value: string) => {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return date.toLocaleString([], {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  })
}

const rsvpOptions: { status: RsvpStatus; label: string; icon: React.ElementType; tint: string }[] = [
  { status: 'going', label: 'Going', icon: CheckCircle2, tint: 'bento-tint-sage' },
  { status: 'interested', label: 'Interested', icon: Sparkles, tint: 'bento-tint-mist' },
  { status: 'cant_go', label: "Can't go", icon: XCircle, tint: 'bento-tint-rose' },
]

export default function EventDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { user, loading, initialized } = useAuth()
  const [event, setEvent] = useState<EventDetail | null>(null)
  const [attendees, setAttendees] = useState<Attendee[]>([])
  const [counts, setCounts] = useState<RsvpCounts>({ going: 0, interested: 0, cant_go: 0 })
  const [myRsvp, setMyRsvp] = useState<RsvpStatus | null>(null)
  const [loadingEvent, setLoadingEvent] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [rsvpError, setRsvpError] = useState<string | null>(null)
  const [redirecting, setRedirecting] = useState(false)
  const [sheetStatus, setSheetStatus] = useState<RsvpStatus | null>(null)

  const eventId = typeof params.id === 'string' ? params.id : params.id?.[0]

  useEffect(() => {
    if (!initialized || loading) return
    if (!user) {
      setRedirecting(true)
      router.replace('/')
    }
  }, [initialized, loading, user, router])

  useEffect(() => {
    if (!user || !eventId) return
    let active = true
    setLoadingEvent(true)
    setError(null)
    fetch(`/api/events/${encodeURIComponent(eventId)}`)
      .then((res) => {
        if (!res.ok) throw new Error('Event not found')
        return res.json()
      })
      .then((data) => {
        if (!active) return
        setEvent(data.event ?? null)
        setCounts(data.rsvp_counts ?? { going: 0, interested: 0, cant_go: 0 })
        setMyRsvp(data.my_rsvp ?? null)
        setAttendees(data.attendees ?? [])
      })
      .catch((err) => {
        if (!active) return
        setError(err instanceof Error ? err.message : 'Event not found')
      })
      .finally(() => {
        if (active) setLoadingEvent(false)
      })
    return () => {
      active = false
    }
  }, [user, eventId])

  if (!initialized || loading || redirecting) return <LoadingScreen />
  if (!user) return <LoadingScreen />
  if (loadingEvent) return <LoadingScreen />

  if (error || !event) {
    return (
      <div className="min-h-screen bg-surface-primary safe-top safe-bottom flex flex-col items-center justify-center px-6 text-center">
        <p className="text-body text-content-secondary mb-4">{error || 'Event not found'}</p>
        <Button variant="secondary" onClick={() => router.back()}>
          Go back
        </Button>
      </div>
    )
  }

  const handleRsvp = async (status: RsvpStatus) => {
    setRsvpError(null)
    const previous = myRsvp

    // Optimistic update
    setMyRsvp(status)
    setCounts((prev) => {
      const next = { ...prev }
      if (previous === 'going') next.going = Math.max(0, next.going - 1)
      if (previous === 'interested') next.interested = Math.max(0, next.interested - 1)
      if (previous === 'cant_go') next.cant_go = Math.max(0, next.cant_go - 1)
      if (status === 'going') next.going += 1
      if (status === 'interested') next.interested += 1
      if (status === 'cant_go') next.cant_go += 1
      return next
    })

    // Show confirmation sheet
    setSheetStatus(status)

    try {
      const response = await fetch('/api/events/rsvp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ event_id: eventId, status }),
      })
      const data = await response.json().catch(() => null)
      if (!response.ok) throw new Error(data?.error || 'Failed to RSVP')
      if (data?.counts) setCounts(data.counts)
    } catch (err) {
      setMyRsvp(previous)
      setSheetStatus(null)
      setRsvpError(err instanceof Error ? err.message : 'Unable to update RSVP. Please try again.')
      // Revert count
      setCounts((prev) => {
        const next = { ...prev }
        if (status === 'going') next.going = Math.max(0, next.going - 1)
        if (status === 'interested') next.interested = Math.max(0, next.interested - 1)
        if (status === 'cant_go') next.cant_go = Math.max(0, next.cant_go - 1)
        if (previous === 'going') next.going += 1
        if (previous === 'interested') next.interested += 1
        if (previous === 'cant_go') next.cant_go += 1
        return next
      })
    }
  }

  const isFull =
    event.max_attendees !== null &&
    event.max_attendees !== undefined &&
    counts.going >= event.max_attendees &&
    myRsvp !== 'going'

  const handleShare = async () => {
    const url = `${window.location.origin}/events/${event.id}`
    if (navigator.share) {
      await navigator.share({ title: event.title, url }).catch(() => null)
    } else {
      await navigator.clipboard.writeText(url).catch(() => null)
    }
  }

  return (
    <div className="relative min-h-screen bg-surface-primary safe-top safe-bottom animate-route-enter">
      {/* Ambient orbs */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <span className="absolute left-[-12%] top-[14%] h-44 w-44 rounded-full bg-content-primary/5 blur-3xl animate-ambient-float-soft" />
        <span className="absolute right-[-14%] bottom-[20%] h-48 w-48 rounded-full bg-content-primary/5 blur-3xl animate-ambient-float-soft-reverse" />
      </div>

      {/* Header */}
      <header className="relative z-10 px-4 py-4 flex items-center justify-between border-b border-border-secondary animate-section-reveal">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
          aria-label="Go back"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">Event</h1>
        <button
          onClick={handleShare}
          className="p-2 -mr-2 rounded-full hover:bg-accent-muted transition-colors"
          aria-label="Share event"
        >
          <Share2 className="h-4.5 w-4.5 text-content-secondary" />
        </button>
      </header>

      <main className="relative z-10 px-4 py-6">
        <div className="max-w-md mx-auto">
          <BentoFrame>
            <BentoGrid>
              {/* Hero cell with visual + title */}
              <BentoCell className="bento-tint-peach hierarchy-hero border-t-0 border-l-0 space-y-3 animate-section-reveal">
                <VisualSurface
                  seed={`${event.id}-${event.title}`}
                  variant="door"
                  title={event.title}
                  className="mx-auto w-[min(72vw,14rem)]"
                />
                <div className="flex items-center justify-center gap-2 flex-wrap">
                  {event.is_campus_only && <BentoLabel>Campus-only</BentoLabel>}
                  {myRsvp && (
                    <span className={`bento-label ${
                      myRsvp === 'going' ? 'bg-[color:var(--tint-sage)]' :
                      myRsvp === 'interested' ? 'bg-[color:var(--tint-mist)]' :
                      'bg-[color:var(--tint-rose)]'
                    }`}>
                      {myRsvp === 'going' ? 'Going' : myRsvp === 'interested' ? 'Interested' : "Can't go"}
                    </span>
                  )}
                </div>
                <BentoDivider />
                <h2 className="text-headline text-content-primary font-semibold text-center leading-snug">{event.title}</h2>
                <div className="flex items-center gap-2 text-callout text-content-secondary">
                  <Calendar className="h-4 w-4 flex-shrink-0" />
                  <span>{formatDateTime(event.starts_at)}</span>
                </div>
                {event.ends_at && (
                  <div className="flex items-center gap-2 text-caption text-content-tertiary ml-6">
                    <span>Ends {formatDateTime(event.ends_at)}</span>
                  </div>
                )}
                {event.location_text && (
                  <a
                    href={`https://maps.google.com/?q=${encodeURIComponent(event.location_text)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-callout text-content-secondary hover:text-content-primary transition-colors"
                  >
                    <MapPin className="h-4 w-4 flex-shrink-0" />
                    <span className="underline decoration-dotted underline-offset-2">{event.location_text}</span>
                  </a>
                )}
              </BentoCell>

              {/* Description */}
              {event.description && (
                <BentoCell className="bento-tint-mist animate-section-reveal" style={{ animationDelay: '70ms' }}>
                  <p className="text-body text-content-secondary type-align-body whitespace-pre-line">{event.description}</p>
                </BentoCell>
              )}

              {/* RSVP section */}
              <BentoCell className="bento-tint-lilac space-y-4 animate-section-reveal" style={{ animationDelay: '110ms' }}>
                {/* Counts row */}
                <div className="grid grid-cols-3 gap-2 text-center">
                  {[
                    { label: 'Going', count: counts.going, active: myRsvp === 'going', tint: 'var(--tint-sage)' },
                    { label: 'Interested', count: counts.interested, active: myRsvp === 'interested', tint: 'var(--tint-mist)' },
                    { label: "Can't go", count: counts.cant_go, active: myRsvp === 'cant_go', tint: 'var(--tint-rose)' },
                  ].map((stat) => (
                    <div
                      key={stat.label}
                      className={`rounded-[14px] py-2.5 px-2 transition-all ${stat.active ? 'bg-surface-primary/60 border border-border-secondary' : ''}`}
                      style={stat.active ? { background: `color-mix(in oklab, ${stat.tint} 28%, var(--surface-primary))` } : {}}
                    >
                      <p className="text-title font-semibold text-content-primary">{stat.count}</p>
                      <p className="text-caption text-content-tertiary">{stat.label}</p>
                    </div>
                  ))}
                </div>

                <BentoDivider />

                {event.max_attendees && (
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-caption text-content-secondary">
                      <span>Capacity</span>
                      <span>{counts.going} / {event.max_attendees}</span>
                    </div>
                    {/* Capacity bar */}
                    <div className="h-1.5 rounded-full bg-surface-tertiary overflow-hidden">
                      <div
                        className="h-full rounded-full bg-accent-primary transition-all duration-500"
                        style={{ width: `${Math.min(100, (counts.going / event.max_attendees) * 100)}%` }}
                      />
                    </div>
                  </div>
                )}

                {/* Error */}
                {rsvpError && (
                  <p className="text-callout text-error">{rsvpError}</p>
                )}

                {/* RSVP buttons */}
                <div className="grid grid-cols-3 gap-2">
                  {rsvpOptions.map(({ status, label, icon: Icon, tint }) => {
                    const isActive = myRsvp === status
                    const disabled = status === 'going' && isFull
                    return (
                      <button
                        key={status}
                        onClick={() => !disabled && handleRsvp(status)}
                        disabled={disabled}
                        className={`group flex flex-col items-center gap-1.5 rounded-[16px] border py-3 px-2 transition-all disabled:opacity-40 disabled:pointer-events-none ${
                          isActive
                            ? `${tint} border-border-secondary shadow-sm scale-[1.03]`
                            : 'bg-surface-primary/40 border-border-secondary hover:bg-surface-secondary/60 hover:-translate-y-0.5'
                        }`}
                      >
                        <Icon
                          className={`h-4.5 w-4.5 transition-transform ${isActive ? 'scale-110' : 'group-hover:scale-105'} text-content-primary`}
                        />
                        <span className="text-caption text-content-primary font-medium">
                          {disabled ? 'Full' : label}
                        </span>
                      </button>
                    )
                  })}
                </div>
              </BentoCell>

              {/* Attendees */}
              <BentoCell className="bento-tint-sage space-y-3 animate-section-reveal" style={{ animationDelay: '150ms' }}>
                <div className="flex items-center gap-2 text-callout text-content-secondary">
                  <Users className="h-4 w-4" />
                  <span>Going</span>
                  {counts.going > 0 && (
                    <button
                      onClick={() => router.push(`/events/${event.id}/attendees`)}
                      className="ml-auto text-caption text-content-tertiary hover:text-content-secondary transition-colors"
                    >
                      {counts.going} people &rsaquo;
                    </button>
                  )}
                </div>
                <BentoDivider />
                {attendees.length === 0 ? (
                  <p className="text-body text-content-tertiary">Be the first to RSVP.</p>
                ) : (
                  <button
                    onClick={() => router.push(`/events/${event.id}/attendees`)}
                    className="flex items-center gap-1 w-full hover:opacity-80 transition-opacity"
                  >
                    {attendees.map((person, index) => (
                      <div key={person.id} className={index === 0 ? '' : '-ml-2.5'} style={{ zIndex: attendees.length - index }}>
                        <div title={person.full_name ?? person.username ?? ''}>
                          <Avatar src={person.avatar_url} size="sm" />
                        </div>
                      </div>
                    ))}
                    {counts.going > attendees.length && (
                      <span className="ml-3 text-caption text-content-secondary">
                        +{counts.going - attendees.length} more
                      </span>
                    )}
                  </button>
                )}
              </BentoCell>

              {/* Event chat */}
              <BentoCell className="bento-tint-honey animate-section-reveal" style={{ animationDelay: '190ms' }}>
                <Button
                  variant="secondary"
                  className="w-full"
                  onClick={() => router.push(`/events/${event.id}/chat`)}
                >
                  <MessageCircle className="h-4 w-4" />
                  Open Event Chat
                </Button>
              </BentoCell>
            </BentoGrid>
          </BentoFrame>
        </div>
      </main>

      {/* RSVP confirmation sheet */}
      {sheetStatus && event && (
        <RsvpSheet
          status={sheetStatus}
          eventId={event.id}
          eventTitle={event.title}
          startsAt={event.starts_at}
          goingCount={counts.going}
          attendees={attendees}
          onDismiss={() => setSheetStatus(null)}
        />
      )}
    </div>
  )
}
