'use client'

import { useEffect, useRef, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Avatar } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { ArrowLeft } from 'lucide-react'

type ChatMessage = {
  id: string
  content: string
  created_at: string
  sender: {
    id: string
    username: string | null
    full_name: string | null
    avatar_url: string | null
  } | null
}

type EventSummary = {
  id: string
  title: string
  is_campus_only?: boolean
}

const formatTime = (value: string) => {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })
}

export default function EventChatPage() {
  const params = useParams()
  const router = useRouter()
  const { user, loading, initialized } = useAuth()
  const [event, setEvent] = useState<EventSummary | null>(null)
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [loadingChat, setLoadingChat] = useState(true)
  const [text, setText] = useState('')
  const [sending, setSending] = useState(false)
  const bottomRef = useRef<HTMLDivElement | null>(null)

  const eventId = typeof params.id === 'string' ? params.id : params.id?.[0]

  useEffect(() => {
    if (!initialized || loading) return
    if (!user) {
      router.replace('/')
    }
  }, [initialized, loading, user, router])

  useEffect(() => {
    if (!user || !eventId) return
    let active = true
    setLoadingChat(true)
    fetch(`/api/events/${encodeURIComponent(eventId)}/chat`)
      .then((res) => res.json())
      .then((data) => {
        if (!active) return
        setEvent(data.event ?? null)
        setMessages(data.messages ?? [])
      })
      .finally(() => {
        if (active) setLoadingChat(false)
      })
    return () => {
      active = false
    }
  }, [user, eventId])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' })
  }, [messages.length])

  const handleSend = async () => {
    const trimmed = text.trim()
    if (!trimmed || !eventId || sending) return
    setSending(true)
    try {
      const response = await fetch(`/api/events/${encodeURIComponent(eventId)}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: trimmed }),
      })
      const data = await response.json()
      if (!response.ok) {
        throw new Error(data.error || 'Failed to send message')
      }
      if (data.message) {
        setMessages((prev) => [...prev, data.message])
      }
      setText('')
    } catch {
      // keep the draft text for retry
    } finally {
      setSending(false)
    }
  }

  if (!initialized || loading) {
    return <LoadingScreen />
  }

  if (!user) {
    return <LoadingScreen />
  }

  if (loadingChat) {
    return <LoadingScreen />
  }

  return (
    <div className="min-h-screen bg-surface-primary safe-top safe-bottom flex flex-col">
      <header className="px-4 py-4 flex items-center justify-between border-b border-border-secondary">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <div className="text-center">
          <h1 className="text-headline">{event?.title || 'Event chat'}</h1>
          {event?.is_campus_only && (
            <p className="text-caption text-content-tertiary">Campus-only</p>
          )}
        </div>
        <div className="w-9" />
      </header>

      <main className="flex-1 overflow-y-auto px-4 py-6 space-y-4">
        {messages.length === 0 ? (
          <div className="rounded-card border border-border-secondary bg-surface-secondary p-6 text-center">
            <p className="text-body text-content-secondary">
              No messages yet. Say hello to kick things off.
            </p>
          </div>
        ) : (
          messages.map((message) => {
            const isMe = message.sender?.id === user.id
            return (
              <div key={message.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[75%] rounded-2xl px-4 py-3 ${
                  isMe ? 'bg-content-primary text-white' : 'bg-surface-secondary text-content-primary'
                }`}>
                  {!isMe && message.sender && (
                    <div className="flex items-center gap-2 mb-2">
                      <Avatar src={message.sender.avatar_url} size="xs" />
                      <span className="text-caption text-content-secondary">
                        {message.sender.full_name || message.sender.username || 'Member'}
                      </span>
                    </div>
                  )}
                  <p className="text-body whitespace-pre-wrap">{message.content}</p>
                  <p className={`mt-2 text-[11px] ${
                    isMe ? 'text-white/70' : 'text-content-tertiary'
                  }`}>
                    {formatTime(message.created_at)}
                  </p>
                </div>
              </div>
            )
          })
        )}
        <div ref={bottomRef} />
      </main>

      <div className="border-t border-border-secondary bg-surface-primary px-4 py-4">
        <div className="flex items-center gap-2">
          <input
            value={text}
            onChange={(event) => setText(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault()
                handleSend()
              }
            }}
            placeholder="Write a message…"
            className="flex-1 rounded-full border border-border-secondary bg-surface-secondary px-4 py-2 text-body text-content-primary placeholder:text-content-tertiary focus:outline-none focus:ring-2 focus:ring-content-primary/10"
          />
          <Button size="sm" onClick={handleSend} disabled={sending || !text.trim()}>
            Send
          </Button>
        </div>
      </div>
    </div>
  )
}
