'use client'

import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Button } from '@/components/ui/button'
import { Avatar } from '@/components/ui/avatar'
import { BentoCell, BentoDivider, BentoFrame, BentoGrid } from '@/components/ui/bento'
import {
  ArrowLeft,
  Users,
  CheckCircle2,
  Sparkles,
  XCircle,
  Share2,
  Search,
} from 'lucide-react'

type AttendeeData = {
  user_id: string
  status: 'going' | 'interested' | 'cant_go'
  rsvp_at: string
  profile: {
    id: string
    username: string | null
    full_name: string | null
    avatar_url: string | null
    university_name: string | null
    university_verified: boolean
  } | null
}

type EventInfo = {
  id: string
  title: string
  creator_id: string
  attendee_count: number
  max_attendees: number | null
}

type Counts = {
  going: number
  interested: number
  cant_go: number
}

const formatRsvpTime = (iso: string) => {
  const d = new Date(iso)
  return d.toLocaleDateString([], { month: 'short', day: 'numeric' }) +
    ' at ' +
    d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })
}

const statusConfig = {
  going: { label: 'Going', icon: CheckCircle2, color: 'text-[color:var(--success)]', bg: 'bg-[color:var(--success)]/10' },
  interested: { label: 'Interested', icon: Sparkles, color: 'text-content-secondary', bg: 'bg-surface-secondary' },
  cant_go: { label: "Can't go", icon: XCircle, color: 'text-content-tertiary', bg: 'bg-surface-secondary' },
}

export default function EventAttendeesPage() {
  const params = useParams()
  const router = useRouter()
  const { user, loading: authLoading, initialized } = useAuth()

  const [event, setEvent] = useState<EventInfo | null>(null)
  const [attendees, setAttendees] = useState<AttendeeData[]>([])
  const [counts, setCounts] = useState<Counts>({ going: 0, interested: 0, cant_go: 0 })
  const [isCreator, setIsCreator] = useState(false)
  const [loadingData, setLoadingData] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState<'all' | 'going' | 'interested' | 'cant_go'>('all')

  const eventId = typeof params.id === 'string' ? params.id : params.id?.[0]

  useEffect(() => {
    if (!initialized || authLoading) return
    if (!user) { router.replace('/'); return }
    if (!eventId) return

    let active = true
    setLoadingData(true)

    fetch(`/api/events/${encodeURIComponent(eventId)}/attendees`)
      .then(res => {
        if (!res.ok) throw new Error('Failed to load attendees')
        return res.json()
      })
      .then(data => {
        if (!active) return
        setEvent(data.event)
        setAttendees(data.attendees ?? [])
        setCounts(data.counts ?? { going: 0, interested: 0, cant_go: 0 })
        setIsCreator(data.is_creator ?? false)
      })
      .catch(err => {
        if (!active) return
        setError(err instanceof Error ? err.message : 'Something went wrong')
      })
      .finally(() => { if (active) setLoadingData(false) })

    return () => { active = false }
  }, [user, eventId, initialized, authLoading, router])

  if (!initialized || authLoading || loadingData) return <LoadingScreen />

  if (error || !event) {
    return (
      <div className="min-h-screen bg-surface-primary safe-top safe-bottom flex flex-col items-center justify-center px-6 text-center">
        <p className="text-body text-content-secondary mb-4">{error || 'Event not found'}</p>
        <Button variant="secondary" onClick={() => router.back()}>Go back</Button>
      </div>
    )
  }

  const filteredAttendees = attendees
    .filter(a => filter === 'all' || a.status === filter)
    .filter(a => {
      if (!search.trim()) return true
      const q = search.toLowerCase()
      const name = a.profile?.full_name?.toLowerCase() ?? ''
      const uname = a.profile?.username?.toLowerCase() ?? ''
      return name.includes(q) || uname.includes(q)
    })

  const goingList = filteredAttendees.filter(a => a.status === 'going')
  const otherList = filteredAttendees.filter(a => a.status !== 'going')

  const handleShare = async () => {
    const url = `${window.location.origin}/events/${event.id}`
    if (navigator.share) {
      await navigator.share({ title: `${event.title} - Attendees`, url }).catch(() => null)
    } else {
      await navigator.clipboard.writeText(url).catch(() => null)
    }
  }

  return (
    <div className="relative min-h-screen bg-surface-primary safe-top safe-bottom animate-route-enter">
      {/* Ambient orbs */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <span className="absolute left-[-12%] top-[14%] h-44 w-44 rounded-full bg-content-primary/5 blur-3xl animate-ambient-float-soft" />
        <span className="absolute right-[-14%] bottom-[20%] h-48 w-48 rounded-full bg-content-primary/5 blur-3xl animate-ambient-float-soft-reverse" />
      </div>

      {/* Header */}
      <header className="relative z-10 px-4 py-4 flex items-center justify-between border-b border-border-secondary">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
          aria-label="Go back"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline font-semibold">Attendees</h1>
        <button
          onClick={handleShare}
          className="p-2 -mr-2 rounded-full hover:bg-accent-muted transition-colors"
          aria-label="Share event"
        >
          <Share2 className="h-4.5 w-4.5 text-content-secondary" />
        </button>
      </header>

      <main className="relative z-10 px-4 py-6">
        <div className="max-w-md mx-auto">
          <BentoFrame>
            <BentoGrid>
              {/* Summary card */}
              <BentoCell className="bento-tint-sage space-y-4 animate-section-reveal">
                <h2 className="text-callout text-content-primary font-semibold truncate">{event.title}</h2>
                <div className="grid grid-cols-3 gap-3 text-center">
                  <div>
                    <p className="text-title font-bold text-content-primary">{counts.going}</p>
                    <p className="text-caption text-content-tertiary">Going</p>
                  </div>
                  <div>
                    <p className="text-title font-bold text-content-primary">{event.max_attendees ?? '--'}</p>
                    <p className="text-caption text-content-tertiary">Capacity</p>
                  </div>
                  <div>
                    <p className="text-title font-bold text-content-primary">{attendees.length}</p>
                    <p className="text-caption text-content-tertiary">Total RSVPs</p>
                  </div>
                </div>
                {event.max_attendees != null && (
                  <div className="space-y-1.5">
                    <div className="h-1.5 rounded-full bg-surface-tertiary overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          counts.going >= event.max_attendees ? 'bg-error' : 'bg-[color:var(--success)]'
                        }`}
                        style={{ width: `${Math.min(100, (counts.going / event.max_attendees) * 100)}%` }}
                      />
                    </div>
                    <p className="text-caption text-content-tertiary text-center">
                      {counts.going >= event.max_attendees
                        ? 'At capacity'
                        : `${event.max_attendees - counts.going} spots left`}
                    </p>
                  </div>
                )}
              </BentoCell>

              {/* Search + filter */}
              <BentoCell className="bento-tint-mist space-y-3 animate-section-reveal" style={{ animationDelay: '70ms' }}>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-content-tertiary" />
                  <input
                    type="text"
                    placeholder="Search attendees..."
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 text-callout bg-surface-primary/50 border border-border-secondary rounded-[14px] text-content-primary placeholder:text-content-tertiary outline-none focus:border-content-tertiary transition-colors"
                  />
                </div>
                <div className="flex gap-2">
                  {(['all', 'going', 'interested', 'cant_go'] as const).map(f => (
                    <button
                      key={f}
                      onClick={() => setFilter(f)}
                      className={`px-3 py-1.5 rounded-full text-caption font-medium transition-all ${
                        filter === f
                          ? 'bg-[color:var(--accent-primary)] text-[color:var(--accent-on-primary)]'
                          : 'bg-surface-primary/50 text-content-secondary border border-border-secondary hover:bg-surface-secondary'
                      }`}
                    >
                      {f === 'all' ? 'All' : f === 'going' ? 'Going' : f === 'interested' ? 'Interested' : "Can't go"}
                      <span className="ml-1 opacity-60">
                        {f === 'all' ? attendees.length : f === 'going' ? counts.going : f === 'interested' ? counts.interested : counts.cant_go}
                      </span>
                    </button>
                  ))}
                </div>
              </BentoCell>

              {/* Attendee list */}
              <BentoCell className="bento-tint-peach animate-section-reveal !p-0" style={{ animationDelay: '110ms' }}>
                {filteredAttendees.length === 0 ? (
                  <div className="py-12 px-4 text-center">
                    <Users className="h-10 w-10 text-content-tertiary mx-auto mb-3" />
                    <p className="text-body text-content-primary font-semibold">No attendees found</p>
                    <p className="text-callout text-content-secondary mt-1">
                      {search ? 'Try a different search term' : 'Share this event to invite people'}
                    </p>
                  </div>
                ) : (
                  <div className="divide-y divide-border-secondary">
                    {[...goingList, ...otherList].map((attendee, index) => {
                      const config = statusConfig[attendee.status]
                      const StatusIcon = config.icon
                      return (
                        <button
                          key={attendee.user_id}
                          onClick={() => {
                            if (attendee.profile?.username) {
                              router.push(`/profile/${attendee.profile.username}`)
                            }
                          }}
                          className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-surface-secondary/30 transition-colors text-left"
                        >
                          <span className="text-caption text-content-tertiary w-6 text-center font-medium">
                            {index + 1}
                          </span>
                          <Avatar src={attendee.profile?.avatar_url} size="sm" />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1.5">
                              <span className="text-callout text-content-primary font-semibold truncate">
                                {attendee.profile?.full_name ?? attendee.profile?.username ?? 'Unknown'}
                              </span>
                              {attendee.profile?.university_verified && (
                                <CheckCircle2 className="h-3.5 w-3.5 text-[color:var(--success)] flex-shrink-0" />
                              )}
                            </div>
                            {attendee.profile?.username && (
                              <p className="text-caption text-content-secondary">@{attendee.profile.username}</p>
                            )}
                            <p className="text-[10px] text-content-tertiary mt-0.5">
                              RSVP'd {formatRsvpTime(attendee.rsvp_at)}
                            </p>
                          </div>
                          <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-[11px] font-medium ${config.bg} ${config.color}`}>
                            <StatusIcon className="h-3 w-3" />
                            {config.label}
                          </span>
                        </button>
                      )
                    })}
                  </div>
                )}
              </BentoCell>
            </BentoGrid>
          </BentoFrame>
        </div>
      </main>
    </div>
  )
}
