'use client'

import { useEffect, useRef, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { ArrowLeft, Send, Smile, ImagePlus, MoreHorizontal, Trash2 } from 'lucide-react'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Avatar } from '@/components/ui/avatar'

interface ChatMessage {
  id: string
  content: string
  created_at: string
  edited_at: string | null
  deleted_at: string | null
  sender_id: string
  sender: {
    id: string
    username: string | null
    full_name: string | null
    avatar_url: string | null
  } | null
  status?: 'sent' | 'delivered' | 'read' | null
}

interface OtherUser {
  id: string
  username: string | null
  full_name: string | null
  avatar_url: string | null
  is_online?: boolean
  last_active_at?: string | null
  show_read_receipts?: boolean
}

const formatTime = (value: string) => {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })
}

const EMOJIS = ['😊', '😂', '😍', '🔥', '🎉', '🥳', '🙏', '✨', '🤍', '😎']
const UNSEND_WINDOW_MS = 5 * 60 * 1000

export default function MessageThreadPage() {
  const params = useParams()
  const router = useRouter()
  const { user, loading, initialized } = useAuth()
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [otherUser, setOtherUser] = useState<OtherUser | null>(null)
  const [loadingThread, setLoadingThread] = useState(true)
  const [text, setText] = useState('')
  const [sending, setSending] = useState(false)
  const [composerError, setComposerError] = useState<string | null>(null)
  const [emojiOpen, setEmojiOpen] = useState(false)
  const [activeMenuMessageId, setActiveMenuMessageId] = useState<string | null>(null)
  const bottomRef = useRef<HTMLDivElement | null>(null)
  const fileInputRef = useRef<HTMLInputElement | null>(null)
  const textareaRef = useRef<HTMLTextAreaElement | null>(null)

  const threadId = typeof params.id === 'string' ? params.id : params.id?.[0]

  useEffect(() => {
    if (!initialized || loading) return
    if (!user) {
      router.replace('/')
    }
  }, [initialized, loading, user, router])

  const loadThread = () => {
    if (!user || !threadId) return
    setLoadingThread(true)
    fetch(`/api/dms/${encodeURIComponent(threadId)}`)
      .then((res) => res.json())
      .then((data) => {
        setMessages(data.messages ?? [])
        setOtherUser(data.other_user ?? null)
      })
      .finally(() => {
        setLoadingThread(false)
      })
  }

  useEffect(() => {
    if (!user || !threadId) return
    loadThread()
  }, [user, threadId])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages.length])

  const resizeComposer = () => {
    const textarea = textareaRef.current
    if (!textarea) return
    textarea.style.height = 'auto'
    textarea.style.height = `${Math.min(textarea.scrollHeight, 160)}px`
  }

  useEffect(() => {
    resizeComposer()
  }, [text])

  useEffect(() => {
    if (!user) return
    let active = true
    const ping = () => {
      fetch('/api/presence', { method: 'POST' }).catch(() => {})
    }
    ping()
    const interval = window.setInterval(() => {
      if (active) ping()
    }, 60000)
    return () => {
      active = false
      window.clearInterval(interval)
    }
  }, [user])

  const sendMessage = async (content: string, onSuccess?: () => void) => {
    if (!content || !threadId || sending) return
    setSending(true)
    setComposerError(null)
    setActiveMenuMessageId(null)
    try {
      const response = await fetch(`/api/dms/${encodeURIComponent(threadId)}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content }),
      })
      const data = await response.json()
      if (!response.ok) {
        throw new Error(data.error || 'Failed to send message')
      }
      if (data.message) {
        setMessages((prev) => [...prev, data.message])
      }
      onSuccess?.()
    } catch (err) {
      setComposerError(err instanceof Error ? err.message : 'Failed to send message')
    } finally {
      setSending(false)
    }
  }

  const handleSend = async () => {
    const trimmed = text.trim()
    if (!trimmed) return
    await sendMessage(trimmed, () => setText(''))
  }

  const handleEmojiSelect = (emoji: string) => {
    setText((prev) => `${prev}${emoji}`)
    setEmojiOpen(false)
  }

  const handleImagePick = () => {
    fileInputRef.current?.click()
  }

  const handleImageChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return
    if (!file.type.startsWith('image/')) {
      setComposerError('Please select an image file.')
      event.target.value = ''
      return
    }
    const maxBytes = 900 * 1024
    if (file.size > maxBytes) {
      setComposerError('Image must be under 900KB.')
      event.target.value = ''
      return
    }
    const reader = new FileReader()
    reader.onload = async () => {
      if (typeof reader.result !== 'string') {
        setComposerError('Unable to read image.')
        return
      }
      await sendMessage(reader.result, () => {
        setText('')
      })
    }
    reader.readAsDataURL(file)
    event.target.value = ''
  }

  const canUnsendMessage = (message: ChatMessage) => {
    if (!user || message.sender_id !== user.id || message.deleted_at) return false
    const createdAtMs = new Date(message.created_at).getTime()
    if (Number.isNaN(createdAtMs)) return false
    return Date.now() - createdAtMs <= UNSEND_WINDOW_MS
  }

  const upsertMessage = (nextMessage: ChatMessage) => {
    setMessages((prev) =>
      prev.map((message) => (message.id === nextMessage.id ? { ...message, ...nextMessage } : message))
    )
  }

  const unsendMessage = async (messageId: string) => {
    if (!threadId || sending) return
    setSending(true)
    setComposerError(null)
    setActiveMenuMessageId(null)
    try {
      const response = await fetch(`/api/dms/${encodeURIComponent(threadId)}/messages`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message_id: messageId,
        }),
      })
      const data = await response.json().catch(() => ({}))
      if (!response.ok || !data?.message) {
        throw new Error(data?.error || 'Unable to unsend message.')
      }
      upsertMessage(data.message)
    } catch (err) {
      setComposerError(err instanceof Error ? err.message : 'Unable to unsend message.')
    } finally {
      setSending(false)
    }
  }

  const handleKeyPress = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault()
      handleSend()
    }
  }

  if (!initialized || loading) {
    return <LoadingScreen />
  }

  if (!user) {
    return <LoadingScreen />
  }

  if (loadingThread) {
    return <LoadingScreen />
  }

  if (!otherUser) {
    return (
      <div className="min-h-screen bg-surface-primary safe-top safe-bottom flex items-center justify-center">
        <p className="text-content-secondary">Conversation not found</p>
      </div>
    )
  }

  const title = otherUser.full_name || otherUser.username || 'Message'

  return (
    <div className="relative min-h-screen bg-surface-primary safe-top safe-bottom flex flex-col animate-route-enter">
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <span className="absolute left-[-8%] top-[16%] h-36 w-36 rounded-full bg-content-primary/4 blur-3xl animate-ambient-float-soft" />
        <span className="absolute right-[-10%] bottom-[22%] h-40 w-40 rounded-full bg-content-primary/4 blur-3xl animate-ambient-float-soft-reverse" />
      </div>

      <div className="relative z-10 px-6 pt-14 pb-4 border-b border-border-secondary animate-section-reveal">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4 flex-1 min-w-0">
            <button
              onClick={() => router.push('/messages')}
              className="w-10 h-10 rounded-full bg-surface-secondary flex items-center justify-center flex-shrink-0"
            >
              <ArrowLeft className="w-5 h-5 text-content-primary" strokeWidth={1.5} />
            </button>

            <div className="flex items-center gap-3 flex-1 min-w-0">
              <div className="relative flex-shrink-0">
                <Avatar src={otherUser.avatar_url} size="sm" />
                {otherUser.is_online && (
                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-[color:var(--surface-primary)] rounded-full" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <h2 className="text-content-primary truncate">{title}</h2>
                {otherUser.is_online && (
                  <p className="text-sm text-content-tertiary">Active now</p>
                )}
              </div>
            </div>
          </div>

        </div>
      </div>

      <div className="relative z-10 flex-1 overflow-y-auto px-6 py-6">
        <div className="space-y-4">
          {messages.map((message, index) => {
            const isSent = message.sender_id === user.id
            const isDeleted = Boolean(message.deleted_at)
            const isImage = !isDeleted && message.content?.startsWith('data:image/')
            const canUnsend = canUnsendMessage(message)
            return (
              <div
                key={message.id}
                className={`flex animate-section-reveal ${isSent ? 'justify-end' : 'justify-start'}`}
                style={{ animationDelay: `${Math.min(index, 10) * 28}ms` }}
              >
                <div className={`flex flex-col ${isSent ? 'items-end' : 'items-start'} max-w-[75%]`}>
                  <div
                    className={`dynamic-card rounded-2xl ${
                      isDeleted
                        ? 'px-4 py-3 bg-surface-secondary text-content-tertiary'
                        : isImage
                        ? 'p-1 bg-surface-secondary'
                        : isSent
                          ? 'px-4 py-3 bg-content-primary text-content-inverse'
                          : 'px-4 py-3 bg-surface-secondary text-content-primary'
                    }`}
                  >
                    {isDeleted ? (
                      <p className="italic">Message unsent</p>
                    ) : isImage ? (
                      <div className="media-frame max-w-[min(72vw,22rem)] rounded-xl">
                        <img
                          src={message.content}
                          alt="Attachment"
                          className="block h-auto w-full"
                        />
                        <span className="media-scrim-gradient opacity-90" />
                        <span className="media-scrim-content media-copy-solid-scrim-soft absolute bottom-2 left-3 px-2 py-1 text-[10px] uppercase tracking-[0.12em] text-white/85">
                          Shared photo
                        </span>
                      </div>
                    ) : (
                      <p className="whitespace-pre-wrap break-words">{message.content}</p>
                    )}
                  </div>
                  <div className="mt-1 flex items-center gap-1 px-1">
                    <span className="text-xs text-content-tertiary">
                      {formatTime(message.created_at)}
                    </span>
                    {isSent && message.status && (
                      <span className="text-xs text-content-tertiary">
                        • {message.status === 'read' ? 'Read' : message.status === 'delivered' ? 'Delivered' : 'Sent'}
                      </span>
                    )}
                    {canUnsend && (
                      <div className="relative ml-1">
                        <button
                          type="button"
                          onClick={() =>
                            setActiveMenuMessageId((current) =>
                              current === message.id ? null : message.id
                            )
                          }
                          className="flex h-5 w-5 items-center justify-center rounded-full text-content-tertiary hover:text-content-primary"
                          aria-label="Message actions"
                        >
                          <MoreHorizontal className="h-3.5 w-3.5" />
                        </button>
                        {activeMenuMessageId === message.id && (
                          <div className="absolute right-0 top-6 z-20 min-w-[8.5rem] rounded-lg border border-border-secondary bg-surface-primary p-1 shadow-lg">
                            {canUnsend && (
                              <button
                                type="button"
                                onClick={() => void unsendMessage(message.id)}
                                className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm text-error hover:bg-surface-secondary"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                                Unsend
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )
          })}
          <div ref={bottomRef} />
        </div>
      </div>

      <div className="relative z-10 px-6 py-4 border-t border-border-secondary animate-section-reveal" style={{ animationDelay: '120ms' }}>
        {composerError && (
          <p className="mb-2 text-xs text-error">{composerError}</p>
        )}
        {emojiOpen && (
          <div className="mb-3 flex flex-wrap gap-2 rounded-xl border border-border-secondary bg-surface-secondary p-3">
            {EMOJIS.map((emoji) => (
              <button
                key={emoji}
                onClick={() => handleEmojiSelect(emoji)}
                className="h-9 w-9 rounded-full bg-surface-primary text-lg"
                aria-label={`Insert ${emoji}`}
              >
                {emoji}
              </button>
            ))}
          </div>
        )}
        <div className="flex items-end gap-3">
          <div className="flex min-w-0 flex-1 items-center gap-2 rounded-2xl border border-border-secondary bg-surface-secondary px-3 py-2">
            <button
              type="button"
              onClick={() => setEmojiOpen((prev) => !prev)}
              className="h-8 w-8 rounded-full flex items-center justify-center text-content-tertiary hover:text-content-primary"
              aria-label="Add emoji"
            >
              <Smile className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={handleImagePick}
              className="h-8 w-8 rounded-full flex items-center justify-center text-content-tertiary hover:text-content-primary"
              aria-label="Add image"
            >
              <ImagePlus className="h-4 w-4" />
            </button>
            <textarea
              ref={textareaRef}
              value={text}
              onChange={(e) => setText(e.target.value)}
              onInput={resizeComposer}
              onKeyDown={handleKeyPress}
              placeholder="Message…"
              rows={1}
              className="min-h-[1.5rem] max-h-40 w-full min-w-0 flex-1 resize-none overflow-x-hidden overflow-y-auto bg-transparent text-content-primary placeholder:text-content-tertiary focus:outline-none"
              style={{ height: '1.5rem', lineHeight: 1.5, wordBreak: 'break-word', overflowWrap: 'anywhere' }}
            />
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              className="hidden"
            />
          </div>

          <button
            onClick={handleSend}
            disabled={!text.trim() || sending}
            className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 transition-colors ${
              text.trim() && !sending
                ? 'bg-content-primary'
                : 'bg-surface-secondary'
            }`}
          >
            <Send
              className={`w-5 h-5 ${
                text.trim() && !sending
                  ? 'text-content-inverse'
                  : 'text-content-tertiary'
              }`}
              strokeWidth={1.5}
            />
          </button>
        </div>
      </div>
    </div>
  )
}
