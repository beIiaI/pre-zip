'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowLeft, Search, Edit3, MessageCircle } from 'lucide-react'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Divider } from '@/components/ui-circle/Divider'
import { BottomSheet } from '@/components/ui-circle/BottomSheet'
import { Avatar } from '@/components/ui/avatar'
import { Alert } from '@/components/ui/alert'
import { BentoCell, BentoDivider, BentoFrame, BentoGrid } from '@/components/ui/bento'

interface ThreadItem {
  id: string
  other_user: {
    id: string
    username: string | null
    full_name: string | null
    avatar_url: string | null
    is_online?: boolean
    last_active_at?: string | null
  } | null
  last_message: {
    id: string
    content: string
    created_at: string
    sender_id: string
  } | null
  unread_count: number
}

interface UserResult {
  id: string
  username: string | null
  full_name: string | null
  avatar_url: string | null
  bio: string | null
  location: string | null
  early_supporter_number: number | null
  founder_number: number | null
  is_founder: boolean | null
  is_following: boolean
}

const formatRelativeTime = (value: string | null) => {
  if (!value) return ''
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return ''
  const diff = Date.now() - date.getTime()
  const minutes = Math.floor(diff / 60000)
  if (minutes < 1) return 'now'
  if (minutes < 60) return `${minutes}m`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours}h`
  const days = Math.floor(hours / 24)
  return `${days}d`
}

const SEARCH_DELAY = 320

export default function MessagesPage() {
  const { user, loading, initialized } = useAuth()
  const router = useRouter()
  const [threads, setThreads] = useState<ThreadItem[]>([])
  const [loadingThreads, setLoadingThreads] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')

  const [composeOpen, setComposeOpen] = useState(false)
  const [composeQuery, setComposeQuery] = useState('')
  const [composeResults, setComposeResults] = useState<UserResult[]>([])
  const [composeLoading, setComposeLoading] = useState(false)
  const [composeError, setComposeError] = useState<string | null>(null)
  const debounceRef = useRef<number | null>(null)
  const abortRef = useRef<AbortController | null>(null)

  useEffect(() => {
    if (!initialized || loading) return
    if (!user) {
      router.replace('/')
    }
  }, [initialized, loading, user, router])

  useEffect(() => {
    if (!user) return
    let active = true
    setLoadingThreads(true)
    fetch('/api/dms')
      .then((res) => res.json())
      .then((data) => {
        if (!active) return
        setThreads(data.threads ?? [])
      })
      .finally(() => {
        if (active) setLoadingThreads(false)
      })
    return () => {
      active = false
    }
  }, [user])

  useEffect(() => {
    if (!user) return
    let active = true
    const ping = () => {
      fetch('/api/presence', { method: 'POST' }).catch(() => {})
    }
    ping()
    const interval = window.setInterval(() => {
      if (active) ping()
    }, 60000)
    return () => {
      active = false
      window.clearInterval(interval)
    }
  }, [user])

  useEffect(() => {
    if (!composeOpen) return
    if (!composeQuery.trim()) {
      setComposeResults([])
      setComposeLoading(false)
      return
    }

    if (debounceRef.current) {
      window.clearTimeout(debounceRef.current)
    }

    const controller = new AbortController()
    abortRef.current?.abort()
    abortRef.current = controller

    setComposeLoading(true)

    debounceRef.current = window.setTimeout(async () => {
      try {
        const response = await fetch(`/api/users/search?q=${encodeURIComponent(composeQuery)}`, {
          signal: controller.signal,
        })
        if (!response.ok) {
          throw new Error('Search failed')
        }
        const data = await response.json()
        setComposeResults(data.results ?? [])
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          setComposeResults([])
        }
      } finally {
        setComposeLoading(false)
      }
    }, SEARCH_DELAY)

    return () => {
      if (debounceRef.current) {
        window.clearTimeout(debounceRef.current)
      }
      controller.abort()
    }
  }, [composeQuery, composeOpen])

  useEffect(() => {
    if (!composeOpen) {
      setComposeError(null)
    }
  }, [composeOpen])

  const filteredThreads = useMemo(() => {
    const query = searchQuery.trim().toLowerCase()
    if (!query) return threads
    return threads.filter((thread) => {
      const name = thread.other_user?.full_name || thread.other_user?.username || ''
      return name.toLowerCase().includes(query)
    })
  }, [threads, searchQuery])

  const handleComposeSelect = async (person: UserResult) => {
    setComposeError(null)
    try {
      const response = await fetch('/api/dms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: person.id }),
      })
      const payload = await response.json()
      if (!response.ok) {
        throw new Error(payload.error || 'Unable to start message')
      }
      if (payload.thread_id) {
        setComposeOpen(false)
        setComposeQuery('')
        setComposeResults([])
        router.push(`/messages/${payload.thread_id}`)
      }
    } catch (err) {
      setComposeError(err instanceof Error ? err.message : 'Unable to start message')
    }
  }

  if (!initialized || loading) {
    return <LoadingScreen />
  }

  if (!user) {
    return <LoadingScreen />
  }

  return (
    <div className="relative app-page safe-top safe-bottom flex flex-col animate-route-enter">
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <span className="absolute left-[-12%] top-[10%] h-40 w-40 rounded-full bg-content-primary/5 blur-3xl animate-ambient-float-soft" />
        <span className="absolute right-[-16%] bottom-[18%] h-44 w-44 rounded-full bg-content-primary/5 blur-3xl animate-ambient-float-soft-reverse" />
      </div>

      <header className="relative z-10 app-header px-4 pb-4 pt-14">
        <div className="mx-auto mb-4 flex w-full max-w-[42rem] items-center justify-between animate-section-reveal">
          <div className="flex items-center gap-4">
            <button
              onClick={() => router.push('/home')}
              className="w-10 h-10 rounded-full bg-surface-secondary flex items-center justify-center"
            >
              <ArrowLeft className="w-5 h-5 text-content-primary" strokeWidth={1.5} />
            </button>
            <h1 className="text-[clamp(1.25rem,5.8vw,1.5rem)] leading-tight text-content-primary">Messages</h1>
          </div>
          <button
            className="w-10 h-10 rounded-full bg-surface-secondary flex items-center justify-center"
            onClick={() => setComposeOpen(true)}
            aria-label="Compose new message"
          >
            <Edit3 className="w-5 h-5 text-content-primary" strokeWidth={1.5} />
          </button>
        </div>
        <div className="mx-auto w-full max-w-[42rem] space-y-3 animate-section-reveal" style={{ animationDelay: '80ms' }}>
          <div className="flex items-center gap-2 text-xs tracking-[0.04em] text-content-tertiary">
            <MessageCircle className="h-3.5 w-3.5 flex-shrink-0" strokeWidth={1.5} />
            <span>Private by design: only thread participants can read messages.</span>
          </div>
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-content-tertiary" strokeWidth={1.5} />
            <input
              type="text"
              placeholder="Search messages"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 rounded-xl border border-border-secondary bg-surface-secondary text-content-primary placeholder:text-content-tertiary focus:outline-none focus:border-border-primary"
              style={{ color: 'var(--content-primary)', WebkitTextFillColor: 'var(--content-primary)' }}
            />
          </div>
        </div>
      </header>

      <Divider spacing="none" />

      <div className="relative z-10 mx-auto flex w-full max-w-[42rem] flex-1 overflow-y-auto">
        {loadingThreads ? (
          <LoadingScreen />
        ) : filteredThreads.length === 0 ? (
          <div className="w-full px-4 pb-6">
            <BentoFrame className="animate-section-reveal">
              <BentoCell className="border-t-0 border-l-0 flex flex-col items-center justify-center py-14 text-center">
                <div className="w-16 h-16 rounded-full bg-surface-secondary flex items-center justify-center mb-4">
                  <Search className="w-8 h-8 text-content-tertiary" strokeWidth={1.5} />
                </div>
                <p className="text-content-secondary">
                  {threads.length === 0 && !searchQuery.trim() ? 'No conversations yet' : 'No conversations found'}
                </p>
              </BentoCell>
            </BentoFrame>
          </div>
        ) : (
          <div className="w-full px-4 pb-6">
            <BentoFrame>
              <BentoGrid>
                {filteredThreads.map((thread, index) => {
                  const name = thread.other_user?.full_name || thread.other_user?.username || 'Unknown'
                  const timestamp = formatRelativeTime(thread.last_message?.created_at ?? null)
                  const lastMessage = thread.last_message?.content ?? 'Start the conversation'
                  const lastPreview = lastMessage.startsWith('data:image/') ? 'Photo' : lastMessage
                  return (
                    <BentoCell
                      key={thread.id}
                      className={`dynamic-card animate-section-reveal cursor-pointer ${
                        index % 3 === 0 ? 'bento-tint-sage' : index % 3 === 1 ? 'bento-tint-lilac' : 'bento-tint-honey'
                      }`}
                      style={{ animationDelay: `${Math.min(index, 10) * 55}ms` }}
                      onClick={() => router.push(`/messages/${thread.id}`)}
                    >
                      <div className="flex items-center gap-4">
                        <div className="relative flex-shrink-0">
                          <Avatar src={thread.other_user?.avatar_url} size="lg" />
                          {thread.other_user?.is_online && (
                            <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 border-2 border-[color:var(--surface-primary)] rounded-full" />
                          )}
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <h3 className="text-content-primary truncate">{name}</h3>
                            <span className="text-sm text-content-tertiary ml-2 flex-shrink-0">
                              {timestamp}
                            </span>
                          </div>
                          <BentoDivider variant="secondary" className="mb-2" />
                          <div className="flex items-center justify-between">
                            <p className={`text-sm truncate ${
                              thread.unread_count > 0
                                ? 'text-content-primary'
                                : 'text-content-secondary'
                            }`}>
                              {lastPreview}
                            </p>
                            {thread.unread_count > 0 && (
                              <div className="min-w-[20px] h-5 px-1 rounded-full bg-content-primary flex items-center justify-center ml-2 flex-shrink-0">
                                <span className="text-xs text-content-inverse">
                                  {thread.unread_count}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </BentoCell>
                  )
                })}
              </BentoGrid>
            </BentoFrame>
          </div>
        )}
      </div>

      <BottomSheet isOpen={composeOpen} onClose={() => setComposeOpen(false)} title="New message">
        <div className="px-6 py-6 space-y-4">
          {composeError && (
            <Alert variant="error" dismissible onDismiss={() => setComposeError(null)}>
              {composeError}
            </Alert>
          )}
          <div className="relative animate-section-reveal">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-content-tertiary" strokeWidth={1.5} />
            <input
              type="text"
              placeholder="Search people"
              value={composeQuery}
              onChange={(e) => setComposeQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 rounded-xl border border-border-secondary bg-surface-secondary text-content-primary placeholder:text-content-tertiary focus:outline-none focus:border-border-primary"
              style={{ color: 'var(--content-primary)', WebkitTextFillColor: 'var(--content-primary)' }}
            />
          </div>

          {composeLoading ? (
            <div className="text-center text-sm text-content-tertiary">Searching…</div>
          ) : composeQuery.trim() && composeResults.length === 0 ? (
            <div className="text-center text-sm text-content-tertiary">No results</div>
          ) : (
            <div className="space-y-3">
              {composeResults.map((person) => (
                <button
                  key={person.id}
                  onClick={() => handleComposeSelect(person)}
                  className="dynamic-card hierarchy-section w-full flex items-center gap-4 rounded-xl p-3 text-left hover:bg-surface-secondary animate-section-reveal"
                >
                  <Avatar src={person.avatar_url} size="lg" />
                  <div className="flex-1 min-w-0">
                    <p className="text-content-primary truncate">
                      {person.full_name || person.username || 'Unknown'}
                    </p>
                    {person.username && (
                      <p className="text-sm text-content-tertiary">@{person.username}</p>
                    )}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </BottomSheet>
    </div>
  )
}
