'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Avatar } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { ArrowLeft, Edit2, Award, MapPin, Calendar, UserPlus, ShieldCheck } from 'lucide-react'
import { formatDate, getLocationDisplay } from '@/lib/utils'
import { MemberBadgeStack } from '@/components/ui/member-badge-stack'
import { getNormalizedUniversityName } from '@/lib/verification/university'
import Link from 'next/link'

export default function ProfilePage() {
  const { user, profile, loading, initialized, profileLoaded } = useAuth()
  const router = useRouter()
  const locationDisplay = getLocationDisplay(profile?.location)
  const hasEarlySupporterNumber =
    profile?.early_supporter_number !== null && profile?.early_supporter_number !== undefined
  const isFounder = profile?.is_founder === true
  const hasMemberBadges = isFounder || hasEarlySupporterNumber
  const isUniversityVerified =
    profile?.university_verified === true ||
    (profile?.is_verified === true && profile?.verification_type === 'university_email')
  const showUniversityOnProfile = profile?.show_university !== false
  const showCollegeOnProfile = profile?.show_college === true
  const membershipSince = profile?.created_at
    ? new Intl.DateTimeFormat('en-US', {
        month: 'short',
        year: '2-digit',
      }).format(new Date(profile.created_at))
    : ''
  const universityName = getNormalizedUniversityName(
    profile?.university_domain || null,
    profile?.university_name || null
  )
  const [followersCount, setFollowersCount] = useState<number>(0)
  const [followingCount, setFollowingCount] = useState<number>(0)
  const [collegeName, setCollegeName] = useState<string | null>(null)

  useEffect(() => {
    if (!initialized) return
    if (!user) {
      router.replace('/')
    }
    if (profileLoaded && !profile) {
      router.replace('/onboarding')
    }
  }, [user, profile, profileLoaded, initialized, router])

  useEffect(() => {
    if (!profile?.id) return
    let active = true
    fetch(`/api/users/preview?id=${encodeURIComponent(profile.id)}`)
      .then((res) => res.json())
      .then((data) => {
        if (!active) return
        setFollowersCount(data?.profile?.followers_count ?? 0)
        setFollowingCount(data?.profile?.following_count ?? 0)
        setCollegeName(typeof data?.profile?.college_name === 'string' ? data.profile.college_name : null)
      })
      .catch(() => {
        if (!active) return
        setCollegeName(null)
      })
    return () => {
      active = false
    }
  }, [profile?.id])

  if (!initialized || loading || !profileLoaded || !profile) {
    return <LoadingScreen />
  }

  return (
    <div className="relative min-h-screen bg-surface-primary safe-top safe-bottom animate-route-enter">
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <span className="absolute left-[-14%] top-[12%] h-48 w-48 rounded-full bg-content-primary/5 blur-3xl animate-ambient-float-soft" />
        <span className="absolute right-[-12%] bottom-[16%] h-44 w-44 rounded-full bg-content-primary/5 blur-3xl animate-ambient-float-soft-reverse" />
      </div>

      {/* Header */}
      <header className="relative z-10 px-4 py-4 flex items-center justify-between border-b border-border-secondary animate-section-reveal">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
          data-testid="profile-back-button"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">Profile</h1>
        <Link
          href="/profile/edit"
          className="p-2 -mr-2 rounded-full hover:bg-accent-muted transition-colors"
          data-testid="profile-edit-link"
        >
          <Edit2 className="h-5 w-5 text-content-primary" />
        </Link>
      </header>

      {/* Profile Content */}
      <main className="relative z-10 px-6 py-8">
        <div className="max-w-md mx-auto space-y-8">
          <section className="animate-section-reveal flex flex-col items-center text-center space-y-4">
            <Avatar src={profile.avatar_url} size="xl" />
            <div className="space-y-2">
              <h2 className="text-title text-content-primary">{profile.full_name || 'Anonymous'}</h2>
              {profile.username && (
                <p className="text-body text-content-secondary">@{profile.username}</p>
              )}
              <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                <span className="inline-flex items-center rounded-full border border-border-secondary bg-surface-secondary px-2.5 py-1 text-label-caps text-content-primary">
                  {isFounder ? 'Founder' : 'Access'}
                </span>
                <span className="inline-flex items-center gap-1.5 text-caption text-content-secondary">
                  <ShieldCheck className="h-3.5 w-3.5 text-content-tertiary" />
                  Since {membershipSince}
                </span>
              </div>
            </div>
            {(isUniversityVerified && showUniversityOnProfile) || hasMemberBadges ? (
              <div className="flex flex-wrap items-center justify-center gap-2">
                {isUniversityVerified && showUniversityOnProfile && (
                  <span className="px-3 py-1 rounded-full border border-border-secondary bg-surface-secondary text-caption text-content-primary">
                    {universityName || 'University'}
                  </span>
                )}
                {isUniversityVerified && showUniversityOnProfile && showCollegeOnProfile && collegeName && (
                  <span className="px-3 py-1 rounded-full border border-border-secondary bg-surface-secondary text-caption text-content-primary">
                    {collegeName}
                  </span>
                )}
                {hasMemberBadges && (
                  <Link
                    href={`/badges/early-supporter?uid=${encodeURIComponent(profile.id)}`}
                    data-testid="early-supporter-link"
                  >
                    <MemberBadgeStack
                      isFounder={isFounder}
                      founderNumber={profile.founder_number}
                      earlySupporterNumber={profile.early_supporter_number}
                    />
                  </Link>
                )}
              </div>
            ) : null}
          </section>

          <div className="h-px bg-border-secondary animate-section-reveal" style={{ animationDelay: '40ms' }} />

          {profile.bio && (
            <section className="space-y-2 animate-section-reveal" style={{ animationDelay: '70ms' }}>
              <p className="text-label-caps text-content-tertiary">About</p>
              <p className="text-body text-content-secondary type-align-body whitespace-pre-wrap break-words">{profile.bio}</p>
            </section>
          )}

          <section className="space-y-3 animate-section-reveal" style={{ animationDelay: '100ms' }}>
            <p className="text-label-caps text-content-tertiary">Details</p>
            <div className="space-y-2">
              {locationDisplay && (
                <div className="flex items-center gap-3 rounded-full border border-border-secondary bg-surface-secondary/70 px-4 py-2.5">
                  <MapPin className="h-4 w-4 text-content-tertiary" />
                  <span className="text-callout text-content-primary">{locationDisplay}</span>
                </div>
              )}
              <div className="flex items-center gap-3 rounded-full border border-border-secondary bg-surface-secondary/70 px-4 py-2.5">
                <Calendar className="h-4 w-4 text-content-tertiary" />
                <span className="text-callout text-content-primary">
                  Joined {formatDate(profile.created_at)}
                </span>
              </div>
            </div>
          </section>

          <section className="space-y-3 animate-section-reveal" style={{ animationDelay: '140ms' }}>
            <p className="text-label-caps text-content-tertiary">Community</p>
            <div className="rounded-[1.2rem] border border-border-secondary bg-surface-secondary/70 p-2.5">
              <div className="grid grid-cols-3 divide-x divide-border-secondary">
                <div className="text-center py-2">
                  <p className="text-title text-content-primary">{profile.total_points}</p>
                  <p className="text-caption text-content-secondary">Points</p>
                </div>
                <Link
                  href={profile.username
                    ? `/profile/${encodeURIComponent(profile.username)}/followers`
                    : `/profile/followers?uid=${encodeURIComponent(profile.id)}`}
                  className="text-center py-2"
                >
                  <p className="text-title text-content-primary">{followersCount}</p>
                  <p className="text-caption text-content-secondary">Followers</p>
                </Link>
                <Link
                  href={profile.username
                    ? `/profile/${encodeURIComponent(profile.username)}/following`
                    : `/profile/following?uid=${encodeURIComponent(profile.id)}`}
                  className="text-center py-2"
                >
                  <p className="text-title text-content-primary">{followingCount}</p>
                  <p className="text-caption text-content-secondary">Following</p>
                </Link>
              </div>
            </div>
          </section>

          <section className="animate-section-reveal" style={{ animationDelay: '165ms' }}>
            <Link
              href="/settings/invites"
              className="block rounded-[1.35rem] border border-border-secondary bg-surface-secondary/65 p-5 transition-colors hover:bg-surface-secondary"
            >
              <div className="mb-3 inline-flex h-9 w-9 items-center justify-center rounded-full border border-border-secondary bg-surface-primary/80">
                <UserPlus className="h-4 w-4 text-content-primary" />
              </div>
              <p className="text-label-caps text-content-tertiary">Referral Network</p>
              <h3 className="text-title text-content-primary">Invite Your Crew</h3>
              <p className="mt-1 text-body text-content-secondary">
                Share your invite links and bring trusted people into pre.
              </p>
            </Link>
          </section>

          {profile.interests && profile.interests.length > 0 && (
            <section className="space-y-3 animate-section-reveal" style={{ animationDelay: '180ms' }}>
              <p className="text-label-caps text-content-tertiary">Interests</p>
              <div className="flex flex-wrap gap-2">
                {profile.interests.map((interest) => (
                  <span
                    key={interest}
                    className="px-3 py-1.5 rounded-full border border-border-secondary bg-surface-secondary/60 text-caption text-content-primary"
                  >
                    {interest}
                  </span>
                ))}
              </div>
            </section>
          )}

          <Link href="/badges" className="block animate-section-reveal" style={{ animationDelay: '220ms' }}>
            <Button variant="secondary" className="w-full" data-testid="profile-badges-link">
              <Award className="h-4 w-4" />
              View Badges
            </Button>
          </Link>
        </div>
      </main>
    </div>
  )
}
