'use client'

import { PublicProfilePage } from '@/components/screens/PublicProfilePage'

export default function ProfileByUsernamePage() {
  return <PublicProfilePage />
}
