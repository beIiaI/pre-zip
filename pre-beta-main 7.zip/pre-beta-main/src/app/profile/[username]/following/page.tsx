'use client'

import { FollowListPage } from '@/components/screens/FollowListPage'

export default function ProfileFollowingPage() {
  return <FollowListPage mode="following" />
}
