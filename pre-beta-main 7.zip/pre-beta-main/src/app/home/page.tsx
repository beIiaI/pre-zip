'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { HomeHeader } from '@/components/home/header'
import { HomeTabs } from '@/components/home/tabs'
import { UpcomingPlans } from '@/components/home/upcoming-plans'
import { LoadingScreen } from '@/components/ui/spinner'

export default function HomePage() {
  const { user, profile, loading, initialized, profileLoaded } = useAuth()
  const router = useRouter()
  const booting = !initialized || loading || !profileLoaded
  const redirectTarget = !booting
    ? (!user ? '/' : (!profile || profile.onboarding_completed !== true ? '/onboarding' : null))
    : null

  useEffect(() => {
    if (redirectTarget) {
      router.replace(redirectTarget)
    }
  }, [redirectTarget, router])

  if (booting || redirectTarget || !user || !profile || profile.onboarding_completed !== true) {
    return <LoadingScreen />
  }

  const firstName = profile.full_name?.split(' ')[0] ?? profile.username ?? 'there'
  const hour = new Date().getHours()
  const greeting =
    hour < 5 ? 'Still up,' :
    hour < 12 ? 'Good morning,' :
    hour < 17 ? 'Good afternoon,' :
    hour < 21 ? 'Good evening,' :
    'Good night,'

  return (
    <div className="app-page safe-top safe-bottom">
      <HomeHeader profile={profile} />

      {/* Greeting strip */}
      <div className="mx-auto w-full max-w-[64rem] px-5 pt-5 pb-0 animate-section-reveal">
        <p className="text-caption text-content-tertiary type-eyebrow">{greeting}</p>
        <h2 className="text-title text-content-primary font-semibold">{firstName}</h2>
      </div>

      <main className="mx-auto w-full max-w-[64rem] px-4 pb-6 pt-4 sm:px-5 space-y-6">
        {/* Upcoming plans strip — only renders when user has RSVPs */}
        <UpcomingPlans />

        <HomeTabs />
      </main>
    </div>
  )
}
