'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowLeft, ChevronRight, Eye, EyeOff, Lock, UserX, MapPin as MapPinIcon, Check, Building2 } from 'lucide-react'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Divider } from '@/components/ui-circle/Divider'
import { Alert } from '@/components/ui/alert'

export default function PrivacyPage() {
  const { user, profile, loading, initialized, profileLoaded, updateProfile } = useAuth()
  const router = useRouter()
  const [error, setError] = useState<string | null>(null)
  const [redirecting, setRedirecting] = useState(false)

  useEffect(() => {
    if (!initialized || loading || !profileLoaded) return
    if (!user) {
      setRedirecting(true)
      router.replace('/')
    }
  }, [initialized, loading, profileLoaded, user, router])

  const [profileVisibility, setProfileVisibility] = useState<'public' | 'friends' | 'private'>('public')
  const [messageRequests, setMessageRequests] = useState<'everyone' | 'friends' | 'off'>('everyone')
  const [activityStatus, setActivityStatus] = useState(true)
  const [readReceipts, setReadReceipts] = useState(true)
  const [locationSharing, setLocationSharing] = useState(true)
  const [searchable, setSearchable] = useState(true)
  const [showCollege, setShowCollege] = useState(false)

  useEffect(() => {
    if (!profile) return
    setProfileVisibility((profile.profile_visibility as 'public' | 'friends' | 'private') || 'public')
    setMessageRequests((profile.message_requests as 'everyone' | 'friends' | 'off') || 'everyone')
    setActivityStatus(profile.show_activity_status ?? true)
    setReadReceipts(profile.show_read_receipts ?? true)
    setLocationSharing(profile.show_location ?? true)
    setSearchable(profile.discoverable ?? true)
    setShowCollege(profile.show_college ?? false)
  }, [profile])

  if (!initialized || loading || !profileLoaded || redirecting) {
    return <LoadingScreen />
  }

  if (!user) {
    return <LoadingScreen />
  }

  const applyUpdate = async (updates: Record<string, unknown>, rollback: () => void) => {
    setError(null)
    const { error: updateError } = await updateProfile(updates)
    if (updateError) {
      rollback()
      setError(updateError.message)
    }
  }

  const updateProfileVisibility = (value: 'public' | 'friends' | 'private') => {
    const prev = profileVisibility
    setProfileVisibility(value)
    applyUpdate({ profile_visibility: value }, () => setProfileVisibility(prev))
  }

  const updateMessageRequests = (value: 'everyone' | 'friends' | 'off') => {
    const prev = messageRequests
    setMessageRequests(value)
    applyUpdate({ message_requests: value }, () => setMessageRequests(prev))
  }

  const toggleActivityStatus = () => {
    const next = !activityStatus
    setActivityStatus(next)
    applyUpdate({ show_activity_status: next }, () => setActivityStatus(!next))
  }

  const toggleReadReceipts = () => {
    const next = !readReceipts
    setReadReceipts(next)
    applyUpdate({ show_read_receipts: next }, () => setReadReceipts(!next))
  }

  const toggleLocationSharing = () => {
    const next = !locationSharing
    setLocationSharing(next)
    applyUpdate({ show_location: next }, () => setLocationSharing(!next))
  }

  const toggleSearchable = () => {
    const next = !searchable
    setSearchable(next)
    applyUpdate({ discoverable: next }, () => setSearchable(!next))
  }

  const toggleShowCollege = () => {
    if (profile?.university_verified !== true) return
    const next = !showCollege
    setShowCollege(next)
    applyUpdate({ show_college: next }, () => setShowCollege(!next))
  }

  return (
    <div className="min-h-screen bg-surface-primary safe-top safe-bottom flex flex-col">
      <div className="px-6 pt-14 pb-4 border-b border-border-secondary">
        <div className="flex items-center gap-4">
          <button
            onClick={() => {
              router.back()
            }}
            className="w-10 h-10 rounded-full bg-surface-secondary flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-content-primary" strokeWidth={1.5} />
          </button>
          <h1 className="text-[24px] leading-tight text-content-primary">Privacy</h1>
        </div>
      </div>

      {error && (
        <div className="px-6 pt-4">
          <Alert variant="error" dismissible onDismiss={() => setError(null)}>
            {error}
          </Alert>
        </div>
      )}

      <div className="flex-1 overflow-y-auto pb-24">
        <div className="px-6 py-6">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-surface-secondary flex items-center justify-center flex-shrink-0">
                {profileVisibility === 'public' ? (
                  <Eye className="w-5 h-5 text-content-primary" strokeWidth={1.5} />
                ) : (
                  <EyeOff className="w-5 h-5 text-content-primary" strokeWidth={1.5} />
                )}
              </div>
              <div>
                <h4 className="text-content-primary">Profile Visibility</h4>
                <p className="text-sm text-content-secondary">Who can see your profile</p>
              </div>
            </div>
          </div>
          <div className="space-y-2 ml-12">
            <button
              onClick={() => updateProfileVisibility('public')}
              className={`w-full p-3 rounded-xl border text-left transition-colors ${
                profileVisibility === 'public'
                  ? 'border-border-primary bg-surface-secondary'
                  : 'border-border-secondary'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm text-content-primary">Public</span>
                {profileVisibility === 'public' && (
                  <Check className="w-4 h-4 text-content-primary" strokeWidth={2} />
                )}
              </div>
            </button>
            <button
              onClick={() => updateProfileVisibility('friends')}
              className={`w-full p-3 rounded-xl border text-left transition-colors ${
                profileVisibility === 'friends'
                  ? 'border-border-primary bg-surface-secondary'
                  : 'border-border-secondary'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm text-content-primary">Friends Only</span>
                {profileVisibility === 'friends' && (
                  <Check className="w-4 h-4 text-content-primary" strokeWidth={2} />
                )}
              </div>
            </button>
            <button
              onClick={() => updateProfileVisibility('private')}
              className={`w-full p-3 rounded-xl border text-left transition-colors ${
                profileVisibility === 'private'
                  ? 'border-border-primary bg-surface-secondary'
                  : 'border-border-secondary'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm text-content-primary">Private</span>
                {profileVisibility === 'private' && (
                  <Check className="w-4 h-4 text-content-primary" strokeWidth={2} />
                )}
              </div>
            </button>
          </div>
        </div>

        <Divider spacing="none" />

        <div className="px-6 py-6">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-surface-secondary flex items-center justify-center flex-shrink-0">
                <Lock className="w-5 h-5 text-content-primary" strokeWidth={1.5} />
              </div>
              <div>
                <h4 className="text-content-primary">Message Requests</h4>
                <p className="text-sm text-content-secondary">Who can message you</p>
              </div>
            </div>
          </div>
          <div className="space-y-2 ml-12">
            <button
              onClick={() => updateMessageRequests('everyone')}
              className={`w-full p-3 rounded-xl border text-left transition-colors ${
                messageRequests === 'everyone'
                  ? 'border-border-primary bg-surface-secondary'
                  : 'border-border-secondary'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm text-content-primary">Everyone</span>
                {messageRequests === 'everyone' && (
                  <Check className="w-4 h-4 text-content-primary" strokeWidth={2} />
                )}
              </div>
            </button>
            <button
              onClick={() => updateMessageRequests('friends')}
              className={`w-full p-3 rounded-xl border text-left transition-colors ${
                messageRequests === 'friends'
                  ? 'border-border-primary bg-surface-secondary'
                  : 'border-border-secondary'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm text-content-primary">Friends Only</span>
                {messageRequests === 'friends' && (
                  <Check className="w-4 h-4 text-content-primary" strokeWidth={2} />
                )}
              </div>
            </button>
            <button
              onClick={() => updateMessageRequests('off')}
              className={`w-full p-3 rounded-xl border text-left transition-colors ${
                messageRequests === 'off'
                  ? 'border-border-primary bg-surface-secondary'
                  : 'border-border-secondary'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm text-content-primary">Off</span>
                {messageRequests === 'off' && (
                  <Check className="w-4 h-4 text-content-primary" strokeWidth={2} />
                )}
              </div>
            </button>
          </div>
        </div>

        <Divider spacing="none" />

        <div className="px-6 py-6 space-y-3">
          <button
            onClick={toggleActivityStatus}
            className="w-full p-4 rounded-xl border border-border-secondary text-left"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-surface-secondary flex items-center justify-center">
                  <div className={`w-2 h-2 rounded-full ${activityStatus ? 'bg-green-500' : 'bg-content-tertiary'}`} />
                </div>
                <div>
                  <h4 className="text-content-primary">Activity Status</h4>
                  <p className="text-sm text-content-secondary">Show when you're active</p>
                </div>
              </div>
              <div className={`w-11 h-6 rounded-full transition-colors ${activityStatus ? 'bg-content-primary' : 'bg-surface-tertiary'}`}>
                <div className={`w-5 h-5 bg-surface-primary rounded-full shadow-sm transition-transform ${activityStatus ? 'translate-x-5' : 'translate-x-0.5'} translate-y-0.5`} />
              </div>
            </div>
          </button>

          <button
            onClick={toggleReadReceipts}
            className="w-full p-4 rounded-xl border border-border-secondary text-left"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-surface-secondary flex items-center justify-center">
                  <Check className="w-5 h-5 text-content-primary" strokeWidth={1.5} />
                </div>
                <div>
                  <h4 className="text-content-primary">Read Receipts</h4>
                  <p className="text-sm text-content-secondary">Show when you've read messages</p>
                </div>
              </div>
              <div className={`w-11 h-6 rounded-full transition-colors ${readReceipts ? 'bg-content-primary' : 'bg-surface-tertiary'}`}>
                <div className={`w-5 h-5 bg-surface-primary rounded-full shadow-sm transition-transform ${readReceipts ? 'translate-x-5' : 'translate-x-0.5'} translate-y-0.5`} />
              </div>
            </div>
          </button>

          <button
            onClick={toggleLocationSharing}
            className="w-full p-4 rounded-xl border border-border-secondary text-left"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-surface-secondary flex items-center justify-center">
                  <MapPinIcon className="w-5 h-5 text-content-primary" strokeWidth={1.5} />
                </div>
                <div>
                  <h4 className="text-content-primary">Location Sharing</h4>
                  <p className="text-sm text-content-secondary">Share your city with others</p>
                </div>
              </div>
              <div className={`w-11 h-6 rounded-full transition-colors ${locationSharing ? 'bg-content-primary' : 'bg-surface-tertiary'}`}>
                <div className={`w-5 h-5 bg-surface-primary rounded-full shadow-sm transition-transform ${locationSharing ? 'translate-x-5' : 'translate-x-0.5'} translate-y-0.5`} />
              </div>
            </div>
          </button>

          <button
            onClick={toggleSearchable}
            className="w-full p-4 rounded-xl border border-border-secondary text-left"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-surface-secondary flex items-center justify-center">
                  <Eye className="w-5 h-5 text-content-primary" strokeWidth={1.5} />
                </div>
                <div>
                  <h4 className="text-content-primary">Discoverable</h4>
                  <p className="text-sm text-content-secondary">Allow others to find you by search</p>
                </div>
              </div>
              <div className={`w-11 h-6 rounded-full transition-colors ${searchable ? 'bg-content-primary' : 'bg-surface-tertiary'}`}>
                <div className={`w-5 h-5 bg-surface-primary rounded-full shadow-sm transition-transform ${searchable ? 'translate-x-5' : 'translate-x-0.5'} translate-y-0.5`} />
              </div>
            </div>
          </button>

          <button
            onClick={toggleShowCollege}
            disabled={profile?.university_verified !== true}
            className={`w-full p-4 rounded-xl border text-left ${
              profile?.university_verified === true
                ? 'border-border-secondary'
                : 'border-border-secondary opacity-60 cursor-not-allowed'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-surface-secondary flex items-center justify-center">
                  <Building2 className="w-5 h-5 text-content-primary" strokeWidth={1.5} />
                </div>
                <div>
                  <h4 className="text-content-primary">Show College</h4>
                  <p className="text-sm text-content-secondary">
                    Show your college on profile when selected
                  </p>
                </div>
              </div>
              <div className={`w-11 h-6 rounded-full transition-colors ${showCollege ? 'bg-content-primary' : 'bg-surface-tertiary'}`}>
                <div className={`w-5 h-5 bg-surface-primary rounded-full shadow-sm transition-transform ${showCollege ? 'translate-x-5' : 'translate-x-0.5'} translate-y-0.5`} />
              </div>
            </div>
          </button>
        </div>

        <Divider spacing="none" />

        <div className="px-6 py-6">
          <button
            className="w-full p-4 rounded-xl border border-border-secondary text-left"
            onClick={() => router.push('/settings/privacy/blocked')}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-surface-secondary flex items-center justify-center">
                  <UserX className="w-5 h-5 text-content-primary" strokeWidth={1.5} />
                </div>
                <div>
                  <h4 className="text-content-primary">Blocked Users</h4>
                  <p className="text-sm text-content-secondary">Manage blocked accounts</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-content-tertiary" strokeWidth={1.5} />
            </div>
          </button>
        </div>
      </div>
    </div>
  )
}
