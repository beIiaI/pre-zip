'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Button } from '@/components/ui/button'
import { Alert } from '@/components/ui/alert'
import { ArrowLeft } from 'lucide-react'

type AccessApplication = {
  id: string
  email: string
  full_name: string | null
  note: string | null
  status: 'pending' | 'approved' | 'rejected'
  created_at: string
}

export default function AccessReviewPage() {
  const { user, profile, loading, initialized } = useAuth()
  const router = useRouter()
  const [items, setItems] = useState<AccessApplication[]>([])
  const [error, setError] = useState<string | null>(null)
  const [savingId, setSavingId] = useState<string | null>(null)
  const [pageLoading, setPageLoading] = useState(true)

  useEffect(() => {
    if (!initialized || loading) return
    if (!user || !profile?.is_internal) {
      router.replace('/settings')
      return
    }

    let active = true
    fetch('/api/access/applications?status=pending', { cache: 'no-store' })
      .then(async (res) => {
        const payload = await res.json().catch(() => ({}))
        if (!res.ok) {
          throw new Error(payload?.error || 'Unable to load queue')
        }
        return payload
      })
      .then((payload) => {
        if (!active) return
        setItems(Array.isArray(payload?.applications) ? payload.applications : [])
      })
      .catch((err) => {
        if (!active) return
        setError(err instanceof Error ? err.message : 'Unable to load queue')
      })
      .finally(() => {
        if (active) setPageLoading(false)
      })

    return () => {
      active = false
    }
  }, [initialized, loading, profile?.is_internal, router, user])

  const setStatus = async (id: string, status: 'approved' | 'rejected') => {
    setError(null)
    setSavingId(id)
    try {
      const response = await fetch('/api/access/applications', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status }),
      })
      const payload = await response.json().catch(() => ({}))
      if (!response.ok) {
        throw new Error(payload?.error || 'Unable to update request')
      }
      setItems((current) => current.filter((item) => item.id !== id))
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to update request')
    } finally {
      setSavingId(null)
    }
  }

  if (!initialized || loading || pageLoading) {
    return <LoadingScreen />
  }

  return (
    <div className="app-page safe-top safe-bottom">
      <header className="app-header px-4 py-4 flex items-center justify-between">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">Membership Queue</h1>
        <div className="w-9" />
      </header>

      <main className="app-content space-y-4">
        {error && (
          <Alert variant="error" dismissible onDismiss={() => setError(null)}>
            {error}
          </Alert>
        )}

        {items.length === 0 ? (
          <div className="surface-block p-5">
            <p className="text-body text-content-secondary">No pending vetted access requests.</p>
          </div>
        ) : (
          items.map((item) => (
            <div key={item.id} className="surface-block p-5 space-y-3">
              <div>
                <p className="text-headline text-content-primary">{item.full_name || item.email}</p>
                <p className="text-caption text-content-secondary">{item.email}</p>
                <p className="text-caption text-content-tertiary">
                  Submitted {new Date(item.created_at).toLocaleString()}
                </p>
              </div>
              {item.note && (
                <p className="text-body text-content-secondary whitespace-pre-wrap">{item.note}</p>
              )}
              <div className="grid grid-cols-2 gap-3">
                <Button
                  variant="secondary"
                  className="w-full"
                  disabled={savingId === item.id}
                  onClick={() => setStatus(item.id, 'rejected')}
                >
                  Reject
                </Button>
                <Button
                  className="w-full"
                  loading={savingId === item.id}
                  disabled={savingId === item.id}
                  onClick={() => setStatus(item.id, 'approved')}
                >
                  Approve
                </Button>
              </div>
            </div>
          ))
        )}
      </main>
    </div>
  )
}
