'use client'

import { useRouter } from 'next/navigation'
import { ArrowLeft, Mail, Shield, Calendar, AlertTriangle, User, Lock } from 'lucide-react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'

const sections = [
  {
    title: 'Account',
    icon: User,
    items: [
      {
        question: 'Update your profile',
        answer: 'Go to Profile > Edit Profile to change your name, bio, or avatar.',
        link: '/profile/edit',
      },
      {
        question: 'Reset your password',
        answer: 'Use the Sign In screen to request a password reset email.',
        link: '/auth?mode=signin',
      },
      {
        question: 'Invite-only access',
        answer: 'Members can nominate in batches of 5 from Settings > Invite Users.',
        link: '/settings/invites',
      },
    ],
  },
  {
    title: 'Verification',
    icon: Shield,
    items: [
      {
        question: 'University verification',
        answer: 'Add your university email to unlock campus-only events and features.',
        link: '/settings/safety-verification',
      },
    ],
  },
  {
    title: 'Events',
    icon: Calendar,
    items: [
      {
        question: 'Create an event',
        answer: 'Tap the + button in Events to host a public or campus-only event.',
        link: '/events/new',
      },
      {
        question: 'RSVP status',
        answer: 'Your RSVP is visible on the event detail screen and in your Events list.',
        link: '/events',
      },
    ],
  },
  {
    title: 'Safety',
    icon: AlertTriangle,
    items: [
      {
        question: 'Emergency contacts',
        answer: 'Add trusted contacts so they can receive your panic alerts.',
        link: '/settings/safety-verification',
      },
      {
        question: 'Blocked users',
        answer: 'Manage your block list from Privacy settings.',
        link: '/settings/privacy/blocked',
      },
    ],
  },
  {
    title: 'Reporting & Blocking',
    icon: Lock,
    items: [
      {
        question: 'Report a profile',
        answer: 'Open any profile and use the Report option in the overflow menu.',
        link: '/settings/privacy',
      },
    ],
  },
]

export default function HelpSupportPage() {
  const router = useRouter()

  return (
    <div className="app-page safe-top safe-bottom">
      <header className="app-header px-4 py-4 flex items-center justify-between">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
          aria-label="Back"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">Help & Support</h1>
        <div className="w-9" />
      </header>

      <main className="app-content space-y-6">
        {sections.map((section) => {
          const Icon = section.icon
          return (
            <section key={section.title} className="app-section">
              <div className="flex items-center gap-2 app-section-label">
                <Icon className="h-4 w-4" />
                <span>{section.title}</span>
              </div>
              <div className="space-y-3">
                {section.items.map((item) => (
                  <div
                    key={item.question}
                    className="surface-block p-4"
                  >
                    <p className="text-body font-medium text-content-primary">{item.question}</p>
                    <p className="mt-1 text-callout text-content-secondary">{item.answer}</p>
                    <div className="mt-3">
                      <Link
                        href={item.link}
                        className="text-callout text-content-primary underline"
                      >
                        Go to {section.title}
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )
        })}

        <section className="app-section">
          <div className="flex items-center gap-2 app-section-label">
            <Mail className="h-4 w-4" />
            <span>Contact</span>
          </div>
          <div className="surface-block p-4 space-y-3">
            <p className="text-callout text-content-secondary">
              Need help with your account or an urgent safety issue? Reach us directly.
            </p>
            <Button
              variant="secondary"
              className="w-full"
              onClick={() => {
                if (typeof window !== 'undefined') {
                  window.location.href = 'mailto:support@presocial.app?subject=Pre%20Support'
                }
              }}
            >
              Contact Support
            </Button>
          </div>
        </section>
      </main>
    </div>
  )
}
