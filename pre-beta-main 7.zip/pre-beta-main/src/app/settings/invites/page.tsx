'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowLeft, CheckCircle2, Clock3, Copy, Link2, Share2, Sparkles, UserPlus, XCircle } from 'lucide-react'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Alert } from '@/components/ui/alert'
import { validateEmail } from '@/lib/utils'

type InviteItem = {
  id: string
  invitee_email: string | null
  invitee_name: string | null
  invite_code: string
  status: 'pending' | 'accepted' | 'revoked' | 'expired'
  accepted_member_label: string | null
  signed_up: boolean
  created_at: string
  expires_at: string | null
  accepted_at: string | null
}

type InviteListResponse = {
  invites: InviteItem[]
  remaining: number | null
  used: number
  pending: number
  acceptedCount: number
  max: number | null
  baseMax: number
  refreshCount: number
  isFounder: boolean
  canRefresh: boolean
}

const defaultStats: Pick<
  InviteListResponse,
  'remaining' | 'used' | 'pending' | 'acceptedCount' | 'max' | 'baseMax' | 'refreshCount' | 'isFounder' | 'canRefresh'
> = {
  remaining: 0,
  used: 0,
  pending: 0,
  acceptedCount: 0,
  max: 5,
  baseMax: 5,
  refreshCount: 0,
  isFounder: false,
  canRefresh: false,
}

function formatInviteDate(value: string | null) {
  if (!value) return null
  return new Date(value).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  })
}

function maskEmail(value: string) {
  const [localPart, domain] = value.split('@')
  if (!localPart || !domain) return value
  if (localPart.length <= 2) {
    return `${localPart[0] ?? '*'}*@${domain}`
  }
  return `${localPart[0]}${'*'.repeat(Math.min(4, localPart.length - 2))}${localPart[localPart.length - 1]}@${domain}`
}

export default function InviteUsersPage() {
  const { user, loading, initialized } = useAuth()
  const router = useRouter()
  const [redirecting, setRedirecting] = useState(false)
  const [invitesLoading, setInvitesLoading] = useState(true)
  const [creatingInvite, setCreatingInvite] = useState(false)
  const [refreshingInvites, setRefreshingInvites] = useState(false)
  const [revokingInviteId, setRevokingInviteId] = useState<string | null>(null)
  const [copyingInviteId, setCopyingInviteId] = useState<string | null>(null)
  const [sharingInviteId, setSharingInviteId] = useState<string | null>(null)
  const [inviteEmail, setInviteEmail] = useState('')
  const [inviteeName, setInviteeName] = useState('')
  const [invites, setInvites] = useState<InviteItem[]>([])
  const [stats, setStats] = useState(defaultStats)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  useEffect(() => {
    if (!initialized || loading) return
    if (!user) {
      setRedirecting(true)
      router.replace('/')
    }
  }, [initialized, loading, user, router])

  const loadInvites = useCallback(async () => {
    setError(null)
    setInvitesLoading(true)
    try {
      const response = await fetch('/api/invites/list', {
        method: 'GET',
        cache: 'no-store',
      })
      const data = (await response.json().catch(() => ({}))) as Partial<InviteListResponse> & { error?: string }
      if (!response.ok) {
        throw new Error(data.error || 'Unable to load invitations.')
      }
      setInvites(data.invites ?? [])
      setStats({
        remaining: data.remaining ?? (data.isFounder ? null : 0),
        used: data.used ?? 0,
        pending: data.pending ?? 0,
        acceptedCount: data.acceptedCount ?? 0,
        max: data.max ?? (data.isFounder ? null : 5),
        baseMax: data.baseMax ?? 5,
        refreshCount: data.refreshCount ?? 0,
        isFounder: !!data.isFounder,
        canRefresh: !!data.canRefresh,
      })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load invitations.')
    } finally {
      setInvitesLoading(false)
    }
  }, [])

  useEffect(() => {
    if (!user) return
    loadInvites()
  }, [user, loadInvites])

  const baseInviteUrl = useMemo(() => {
    if (typeof window === 'undefined') return null
    return `${window.location.origin}/auth?mode=signup&invite=`
  }, [])

  const buildInviteLink = useCallback((inviteCode: string) => {
    if (!baseInviteUrl) return null
    return `${baseInviteUrl}${encodeURIComponent(inviteCode)}`
  }, [baseInviteUrl])

  const copyInviteLink = async (inviteId: string, inviteCode: string) => {
    const inviteUrl = buildInviteLink(inviteCode)
    if (!inviteUrl) return
    setCopyingInviteId(inviteId)
    setError(null)
    setSuccess(null)
    try {
      if (!navigator.clipboard?.writeText) {
        throw new Error('Clipboard is unavailable')
      }
      await navigator.clipboard.writeText(inviteUrl)
      setSuccess('Invite link copied.')
    } catch {
      setError('Unable to copy invite link on this device.')
    } finally {
      setCopyingInviteId(null)
    }
  }

  const shareInviteLink = async (inviteId: string, inviteCode: string) => {
    const inviteUrl = buildInviteLink(inviteCode)
    if (!inviteUrl) return

    setSharingInviteId(inviteId)
    setError(null)
    setSuccess(null)

    try {
      if (typeof navigator.share === 'function') {
        await navigator.share({
          title: 'Join me on pre',
          text: 'Use my nomination link to join pre.',
          url: inviteUrl,
        })
        setSuccess('Invite link shared.')
        return
      }

      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(inviteUrl)
        setSuccess('Share is unavailable here. Invite link copied instead.')
        return
      }

      throw new Error('Sharing unavailable')
    } catch (err) {
      if (err instanceof Error && err.name === 'AbortError') {
        return
      }
      setError('Unable to share invite link on this device.')
    } finally {
      setSharingInviteId(null)
    }
  }

  const handleCreateInvite = async () => {
    setError(null)
    setSuccess(null)
    const email = inviteEmail.trim().toLowerCase()
    if (email && !validateEmail(email)) {
      setError('Enter a valid email or leave it blank to create an open invite link.')
      return
    }
    if (!stats.isFounder && (stats.remaining ?? 0) <= 0) {
      setError('You have used all nomination slots.')
      return
    }

    setCreatingInvite(true)
    try {
      const response = await fetch('/api/invites/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: email || undefined,
          name: inviteeName.trim(),
        }),
      })
      const data = await response.json().catch(() => ({}))
      if (!response.ok) {
        throw new Error(data?.error || 'Unable to create invite.')
      }
      setInviteEmail('')
      setInviteeName('')
      const createdInvite = data?.invite as InviteItem | undefined
      const inviteUrl = typeof data?.inviteUrl === 'string' ? data.inviteUrl : (createdInvite ? buildInviteLink(createdInvite.invite_code) : null)

      if (data?.reused) {
        setSuccess('Active invite already existed. Reusing the same link.')
      } else {
        setSuccess(email ? 'Invite link reserved for that email.' : 'Open invite link created.')
      }

      if (inviteUrl && typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(inviteUrl)
        setSuccess((email ? 'Invite link created' : 'Open invite link created') + '. Link copied.')
      }
      await loadInvites()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to create invite.')
    } finally {
      setCreatingInvite(false)
    }
  }

  const handleRefreshInvites = async () => {
    setError(null)
    setSuccess(null)
    setRefreshingInvites(true)
    try {
      const response = await fetch('/api/invites/refresh', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      })
      const data = await response.json().catch(() => ({}))
      if (!response.ok) {
        throw new Error(data?.error || 'Unable to refresh referrals.')
      }
      setSuccess(data?.message || 'Referrals refreshed.')
      await loadInvites()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to refresh referrals.')
    } finally {
      setRefreshingInvites(false)
    }
  }

  const handleRevokeInvite = async (inviteId: string) => {
    setError(null)
    setSuccess(null)
    setRevokingInviteId(inviteId)
    try {
      const response = await fetch('/api/invites/revoke', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ inviteId }),
      })
      const data = await response.json().catch(() => ({}))
      if (!response.ok) {
        throw new Error(data?.error || 'Unable to revoke invite.')
      }
      setSuccess('Invite revoked.')
      await loadInvites()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to revoke invite.')
    } finally {
      setRevokingInviteId(null)
    }
  }

  if (!initialized || loading || redirecting) {
    return <LoadingScreen />
  }

  if (!user) {
    return <LoadingScreen />
  }

  return (
    <div className="app-page safe-top safe-bottom">
      <header className="app-header px-4 py-4 flex items-center justify-between">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
          aria-label="Back"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">Invite Users</h1>
        <div className="w-9" />
      </header>

      <main className="app-content space-y-5">
          <section className="surface-block p-4 space-y-3">
            <div className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-surface-primary border border-border-secondary">
              <Sparkles className="h-4 w-4 text-content-primary" />
            </div>
            <div className="space-y-1">
              <h2 className="text-body font-medium text-content-primary">Private Member Access</h2>
              <p className="text-caption text-content-secondary">
                {stats.isFounder
                  ? 'pre is invite-only. Founder accounts have unlimited private referral links.'
                  : `pre is invite-only. Each member can nominate in batches of ${stats.baseMax} people.`}
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2 text-center sm:grid-cols-4">
              <div className="rounded-xl border border-border-secondary bg-surface-primary px-2 py-2">
                <p className="text-caption text-content-tertiary">Remaining</p>
                <p className="text-body text-content-primary">{stats.isFounder ? '∞' : stats.remaining ?? 0}</p>
              </div>
              <div className="rounded-xl border border-border-secondary bg-surface-primary px-2 py-2">
                <p className="text-caption text-content-tertiary">Pending</p>
                <p className="text-body text-content-primary">{stats.pending}</p>
              </div>
              <div className="rounded-xl border border-border-secondary bg-surface-primary px-2 py-2">
                <p className="text-caption text-content-tertiary">Accepted</p>
                <p className="text-body text-content-primary">{stats.acceptedCount}</p>
              </div>
              <div className="rounded-xl border border-border-secondary bg-surface-primary px-2 py-2">
                <p className="text-caption text-content-tertiary">Capacity</p>
                <p className="text-body text-content-primary">{stats.isFounder ? 'Unlimited' : stats.max ?? stats.baseMax}</p>
              </div>
            </div>
            {!stats.isFounder && (
              <p className="text-caption text-content-tertiary">
                Refreshes used: {stats.refreshCount}
              </p>
            )}
          </section>

          {error && (
            <Alert variant="error" dismissible onDismiss={() => setError(null)}>
              {error}
            </Alert>
          )}
          {success && (
            <Alert variant="success" dismissible onDismiss={() => setSuccess(null)}>
              {success}
            </Alert>
          )}

          <section className="surface-block p-4 space-y-3">
            <h3 className="text-body font-medium text-content-primary">Create invite link</h3>
            <Input
              type="email"
              label="Invitee email (optional)"
              placeholder="name@domain.com"
              value={inviteEmail}
              onChange={(event) => setInviteEmail(event.target.value)}
              autoComplete="email"
              hint="Leave blank to create an open invite link you can share anywhere."
            />
            <Input
              type="text"
              label="Name (optional)"
              placeholder="Full name"
              value={inviteeName}
              onChange={(event) => setInviteeName(event.target.value)}
              maxLength={80}
            />
            <Button
              className="w-full"
              onClick={handleCreateInvite}
              loading={creatingInvite}
              disabled={creatingInvite || (!stats.isFounder && (stats.remaining ?? 0) <= 0)}
            >
              <UserPlus className="h-4 w-4" />
              Create Link
            </Button>
          </section>

          {!stats.isFounder && (
            <section className="surface-block p-4 space-y-3">
              <h3 className="text-body font-medium text-content-primary">Refresh referrals</h3>
              <p className="text-caption text-content-secondary">
                Once all current slots are accepted, refresh to unlock {stats.baseMax} additional referrals.
              </p>
              <Button
                type="button"
                variant="secondary"
                className="w-full"
                onClick={handleRefreshInvites}
                loading={refreshingInvites}
                disabled={refreshingInvites || !stats.canRefresh}
              >
                {stats.canRefresh ? `Refresh (+${stats.baseMax})` : 'Not available yet'}
              </Button>
            </section>
          )}

          <section className="surface-block p-4 space-y-3">
            <h3 className="text-body font-medium text-content-primary">Your invite links</h3>
            {invitesLoading ? (
              <p className="text-caption text-content-secondary">Loading invites...</p>
            ) : invites.length === 0 ? (
              <p className="text-caption text-content-secondary">No invite links yet.</p>
            ) : (
              <div className="space-y-3">
                {invites.map((invite) => {
                  const inviteExpired =
                    invite.status === 'pending' &&
                    !!invite.expires_at &&
                    new Date(invite.expires_at).getTime() < Date.now()
                  const statusLabel = inviteExpired ? 'expired' : invite.status
                  const isPending = statusLabel === 'pending'
                  const primaryLabel =
                    statusLabel === 'accepted'
                      ? invite.accepted_member_label || 'Used by invited member'
                      : invite.invitee_name || (invite.invitee_email ? maskEmail(invite.invitee_email) : 'Open invite link')

                  const secondaryLabel =
                    statusLabel === 'accepted'
                      ? 'Signed up successfully'
                      : invite.invitee_email
                        ? invite.invitee_name
                          ? maskEmail(invite.invitee_email)
                          : 'Reserved invite'
                        : 'First signup that claims this code gets the slot.'
                  return (
                    <div
                      key={invite.id}
                      className="rounded-[0.95rem] border border-border-secondary bg-surface-primary/70 p-3 space-y-2"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="text-callout text-content-primary">{primaryLabel}</p>
                          <p className="text-caption text-content-secondary">{secondaryLabel}</p>
                        </div>
                        <span
                          className={`inline-flex items-center gap-1 rounded-full px-2 py-1 text-[11px] uppercase tracking-[0.1em] ${
                            statusLabel === 'accepted'
                              ? 'bg-success/15 text-success'
                              : statusLabel === 'pending'
                                ? 'bg-accent-muted text-content-primary'
                                : 'bg-surface-tertiary text-content-tertiary'
                          }`}
                        >
                          {statusLabel === 'accepted' ? (
                            <CheckCircle2 className="h-3.5 w-3.5" />
                          ) : statusLabel === 'pending' ? (
                            <Clock3 className="h-3.5 w-3.5" />
                          ) : (
                            <XCircle className="h-3.5 w-3.5" />
                          )}
                          {statusLabel}
                        </span>
                      </div>
                      <div className="flex items-center gap-1 text-caption text-content-tertiary">
                        <Link2 className="h-3.5 w-3.5" />
                        <span>Code: {invite.invite_code}</span>
                      </div>
                      <div className="text-caption text-content-tertiary">
                        Sent {formatInviteDate(invite.created_at)}
                        {invite.accepted_at ? ` • Accepted ${formatInviteDate(invite.accepted_at)}` : ''}
                        {!invite.accepted_at && invite.expires_at ? ` • Expires ${formatInviteDate(invite.expires_at)}` : ''}
                      </div>
                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                        <Button
                          type="button"
                          variant="secondary"
                          className="w-full"
                          onClick={() => copyInviteLink(invite.id, invite.invite_code)}
                          disabled={!!copyingInviteId || !!sharingInviteId || !isPending}
                        >
                          <Copy className="h-4 w-4" />
                          {copyingInviteId === invite.id ? 'Copying...' : 'Copy Link'}
                        </Button>
                        <Button
                          type="button"
                          variant="secondary"
                          className="w-full"
                          onClick={() => shareInviteLink(invite.id, invite.invite_code)}
                          disabled={!!sharingInviteId || !!copyingInviteId || !isPending}
                        >
                          <Share2 className="h-4 w-4" />
                          {sharingInviteId === invite.id ? 'Sharing...' : 'Share Link'}
                        </Button>
                        {isPending && (
                          <Button
                            type="button"
                            variant="outline"
                            className="w-full sm:col-span-2"
                            onClick={() => handleRevokeInvite(invite.id)}
                            disabled={revokingInviteId === invite.id}
                          >
                            {revokingInviteId === invite.id ? 'Revoking...' : 'Revoke'}
                          </Button>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </section>
      </main>
    </div>
  )
}
