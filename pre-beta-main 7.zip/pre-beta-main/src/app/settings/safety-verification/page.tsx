'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { SafetyVerification } from '@/components/screens/SafetyVerification'

export default function SafetyVerificationPage() {
  const { user, loading, initialized } = useAuth()
  const router = useRouter()
  const [redirecting, setRedirecting] = useState(false)

  useEffect(() => {
    if (!initialized || loading) return
    if (!user) {
      setRedirecting(true)
      router.replace('/')
    }
  }, [initialized, loading, user, router])

  if (!initialized || loading || redirecting) {
    return <LoadingScreen />
  }

  if (!user) {
    return <LoadingScreen />
  }

  return <SafetyVerification onBack={() => router.back()} />
}
