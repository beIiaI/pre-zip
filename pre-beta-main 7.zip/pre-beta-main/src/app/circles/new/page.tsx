'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowLeft } from 'lucide-react'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Toggle } from '@/components/ui/toggle'
import { Alert } from '@/components/ui/alert'

export default function NewCirclePage() {
  const { user, loading, initialized } = useAuth()
  const router = useRouter()
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [category, setCategory] = useState('')
  const [isPublic, setIsPublic] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!initialized || loading) return
    if (!user) {
      router.replace('/')
    }
  }, [initialized, loading, user, router])

  if (!initialized || loading) {
    return <LoadingScreen />
  }

  if (!user) {
    return <LoadingScreen />
  }

  const handleSubmit = async () => {
    if (!name.trim()) {
      setError('Circle name is required')
      return
    }
    setError(null)
    setSubmitting(true)
    try {
      const response = await fetch('/api/circles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          description: description.trim() || null,
          category: category.trim() || null,
          is_public: isPublic,
        }),
      })
      const data = await response.json()
      if (!response.ok) {
        throw new Error(data.error || 'Failed to create circle')
      }
      router.push('/home')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create circle')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-surface-primary safe-top safe-bottom">
      <header className="px-4 py-4 flex items-center justify-between border-b border-border-secondary">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">New Circle</h1>
        <div className="w-9" />
      </header>

      <main className="px-4 py-6">
        <div className="max-w-md mx-auto space-y-6">
          {error && (
            <Alert variant="error" dismissible onDismiss={() => setError(null)}>
              {error}
            </Alert>
          )}

          <Input
            label="Circle name"
            placeholder="e.g. Film photographers"
            value={name}
            onChange={(event) => setName(event.target.value)}
          />

          <div className="space-y-2">
            <label className="text-callout font-medium text-content-primary">Description</label>
            <textarea
              placeholder="What is this circle about?"
              value={description}
              onChange={(event) => setDescription(event.target.value)}
              rows={4}
              className="flex w-full rounded-input border bg-surface-secondary px-4 py-3 text-body text-content-primary placeholder:text-content-tertiary border-border-primary focus:border-border-focus focus:outline-none focus:ring-1 focus:ring-border-focus resize-none"
            />
          </div>

          <Input
            label="Category (optional)"
            placeholder="Art, fitness, music..."
            value={category}
            onChange={(event) => setCategory(event.target.value)}
          />

          <div className="rounded-card border border-border-secondary bg-surface-secondary p-4">
            <Toggle
              enabled={!isPublic}
              onChange={(value) => setIsPublic(!value)}
              label="Private circle"
              description="Only members can see private circles"
            />
          </div>

          <Button className="w-full" onClick={handleSubmit} loading={submitting}>
            Create Circle
          </Button>
        </div>
      </main>
    </div>
  )
}
