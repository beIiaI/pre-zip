'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Alert } from '@/components/ui/alert'
import { OnboardingIntro } from '@/components/onboarding/intro'
import { OnboardingName } from '@/components/onboarding/name'
import { OnboardingUsername } from '@/components/onboarding/username'
import { OnboardingIntent } from '@/components/onboarding/intent'
import { OnboardingInterests } from '@/components/onboarding/interests'
import { OnboardingDOB } from '@/components/onboarding/dob'
import { OnboardingLocation } from '@/components/onboarding/location'
import { OnboardingTheme } from '@/components/onboarding/theme'
import { OnboardingProfile } from '@/components/onboarding/profile'
import { isRestrictedBio } from '@/lib/moderation/restrictedWordsClient'
import type { Profile } from '@/types/database'

export interface OnboardingData {
  fullName: string
  username: string
  userIntent: string[]
  interests: string[]
  dateOfBirth: string
  location: string
  locationLat?: number
  locationLng?: number
  themeMode: 'light' | 'dark' | 'system'
  amoledEnabled: boolean
  avatarUrl?: string
  bio: string
}

const TOTAL_STEPS = 9

export default function OnboardingPage() {
  const { user, profile, loading, initialized, updateProfile, setProfileState, profileLoaded, refreshProfile } = useAuth()
  const router = useRouter()
  type UpdateProfileResult = Awaited<ReturnType<typeof updateProfile>>
  const [step, setStep] = useState(1)
  const [isCompleting, setIsCompleting] = useState(false)
  const [completionError, setCompletionError] = useState<string | null>(null)
  const [hasRedirected, setHasRedirected] = useState(false)
  const completionStatusRef = useRef<'idle' | 'inflight' | 'success' | 'error'>('idle')
  const completionAttemptRef = useRef(0)
  const pendingStepSaveRef = useRef<Promise<UpdateProfileResult> | null>(null)
  
  // Track if we've done initial setup
  const initialSetupDone = useRef(false)
  
  const [data, setData] = useState<OnboardingData>({
    fullName: '',
    username: '',
    userIntent: [],
    interests: [],
    dateOfBirth: '',
    location: '',
    themeMode: 'system',
    amoledEnabled: false,
    bio: '',
  })

  // Handle initial redirect logic - only runs once when initialized
  useEffect(() => {
    // Don't run until we have auth state
    if (!initialized || !profileLoaded) return
    
    // Don't run if we're in the middle of completing
    if (isCompleting) return
    
    // Don't run if we've already redirected
    if (hasRedirected) return
    
    // Not logged in -> splash page
    if (!user) {
      console.log('[Onboarding] No user, redirecting to splash')
      setHasRedirected(true)
      router.replace('/')
      return
    }
    
    // Already completed onboarding -> home
    if (profile?.onboarding_completed === true) {
      console.log('[Onboarding] Already completed, redirecting to home')
      setHasRedirected(true)
      router.replace('/home')
      return
    }

    if (profileLoaded && !profile) {
      console.log('[Onboarding] No profile row yet, waiting for ensure')
      return
    }
    
    // First time setup - restore saved progress
    if (!initialSetupDone.current && profile) {
      initialSetupDone.current = true
      
      if (profile.onboarding_step && profile.onboarding_step > 1) {
        console.log('[Onboarding] Resuming from step:', profile.onboarding_step)
        setStep(profile.onboarding_step)
        setData({
          fullName: profile.full_name || '',
          username: profile.username || '',
          userIntent: profile.user_intent || [],
          interests: profile.interests || [],
          dateOfBirth: profile.date_of_birth || '',
          location: profile.location || '',
          locationLat: profile.location_lat ?? undefined,
          locationLng: profile.location_lng ?? undefined,
          themeMode: (profile.theme_mode as 'light' | 'dark' | 'system') || 'system',
          amoledEnabled: profile.amoled_enabled || false,
          bio: profile.bio || '',
          avatarUrl: profile.avatar_url ?? undefined,
        })
      }
    }
  }, [initialized, profileLoaded, user, profile, router, isCompleting, hasRedirected])

  const updateData = useCallback((updates: Partial<OnboardingData>) => {
    setData(prev => ({ ...prev, ...updates }))
  }, [])

  const nextStep = useCallback(async () => {
    if (completionStatusRef.current === 'inflight') {
      console.log('[Onboarding] Completion in progress, ignoring next step')
      return
    }
    const nextStepNum = step + 1
    
    // Save progress to profile (fire and forget for intermediate steps)
    const savePromise = updateProfile({
      onboarding_step: nextStepNum,
      full_name: data.fullName || null,
      username: data.username || null,
      user_intent: data.userIntent,
      interests: data.interests,
      date_of_birth: data.dateOfBirth || null,
      location: data.location || null,
      location_lat: data.locationLat ?? null,
      location_lng: data.locationLng ?? null,
      theme_mode: data.themeMode,
      amoled_enabled: data.amoledEnabled,
      bio: data.bio || null,
      avatar_url: data.avatarUrl ?? null,
    }).catch(err => {
      console.error('[Onboarding] Error saving step progress:', err)
      return { error: err as Error }
    })
    pendingStepSaveRef.current = savePromise
    
    setStep(nextStepNum)
  }, [step, data, updateProfile])

  const prevStep = useCallback(() => {
    if (step > 1) {
      setStep(step - 1)
    }
  }, [step])

  const updateProfileWithRetry = useCallback(async (payload: Record<string, unknown>) => {
    const maxAttempts = 2
    let lastResult: UpdateProfileResult = { error: new Error('Unknown error') }

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      console.log(`[Onboarding] updateProfile attempt ${attempt}/${maxAttempts}`)
      const result = await updateProfile(payload)
      if (!result.error) {
        return result
      }

      lastResult = result
      const err = result.error as Error
      const name = (err as Error & { name?: string }).name || 'Error'
      const message = err.message || 'Unknown error'
      const isAbort =
        name === 'AbortError' ||
        message.includes('AbortError') ||
        message.toLowerCase().includes('aborted')

      console.warn('[Onboarding] updateProfile failed:', { attempt, name, message, isAbort })

      if (!isAbort || attempt === maxAttempts) {
        return result
      }

      await new Promise(resolve => setTimeout(resolve, 300 * attempt))
    }

    return lastResult
  }, [updateProfile])

  const completeOnboardingServer = useCallback(async (payload: Record<string, unknown>) => {
    const response = await fetch('/api/onboarding/complete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      keepalive: true,
      cache: 'no-store',
      credentials: 'include',
    })

    const data = await response.json().catch(() => ({}))

    if (!response.ok) {
      const message = typeof data?.error === 'string' ? data.error : 'Failed to complete onboarding'
      throw new Error(message)
    }

    return data as { profile?: Profile }
  }, [])

  const completeOnboarding = useCallback(async () => {
    // Prevent double-clicks or re-entry
    if (isCompleting || completionStatusRef.current === 'inflight') {
      console.log('[Onboarding] Already completing, ignoring')
      return
    }

    if (data.bio && isRestrictedBio(data.bio)) {
      completionStatusRef.current = 'error'
      setCompletionError('Bio contains restricted words.')
      return
    }
    
    completionAttemptRef.current += 1
    const attemptId = completionAttemptRef.current
    console.log(`[Onboarding] Starting completion attempt #${attemptId}...`)
    completionStatusRef.current = 'inflight'
    setIsCompleting(true)
    setCompletionError(null)
    
    try {
      if (pendingStepSaveRef.current) {
        console.log('[Onboarding] Waiting for in-flight step save to finish...')
        const priorResult = await pendingStepSaveRef.current
        pendingStepSaveRef.current = null
        if (priorResult?.error) {
          console.warn('[Onboarding] Prior step save failed (continuing):', priorResult.error)
        }
      }
      // Build the final update payload
      const updatePayload = {
        onboarding_completed: true,
        onboarding_step: TOTAL_STEPS,
        full_name: data.fullName || null,
        username: data.username || null,
        user_intent: data.userIntent,
        interests: data.interests,
        date_of_birth: data.dateOfBirth || null,
        location: data.location || null,
        location_lat: data.locationLat ?? null,
        location_lng: data.locationLng ?? null,
        theme_mode: data.themeMode,
        amoled_enabled: data.amoledEnabled,
        bio: data.bio || null,
        avatar_url: data.avatarUrl ?? null,
      }
      
      console.log('[Onboarding] Sending update:', updatePayload)
      
      let result: { profile?: Profile } | undefined
      try {
        result = await completeOnboardingServer(updatePayload)
        if (result?.profile) {
          console.log('[Onboarding] Server completion succeeded')
        } else {
          console.warn('[Onboarding] Server completion returned no profile')
        }
      } catch (error) {
        console.error('[Onboarding] Server completion failed:', error)
      }

      if (!result?.profile) {
        console.warn('[Onboarding] Falling back to client update')
        const clientResult = await updateProfileWithRetry(updatePayload)
        if (clientResult.error) {
          console.error('[Onboarding] Update failed:', clientResult.error)
          const message = clientResult.error.message || 'Unknown error'
          completionStatusRef.current = 'error'
          setCompletionError(`Failed to save profile: ${message}`)
          setIsCompleting(false)
          return
        }
        const profile = clientResult.profile ?? undefined
        result = { profile }
      }

      if (result?.profile) {
        setProfileState(result.profile)
      }

      const refreshed = await refreshProfile()
      if (refreshed) {
        setProfileState(refreshed)
      }
      
      const finalProfile = refreshed ?? result?.profile
      // Verify the profile was updated
      if (!finalProfile?.onboarding_completed) {
        console.error('[Onboarding] Profile not updated correctly:', result?.profile)
        completionStatusRef.current = 'error'
        setCompletionError('Profile update did not persist. Please try again.')
        setIsCompleting(false)
        return
      }
      
      console.log('[Onboarding] Success! Profile updated:', finalProfile)
      console.log('[Onboarding] Navigating to /home...')
      completionStatusRef.current = 'success'
      
      // Mark as redirected to prevent useEffect from interfering
      setHasRedirected(true)
      
      // Navigate to home
      router.push('/home')
      
    } catch (error) {
      console.error('[Onboarding] Exception during completion:', error)
      completionStatusRef.current = 'error'
      setCompletionError(`An error occurred: ${error instanceof Error ? error.message : 'Unknown error'}`)
      setIsCompleting(false)
    }
  }, [isCompleting, data, updateProfileWithRetry, completeOnboardingServer, setProfileState, refreshProfile, router])

  useEffect(() => {
    return () => {
      if (completionStatusRef.current === 'inflight') {
        console.warn('[Onboarding] Unmounted while completion was in-flight')
      }
    }
  }, [])

  // Show loading while initializing
  if (!initialized || loading || !profileLoaded) {
    return <LoadingScreen />
  }

  // Show loading if no user (will redirect)
  if (!user) {
    return <LoadingScreen />
  }

  // Show loading if already completed (will redirect)  
  if (profile?.onboarding_completed && !isCompleting) {
    return <LoadingScreen />
  }

  const renderStep = () => {
    switch (step) {
      case 1:
        return <OnboardingIntro onNext={nextStep} />
      case 2:
        return (
          <OnboardingName
            value={data.fullName}
            onChange={(fullName) => updateData({ fullName })}
            onNext={nextStep}
            onBack={prevStep}
          />
        )
      case 3:
        return (
          <OnboardingUsername
            value={data.username}
            onChange={(username) => updateData({ username })}
            onNext={nextStep}
            onBack={prevStep}
          />
        )
      case 4:
        return (
          <OnboardingIntent
            value={data.userIntent}
            onChange={(userIntent) => updateData({ userIntent })}
            onNext={nextStep}
            onBack={prevStep}
          />
        )
      case 5:
        return (
          <OnboardingInterests
            value={data.interests}
            onChange={(interests) => updateData({ interests })}
            onNext={nextStep}
            onBack={prevStep}
          />
        )
      case 6:
        return (
          <OnboardingDOB
            value={data.dateOfBirth}
            onChange={(dateOfBirth) => updateData({ dateOfBirth })}
            onNext={nextStep}
            onBack={prevStep}
          />
        )
      case 7:
        return (
          <OnboardingLocation
            value={data.location}
            onChange={(location, lat, lng) => updateData({ location, locationLat: lat, locationLng: lng })}
            onNext={nextStep}
            onBack={prevStep}
          />
        )
      case 8:
        return (
          <OnboardingTheme
            mode={data.themeMode}
            amoled={data.amoledEnabled}
            onChangeMode={(themeMode) => updateData({ themeMode })}
            onChangeAmoled={(amoledEnabled) => updateData({ amoledEnabled })}
            onNext={nextStep}
            onBack={prevStep}
          />
        )
      case 9:
        return (
          <OnboardingProfile
            bio={data.bio}
            avatarUrl={data.avatarUrl}
            onChangeBio={(bio) => updateData({ bio })}
            onChangeAvatar={(avatarUrl) => updateData({ avatarUrl })}
            onComplete={completeOnboarding}
            onBack={prevStep}
            isCompleting={isCompleting}
            error={completionError}
            onDismissError={() => setCompletionError(null)}
          />
        )
      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-surface-primary safe-top safe-bottom">
      <div key={`onboarding-step-${step}`} className="animate-onboarding-enter">
        {renderStep()}
      </div>
    </div>
  )
}
