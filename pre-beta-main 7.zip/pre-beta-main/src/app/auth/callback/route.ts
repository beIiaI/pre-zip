import { type EmailOtpType } from '@supabase/supabase-js'
import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createRequestId, logServerError } from '@/lib/security/api'

export const runtime = 'nodejs'

const ALLOWED_OTP_TYPES = new Set<EmailOtpType>([
  'signup',
  'invite',
  'magiclink',
  'recovery',
  'email',
  'email_change',
])

function safeNext(next: string | null, fallback = '/'): string {
  if (!next) return fallback
  if (!next.startsWith('/')) return fallback
  return next
}

function authErrorRedirect(origin: string, message: string) {
  return NextResponse.redirect(`${origin}/auth?error=${encodeURIComponent(message)}`)
}

type RecoveryReason = 'expired' | 'invalid' | 'missing'

function recoveryErrorRedirect(origin: string, reason: RecoveryReason) {
  return NextResponse.redirect(`${origin}/auth/reset/error?reason=${encodeURIComponent(reason)}`)
}

export async function GET(request: Request) {
  const requestId = createRequestId()
  const { searchParams, origin } = new URL(request.url)
  const code = searchParams.get('code')
  const tokenHash = searchParams.get('token_hash') ?? searchParams.get('token')
  const typeParam = searchParams.get('type')
  const errorCode = searchParams.get('error_code')
  const errorDescription = (searchParams.get('error_description') || '').toLowerCase()
  const type = typeParam && ALLOWED_OTP_TYPES.has(typeParam as EmailOtpType)
    ? (typeParam as EmailOtpType)
    : null

  // OAuth / PKCE callback
  if (code) {
    const next = safeNext(searchParams.get('next'), '/')
    const supabase = await createClient()
    const { error } = await supabase.auth.exchangeCodeForSession(code)
    if (!error) {
      return NextResponse.redirect(`${origin}${next}`)
    }
    logServerError('auth.callback.exchange_code', requestId, error, { next })
    return authErrorRedirect(origin, error.message || 'Could not authenticate user')
  }

  // Email-based callback (recovery/signup/magic link/etc.)
  if (tokenHash && type) {
    const fallback = type === 'recovery' ? '/auth/reset' : '/'
    const next = safeNext(searchParams.get('next'), fallback)
    const supabase = await createClient()
    const { error } = await supabase.auth.verifyOtp({
      type,
      token_hash: tokenHash,
    })

    if (!error) {
      return NextResponse.redirect(`${origin}${next}`)
    }

    if (type === 'recovery') {
      const errorText = (error.message || '').toLowerCase()
      const reason: RecoveryReason = errorText.includes('expired') ? 'expired' : 'invalid'
      logServerError('auth.callback.recovery_otp', requestId, error, { next })
      return recoveryErrorRedirect(origin, reason)
    }
    logServerError('auth.callback.verify_otp', requestId, error, { type, next })
    return authErrorRedirect(origin, error.message || 'Could not authenticate user')
  }

  const looksLikeRecoveryFailure =
    typeParam === 'recovery' ||
    safeNext(searchParams.get('next'), '') === '/auth/reset' ||
    errorDescription.includes('recovery') ||
    errorDescription.includes('reset')

  if (looksLikeRecoveryFailure) {
    if ((errorCode || '').toLowerCase().includes('expired')) {
      return recoveryErrorRedirect(origin, 'expired')
    }
    return recoveryErrorRedirect(origin, tokenHash ? 'invalid' : 'missing')
  }

  return authErrorRedirect(origin, 'Could not authenticate user')
}
