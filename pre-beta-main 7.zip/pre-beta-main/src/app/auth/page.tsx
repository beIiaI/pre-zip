'use client'

import { Suspense, useEffect, useMemo, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Alert } from '@/components/ui/alert'
import { LoadingScreen } from '@/components/ui/spinner'
import { PreLogotype } from '@/components/ui/pre-logotype'
import { validateEmail, validatePassword } from '@/lib/utils'
import { createClient } from '@/lib/supabase/client'
import { SegmentedControl } from '@/components/ui/segmented-control'
import { ChevronLeft, Check, X, Mail, Sparkles } from 'lucide-react'

type InviteDetails = {
  code: string
  inviterName: string
  inviteeEmail: string | null
  isOpenInvite?: boolean
  inviteeName: string | null
  expiresAt: string | null
}

function normalizeInviteCode(value: string) {
  return value.trim().toUpperCase().replace(/[^A-Z0-9]/g, '')
}

function AuthPageContent() {
  const [mode, setMode] = useState<'signin' | 'signup'>('signin')
  const [step, setStep] = useState<'method' | 'email' | 'otp'>('method')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [otp, setOtp] = useState('')
  const [inviteCode, setInviteCode] = useState('')
  const [inviteValidating, setInviteValidating] = useState(false)
  const [inviteDetails, setInviteDetails] = useState<InviteDetails | null>(null)
  const [accessRequestNote, setAccessRequestNote] = useState('')
  const [accessRequestLoading, setAccessRequestLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [otpLoading, setOtpLoading] = useState(false)
  const [otpResending, setOtpResending] = useState(false)
  const [forgotLoading, setForgotLoading] = useState(false)
  const [oauthLoading, setOauthLoading] = useState<'google' | 'apple' | null>(null)
  const [existingAccountEmail, setExistingAccountEmail] = useState<string | null>(null)

  const { signIn, signUp } = useAuth()
  const router = useRouter()
  const searchParams = useSearchParams()
  const supabase = useMemo(() => createClient(), [])

  const handleOAuth = async (provider: 'google' | 'apple') => {
    setError(null)
    setSuccess(null)
    if (mode === 'signup') {
      setError('Sign up is invite-only. Continue with email and your invite code.')
      return
    }
    setOauthLoading(provider)

    const { error: oauthError } = await supabase.auth.signInWithOAuth({
      provider,
      options: {
        redirectTo: `${window.location.origin}/auth/callback?next=/`,
      },
    })

    if (oauthError) {
      const message = oauthError.message || 'Unable to sign in with provider'
      const friendly = message.toLowerCase().includes('provider') || message.toLowerCase().includes('not enabled')
        ? 'Provider not configured. Enable it in Supabase Auth settings.'
        : message
      setError(friendly)
      setOauthLoading(null)
    }
  }

  const validateInviteForSignup = async (targetEmail: string) => {
    const normalizedCode = normalizeInviteCode(inviteCode)
    if (!normalizedCode) {
      setError('An invite code is required to create an account.')
      return false
    }
    if (!validateEmail(targetEmail)) {
      setError('Please enter a valid email before validating your invite.')
      return false
    }

    setInviteValidating(true)
    try {
      const response = await fetch('/api/invites/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: normalizedCode,
          email: targetEmail.trim().toLowerCase(),
        }),
      })
      const data = await response.json().catch(() => ({}))
      if (!response.ok) {
        setInviteDetails(null)
        setError(data?.error || 'Invite code is invalid or unavailable.')
        return false
      }
      const invite = data?.invite as InviteDetails | undefined
      if (!invite?.code) {
        setInviteDetails(null)
        setError('Invite validation returned an invalid response.')
        return false
      }
      setInviteCode(invite.code)
      setInviteDetails(invite)
      return true
    } catch {
      setInviteDetails(null)
      setError('Unable to validate invite right now.')
      return false
    } finally {
      setInviteValidating(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setSuccess(null)
    setExistingAccountEmail(null)

    const normalizedEmail = email.trim().toLowerCase()

    if (!validateEmail(normalizedEmail)) {
      setError('Please enter a valid email address')
      return
    }
    setEmail(normalizedEmail)

    if (mode === 'signup') {
      const passwordValidation = validatePassword(password)
      if (!passwordValidation.valid) {
        setError(passwordValidation.error || 'Invalid password')
        return
      }

      if (password !== confirmPassword) {
        setError('Passwords do not match')
        return
      }

      const inviteValid = await validateInviteForSignup(normalizedEmail)
      if (!inviteValid) {
        return
      }
    }

    setIsLoading(true)

    try {
      if (mode === 'signin') {
        const { error: signInError } = await signIn(normalizedEmail, password)
        if (signInError) {
          setError(signInError.message)
        } else {
          router.push('/')
        }
      } else {
        const result = await signUp(normalizedEmail, password)
        if (result.error) {
          const message = result.error.message || 'Unable to create account'
          if (message.toLowerCase().includes('already exists') || message.toLowerCase().includes('already registered')) {
            setError('Account already exists — please sign in')
            setExistingAccountEmail(normalizedEmail)
            setMode('signin')
          } else {
            setError(message)
          }
        } else {
          setSuccess(
            'Check your email and tap the confirmation link to finish signing up. If your inbox shows a numeric code instead, enter it below.'
          )
          setOtp('')
          setStep('otp')
        }
      }
    } catch {
      setError('An unexpected error occurred. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  const handleVerifyOtp = async () => {
    setError(null)
    setSuccess(null)
    const token = otp.replace(/\D/g, '').slice(0, 8)
    const normalizedEmail = email.trim().toLowerCase()
    if (token.length !== 8) {
      setError('Enter the verification code from your email.')
      return
    }
    if (!validateEmail(normalizedEmail)) {
      setError('Missing email for verification.')
      return
    }
    setEmail(normalizedEmail)
    setOtpLoading(true)
    try {
      const { error: verifyError } = await supabase.auth.verifyOtp({
        email: normalizedEmail,
        token,
        type: 'signup',
      })
      if (verifyError) {
        throw new Error(verifyError.message || 'Unable to verify code')
      }

      if (mode === 'signup') {
        const code = normalizeInviteCode(inviteCode)
        if (!code) {
          throw new Error('Missing invite code. Please return and try again.')
        }
        const claimResponse = await fetch('/api/invites/claim', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            code,
            email: normalizedEmail,
          }),
        })
        const claimData = await claimResponse.json().catch(() => ({}))
        if (!claimResponse.ok) {
          throw new Error(claimData?.error || 'Invite could not be finalized.')
        }
      }

      router.replace('/onboarding')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to verify code.')
    } finally {
      setOtpLoading(false)
    }
  }

  const handleResendOtp = async () => {
    setError(null)
    setSuccess(null)
    const normalizedEmail = email.trim().toLowerCase()
    if (!validateEmail(normalizedEmail)) {
      setError('Enter your email to resend the verification email.')
      return
    }
    setEmail(normalizedEmail)
    setOtpResending(true)
    try {
      const response = await fetch('/api/auth/otp/resend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: normalizedEmail }),
      })
      const data = await response.json().catch(() => ({}))
      if (!response.ok) {
        throw new Error(
          (typeof data?.error === 'string' && data.error) || 'Unable to resend verification email.'
        )
      }
      setSuccess('Verification email resent.')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to resend verification email.')
    } finally {
      setOtpResending(false)
    }
  }

  const handleForgotPassword = async () => {
    setError(null)
    setSuccess(null)
    const normalizedEmail = email.trim().toLowerCase()
    if (!validateEmail(normalizedEmail)) {
      setError('Enter your email to reset your password.')
      return
    }
    setEmail(normalizedEmail)
    setForgotLoading(true)
    try {
      const response = await fetch('/api/auth/password/forgot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: normalizedEmail }),
      })
      const data = await response.json().catch(() => ({}))

      if (!response.ok) {
        throw new Error(
          (typeof data?.error === 'string' && data.error) ||
            'Unable to send reset email. Please try again.'
        )
      }

      setSuccess(
        (typeof data?.message === 'string' && data.message) ||
          'If an account exists for that email, password reset instructions have been sent.'
      )
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to send reset email.')
    } finally {
      setForgotLoading(false)
    }
  }

  const handleRequestAccess = async () => {
    setError(null)
    setSuccess(null)
    const normalizedEmail = email.trim().toLowerCase()
    if (!validateEmail(normalizedEmail)) {
      setError('Enter your email first to request vetted access.')
      return
    }
    setEmail(normalizedEmail)
    setAccessRequestLoading(true)
    try {
      const response = await fetch('/api/access/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: normalizedEmail,
          note: accessRequestNote.trim(),
        }),
      })
      const data = await response.json().catch(() => ({}))
      if (!response.ok) {
        throw new Error(data?.error || 'Unable to submit access request.')
      }
      setSuccess(
        data?.alreadySubmitted
          ? 'You already have a pending access request in our review queue.'
          : 'Access request submitted to our membership review queue. We will email you after review.'
      )
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to submit access request.')
    } finally {
      setAccessRequestLoading(false)
    }
  }

  useEffect(() => {
    const errorParam = searchParams.get('error')
    if (errorParam) {
      setError(decodeURIComponent(errorParam))
    }
  }, [searchParams])

  const modeParam = searchParams.get('mode')
  const inviteParam = searchParams.get('invite')

  useEffect(() => {
    if (modeParam === 'signup' || modeParam === 'signin') {
      setMode(modeParam)
      setStep('method')
      setError(null)
      setSuccess(null)
      setExistingAccountEmail(null)
      if (modeParam === 'signin') {
        setInviteCode('')
        setInviteDetails(null)
      }
    }
  }, [modeParam])

  useEffect(() => {
    if (!inviteParam) return
    const normalizedCode = normalizeInviteCode(inviteParam)
    if (!normalizedCode) return
    setMode('signup')
    setStep('email')
    setInviteCode(normalizedCode)
    setSuccess('Invite code applied. Create your account to join.')
    setError(null)
  }, [inviteParam])

  const passwordChecks = {
    length: password.length >= 8,
    lower: /[a-z]/.test(password),
    upper: /[A-Z]/.test(password),
    number: /[0-9]/.test(password),
    symbol: /[^A-Za-z0-9]/.test(password),
  }

  return (
    <div className="app-page flex flex-col safe-top safe-bottom">
      <header className="app-header px-6 pb-4 pt-8">
        <div className="mx-auto w-full max-w-sm">
          <PreLogotype size="medium" />
        </div>
      </header>

      <main className="flex flex-1 flex-col px-6 pb-10">
        <div className="w-full max-w-sm mx-auto flex-1 flex flex-col justify-center">
          <div className="space-y-6 animate-onboarding-enter">
            {step !== 'method' && (
              <button
                type="button"
                onClick={() => {
                  if (step === 'otp') {
                    setOtp('')
                  }
                  setStep(step === 'otp' ? 'email' : 'method')
                  setError(null)
                  setSuccess(null)
                  setExistingAccountEmail(null)
                }}
                className="mb-2 inline-flex h-10 w-10 items-center justify-center rounded-full bg-surface-secondary border border-border-secondary"
              >
                <ChevronLeft className="h-5 w-5 text-content-primary" />
              </button>
            )}

            <div className="space-y-2">
              <h1 className="text-display text-content-primary font-display">
                {step === 'otp' ? 'Verify your email' : mode === 'signin' ? 'Sign in' : 'Private Sign Up'}
              </h1>
              <p className="text-body text-content-secondary">
                {step === 'otp'
                  ? 'Open the email we sent and use the confirmation link. If your inbox includes a numeric code, you can enter it below.'
                  : mode === 'signup'
                    ? 'pre is invite-only. Existing members nominate in batches of 5.'
                    : 'Connect with people who share your interests'}
              </p>
            </div>

            {step !== 'otp' && (
              <SegmentedControl
                value={mode}
                onChange={(value) => {
                  const nextMode = value === 'signin' ? 'signin' : 'signup'
                  setMode(nextMode)
                  setStep((prev) => (prev === 'method' ? 'method' : 'email'))
                  setError(null)
                  setSuccess(null)
                  setExistingAccountEmail(null)
                  setPassword('')
                  setConfirmPassword('')
                  if (nextMode === 'signin') {
                    setInviteCode('')
                    setInviteDetails(null)
                  }
                }}
                options={[
                  { label: 'Sign in', value: 'signin' },
                  { label: 'Sign up', value: 'signup' },
                ]}
              />
            )}

            {error && (
              <Alert variant="error" dismissible onDismiss={() => setError(null)}>
                {error}
              </Alert>
            )}
            {success && (
              <Alert variant="success" dismissible onDismiss={() => setSuccess(null)}>
                {success}
              </Alert>
            )}
            {existingAccountEmail && (
              <div className="rounded-card border border-border-secondary bg-surface-secondary px-4 py-3">
                <p className="text-caption text-content-secondary">
                  Account already exists — please sign in.
                </p>
                <Button
                  type="button"
                  variant="ghost"
                  className="mt-2 w-full"
                  onClick={() => {
                    setMode('signin')
                    setPassword('')
                    setConfirmPassword('')
                  }}
                >
                  Switch to sign in
                </Button>
              </div>
            )}

            {step === 'method' ? (
              <div className="space-y-4">
                <div className="space-y-3">
                  {mode === 'signin' ? (
                    <>
                      <button
                        type="button"
                        onClick={() => handleOAuth('apple')}
                        disabled={oauthLoading === 'apple'}
                        className="w-full px-6 py-4 rounded-xl border border-border-secondary/45 flex items-center justify-center gap-3 bg-surface-elevated active:bg-surface-secondary transition-colors disabled:opacity-60 disabled:pointer-events-none"
                        data-testid="auth-apple-button"
                      >
                        <svg className="w-5 h-5 text-content-primary" viewBox="0 0 24 24">
                          <path fill="currentColor" d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09l.01-.01zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z" />
                        </svg>
                        <span className="text-base text-content-primary">
                          Continue with Apple
                        </span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleOAuth('google')}
                        disabled={oauthLoading === 'google'}
                        className="w-full px-6 py-4 rounded-xl border border-border-secondary/45 flex items-center justify-center gap-3 bg-surface-elevated active:bg-surface-secondary transition-colors disabled:opacity-60 disabled:pointer-events-none"
                        data-testid="auth-google-button"
                      >
                        <svg className="w-5 h-5" viewBox="0 0 24 24">
                          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                          <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                        </svg>
                        <span className="text-base text-content-primary">
                          Continue with Google
                        </span>
                      </button>
                    </>
                  ) : (
                    <div className="rounded-card border border-border-secondary bg-surface-secondary p-4 space-y-3">
                      <div className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-border-secondary bg-surface-primary">
                        <Sparkles className="h-4 w-4 text-content-primary" />
                      </div>
                      <p className="text-caption text-content-secondary">
                        Membership is private and vetted. Existing members nominate in batches of 5.
                      </p>
                      <Input
                        type="text"
                        label="Invite code"
                        placeholder="Enter invite code"
                        value={inviteCode}
                        onChange={(event) => setInviteCode(normalizeInviteCode(event.target.value))}
                        autoComplete="off"
                      />
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={() => setStep('email')}
                    className="w-full px-6 py-4 rounded-xl bg-content-primary text-content-inverse transition-colors active:opacity-90"
                    data-testid="auth-email-cta"
                  >
                    Continue with Email
                  </button>
                </div>

                <p className="text-center text-caption text-content-tertiary">
                  By continuing, you agree to our Terms of Service and Privacy Policy
                </p>
              </div>
            ) : step === 'email' ? (
              <form onSubmit={handleSubmit} className="space-y-4">
                <Input
                  type="email"
                  label="Email"
                  placeholder="Email address"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  autoComplete="email"
                  required
                  data-testid="auth-email-input"
                />

                <Input
                  type="password"
                  label="Password"
                  placeholder={mode === 'signin' ? 'Enter your password' : 'Create a password'}
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  autoComplete={mode === 'signin' ? 'current-password' : 'new-password'}
                  required
                  data-testid="auth-password-input"
                />

                {mode === 'signup' && (
                  <>
                    <Input
                      type="text"
                      label="Invite Code"
                      placeholder="Invitation code"
                      value={inviteCode}
                      onChange={(event) => {
                        setInviteCode(normalizeInviteCode(event.target.value))
                        setInviteDetails(null)
                      }}
                      autoComplete="off"
                      required
                    />
                    {inviteDetails && (
                      <p className="text-caption text-success">
                        {inviteDetails.inviteeEmail
                          ? `Reserved by ${inviteDetails.inviterName} for ${inviteDetails.inviteeEmail}`
                          : `Invite shared by ${inviteDetails.inviterName}. This link can be claimed by any new member.`}
                      </p>
                    )}
                    {inviteValidating && (
                      <p className="text-caption text-content-tertiary">Checking invite code...</p>
                    )}

                    <Input
                      type="password"
                      label="Confirm Password"
                      placeholder="Re-enter your password"
                      value={confirmPassword}
                      onChange={(event) => setConfirmPassword(event.target.value)}
                      autoComplete="new-password"
                      required
                      data-testid="auth-confirm-password-input"
                    />
                    <div className="rounded-card border border-border-secondary bg-surface-secondary px-4 py-3 space-y-2">
                      <p className="text-caption text-content-secondary">Password must include:</p>
                      {[
                        { label: 'At least 8 characters', ok: passwordChecks.length },
                        { label: 'One lowercase letter', ok: passwordChecks.lower },
                        { label: 'One uppercase letter', ok: passwordChecks.upper },
                        { label: 'One number', ok: passwordChecks.number },
                        { label: 'One symbol', ok: passwordChecks.symbol },
                      ].map((rule) => (
                        <div key={rule.label} className="flex items-center gap-2 text-caption">
                          {rule.ok ? (
                            <Check className="h-3.5 w-3.5 text-success" />
                          ) : (
                            <X className="h-3.5 w-3.5 text-content-tertiary" />
                          )}
                          <span className={rule.ok ? 'text-content-primary' : 'text-content-tertiary'}>
                            {rule.label}
                          </span>
                        </div>
                      ))}
                    </div>

                    <div className="rounded-card border border-border-secondary bg-surface-secondary px-4 py-3 space-y-3">
                      <p className="text-caption text-content-secondary">
                        Don&apos;t have an invite? Submit a vetted access request.
                      </p>
                      <textarea
                        value={accessRequestNote}
                        onChange={(event) => setAccessRequestNote(event.target.value.slice(0, 600))}
                        placeholder="Tell us why you'd like to join (optional)"
                        className="w-full min-h-[82px] rounded-xl border border-border-secondary bg-surface-primary px-3 py-2 text-sm text-content-primary placeholder:text-content-tertiary resize-none"
                      />
                      <Button
                        type="button"
                        variant="secondary"
                        className="w-full"
                        loading={accessRequestLoading}
                        onClick={handleRequestAccess}
                      >
                        Request Vetted Access
                      </Button>
                    </div>
                  </>
                )}

                {mode === 'signin' && (
                  <button
                    type="button"
                    onClick={handleForgotPassword}
                    disabled={forgotLoading}
                    className="text-left text-caption text-content-primary underline disabled:opacity-60"
                  >
                    {forgotLoading ? 'Sending reset email…' : 'Forgot password?'}
                  </button>
                )}

                <Button
                  type="submit"
                  className="w-full"
                  loading={isLoading}
                  disabled={isLoading || inviteValidating}
                  data-testid="auth-submit-button"
                >
                  {mode === 'signin' ? 'Sign In' : 'Create Account'}
                </Button>

                <p className="text-center text-caption text-content-tertiary">
                  By continuing, you agree to our Terms of Service and Privacy Policy
                </p>
              </form>
            ) : (
              <div className="space-y-5">
                <div className="rounded-card border border-border-secondary bg-surface-secondary px-4 py-4 text-center space-y-2">
                  <div className="mx-auto h-10 w-10 rounded-full bg-surface-primary border border-border-secondary flex items-center justify-center">
                    <Mail className="h-5 w-5 text-content-primary" />
                  </div>
                  <p className="text-body text-content-primary">Check your email</p>
                  <p className="text-caption text-content-secondary">
                    We sent a confirmation email to {email}. Tap the button in that email to continue. If a numeric code is shown, enter it below.
                  </p>
                </div>

                <Input
                  type="text"
                  label="Verification code (if shown)"
                  placeholder="8-digit code"
                  value={otp}
                  onChange={(event) => setOtp(event.target.value.replace(/\D/g, '').slice(0, 8))}
                  maxLength={8}
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  data-testid="auth-otp-input"
                />

                <Button
                  type="button"
                  className="w-full"
                  loading={otpLoading}
                  onClick={handleVerifyOtp}
                >
                  Verify code
                </Button>

                <div className="flex flex-col gap-3">
                  <Button
                    type="button"
                    variant="secondary"
                    className="w-full"
                    loading={otpResending}
                    onClick={handleResendOtp}
                  >
                    Resend verification email
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    className="w-full"
                    onClick={() => {
                      if (typeof window !== 'undefined') {
                        window.location.href = 'mailto:'
                      }
                    }}
                  >
                    Open Mail App
                  </Button>
                  <button
                    type="button"
                    onClick={() => {
                      setStep('email')
                      setOtp('')
                      setError(null)
                      setSuccess(null)
                    }}
                    className="text-caption text-content-tertiary underline"
                  >
                    Change email
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}

export default function AuthPage() {
  return (
    <Suspense fallback={<LoadingScreen />}>
      <AuthPageContent />
    </Suspense>
  )
}
