'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Button } from '@/components/ui/button'
import { BentoCell, BentoDivider, BentoFrame, BentoGrid, BentoLabel } from '@/components/ui/bento'
import { VisualSurface } from '@/components/ui/visual-surface'
import { ArrowLeft, Calendar, MapPin, CheckCircle2, Sparkles, XCircle, Plus, Clock } from 'lucide-react'

type RsvpStatus = 'going' | 'interested' | 'cant_go'

type EventItem = {
  id: string
  title: string
  description: string | null
  starts_at: string
  ends_at: string | null
  location_text: string | null
  is_campus_only: boolean
  my_rsvp: RsvpStatus
  rsvp_counts: { going: number; interested: number; cant_go: number }
}

type FilterTab = 'upcoming' | 'interested' | 'past'

const formatDate = (value: string) => {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return date.toLocaleString([], { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })
}

const formatDateShort = (value: string) => {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return date.toLocaleString([], { month: 'short', day: 'numeric' })
}

const rsvpConfig = {
  going: {
    label: 'Going',
    icon: CheckCircle2,
    tint: 'bento-tint-sage',
    chipClass: 'bg-[color:var(--tint-sage)] text-content-primary border border-[color:color-mix(in_oklab,var(--tint-sage)_60%,var(--content-primary))]',
  },
  interested: {
    label: 'Interested',
    icon: Sparkles,
    tint: 'bento-tint-mist',
    chipClass: 'bg-[color:var(--tint-mist)] text-content-primary border border-[color:color-mix(in_oklab,var(--tint-mist)_60%,var(--content-primary))]',
  },
  cant_go: {
    label: "Can't go",
    icon: XCircle,
    tint: 'bento-tint-rose',
    chipClass: 'bg-[color:var(--tint-rose)] text-content-primary border border-[color:color-mix(in_oklab,var(--tint-rose)_60%,var(--content-primary))]',
  },
}

export default function PlansPage() {
  const router = useRouter()
  const { user, loading, initialized, profileLoaded } = useAuth()
  const [events, setEvents] = useState<EventItem[]>([])
  const [loadingEvents, setLoadingEvents] = useState(true)
  const [activeTab, setActiveTab] = useState<FilterTab>('upcoming')

  useEffect(() => {
    if (!initialized || loading) return
    if (!user) {
      router.replace('/')
    }
  }, [initialized, loading, user, router])

  useEffect(() => {
    if (!user) return
    let active = true
    setLoadingEvents(true)
    fetch('/api/events/my-rsvps')
      .then((res) => res.json())
      .then((data) => {
        if (!active) return
        setEvents(data.events ?? [])
      })
      .catch(() => {
        if (!active) return
        setEvents([])
      })
      .finally(() => {
        if (active) setLoadingEvents(false)
      })
    return () => {
      active = false
    }
  }, [user])

  if (!initialized || loading || !profileLoaded) return <LoadingScreen />
  if (!user) return <LoadingScreen />

  const now = new Date()

  const upcoming = events.filter(
    (e) => new Date(e.starts_at) >= now && e.my_rsvp === 'going'
  )
  const interested = events.filter(
    (e) => new Date(e.starts_at) >= now && e.my_rsvp === 'interested'
  )
  const past = events.filter((e) => new Date(e.starts_at) < now)

  const tabData: Record<FilterTab, EventItem[]> = { upcoming, interested, past }
  const visible = tabData[activeTab]

  const tabs: { key: FilterTab; label: string; count: number }[] = [
    { key: 'upcoming', label: 'Going', count: upcoming.length },
    { key: 'interested', label: 'Interested', count: interested.length },
    { key: 'past', label: 'Past', count: past.length },
  ]

  return (
    <div className="relative min-h-screen bg-surface-primary safe-top safe-bottom animate-route-enter">
      {/* Ambient background orbs */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <span className="absolute left-[-10%] top-[8%] h-52 w-52 rounded-full bg-content-primary/5 blur-3xl animate-ambient-float-soft" />
        <span className="absolute right-[-12%] bottom-[15%] h-44 w-44 rounded-full bg-content-primary/5 blur-3xl animate-ambient-float-soft-reverse" />
      </div>

      {/* Header */}
      <header className="relative z-10 flex items-center justify-between px-4 py-4 border-b border-border-secondary animate-section-reveal">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
          aria-label="Go back"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline font-semibold">Your Plans</h1>
        <Button
          size="sm"
          variant="ghost"
          onClick={() => router.push('/events/new')}
          aria-label="Create new event"
        >
          <Plus className="h-4 w-4" />
        </Button>
      </header>

      <main className="relative z-10 px-4 py-5 max-w-lg mx-auto space-y-5">
        {/* Tab filter */}
        <div className="animate-section-reveal">
          <div className="flex gap-2">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`flex items-center gap-1.5 rounded-pill px-4 py-2 text-callout transition-all ${
                  activeTab === tab.key
                    ? 'bg-accent-primary text-content-inverse font-medium'
                    : 'bg-surface-secondary/50 text-content-secondary border border-border-secondary hover:bg-surface-secondary'
                }`}
              >
                {tab.label}
                {tab.count > 0 && (
                  <span
                    className={`rounded-full px-1.5 py-0.5 text-[10px] font-semibold leading-none ${
                      activeTab === tab.key
                        ? 'bg-content-inverse/20 text-content-inverse'
                        : 'bg-surface-tertiary text-content-tertiary'
                    }`}
                  >
                    {tab.count}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Loading */}
        {loadingEvents && (
          <div className="flex flex-col items-center justify-center py-16 animate-section-reveal">
            <div className="mb-4 h-14 w-14 rounded-full bg-surface-secondary flex items-center justify-center">
              <Calendar className="h-7 w-7 text-content-tertiary animate-micro-bob" />
            </div>
            <p className="text-callout text-content-secondary">Loading your plans…</p>
          </div>
        )}

        {/* Empty state */}
        {!loadingEvents && visible.length === 0 && (
          <div className="animate-section-reveal">
            <BentoFrame>
              <BentoGrid>
                <BentoCell className="flex flex-col items-center justify-center py-10 text-center space-y-4">
                  <div className="h-14 w-14 rounded-full bg-surface-secondary flex items-center justify-center">
                    {activeTab === 'upcoming' && <CheckCircle2 className="h-7 w-7 text-content-tertiary" />}
                    {activeTab === 'interested' && <Sparkles className="h-7 w-7 text-content-tertiary" />}
                    {activeTab === 'past' && <Clock className="h-7 w-7 text-content-tertiary" />}
                  </div>
                  <div>
                    <p className="text-headline text-content-primary mb-1">
                      {activeTab === 'upcoming' && 'No upcoming plans'}
                      {activeTab === 'interested' && 'Nothing on your radar yet'}
                      {activeTab === 'past' && 'No past events'}
                    </p>
                    <p className="text-callout text-content-secondary max-w-xs mx-auto">
                      {activeTab === 'upcoming' && 'RSVP "Going" to events to see them here.'}
                      {activeTab === 'interested' && 'Mark events as interested to keep track of them.'}
                      {activeTab === 'past' && 'Events you attended will show here.'}
                    </p>
                  </div>
                  {activeTab === 'upcoming' && (
                    <Button variant="secondary" size="sm" onClick={() => router.push('/events')}>
                      Browse events
                    </Button>
                  )}
                </BentoCell>
              </BentoGrid>
            </BentoFrame>
          </div>
        )}

        {/* Event list */}
        {!loadingEvents && visible.length > 0 && (
          <div className="space-y-3">
            {visible.map((event, index) => {
              const config = rsvpConfig[event.my_rsvp]
              const Icon = config.icon
              const isPast = new Date(event.starts_at) < now
              return (
                <article
                  key={event.id}
                  className={`dynamic-card animate-section-reveal rounded-card border border-bento-border overflow-hidden cursor-pointer ${config.tint}`}
                  style={{ animationDelay: `${index * 60}ms` }}
                  onClick={() => router.push(`/events/${event.id}`)}
                >
                  <VisualSurface
                    seed={`${event.id}-${event.title}`}
                    variant="fullWidth"
                    showWordmark={false}
                    className="opacity-80"
                  />
                  <div className="p-4 space-y-2.5">
                    {/* Title row */}
                    <div className="flex items-start justify-between gap-3">
                      <h3 className="text-headline text-content-primary leading-tight flex-1">{event.title}</h3>
                      <span className={`flex-shrink-0 inline-flex items-center gap-1 rounded-pill px-2.5 py-1 text-[11px] font-semibold ${config.chipClass}`}>
                        <Icon className="h-3 w-3" />
                        {config.label}
                      </span>
                    </div>

                    <BentoDivider variant="secondary" />

                    {/* Date & location */}
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2 text-callout text-content-secondary">
                        <Calendar className="h-3.5 w-3.5 flex-shrink-0" />
                        <span>{formatDate(event.starts_at)}</span>
                        {isPast && (
                          <BentoLabel>Past</BentoLabel>
                        )}
                      </div>
                      {event.location_text && (
                        <div className="flex items-center gap-2 text-callout text-content-secondary">
                          <MapPin className="h-3.5 w-3.5 flex-shrink-0" />
                          <span className="truncate">{event.location_text}</span>
                        </div>
                      )}
                    </div>

                    {/* RSVP counts */}
                    <div className="flex items-center gap-3 text-caption text-content-tertiary pt-0.5">
                      <span>{event.rsvp_counts.going} going</span>
                      <span className="w-px h-3 bg-border-secondary" />
                      <span>{event.rsvp_counts.interested} interested</span>
                    </div>
                  </div>
                </article>
              )
            })}
          </div>
        )}

        {/* Footer actions */}
        {!loadingEvents && (
          <div className="pt-2 animate-section-reveal" style={{ animationDelay: '300ms' }}>
            <Button
              variant="secondary"
              className="w-full"
              onClick={() => router.push('/events')}
            >
              <Calendar className="h-4 w-4" />
              Browse all events
            </Button>
          </div>
        )}
      </main>
    </div>
  )
}
