import type { Metadata, Viewport } from 'next'
import { Analytics } from '@vercel/analytics/next'
import { ThemeProvider } from '@/components/providers/theme-provider'
import { AuthProvider } from '@/components/providers/auth-provider'
import { AppShell } from '@/components/AppShell'
import { cn } from '@/lib/utils'
import './globals.css'

export const metadata: Metadata = {
  title: 'pre - Connect with your people',
  description: 'A social app designed to connect people globally, fostering genuine and healthy friendships.',
  manifest: '/manifest.webmanifest',
  icons: {
    icon: [
      { url: '/icons/pre-logo.png', sizes: '1536x1536', type: 'image/png' },
      { url: '/icons/icon-192.png', sizes: '192x192', type: 'image/png' },
      { url: '/icons/icon-512.png', sizes: '512x512', type: 'image/png' },
    ],
    shortcut: '/icons/icon-192.png',
    apple: [{ url: '/icons/apple-touch-icon.png', sizes: '180x180', type: 'image/png' }],
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: 'default',
    title: 'pre',
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: 'cover',
  themeColor: '#111112',
}

const themeInitScript = `
(() => {
  try {
    const mode = localStorage.getItem('pre-theme-mode') || 'dark'
    const amoled = localStorage.getItem('pre-amoled') === 'true'
    const resolved = mode === 'system'
      ? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
      : mode

    const root = document.documentElement
    root.classList.remove('light', 'dark', 'amoled')

    if (resolved === 'dark') {
      root.classList.add('dark')
      if (amoled) root.classList.add('amoled')
    } else {
      root.classList.add('light')
    }

    const color = resolved === 'dark' ? (amoled ? '#000000' : '#111112') : '#FFFCF8'
    const metas = document.querySelectorAll('meta[name="theme-color"]')
    if (metas.length) {
      metas.forEach((meta) => meta.setAttribute('content', color))
    } else {
      const meta = document.createElement('meta')
      meta.name = 'theme-color'
      meta.content = color
      document.head.appendChild(meta)
    }
  } catch {}
})()
`

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeInitScript }} />
      </head>
      <body
        className={cn(
          'min-h-screen bg-surface-primary text-content-primary antialiased'
        )}
      >
        <ThemeProvider>
          <AuthProvider>
            <AppShell>{children}</AppShell>
          </AuthProvider>
        </ThemeProvider>
        <Analytics />
      </body>
    </html>
  )
}
