'use client'

import { useState, useEffect, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { OnboardingLayout } from './layout'
import { validateUsername } from '@/lib/utils'
import { isRestrictedUsername } from '@/lib/moderation/restrictedWordsClient'
import { Check, X } from 'lucide-react'
import { LoadingDots } from '@/components/ui/loading-dots'

interface Props {
  value: string
  onChange: (value: string) => void
  onNext: () => void
  onBack: () => void
}

export function OnboardingUsername({ value, onChange, onNext, onBack }: Props) {
  const [error, setError] = useState<string | null>(null)
  const [checking, setChecking] = useState(false)
  const [available, setAvailable] = useState<boolean | null>(null)
  const debounceRef = useRef<NodeJS.Timeout | null>(null)
  const abortRef = useRef<AbortController | null>(null)

  // Check username availability
  useEffect(() => {
    if (!value.trim()) {
      setAvailable(null)
      setError(null)
      setChecking(false)
      return
    }

    const validation = validateUsername(value)
    if (!validation.valid) {
      setError(validation.error || null)
      setAvailable(null)
      setChecking(false)
      return
    }

    if (isRestrictedUsername(value)) {
      setError("That username isn't available.")
      setAvailable(false)
      setChecking(false)
      return
    }

    setError(null)
    setAvailable(null)
    setChecking(true)

    if (debounceRef.current) {
      clearTimeout(debounceRef.current)
    }

    debounceRef.current = setTimeout(async () => {
      if (abortRef.current) {
        abortRef.current.abort()
      }
      abortRef.current = new AbortController()
      try {
        const response = await fetch(`/api/username/check?u=${encodeURIComponent(value)}`, {
          signal: abortRef.current.signal,
          cache: 'no-store',
          credentials: 'include',
        })

        if (!response.ok) {
          setAvailable(null)
          setChecking(false)
          return
        }

        const data = await response.json()
        if (data.available) {
          setAvailable(true)
        } else {
          setAvailable(false)
          setError("That username isn't available.")
        }
      } catch (err) {
        if (err instanceof Error && err.name === 'AbortError') {
          return
        }
        setAvailable(null)
      } finally {
        setChecking(false)
      }
    }, 450)

    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current)
      }
      if (abortRef.current) {
        abortRef.current.abort()
      }
    }
  }, [value])

  const handleNext = () => {
    if (!value.trim()) {
      setError('Username is required')
      return
    }

    const validation = validateUsername(value)
    if (!validation.valid) {
      setError(validation.error || 'Invalid username')
      return
    }

    if (isRestrictedUsername(value)) {
      setError("That username isn't available.")
      return
    }

    if (available === false) {
      setError("That username isn't available.")
      return
    }

    if (available !== true) {
      setError('Checking username availability...')
      return
    }

    onNext()
  }

  return (
    <OnboardingLayout
      step={3}
      totalSteps={9}
      title="Choose a username"
      subtitle="Required. This is how people will find you."
      onBack={onBack}
    >
      <div className="space-y-6">
        <div className="relative">
          <Input
            label="Username"
            placeholder="your_username"
            value={value}
            onChange={(e) => onChange(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
            error={error || undefined}
            hint="Letters, numbers, and underscores only"
            autoFocus
            data-testid="onboarding-username-input"
          />
          {value && (
            <div className="absolute right-3 top-[38px]">
              {checking ? (
                <LoadingDots size="md" className="text-content-tertiary" />
              ) : available === true ? (
                <Check className="h-5 w-5 text-success" />
              ) : available === false ? (
                <X className="h-5 w-5 text-error" />
              ) : null}
            </div>
          )}
        </div>

        <Button
          className="w-full"
          size="lg"
          onClick={handleNext}
          disabled={checking || available === false}
          data-testid="onboarding-username-next"
        >
          Continue
        </Button>
      </div>
    </OnboardingLayout>
  )
}
