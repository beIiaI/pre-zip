'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { OnboardingLayout } from './layout'
import { Navigation, MapPin, X } from 'lucide-react'
import { cn } from '@/lib/utils'
import { LoadingDots } from '@/components/ui/loading-dots'

interface LocationResult {
  id: string
  name: string
  formatted: string
  city?: string
  state?: string
  country?: string
  lat: number
  lon: number
}

interface Props {
  value: string
  onChange: (value: string, lat?: number, lng?: number) => void
  onNext: () => void
  onBack: () => void
}

export function OnboardingLocation({ value, onChange, onNext, onBack }: Props) {
  const [inputValue, setInputValue] = useState(value)
  const [results, setResults] = useState<LocationResult[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [isOpen, setIsOpen] = useState(false)
  const [highlightedIndex, setHighlightedIndex] = useState(-1)
  const [gpsLoading, setGpsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  
  const inputRef = useRef<HTMLInputElement>(null)
  const dropdownRef = useRef<HTMLDivElement>(null)
  const abortControllerRef = useRef<AbortController | null>(null)
  const debounceRef = useRef<NodeJS.Timeout | null>(null)

  const buildLocationLabel = useCallback((result: Record<string, any> | undefined | null) => {
    if (!result) return null
    const city = result.city || result.town || result.village || result.suburb
    const region = result.state || result.county
    const country = result.country

    if (city && country) return `${city}, ${country}`
    if (region && country) return `${region}, ${country}`
    if (country) return country
    if (city) return city
    return null
  }, [])

  // Sync input value with prop
  useEffect(() => {
    setInputValue(value)
  }, [value])

  // Fetch autocomplete results
  const fetchResults = useCallback(async (query: string) => {
    if (query.length < 2) {
      setResults([])
      setIsOpen(false)
      return
    }

    // Cancel previous request
    if (abortControllerRef.current) {
      abortControllerRef.current.abort()
    }

    abortControllerRef.current = new AbortController()
    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch(`/api/location/autocomplete?text=${encodeURIComponent(query)}`, {
        signal: abortControllerRef.current.signal,
      })

      if (!response.ok) {
        throw new Error('Failed to fetch locations')
      }

      const data = await response.json()
      setResults(data.results || [])
      setIsOpen(true)
      setHighlightedIndex(-1)
    } catch (err) {
      if (err instanceof Error && err.name === 'AbortError') {
        return // Ignore abort errors
      }
      console.error('Autocomplete error:', err)
      setResults([])
    } finally {
      setIsLoading(false)
    }
  }, [])

  // Debounced input handler
  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value
    setInputValue(newValue)
    
    // Clear the location if user is typing
    if (newValue !== value) {
      onChange(newValue)
    }

    // Debounce the API call
    if (debounceRef.current) {
      clearTimeout(debounceRef.current)
    }

    debounceRef.current = setTimeout(() => {
      fetchResults(newValue)
    }, 300)
  }, [fetchResults, onChange, value])

  // Select a result
  const selectResult = useCallback((result: LocationResult) => {
    const displayValue = result.city && result.country 
      ? `${result.city}, ${result.country}`
      : result.formatted
    
    setInputValue(displayValue)
    onChange(displayValue, result.lat, result.lon)
    setIsOpen(false)
    setResults([])
    inputRef.current?.blur()
  }, [onChange])

  // Keyboard navigation
  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (!isOpen || results.length === 0) return

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault()
        setHighlightedIndex(prev => 
          prev < results.length - 1 ? prev + 1 : 0
        )
        break
      case 'ArrowUp':
        e.preventDefault()
        setHighlightedIndex(prev => 
          prev > 0 ? prev - 1 : results.length - 1
        )
        break
      case 'Enter':
        e.preventDefault()
        if (highlightedIndex >= 0 && highlightedIndex < results.length) {
          selectResult(results[highlightedIndex])
        }
        break
      case 'Escape':
        setIsOpen(false)
        break
    }
  }, [isOpen, results, highlightedIndex, selectResult])

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        dropdownRef.current && 
        !dropdownRef.current.contains(e.target as Node) &&
        inputRef.current &&
        !inputRef.current.contains(e.target as Node)
      ) {
        setIsOpen(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  // Get current location via GPS
  const handleGetLocation = async () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser')
      return
    }

    setGpsLoading(true)
    setError(null)

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords

        try {
          const response = await fetch(
            `/api/location/reverse?lat=${latitude}&lon=${longitude}`
          )
          const data = await response.json()
          const label: string | null = data.label ?? null

          if (label) {
            setInputValue(label)
            onChange(label, latitude, longitude)
          } else {
            // Reverse geocoding returned no readable name — store coords
            // only as lat/lng metadata but leave the text field empty so
            // raw coordinates are never saved as the user's visible location.
            setError('Could not resolve a city name. Please type your location.')
          }
        } catch {
          setError('Could not resolve your location. Please type it manually.')
        }

        setGpsLoading(false)
      },
      () => {
        setError('Unable to get your location. Please enter it manually.')
        setGpsLoading(false)
      }
    )
  }

  // Clear input
  const handleClear = () => {
    setInputValue('')
    onChange('')
    setResults([])
    setIsOpen(false)
    inputRef.current?.focus()
  }

  return (
    <OnboardingLayout
      step={7}
      totalSteps={9}
      title="Where are you based?"
      subtitle="Optional — helps us show you local circles and events."
      onBack={onBack}
    >
      <div className="space-y-6">
        <div className="space-y-3">
          {/* Autocomplete Input */}
          <div className="relative">
            <label className="block text-callout font-medium text-content-primary mb-2">
              Location (optional)
            </label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-content-tertiary" />
              <input
                ref={inputRef}
                type="text"
                value={inputValue}
                onChange={handleInputChange}
                onKeyDown={handleKeyDown}
                onFocus={() => {
                  if (results.length > 0) setIsOpen(true)
                }}
                placeholder="Start typing a city..."
                className="w-full pl-10 pr-10 py-3 rounded-input border bg-surface-secondary text-body text-content-primary placeholder:text-content-tertiary border-border-primary focus:border-border-focus focus:outline-none focus:ring-1 focus:ring-border-focus"
                data-testid="onboarding-location-input"
              />
              {(isLoading || inputValue) && (
                <div className="absolute right-3 top-1/2 -translate-y-1/2">
                  {isLoading ? (
                    <LoadingDots size="md" className="text-content-tertiary" />
                  ) : inputValue ? (
                    <button
                      type="button"
                      onClick={handleClear}
                      className="p-1 rounded-full hover:bg-accent-muted"
                    >
                      <X className="h-4 w-4 text-content-tertiary" />
                    </button>
                  ) : null}
                </div>
              )}
            </div>

            {/* Dropdown */}
            {isOpen && results.length > 0 && (
              <div
                ref={dropdownRef}
                className="absolute z-50 w-full mt-1 bg-surface-primary border border-border-primary rounded-card shadow-lg max-h-64 overflow-auto"
              >
                {results.map((result, index) => (
                  <button
                    key={result.id}
                    type="button"
                    onClick={() => selectResult(result)}
                    onMouseEnter={() => setHighlightedIndex(index)}
                    className={cn(
                      'w-full px-4 py-3 text-left flex items-start gap-3 transition-colors',
                      highlightedIndex === index 
                        ? 'bg-surface-secondary' 
                        : 'hover:bg-surface-secondary'
                    )}
                  >
                    <MapPin className="h-5 w-5 text-content-tertiary flex-shrink-0 mt-0.5" />
                    <div className="min-w-0">
                      <p className="text-body text-content-primary font-medium truncate">
                        {result.city || result.name}
                      </p>
                      <p className="text-caption text-content-secondary truncate">
                        {result.state ? `${result.state}, ${result.country}` : result.country}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {error && (
            <p className="text-caption text-error">{error}</p>
          )}

          {/* GPS Button */}
          <Button
            variant="secondary"
            className="w-full"
            onClick={handleGetLocation}
            disabled={gpsLoading}
            data-testid="onboarding-location-gps"
          >
            {gpsLoading ? (
              <LoadingDots size="sm" className="text-content-tertiary" />
            ) : (
              <Navigation className="h-4 w-4" />
            )}
            Use my current location
          </Button>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <Button
            variant="secondary"
            className="flex-1"
            size="lg"
            onClick={onNext}
            data-testid="onboarding-location-skip"
          >
            Skip
          </Button>
          <Button
            className="flex-1"
            size="lg"
            onClick={onNext}
            data-testid="onboarding-location-next"
          >
            Continue
          </Button>
        </div>
      </div>
    </OnboardingLayout>
  )
}
