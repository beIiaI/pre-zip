'use client'

import { Button } from '@/components/ui/button'
import { PreLogotype } from '@/components/ui/pre-logotype'
import { Users, Calendar, MessageCircle, Shield } from 'lucide-react'

interface Props {
  onNext: () => void
}

export function OnboardingIntro({ onNext }: Props) {
  const features = [
    { icon: Users, label: 'Join circles of like-minded people' },
    { icon: Calendar, label: 'Discover and host local events' },
    { icon: MessageCircle, label: 'Connect through group chats' },
    { icon: Shield, label: 'Safe and verified community' },
  ]

  return (
    <div className="min-h-screen flex flex-col px-6">
      {/* Header */}
      <header className="py-6">
        <PreLogotype size="medium" />
      </header>

      {/* Content */}
      <main className="flex-1 flex flex-col justify-center pb-8">
        <div className="space-y-12 max-w-sm mx-auto w-full">
          {/* Hero */}
          <div className="space-y-4">
            <h1 className="text-display text-content-primary text-balance">
              Connect with your people
            </h1>
            <p className="text-body text-content-secondary">
              pre helps you build genuine friendships through shared interests, local events, and community circles.
            </p>
          </div>

          {/* Features */}
          <div className="space-y-4">
            {features.map(({ icon: Icon, label }) => (
              <div key={label} className="flex items-center gap-4">
                <div className="h-10 w-10 rounded-full bg-surface-secondary flex items-center justify-center border border-border-secondary">
                  <Icon className="h-5 w-5 text-content-primary" />
                </div>
                <span className="text-body text-content-primary">{label}</span>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="py-6">
        <Button
          className="w-full"
          size="lg"
          onClick={onNext}
          data-testid="onboarding-start-button"
        >
          Get Started
        </Button>
      </footer>
    </div>
  )
}
