'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { OnboardingLayout } from './layout'
import { isRestrictedDisplayName } from '@/lib/moderation/restrictedWordsClient'

interface Props {
  value: string
  onChange: (value: string) => void
  onNext: () => void
  onBack: () => void
}

export function OnboardingName({ value, onChange, onNext, onBack }: Props) {
  const [error, setError] = useState<string | null>(null)

  const handleNext = () => {
    if (!value.trim()) {
      setError('Please enter your name')
      return
    }
    if (value.trim().length < 2) {
      setError('Name must be at least 2 characters')
      return
    }
    if (isRestrictedDisplayName(value)) {
      setError("That name isn't available.")
      return
    }
    onNext()
  }

  return (
    <OnboardingLayout
      step={2}
      totalSteps={9}
      title="What's your name?"
      subtitle="This is how you'll appear to others on pre."
      onBack={onBack}
    >
      <div className="space-y-6">
        <Input
          label="Full Name"
          placeholder="Enter your full name"
          value={value}
          onChange={(e) => {
            onChange(e.target.value)
            setError(null)
          }}
          error={error || undefined}
          autoFocus
          data-testid="onboarding-name-input"
        />

        <Button
          className="w-full"
          size="lg"
          onClick={handleNext}
          data-testid="onboarding-name-next"
        >
          Continue
        </Button>
      </div>
    </OnboardingLayout>
  )
}
