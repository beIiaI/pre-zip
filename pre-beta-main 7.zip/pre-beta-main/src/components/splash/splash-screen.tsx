'use client'

import { useEffect, useState } from 'react'
import { cn } from '@/lib/utils'
import { PreLogotype } from '@/components/ui/pre-logotype'

interface Props {
  showActions?: boolean
  onGetStarted?: () => void
  onSignIn?: () => void
  className?: string
}

export function SplashScreen({ showActions = false, onGetStarted, onSignIn, className }: Props) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const circles = [
    { size: '72vmin', x: '20%', y: '30%', duration: 8, delay: 0 },
    { size: '62vmin', x: '75%', y: '45%', duration: 10, delay: 1 },
    { size: '54vmin', x: '50%', y: '60%', duration: 12, delay: 0.5 },
  ]

  const accents = [
    { size: '32vmin', x: '25%', y: '70%', duration: 6, delay: 2 },
    { size: '24vmin', x: '80%', y: '25%', duration: 6, delay: 3 },
  ]

  return (
    <div className={cn('relative min-h-screen overflow-hidden bg-surface-primary', className)}>
      <div className="absolute inset-0">
        {circles.map((circle, index) => (
          <div
            key={`splash-circle-${index}`}
            className={cn(
              'absolute rounded-full border-2 border-[#C7E5FF] opacity-0',
              'dark:border-[#3A7CAF]',
              mounted && 'animate-splash-float'
            )}
            style={{
              width: circle.size,
              height: circle.size,
              left: circle.x,
              top: circle.y,
              transform: 'translate(-50%, -50%)',
              animationDuration: `${circle.duration}s`,
              animationDelay: `${circle.delay}s`,
            }}
          />
        ))}

        {accents.map((accent, index) => (
          <div
            key={`splash-accent-${index}`}
            className={cn(
              'absolute rounded-full border-2 border-[#C7E5FF] opacity-0',
              'dark:border-[#3A7CAF]',
              mounted && 'animate-splash-pulse'
            )}
            style={{
              width: accent.size,
              height: accent.size,
              left: accent.x,
              top: accent.y,
              transform: 'translate(-50%, -50%)',
              animationDuration: `${accent.duration}s`,
              animationDelay: `${accent.delay}s`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 flex min-h-screen flex-col px-6">
        <div className="pt-14 text-center">
          <div className="flex justify-center">
            <PreLogotype size="small" />
          </div>
        </div>

        <div className="flex flex-1 flex-col justify-end pb-10">
          <div className="mb-3 text-center text-[clamp(0.5625rem,2.8vw,0.625rem)] uppercase tracking-[0.24em] text-content-secondary">
            Invitation-only social club
          </div>
          <div className="mb-10 px-4 text-center">
            <h2 className="font-display text-[clamp(2rem,9.5vw,2.375rem)] leading-[1.12] text-content-primary">
              Find your people.
              <br />
              Enter by nomination.
            </h2>
          </div>

          {showActions && (
            <>
              <button
                onClick={onGetStarted}
                className="mb-5 flex h-[clamp(46px,12vw,52px)] w-full items-center justify-center rounded-full bg-content-primary text-[clamp(14px,3.8vw,15px)] font-medium text-content-inverse transition-all active:scale-[0.98]"
              >
                Request access
              </button>
              <p className="pb-2 text-center text-[clamp(0.875rem,3.8vw,0.9375rem)] text-content-secondary">
                Already have an account?{' '}
                <button onClick={onSignIn} className="text-content-primary">
                  Sign in
                </button>
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
