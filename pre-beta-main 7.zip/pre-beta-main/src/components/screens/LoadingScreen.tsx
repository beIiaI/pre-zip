'use client'

import { useEffect, useRef, useState } from 'react'
import { cn } from '@/lib/utils'
import { BrandLoader } from '@/components/ui/brand-loader'

interface LoadingScreenProps {
  onLoadComplete?: () => void
  className?: string
  name?: string | null
}

export function LoadingScreen({ onLoadComplete, className, name }: LoadingScreenProps) {
  const [fadeOut, setFadeOut] = useState(false)
  const finishTimerRef = useRef<number | null>(null)
  const displayName = (name || '').trim()
  const DISPLAY_MS = displayName ? 850 : 620
  const FADE_MS = 220

  useEffect(() => {
    const timer = window.setTimeout(() => {
      setFadeOut(true)
      finishTimerRef.current = window.setTimeout(() => {
        onLoadComplete?.()
      }, FADE_MS)
    }, DISPLAY_MS)

    return () => {
      window.clearTimeout(timer)
      if (finishTimerRef.current) {
        window.clearTimeout(finishTimerRef.current)
      }
    }
  }, [onLoadComplete, DISPLAY_MS, FADE_MS])

  return (
    <div
      className={cn(
        'fixed inset-0 z-[9999] flex items-center justify-center overflow-visible px-4 safe-top safe-bottom transition-opacity',
        fadeOut ? 'opacity-0' : 'opacity-100',
        'bg-surface-primary',
        className
      )}
      style={{ transitionDuration: `${FADE_MS}ms` }}
      aria-busy="true"
      aria-live="polite"
    >
      <BrandLoader name={displayName || undefined} showWelcome />
    </div>
  )
}
