'use client'

import { useEffect, useMemo, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Avatar } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { ArrowLeft, UserPlus } from 'lucide-react'
import { MemberBadgeStack } from '@/components/ui/member-badge-stack'
import { Alert } from '@/components/ui/alert'

type FollowProfile = {
  id: string
  username: string | null
  full_name: string | null
  avatar_url: string | null
  early_supporter_number: number | null
  founder_number: number | null
  is_founder?: boolean | null
  is_following: boolean
}

type TargetProfile = {
  id: string
  username: string | null
  full_name: string | null
}

export function FollowListPage({ mode }: { mode: 'followers' | 'following' }) {
  const { user, loading, initialized } = useAuth()
  const router = useRouter()
  const params = useParams()
  const username = typeof params.username === 'string' ? params.username : params.username?.[0]
  const [profiles, setProfiles] = useState<FollowProfile[]>([])
  const [loadingList, setLoadingList] = useState(true)
  const [target, setTarget] = useState<TargetProfile | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!initialized || loading) return
    if (!user) {
      router.replace('/')
    }
  }, [initialized, loading, user, router])

  useEffect(() => {
    if (!user || !username) return
    let active = true
    setError(null)
    fetch(`/api/users/username?u=${encodeURIComponent(username)}`)
      .then((res) => {
        if (!res.ok) {
          throw new Error('Not found')
        }
        return res.json()
      })
      .then((data) => {
        if (!active) return
        setTarget({
          id: data.profile?.id,
          username: data.profile?.username ?? username,
          full_name: data.profile?.full_name ?? null,
        })
      })
      .catch(() => {
        if (active) setError('Profile not found')
      })
    return () => {
      active = false
    }
  }, [user, username])

  useEffect(() => {
    if (!user || !target?.id) return
    let active = true
    setLoadingList(true)
    const endpoint = mode === 'followers' ? '/api/followers' : '/api/following'
    fetch(`${endpoint}?user_id=${encodeURIComponent(target.id)}`)
      .then((res) => res.json())
      .then((data) => {
        if (active) {
          setProfiles(data.results ?? [])
        }
      })
      .finally(() => {
        if (active) setLoadingList(false)
      })
    return () => {
      active = false
    }
  }, [user, target?.id, mode])

  if (!initialized || loading) {
    return <LoadingScreen />
  }

  if (!user) {
    return <LoadingScreen />
  }

  if (error) {
    return (
      <div className="min-h-screen bg-surface-primary safe-top safe-bottom flex flex-col items-center justify-center">
        <Alert variant="error">{error}</Alert>
      </div>
    )
  }

  const title = mode === 'followers' ? 'Followers' : 'Following'
  const emptyTitle = mode === 'followers' ? 'No followers yet' : 'Not following anyone'
  const emptyCopy = mode === 'followers'
    ? 'Share your profile to start building your audience.'
    : 'Follow people to start building your community.'

  return (
    <div className="min-h-screen bg-surface-primary safe-top safe-bottom">
      <header className="px-4 py-4 flex items-center justify-between border-b border-border-secondary">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <div className="text-center">
          <h1 className="text-headline">{title}</h1>
          {target?.username && (
            <p className="text-caption text-content-tertiary">@{target.username}</p>
          )}
        </div>
        <div className="w-9" />
      </header>

      <main className="px-4 py-6">
        {loadingList ? (
          <LoadingScreen />
        ) : profiles.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="h-16 w-16 rounded-full bg-surface-secondary flex items-center justify-center mb-4">
              <UserPlus className="h-8 w-8 text-content-tertiary" />
            </div>
            <h3 className="text-headline text-content-primary mb-2">{emptyTitle}</h3>
            <p className="text-body text-content-secondary max-w-xs">{emptyCopy}</p>
          </div>
        ) : (
          <div className="space-y-3">
            {profiles.map((person) => {
              const hasEarlySupporter =
                person.early_supporter_number !== null && person.early_supporter_number !== undefined
              const hasFounder = person.is_founder === true
              const hasMemberBadges = hasFounder || hasEarlySupporter
              return (
                <div
                  key={person.id}
                  className="flex items-center gap-4 p-4 rounded-card bg-surface-secondary border border-border-secondary"
                >
                  <Avatar src={person.avatar_url} size="lg" />
                  <div className="flex-1 min-w-0">
                    <p className="text-body font-medium text-content-primary truncate">
                      {person.full_name || person.username || 'Unknown'}
                    </p>
                    {person.username && (
                      <p className="text-callout text-content-secondary">@{person.username}</p>
                    )}
                    {hasMemberBadges && (
                      <div className="mt-2">
                        <MemberBadgeStack
                          isFounder={person.is_founder}
                          founderNumber={person.founder_number}
                          earlySupporterNumber={person.early_supporter_number}
                          size="sm"
                        />
                      </div>
                    )}
                  </div>
                  <Button
                    size="sm"
                    variant={person.is_following ? 'secondary' : 'primary'}
                    onClick={() => {
                      const endpoint = person.is_following ? '/api/unfollow' : '/api/follow'
                      setProfiles((prev) =>
                        prev.map((item) =>
                          item.id === person.id ? { ...item, is_following: !person.is_following } : item
                        )
                      )
                      fetch(endpoint, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ following_id: person.id }),
                      }).catch(() => {
                        setProfiles((prev) =>
                          prev.map((item) =>
                            item.id === person.id ? { ...item, is_following: person.is_following } : item
                          )
                        )
                      })
                    }}
                  >
                    {person.is_following ? 'Following' : 'Follow'}
                  </Button>
                </div>
              )
            })}
          </div>
        )}
      </main>
    </div>
  )
}
