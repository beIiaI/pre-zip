'use client'

import { useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import { AlertTriangle, Mail } from 'lucide-react'
import { Alert } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { PreLogotype } from '@/components/ui/pre-logotype'
import { validateEmail } from '@/lib/utils'

export type RecoveryReason = 'expired' | 'invalid' | 'missing'

const RECOVERY_COPY: Record<RecoveryReason, { title: string; body: string }> = {
  expired: {
    title: 'Reset link expired',
    body: 'Your reset link has expired. Request a new one to continue.',
  },
  invalid: {
    title: 'Reset link invalid',
    body: 'This reset link is no longer valid. Request a new one to continue.',
  },
  missing: {
    title: 'Reset link missing',
    body: 'The reset link is incomplete. Request a fresh reset email to continue.',
  },
}

interface ResetLinkErrorScreenProps {
  reason: RecoveryReason
}

export function ResetLinkErrorScreen({ reason }: ResetLinkErrorScreenProps) {
  const router = useRouter()
  const copy = useMemo(() => RECOVERY_COPY[reason], [reason])

  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  const handleRequestNewLink = async () => {
    setError(null)
    setSuccess(null)
    const normalizedEmail = email.trim().toLowerCase()

    if (!validateEmail(normalizedEmail)) {
      setError('Enter a valid email address.')
      return
    }

    setLoading(true)
    try {
      const response = await fetch('/api/auth/password/forgot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: normalizedEmail }),
      })
      const data = await response.json().catch(() => ({}))
      if (!response.ok) {
        throw new Error(data?.error || 'Unable to send reset email.')
      }
      setSuccess('If an account exists for that email, a new reset link has been sent.')
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : 'Unable to send reset email.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="app-page safe-top safe-bottom flex flex-col">
      <header className="app-header px-6 pb-4 pt-8">
        <div className="mx-auto w-full max-w-sm">
          <PreLogotype size="medium" />
        </div>
      </header>

      <main className="app-content flex-1 px-6 pb-10">
        <div className="mx-auto flex h-full w-full max-w-sm flex-col justify-center space-y-5">
          <div className="space-y-2">
            <div className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-border-secondary bg-surface-secondary">
              <AlertTriangle className="h-5 w-5 text-warning" />
            </div>
            <h1 className="text-display font-display text-content-primary">{copy.title}</h1>
            <p className="text-body text-content-secondary">{copy.body}</p>
          </div>

          {error && (
            <Alert variant="error" dismissible onDismiss={() => setError(null)}>
              {error}
            </Alert>
          )}

          {success && (
            <Alert variant="success" dismissible onDismiss={() => setSuccess(null)}>
              {success}
            </Alert>
          )}

          <Input
            label="Email"
            type="email"
            placeholder="you@school.edu"
            value={email}
            autoComplete="email"
            onChange={(event) => setEmail(event.target.value)}
          />

          <Button className="w-full" loading={loading} onClick={handleRequestNewLink}>
            Send new reset link
          </Button>

          <Button
            variant="secondary"
            className="w-full"
            onClick={() => {
              if (typeof window !== 'undefined') {
                window.location.href = 'mailto:'
              }
            }}
          >
            <Mail className="mr-2 h-4 w-4" />
            Open Mail App
          </Button>

          <Button
            variant="ghost"
            className="w-full"
            onClick={() => router.replace('/auth?mode=signin')}
          >
            Back to sign in
          </Button>
        </div>
      </main>
    </div>
  )
}
