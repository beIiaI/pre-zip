'use client'

import type { CSSProperties } from 'react'
import { cn } from '@/lib/utils'
import { PreLogotype } from '@/components/ui/pre-logotype'

interface SplashScreenProps {
  onGetStarted?: () => void
  onSignIn?: () => void
  showActions?: boolean
  className?: string
}

export function SplashScreen({
  onGetStarted,
  onSignIn,
  showActions = true,
  className,
}: SplashScreenProps) {
  const orbitFields = [
    { size: '76vmin', x: '-12%', y: '26%', delay: '0s', duration: '18s', opacity: 0.36 },
    { size: '58vmin', x: '58%', y: '32%', delay: '-3.2s', duration: '16s', opacity: 0.34 },
    { size: '66vmin', x: '44%', y: '52%', delay: '-6.4s', duration: '20s', opacity: 0.3 },
    { size: '44vmin', x: '8%', y: '58%', delay: '-1.8s', duration: '15s', opacity: 0.28 },
    { size: '38vmin', x: '66%', y: '64%', delay: '-4.1s', duration: '14s', opacity: 0.26 },
    { size: '30vmin', x: '16%', y: '78%', delay: '-2.6s', duration: '13s', opacity: 0.24 },
    { size: '22vmin', x: '74%', y: '22%', delay: '-5.8s', duration: '12s', opacity: 0.22 },
  ] as const

  return (
    <div className={cn('relative min-h-screen overflow-hidden bg-surface-primary', className)}>
      {/* Signature orbital field animation (pre-specific) */}
      <div className="absolute inset-0">
        <div className="pointer-events-none absolute inset-0">
          {orbitFields.map((field, index) => (
            <span
              key={`orbit-field-${index}`}
              className="splash-field-orbit absolute rounded-full"
              style={
                {
                  '--orbit-size': field.size,
                  '--orbit-x': field.x,
                  '--orbit-y': field.y,
                  '--orbit-delay': field.delay,
                  '--orbit-duration': field.duration,
                  '--orbit-opacity': field.opacity,
                } as CSSProperties
              }
            />
          ))}
          <span className="splash-field-line splash-field-line-a absolute left-[-10%] top-[20%]" />
          <span className="splash-field-line splash-field-line-b absolute right-[-16%] top-[46%]" />
          <span className="splash-field-line splash-field-line-c absolute left-[-8%] top-[72%]" />
        </div>
        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[46vh] bg-gradient-to-t from-surface-primary via-surface-primary/84 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 flex min-h-screen flex-col px-6">
        {/* Wordmark */}
        <div className="pt-14">
          <div className="flex justify-center">
            <PreLogotype
              size="hero"
              clearspace={false}
              wordmarkClassName="w-[clamp(6.3rem,30vw,8.8rem)]"
            />
          </div>
        </div>

        {/* Main content area */}
        <div className="flex-1 flex flex-col justify-end pb-10">
          {/* Small tagline */}
          <div className="mb-3">
            <p className="text-center text-[clamp(0.5625rem,2.8vw,0.625rem)] tracking-[0.24em] uppercase text-content-secondary" style={{ fontWeight: 500 }}>
              Invitation-only social club
            </p>
          </div>

          {/* Main headline */}
          <div className="mb-12 px-4">
            <h2 className="font-display text-center text-[clamp(2rem,9.5vw,2.375rem)] leading-[1.12] text-content-primary" style={{ fontWeight: 600 }}>
              Find your people.<br />Enter by nomination.
            </h2>
          </div>

          {/* CTA Button - Premium Design */}
          {showActions && (
            <>
              <div className="mb-5">
                <button
                  onClick={onGetStarted}
                className="w-full bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] transition-all active:scale-[0.98] flex items-center justify-center"
                style={{ 
                    height: 'clamp(46px, 12vw, 52px)',
                    fontSize: 'clamp(14px, 3.8vw, 15px)',
                    fontWeight: 500,
                    letterSpacing: '0.01em',
                    borderRadius: '26px'
                  }}
                >
                  Request access
                </button>
              </div>

              {/* Sign in link */}
              <div className="pb-2">
                <p className="text-center text-[clamp(0.875rem,3.8vw,0.9375rem)] text-[#666666] dark:text-[#AAAAAA]">
                  Already have an account?{' '}
                  <button onClick={onSignIn} className="text-[#1A1A1A] dark:text-white">
                    Sign in
                  </button>
                </p>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
