'use client'

import { useEffect, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { CheckCircle2, Sparkles, XCircle, X, Users, Calendar, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Avatar } from '@/components/ui/avatar'
import { BentoDivider } from '@/components/ui/bento'

type RsvpStatus = 'going' | 'interested' | 'cant_go'

type Attendee = {
  id: string
  username: string | null
  full_name: string | null
  avatar_url: string | null
}

interface RsvpSheetProps {
  status: RsvpStatus
  eventId: string
  eventTitle: string
  startsAt: string
  goingCount: number
  attendees?: Attendee[]
  onDismiss: () => void
}

const formatDateShort = (value: string) => {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return date.toLocaleString([], { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })
}

const config = {
  going: {
    icon: CheckCircle2,
    headline: "You're in!",
    subline: 'Your spot is confirmed. See you there.',
    tint: 'bento-tint-sage',
    orbColor: 'bg-[color:var(--tint-sage)]',
    chipClass: 'bg-[color:var(--tint-sage)] border border-border-secondary text-content-primary',
    label: 'Going',
    particleClass: 'rsvp-particle-sage',
  },
  interested: {
    icon: Sparkles,
    headline: "You're keeping an eye on this.",
    subline: "We'll show you updates as things fill up.",
    tint: 'bento-tint-mist',
    orbColor: 'bg-[color:var(--tint-mist)]',
    chipClass: 'bg-[color:var(--tint-mist)] border border-border-secondary text-content-primary',
    label: 'Interested',
    particleClass: 'rsvp-particle-mist',
  },
  cant_go: {
    icon: XCircle,
    headline: 'No worries.',
    subline: "We've noted your RSVP. Maybe next time.",
    tint: 'bento-tint-rose',
    orbColor: 'bg-[color:var(--tint-rose)]',
    chipClass: 'bg-[color:var(--tint-rose)] border border-border-secondary text-content-primary',
    label: "Can't go",
    particleClass: 'rsvp-particle-rose',
  },
}

export function RsvpSheet({
  status,
  eventId,
  eventTitle,
  startsAt,
  goingCount,
  attendees = [],
  onDismiss,
}: RsvpSheetProps) {
  const router = useRouter()
  const c = config[status]
  const Icon = c.icon
  const [visible, setVisible] = useState(false)
  const [particles, setParticles] = useState<{ id: number; x: number; y: number; delay: number; size: number }[]>([])
  const autoRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  // Entrance animation
  useEffect(() => {
    const raf = requestAnimationFrame(() => setVisible(true))

    // Generate celebration particles for going
    if (status === 'going') {
      const pts = Array.from({ length: 14 }, (_, i) => ({
        id: i,
        x: 20 + Math.random() * 60,
        y: 10 + Math.random() * 40,
        delay: i * 60,
        size: 4 + Math.random() * 5,
      }))
      setParticles(pts)
    }

    // Auto-dismiss after 4 seconds
    autoRef.current = setTimeout(() => handleDismiss(), 4200)

    return () => {
      cancelAnimationFrame(raf)
      if (autoRef.current) clearTimeout(autoRef.current)
    }
  }, [])

  const handleDismiss = () => {
    setVisible(false)
    setTimeout(onDismiss, 360)
  }

  const handleViewEvent = () => {
    handleDismiss()
    setTimeout(() => router.push(`/events/${eventId}`), 100)
  }

  return (
    /* Backdrop */
    <div
      className={`fixed inset-0 z-50 flex flex-col items-end justify-end transition-opacity duration-300 ${
        visible ? 'opacity-100' : 'opacity-0'
      }`}
      style={{ background: 'rgba(0,0,0,0.38)' }}
      onClick={handleDismiss}
    >
      {/* Celebration particles (going only) */}
      {status === 'going' && particles.map((p) => (
        <span
          key={p.id}
          aria-hidden
          className="pointer-events-none fixed rounded-full animate-rsvp-particle"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: p.size,
            height: p.size,
            background: 'var(--tint-sage)',
            animationDelay: `${p.delay}ms`,
            opacity: 0,
          }}
        />
      ))}

      {/* Sheet */}
      <div
        className={`relative w-full max-w-lg mx-auto rounded-t-[28px] overflow-hidden transition-transform duration-[360ms] cubic-bezier(0.16,1,0.3,1) ${
          visible ? 'translate-y-0' : 'translate-y-full'
        } ${c.tint}`}
        style={{ paddingBottom: 'env(safe-area-inset-bottom, 1.5rem)' }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Drag handle */}
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full bg-content-primary/20" />
        </div>

        {/* Ambient orb in background */}
        <div
          aria-hidden
          className={`pointer-events-none absolute right-[-15%] top-[-20%] h-52 w-52 rounded-full ${c.orbColor} opacity-60 blur-3xl animate-ambient-float-soft`}
        />

        <div className="relative z-10 px-6 pt-4 pb-6 space-y-5">
          {/* Dismiss button */}
          <button
            onClick={handleDismiss}
            className="absolute right-4 top-4 p-1.5 rounded-full hover:bg-accent-muted transition-colors"
            aria-label="Close"
          >
            <X className="h-4 w-4 text-content-tertiary" />
          </button>

          {/* Status badge + headline */}
          <div className="space-y-3 animate-rsvp-entrance" style={{ animationDelay: '60ms' }}>
            <div className="flex items-center gap-2.5">
              <span className={`inline-flex items-center gap-1.5 rounded-pill px-3 py-1.5 text-callout font-medium ${c.chipClass}`}>
                <Icon className="h-3.5 w-3.5" />
                {c.label}
              </span>
            </div>
            <div>
              <h2 className="text-title text-content-primary font-semibold">{c.headline}</h2>
              <p className="text-callout text-content-secondary mt-1">{c.subline}</p>
            </div>
          </div>

          {/* Event details */}
          <div
            className="rounded-[18px] bg-surface-primary/60 backdrop-blur-sm border border-border-secondary p-4 space-y-2 animate-rsvp-entrance"
            style={{ animationDelay: '120ms' }}
          >
            <p className="text-body text-content-primary font-medium leading-snug line-clamp-2">{eventTitle}</p>
            <div className="flex items-center gap-1.5 text-callout text-content-secondary">
              <Calendar className="h-3.5 w-3.5 flex-shrink-0" />
              <span>{formatDateShort(startsAt)}</span>
            </div>
          </div>

          {/* Who's going (only when going or interested) */}
          {status !== 'cant_go' && goingCount > 0 && (
            <div
              className="space-y-2.5 animate-rsvp-entrance"
              style={{ animationDelay: '180ms' }}
            >
              <BentoDivider variant="secondary" />
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-callout text-content-secondary">
                  <Users className="h-3.5 w-3.5" />
                  <span>{goingCount} going</span>
                </div>
                {attendees.length > 0 && (
                  <div className="flex items-center">
                    {attendees.slice(0, 5).map((person, idx) => (
                      <div key={person.id} className={idx === 0 ? '' : '-ml-2.5'} style={{ zIndex: 5 - idx }}>
                        <Avatar src={person.avatar_url} size="sm" />
                      </div>
                    ))}
                    {goingCount > attendees.length && (
                      <span className="ml-2.5 text-caption text-content-tertiary">
                        +{goingCount - attendees.length}
                      </span>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Actions */}
          <div
            className="flex gap-2.5 animate-rsvp-entrance"
            style={{ animationDelay: '240ms' }}
          >
            <Button
              variant="primary"
              className="flex-1"
              onClick={handleViewEvent}
            >
              View event
              <ArrowRight className="h-4 w-4" />
            </Button>
            <Button variant="secondary" onClick={handleDismiss} className="px-4">
              Done
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
