'use client'

import { useEffect, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Avatar } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { BentoDivider } from '@/components/ui/bento'
import { Search, UserPlus, X } from 'lucide-react'

const SEARCH_DELAY = 320

type SearchResult = {
  id: string
  username: string | null
  full_name: string | null
  avatar_url: string | null
  bio: string | null
  location: string | null
  early_supporter_number: number | null
  founder_number: number | null
  is_founder?: boolean | null
  is_following: boolean
}

interface PeopleTabProps {
  feedMode: 'discover' | 'following'
  followingSet: Set<string>
  followingLoading: boolean
}

export function PeopleTab({ feedMode, followingSet, followingLoading }: PeopleTabProps) {
  const router = useRouter()
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<SearchResult[]>([])
  const [followingProfiles, setFollowingProfiles] = useState<SearchResult[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const debounceRef = useRef<number | null>(null)
  const abortRef = useRef<AbortController | null>(null)

  useEffect(() => {
    if (feedMode !== 'following') return
    let active = true
    setError(null)
    fetch('/api/following')
      .then((response) => {
        if (!response.ok) throw new Error('Following fetch failed')
        return response.json() as Promise<{ results?: Array<Omit<SearchResult, 'bio' | 'location'>> }>
      })
      .then((data) => {
        if (!active) return
        const profiles = (data.results ?? []).map((row) => ({
          ...row,
          bio: null,
          location: null,
        }))
        setFollowingProfiles(profiles)
      })
      .catch(() => {
        if (!active) return
        setFollowingProfiles([])
      })
    return () => {
      active = false
    }
  }, [feedMode, followingSet])

  useEffect(() => {
    if (feedMode === 'following') {
      const normalized = query.trim().toLowerCase()
      if (!normalized) {
        setResults(followingProfiles)
      } else {
        setResults(
          followingProfiles.filter((person) => {
            const username = (person.username ?? '').toLowerCase()
            const fullName = (person.full_name ?? '').toLowerCase()
            return username.includes(normalized) || fullName.includes(normalized)
          })
        )
      }
      setError(null)
      setLoading(false)
      return
    }

    if (!query.trim()) {
      setResults([])
      setError(null)
      setLoading(false)
      return
    }

    if (debounceRef.current) {
      window.clearTimeout(debounceRef.current)
    }

    const controller = new AbortController()
    abortRef.current?.abort()
    abortRef.current = controller

    setLoading(true)
    setError(null)

    debounceRef.current = window.setTimeout(async () => {
      try {
        const response = await fetch(`/api/users/search?q=${encodeURIComponent(query)}`, {
          signal: controller.signal,
        })
        if (!response.ok) {
          throw new Error('Search failed')
        }
        const data = await response.json()
        setResults(data.results ?? [])
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          setError('Search failed. Try again.')
        }
      } finally {
        setLoading(false)
      }
    }, SEARCH_DELAY)

    return () => {
      if (debounceRef.current) {
        window.clearTimeout(debounceRef.current)
      }
      controller.abort()
    }
  }, [query, feedMode, followingProfiles])

  const handleFollowToggle = async (person: SearchResult, shouldFollow: boolean) => {
    const endpoint = shouldFollow ? '/api/follow' : '/api/unfollow'
    setResults((prev) =>
      prev.map((item) => (item.id === person.id ? { ...item, is_following: shouldFollow } : item))
    )
    setFollowingProfiles((prev) => {
      if (shouldFollow) {
        return prev.some((item) => item.id === person.id)
          ? prev.map((item) => (item.id === person.id ? { ...item, is_following: true } : item))
          : [{ ...person, is_following: true }, ...prev]
      }
      return prev.filter((item) => item.id !== person.id)
    })

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ following_id: person.id }),
      })
      if (!response.ok) {
        throw new Error('Request failed')
      }
      window.dispatchEvent(new Event('pre:following-changed'))
    } catch {
      setResults((prev) =>
        prev.map((item) => (item.id === person.id ? { ...item, is_following: !shouldFollow } : item))
      )
      if (!shouldFollow) {
        setFollowingProfiles((prev) => [{ ...person, is_following: true }, ...prev.filter((item) => item.id !== person.id)])
      } else {
        setFollowingProfiles((prev) => prev.filter((item) => item.id !== person.id))
      }
    }
  }

  const resultEmpty =
    !loading &&
    (feedMode === 'following' || query.trim().length > 0) &&
    results.length === 0

  return (
    <section className="space-y-3">
      <div className="home-panel-soft space-y-3 p-4">
        <div className="home-section-head">
          <div>
            <h3 className="text-title type-h2 text-content-primary">People</h3>
            <p className="text-callout text-content-secondary">Search by handle</p>
          </div>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-content-tertiary" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={feedMode === 'following' ? 'Search followed people' : 'Search @username'}
            className="w-full rounded-full border border-border-secondary/30 bg-[color:var(--input-background)] py-2.5 pl-9 pr-10 text-[15px] font-medium leading-[1.5] text-[color:var(--input-text)] placeholder:text-[color:var(--input-placeholder)] caret-[color:var(--input-text)] focus:outline-none focus:ring-2 focus:ring-content-primary/10"
            data-input-contrast="true"
            autoComplete="username"
            autoCorrect="off"
            autoCapitalize="none"
            spellCheck={false}
            style={{ color: 'var(--input-text)', WebkitTextFillColor: 'var(--input-text)', caretColor: 'var(--input-text)' }}
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded-full p-1 text-content-tertiary hover:text-content-primary"
              aria-label="Clear search"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>

      <div className="space-y-3">
        {(loading || (feedMode === 'following' && followingLoading)) && (
          <div className="home-panel-soft px-4 py-6 text-center text-callout text-content-secondary animate-section-reveal">
            {feedMode === 'following' ? 'Loading followed people…' : 'Searching people…'}
          </div>
        )}

        {error && (
          <div className="home-panel-soft px-4 py-6 text-center text-callout text-error">
            {error}
          </div>
        )}

        {resultEmpty && (
          <div className="home-panel-soft text-center">
            <div className="flex flex-col items-center justify-center py-6 animate-section-reveal">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-surface-secondary">
                <UserPlus className="h-8 w-8 text-content-tertiary" />
              </div>
              <h3 className="mb-2 text-headline type-h3 text-content-primary">No matches yet</h3>
              <p className="max-w-xs text-body text-content-secondary">
                {feedMode === 'following'
                  ? 'You are not following anyone yet, or no followed profile matches this search.'
                  : 'Try another name or username.'}
              </p>
            </div>
          </div>
        )}

        {!loading &&
          results.map((person, index) => {
            // Suppress raw coordinate strings (e.g. "43.6704, -79.3942") that
            // may have been stored when reverse geocoding failed — they reveal
            // precise location and look bad in the UI.
            const coordinatePattern = /^-?\d+(\.\d+)?,\s*-?\d+(\.\d+)?$/
            const safeLocation =
              person.location && !coordinatePattern.test(person.location.trim())
                ? person.location
                : null
            const meta = safeLocation || person.bio || ''
            const target = person.username ? `/profile/${person.username}` : `/u/${person.id}`
            return (
              <article
                key={person.id}
                className="home-panel-soft dynamic-card cursor-pointer animate-section-reveal p-[clamp(0.9rem,3.6vw,1rem)]"
                style={{ animationDelay: `${index * 55}ms` }}
                onClick={() => router.push(target)}
              >
                <div className="flex items-center gap-4">
                  <Avatar src={person.avatar_url} size="lg" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-body font-medium text-content-primary">
                      {person.full_name || person.username || 'Unknown'}
                    </p>
                    {person.username && <p className="text-callout text-content-secondary">@{person.username}</p>}
                    {meta && (
                      <>
                        <BentoDivider variant="secondary" className="my-2" />
                        <p className="truncate text-caption text-content-tertiary type-align-body">{meta}</p>
                      </>
                    )}
                  </div>
                  <Button
                    size="sm"
                    variant={person.is_following ? 'secondary' : 'primary'}
                    onClick={(event) => {
                      event.stopPropagation()
                      handleFollowToggle(person, !person.is_following)
                    }}
                  >
                    {person.is_following ? 'Following' : 'Follow'}
                  </Button>
                </div>
              </article>
            )
          })}
      </div>
    </section>
  )
}
