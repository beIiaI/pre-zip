'use client'

import { useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import { Avatar } from '@/components/ui/avatar'
import { Bell, Settings, MessageCircle } from 'lucide-react'
import type { Profile } from '@/types/database'
import { MemberBadgeStack } from '@/components/ui/member-badge-stack'
import { PreLogotype } from '@/components/ui/pre-logotype'

interface Props {
  profile: Profile
}

export function HomeHeader({ profile }: Props) {
  const hasEarlySupporterNumber =
    profile.early_supporter_number !== null && profile.early_supporter_number !== undefined
  const isFounder = profile.is_founder === true
  const hasMemberBadges = isFounder || hasEarlySupporterNumber
  const [logoActive, setLogoActive] = useState(false)
  const logoTimer = useRef<number | null>(null)

  useEffect(() => {
    return () => {
      if (logoTimer.current) {
        window.clearTimeout(logoTimer.current)
      }
    }
  }, [])

  const triggerLogo = () => {
    setLogoActive(true)
    if (logoTimer.current) {
      window.clearTimeout(logoTimer.current)
    }
    logoTimer.current = window.setTimeout(() => {
      setLogoActive(false)
    }, 900)
  }

  return (
    <header className="relative overflow-hidden px-4 py-4">
      <span
        aria-hidden
        className="pointer-events-none absolute left-[-12%] top-1/2 h-16 w-16 -translate-y-1/2 rounded-full bg-content-primary/10 blur-2xl animate-ambient-float-soft"
      />
      <span
        aria-hidden
        className="pointer-events-none absolute right-[-10%] top-1/2 h-14 w-14 -translate-y-1/2 rounded-full bg-content-primary/10 blur-2xl animate-ambient-float-soft-reverse"
      />
      <span aria-hidden className="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-border-secondary to-transparent" />

      <div className="relative z-10 flex items-center justify-between">
        {/* Logo */}
        <button
          onClick={triggerLogo}
          className="transition-transform"
          aria-label="pre"
        >
          <PreLogotype
            size="small"
            clearspace={false}
            wordmarkClassName={logoActive ? 'pre-logo-animate' : ''}
          />
        </button>

        {/* Actions */}
        <div className="flex items-center gap-2">
          {/* Notifications */}
          <Link
            href="/notifications"
            className="p-2 rounded-full hover:bg-accent-muted transition-colors relative hover:scale-[1.04]"
            data-testid="home-notifications-link"
          >
            <Bell className="h-5 w-5 text-content-primary" />
          </Link>

          {/* Messages */}
          <Link
            href="/messages"
            className="p-2 rounded-full hover:bg-accent-muted transition-colors hover:scale-[1.04]"
            data-testid="home-messages-link"
          >
            <MessageCircle className="h-5 w-5 text-content-primary" />
          </Link>

          {/* Settings */}
          <Link
            href="/settings"
            className="p-2 rounded-full hover:bg-accent-muted transition-colors hover:scale-[1.04]"
            data-testid="home-settings-link"
          >
            <Settings className="h-5 w-5 text-content-primary" />
          </Link>

          {/* Profile */}
          <Link
            href="/profile"
            className="flex items-center gap-2 pl-2"
            data-testid="home-profile-link"
          >
            <Avatar src={profile.avatar_url} size="sm" />
            {hasMemberBadges && (
              <MemberBadgeStack
                isFounder={isFounder}
                founderNumber={profile.founder_number}
                earlySupporterNumber={profile.early_supporter_number}
                size="sm"
              />
            )}
          </Link>
        </div>
      </div>
    </header>
  )
}
