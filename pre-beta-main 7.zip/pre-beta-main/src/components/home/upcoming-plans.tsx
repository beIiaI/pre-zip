'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Calendar, CheckCircle2, ChevronRight, Plus, Sparkles } from 'lucide-react'
import { BentoDivider } from '@/components/ui/bento'

type RsvpStatus = 'going' | 'interested' | 'cant_go'

type EventItem = {
  id: string
  title: string
  starts_at: string
  location_text: string | null
  my_rsvp: RsvpStatus
  rsvp_counts: { going: number; interested: number; cant_go: number }
}

const formatEventTime = (value: string) => {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return ''
  const now = new Date()
  const diffMs = date.getTime() - now.getTime()
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))

  if (diffDays === 0) return 'Today · ' + date.toLocaleString([], { hour: 'numeric', minute: '2-digit' })
  if (diffDays === 1) return 'Tomorrow · ' + date.toLocaleString([], { hour: 'numeric', minute: '2-digit' })
  if (diffDays < 7) return date.toLocaleString([], { weekday: 'short', hour: 'numeric', minute: '2-digit' })
  return date.toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })
}

export function UpcomingPlans() {
  const router = useRouter()
  const [events, setEvents] = useState<EventItem[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let active = true
    fetch('/api/events/my-rsvps')
      .then((res) => res.json())
      .then((data) => {
        if (!active) return
        const now = new Date()
        const upcoming = (data.events ?? [])
          .filter((e: EventItem) => new Date(e.starts_at) >= now && (e.my_rsvp === 'going' || e.my_rsvp === 'interested'))
          .slice(0, 4)
        setEvents(upcoming)
      })
      .catch(() => {
        if (!active) return
        setEvents([])
      })
      .finally(() => {
        if (active) setLoading(false)
      })
    return () => {
      active = false
    }
  }, [])

  if (loading || events.length === 0) return null

  return (
    <section className="space-y-3 animate-section-reveal">
      {/* Section header */}
      <div className="home-section-head px-1.5 py-1">
        <div>
          <h3 className="text-title type-h2 text-content-primary">Coming up</h3>
          <p className="text-callout text-content-secondary">Plans you've committed to</p>
        </div>
        <button
          onClick={() => router.push('/plans')}
          className="flex items-center gap-1 text-callout text-content-secondary hover:text-content-primary transition-colors"
        >
          See all
          <ChevronRight className="h-3.5 w-3.5" />
        </button>
      </div>

      {/* Horizontal scroll row */}
      <div className="flex gap-3 overflow-x-auto pb-1 -mx-4 px-4 snap-x snap-mandatory scrollbar-none">
        {events.map((event, index) => (
          <button
            key={event.id}
            onClick={() => router.push(`/events/${event.id}`)}
            className={`flex-shrink-0 snap-start w-[clamp(13rem,62vw,16rem)] rounded-[18px] border border-bento-border text-left transition-all hover:-translate-y-0.5 animate-section-reveal overflow-hidden ${
              event.my_rsvp === 'going' ? 'bento-tint-sage' : 'bento-tint-mist'
            }`}
            style={{ animationDelay: `${index * 60}ms` }}
          >
            <div className="p-4 space-y-2.5">
              {/* Status chip */}
              <div className="flex items-center gap-1.5">
                {event.my_rsvp === 'going' ? (
                  <span className="inline-flex items-center gap-1 rounded-pill bg-surface-primary/50 border border-border-secondary px-2 py-0.5 text-[10px] font-semibold text-content-primary uppercase tracking-wide">
                    <CheckCircle2 className="h-2.5 w-2.5" />
                    Going
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 rounded-pill bg-surface-primary/50 border border-border-secondary px-2 py-0.5 text-[10px] font-semibold text-content-primary uppercase tracking-wide">
                    <Sparkles className="h-2.5 w-2.5" />
                    Interested
                  </span>
                )}
              </div>
              {/* Title */}
              <p className="text-callout font-semibold text-content-primary leading-snug line-clamp-2">{event.title}</p>
              {/* Time */}
              <div className="flex items-center gap-1.5 text-caption text-content-secondary">
                <Calendar className="h-3 w-3 flex-shrink-0" />
                <span>{formatEventTime(event.starts_at)}</span>
              </div>
              {/* Going count */}
              {event.rsvp_counts.going > 0 && (
                <p className="text-caption text-content-tertiary">{event.rsvp_counts.going} going</p>
              )}
            </div>
          </button>
        ))}

        {/* "Create plan" nudge card */}
        <button
          onClick={() => router.push('/events/new')}
          className="flex-shrink-0 snap-start w-[clamp(10rem,46vw,13rem)] rounded-[18px] border border-dashed border-border-primary/50 text-left flex flex-col items-center justify-center gap-2 p-4 opacity-60 hover:opacity-90 transition-all"
        >
          <div className="h-9 w-9 rounded-full bg-surface-secondary flex items-center justify-center">
            <Plus className="h-4 w-4 text-content-secondary" />
          </div>
          <p className="text-caption text-content-secondary text-center leading-tight">Plan something new</p>
        </button>
      </div>
    </section>
  )
}
