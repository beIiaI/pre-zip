'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { BentoDivider, BentoLabel } from '@/components/ui/bento'
import { Users, Plus, Globe, Lock } from 'lucide-react'
import { useAuth } from '@/components/providers/auth-provider'

interface CircleItem {
  id: string
  name: string
  description: string | null
  is_public: boolean
  category: string | null
  is_member: boolean
  creator_id: string
}

interface CirclesTabProps {
  feedMode: 'discover' | 'following'
  followingSet: Set<string>
  followingLoading: boolean
}

export function CirclesTab({ feedMode, followingSet, followingLoading }: CirclesTabProps) {
  const { user } = useAuth()
  const router = useRouter()
  const [circles, setCircles] = useState<CircleItem[]>([])
  const [loading, setLoading] = useState(true)
  const [deletingCircleId, setDeletingCircleId] = useState<string | null>(null)

  const loadCircles = () => {
    setLoading(true)
    fetch('/api/circles')
      .then((res) => res.json())
      .then((data) => {
        setCircles(data.circles ?? [])
      })
      .finally(() => setLoading(false))
  }

  useEffect(() => {
    loadCircles()
  }, [])

  const handleJoin = async (circleId: string) => {
    setCircles((prev) =>
      prev.map((circle) =>
        circle.id === circleId ? { ...circle, is_member: true } : circle
      )
    )
    const response = await fetch('/api/circles/members', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ circle_id: circleId }),
    })
    if (!response.ok) {
      setCircles((prev) =>
        prev.map((circle) =>
          circle.id === circleId ? { ...circle, is_member: false } : circle
        )
      )
    }
  }

  const handleLeave = async (circleId: string) => {
    setCircles((prev) =>
      prev.map((circle) =>
        circle.id === circleId ? { ...circle, is_member: false } : circle
      )
    )
    const response = await fetch('/api/circles/members', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ circle_id: circleId }),
    })
    if (!response.ok) {
      setCircles((prev) =>
        prev.map((circle) =>
          circle.id === circleId ? { ...circle, is_member: true } : circle
        )
      )
    }
  }

  const handleDelete = async (circleId: string) => {
    if (deletingCircleId) return
    const confirmed = window.confirm('Delete this circle? This cannot be undone.')
    if (!confirmed) return

    const previous = circles
    setDeletingCircleId(circleId)
    setCircles((prev) => prev.filter((circle) => circle.id !== circleId))

    try {
      const response = await fetch(`/api/circles/${encodeURIComponent(circleId)}`, {
        method: 'DELETE',
      })
      if (!response.ok) {
        const payload = await response.json().catch(() => ({}))
        throw new Error(payload.error || 'Unable to delete circle')
      }
    } catch {
      setCircles(previous)
    } finally {
      setDeletingCircleId(null)
    }
  }

  const visibleCircles =
    feedMode === 'following'
      ? circles.filter((circle) => followingSet.has(circle.creator_id))
      : circles

  return (
    <section className="space-y-3">
      <div className="home-section-head px-1.5 pb-1">
        <div>
          <h3 className="text-title type-h2 text-content-primary">Circles</h3>
          <p className="text-callout text-content-secondary">Private and public communities</p>
        </div>
        <Button size="sm" variant="secondary" onClick={() => router.push('/circles/new')}>
          <Plus className="h-4 w-4" />
          New
        </Button>
      </div>

      <div>
        {loading ? (
          <div className="home-panel-soft">
            <div className="flex items-center justify-center py-11">
              <Users className="h-6 w-6 text-content-tertiary animate-micro-bob" />
            </div>
          </div>
        ) : feedMode === 'following' && followingLoading ? (
          <div className="home-panel-soft">
            <div className="flex items-center justify-center py-11">
              <Users className="h-6 w-6 text-content-tertiary animate-micro-bob" />
            </div>
          </div>
        ) : visibleCircles.length === 0 ? (
          <div className="home-panel-soft text-center">
            <div className="flex flex-col items-center justify-center py-11 animate-section-reveal">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-surface-secondary">
                <Users className="h-8 w-8 text-content-tertiary" />
              </div>
              <h3 className="mb-2 text-headline type-h3 text-content-primary">
                {feedMode === 'following' ? 'No circles from followed people yet' : 'No circles yet'}
              </h3>
              <p className="mb-6 max-w-xs text-body text-content-secondary">
                {feedMode === 'following'
                  ? 'Follow more people to personalize this feed, or switch back to Discover.'
                  : 'Start a circle to connect with people who share your interests.'}
              </p>
              <Button onClick={() => router.push('/circles/new')}>
                <Plus className="h-4 w-4" />
                Create Circle
              </Button>
            </div>
          </div>
        ) : (
          <div className="grid gap-3 md:grid-cols-2">
            {visibleCircles.map((circle, index) => (
              <article
                key={circle.id}
                className="home-panel-soft dynamic-card animate-section-reveal space-y-3 p-[clamp(0.9rem,3.6vw,1rem)]"
                style={{ animationDelay: `${index * 65}ms` }}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-headline type-h3 text-content-primary">{circle.name}</p>
                  </div>
                  <BentoLabel className="gap-1 border-border-secondary/35 bg-surface-primary/55">
                    {circle.is_public ? <Globe className="h-3 w-3" /> : <Lock className="h-3 w-3" />}
                    {circle.is_public ? 'Public' : 'Private'}
                  </BentoLabel>
                </div>
                <BentoDivider variant="secondary" />

                {circle.description && (
                  <p className="text-body text-content-secondary type-align-body">{circle.description}</p>
                )}

                <Button
                  variant={circle.is_member ? 'secondary' : 'primary'}
                  className="w-full"
                  disabled={!circle.is_public && !circle.is_member}
                  onClick={() => (circle.is_member ? handleLeave(circle.id) : handleJoin(circle.id))}
                >
                  {circle.is_member ? 'Leave circle' : circle.is_public ? 'Join circle' : 'Private circle'}
                </Button>
                {user?.id === circle.creator_id && (
                  <Button
                    variant="secondary"
                    className="w-full"
                    disabled={deletingCircleId === circle.id}
                    onClick={() => handleDelete(circle.id)}
                  >
                    {deletingCircleId === circle.id ? 'Deleting…' : 'Delete circle'}
                  </Button>
                )}
              </article>
            ))}
          </div>
        )}
      </div>
    </section>
  )
}
