import { ReactNode } from 'react'

interface NavBarProps {
  items: {
    icon: ReactNode
    label: string
    active?: boolean
    onClick?: () => void
  }[]
}

export function NavBar({ items }: NavBarProps) {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-surface-primary border-t border-border-secondary">
      <div className="flex items-center justify-around px-[clamp(0.75rem,4vw,1.5rem)] py-[clamp(0.5rem,2.8vw,0.75rem)] safe-bottom">
        {items.map((item, index) => (
          <button
            key={index}
            onClick={item.onClick}
            className="flex flex-col items-center gap-1 py-2 px-[clamp(0.625rem,3.2vw,1rem)] min-w-[clamp(3rem,16vw,4rem)]"
          >
            <div className={item.active ? 'text-content-primary' : 'text-content-tertiary'}>
              {item.icon}
            </div>
            <span className={`text-[clamp(0.5625rem,2.8vw,0.625rem)] ${item.active ? 'text-content-primary' : 'text-content-tertiary'}`}>
              {item.label}
            </span>
          </button>
        ))}
      </div>
    </div>
  )
}
