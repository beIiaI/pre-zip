import { ReactNode, ButtonHTMLAttributes } from 'react'
import { LoadingDots } from '@/components/ui/loading-dots'

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost'
  size?: 'default' | 'large'
  fullWidth?: boolean
  loading?: boolean
  children: ReactNode
}

export function Button({
  variant = 'primary',
  size = 'default',
  fullWidth = false,
  loading = false,
  disabled,
  children,
  className = '',
  ...props
}: ButtonProps) {
  const baseStyles = 'inline-flex items-center justify-center rounded-full transition-all duration-200 enabled:hover:-translate-y-[1px]'

  const variantStyles = {
    primary:
      'bg-accent-primary text-content-inverse active:opacity-90 disabled:opacity-30',
    secondary:
      'bg-transparent border border-border-primary text-content-primary active:bg-accent-muted disabled:opacity-30',
    ghost:
      'bg-transparent text-content-primary active:bg-accent-muted disabled:opacity-30',
  }

  const sizeStyles = {
    default: 'px-[clamp(1rem,5vw,1.5rem)] py-[clamp(0.625rem,3.2vw,0.75rem)] text-[clamp(0.875rem,3.8vw,0.9375rem)]',
    large: 'px-[clamp(1.25rem,5.5vw,2rem)] py-[clamp(0.75rem,3.8vw,1rem)] text-[clamp(0.9375rem,4vw,1rem)]',
  }

  const widthStyle = fullWidth ? 'w-full' : ''

  return (
    <button
      className={`${baseStyles} ${variantStyles[variant]} ${sizeStyles[size]} ${widthStyle} ${className}`}
      disabled={disabled || loading}
      {...props}
    >
      {loading ? <LoadingDots size="md" /> : children}
    </button>
  )
}
