'use client'

import { ReactNode, useEffect, useState } from 'react'
import { X } from 'lucide-react'
import { cn } from '@/lib/utils'

interface BottomSheetProps {
  isOpen: boolean
  onClose: () => void
  title?: string
  children: ReactNode
}

export function BottomSheet({ isOpen, onClose, title, children }: BottomSheetProps) {
  const [visible, setVisible] = useState(isOpen)

  useEffect(() => {
    if (isOpen) {
      setVisible(true)
    }
  }, [isOpen])

  const handleOverlayClick = () => {
    onClose()
  }

  const handleTransitionEnd = () => {
    if (!isOpen) {
      setVisible(false)
    }
  }

  if (!visible) return null

  return (
    <div
      className={cn(
        'fixed inset-0 z-50 flex items-end bg-black/20 dark:bg-black/60 transition-opacity duration-200',
        isOpen ? 'opacity-100' : 'opacity-0'
      )}
      onClick={handleOverlayClick}
    >
      <div
        className={cn(
          'w-full max-h-[90vh] rounded-t-2xl bg-surface-primary border-t border-border-secondary overflow-hidden transition-transform duration-300',
          isOpen ? 'translate-y-0' : 'translate-y-full'
        )}
        onClick={(e) => e.stopPropagation()}
        onTransitionEnd={handleTransitionEnd}
        role="dialog"
        aria-modal="true"
      >
        <div className="flex justify-center pt-3 pb-2">
          <div className="w-10 h-1 rounded-full bg-[#E0E0E0] dark:bg-[#3A3A3A]" />
        </div>

        {title && (
          <div className="px-6 py-4 border-b border-[#1A1A1A]/10 dark:border-white/10 flex items-center justify-between">
            <h2 className="text-[22px] leading-tight text-content-primary">{title}</h2>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-surface-secondary flex items-center justify-center"
            >
              <X className="w-4 h-4 text-content-primary" strokeWidth={1.5} />
            </button>
          </div>
        )}

        <div className="overflow-y-auto" style={{ maxHeight: title ? 'calc(90vh - 120px)' : 'calc(90vh - 40px)' }}>
          {children}
        </div>
      </div>
    </div>
  )
}
