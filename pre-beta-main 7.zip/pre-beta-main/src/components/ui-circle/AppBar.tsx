import { ReactNode } from 'react'

interface AppBarProps {
  title?: string
  left?: ReactNode
  right?: ReactNode
  subtitle?: string
}

export function AppBar({ title, left, right, subtitle }: AppBarProps) {
  return (
    <div className="app-header">
      <div className="px-[clamp(1rem,5vw,1.5rem)] pt-[max(3.25rem,env(safe-area-inset-top))] pb-4">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            {left}
            {title && <h1 className="text-[clamp(1.5rem,7vw,2rem)] leading-tight text-content-primary">{title}</h1>}
          </div>
          {right}
        </div>
        {subtitle && <p className="text-sm text-content-secondary">{subtitle}</p>}
      </div>
    </div>
  )
}
