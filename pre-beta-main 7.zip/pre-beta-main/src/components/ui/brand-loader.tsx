'use client'

import { useEffect, useState } from 'react'
import { cn } from '@/lib/utils'
import { LoadingDots } from '@/components/ui/loading-dots'
import { PreLogotype } from '@/components/ui/pre-logotype'

interface BrandLoaderProps {
  name?: string | null
  message?: string
  showWelcome?: boolean
  showDots?: boolean
  className?: string
}

const LOADER_LINES = [
  'Preparing your circles',
  'Syncing conversations',
  'Preparing your next move',
]

const getSalutation = () => {
  const hour = new Date().getHours()
  if (hour >= 5 && hour < 12) return 'Good morning'
  if (hour >= 12 && hour < 17) return 'Good afternoon'
  if (hour >= 17 && hour < 22) return 'Good evening'
  return 'Good night'
}

export function BrandLoader({ name, message, showWelcome, showDots = true, className }: BrandLoaderProps) {
  const trimmedName = typeof name === 'string' ? name.trim() : ''
  const shouldShowWelcome = showWelcome ?? !!trimmedName
  const [salutation, setSalutation] = useState('Welcome back')
  const [lineIndex, setLineIndex] = useState(0)

  useEffect(() => {
    setSalutation(getSalutation())
  }, [])

  useEffect(() => {
    if (message) return
    const interval = window.setInterval(() => {
      setLineIndex((current) => (current + 1) % LOADER_LINES.length)
    }, 1700)

    return () => {
      window.clearInterval(interval)
    }
  }, [message])

  const greetingLine = trimmedName ? `${salutation}, ${trimmedName}.` : `${salutation}.`

  return (
    <div
      className={cn(
        'relative flex w-full max-w-[min(92vw,28rem)] flex-col items-center justify-center overflow-visible px-4 py-8 text-center sm:px-8 sm:py-10',
        className
      )}
    >
      <div className="pointer-events-none absolute inset-0 z-0 overflow-visible">
        <span className="absolute left-[14%] top-[24%] h-[clamp(2.2rem,11vw,3.8rem)] w-[clamp(2.2rem,11vw,3.8rem)] rounded-full bg-content-primary/9 blur-3xl animate-brand-loader-drift-a" />
        <span className="absolute right-[12%] bottom-[26%] h-[clamp(2.1rem,10vw,3.6rem)] w-[clamp(2.1rem,10vw,3.6rem)] rounded-full bg-content-primary/8 blur-3xl animate-brand-loader-drift-b" />
      </div>

      <div className="relative z-10 flex flex-col items-center animate-brand-loader-stack">
        {shouldShowWelcome && (
          <div className="mb-[clamp(0.32rem,0.7vh,0.52rem)] -translate-y-[clamp(6.2rem,15vh,10rem)] animate-brand-loader-intro-block">
            <p className="max-w-[min(90vw,26rem)] px-1 text-[10px] uppercase text-label-caps tracking-[0.16em] text-content-tertiary sm:text-[11px] sm:tracking-[0.2em] animate-brand-loader-greeting">
              {greetingLine}
            </p>
            <p className="mt-1 max-w-[min(90vw,26rem)] px-1 text-[10px] uppercase text-label-caps tracking-[0.15em] text-content-secondary sm:text-[11px] sm:tracking-[0.18em] animate-brand-loader-subtitle">
              Welcome to
            </p>
          </div>
        )}

        <div className={cn('loader-phone-scale relative flex h-[min(42vw,9.65rem)] w-[min(42vw,9.65rem)] items-center justify-center overflow-visible', shouldShowWelcome ? '' : 'mt-0')}>
          <div className="pointer-events-none absolute inset-[-22%] overflow-visible">
            <span className="absolute inset-[0%] rounded-full border border-content-primary/26 animate-brand-loader-concentric-cw" />
            <span className="absolute inset-[8%] rounded-full border border-content-primary/22 animate-brand-loader-concentric-ccw" />
            <span className="absolute inset-[16%] rounded-full border border-content-primary/18 animate-brand-loader-concentric-cw-slow" />
            <span className="absolute inset-[24%] rounded-full border border-content-primary/16 animate-brand-loader-concentric-ccw-fast" />
            <span className="absolute inset-[6%] rounded-full border border-content-primary/12 border-dashed animate-brand-loader-orbit-slow" />
            <span className="absolute inset-[13%] rounded-full bg-content-primary/6 blur-3xl animate-brand-loader-halo" />
            <span className="absolute left-[9%] top-[50%] h-1.5 w-1.5 -translate-y-1/2 rounded-full bg-content-primary/65 shadow-[0_0_10px_color-mix(in_oklab,var(--content-primary)_46%,transparent)] animate-brand-loader-twinkle" />
            <span className="absolute right-[12%] top-[27%] h-1.5 w-1.5 rounded-full bg-content-primary/58 shadow-[0_0_10px_color-mix(in_oklab,var(--content-primary)_42%,transparent)] animate-brand-loader-twinkle-b" />
          </div>

          <PreLogotype
            size="hero"
            clearspace={false}
            wordmarkClassName="relative z-20 animate-brand-loader-logo"
          />
          <span
            aria-hidden
            className="pointer-events-none absolute z-30 -inset-y-2 left-1/2 w-[34%] -translate-x-[220%] bg-gradient-to-r from-transparent via-content-primary/30 to-transparent animate-brand-loader-sweep"
          />
        </div>

        <div className="mt-[clamp(5rem,12.2vh,7.6rem)] translate-y-[clamp(1.9rem,4.2vh,2.8rem)] flex flex-col items-center">
          {showDots && (
            <LoadingDots size="md" className="text-content-secondary animate-brand-loader-dots" />
          )}

          <p
            key={message ? `static-${message}` : `line-${lineIndex}`}
            className="mt-3 min-h-[1.25rem] text-[11px] uppercase text-label-caps tracking-[0.13em] text-content-tertiary animate-brand-loader-message"
          >
            {message || LOADER_LINES[lineIndex]}
          </p>
        </div>
      </div>
    </div>
  )
}
