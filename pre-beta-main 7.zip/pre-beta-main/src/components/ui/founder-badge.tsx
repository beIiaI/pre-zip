import { cn, formatFounderNumber } from '@/lib/utils'

interface Props {
  number?: number | null
  size?: 'sm' | 'md'
  className?: string
}

export function FounderBadge({ number = null, size = 'md', className }: Props) {
  const isSmall = size === 'sm'

  return (
    <div
      className={cn(
        'inline-flex items-center gap-2 rounded-full border border-[#4E2A2A]/35 bg-gradient-to-r from-[#4A202B] via-[#5A2833] to-[#6C3240] text-[#F7D9CC]',
        'dark:border-[#6C4350]/55 dark:from-[#3A1822] dark:via-[#4A202C] dark:to-[#5A2732] dark:text-[#F8D8CB]',
        isSmall ? 'px-2.5 py-0.5 text-[10px]' : 'px-3.5 py-1 text-xs',
        className
      )}
    >
      <span className={cn('uppercase tracking-[0.28em] font-semibold', isSmall ? 'text-[8px]' : 'text-[10px]')}>
        Founder
      </span>
      {number !== null && number !== undefined && (
        <span className={cn('font-mono font-semibold', isSmall ? 'text-[10px]' : 'text-[11px]')}>
          {formatFounderNumber(number)}
        </span>
      )}
    </div>
  )
}
