'use client'

import type { CSSProperties, HTMLAttributes } from 'react'
import type { LucideIcon } from 'lucide-react'
import { cn } from '@/lib/utils'
import { PreLogotype } from '@/components/ui/pre-logotype'

type VisualVariant = 'fullBleed' | 'fullWidth' | 'thumb' | 'door'

const VARIANT_CLASS: Record<VisualVariant, string> = {
  fullBleed: 'media-frame h-[clamp(12.5rem,34vw,18rem)]',
  fullWidth: 'media-frame h-[clamp(8.25rem,20vw,11.5rem)]',
  thumb: 'media-frame h-[clamp(5.4rem,13vw,7.4rem)]',
  door: 'media-frame media-door-mask h-[clamp(10.5rem,26vw,14rem)]',
}

function hashSeed(seed: string) {
  let hash = 0
  for (let index = 0; index < seed.length; index += 1) {
    hash = (hash << 5) - hash + seed.charCodeAt(index)
    hash |= 0
  }
  return Math.abs(hash)
}

function buildVisualGradient(seed: string) {
  const hash = hashSeed(seed || 'pre')
  const toneA = hash % 2 === 0 ? 'var(--surface-secondary)' : 'var(--surface-tertiary)'
  const toneB = hash % 3 === 0 ? 'var(--surface-tertiary)' : 'var(--surface-secondary)'
  const toneC = 'var(--surface-primary)'

  return {
    toneA,
    toneB,
    toneC,
    backgroundImage: `
      linear-gradient(
        145deg,
        color-mix(in oklab, ${toneA} 78%, var(--surface-primary)) 0%,
        color-mix(in oklab, ${toneB} 82%, var(--surface-primary)) 52%,
        color-mix(in oklab, ${toneC} 88%, var(--surface-primary)) 100%
      ),
      radial-gradient(
        88% 72% at 14% 8%,
        color-mix(in oklab, var(--content-primary) 12%, transparent) 0%,
        transparent 72%
      ),
      radial-gradient(
        82% 68% at 88% 92%,
        color-mix(in oklab, var(--content-primary) 8%, transparent) 0%,
        transparent 72%
      )
    `,
  }
}

interface VisualSurfaceProps extends HTMLAttributes<HTMLDivElement> {
  seed: string
  variant?: VisualVariant
  title?: string
  subtitle?: string
  icon?: LucideIcon
  showWordmark?: boolean
}

export function VisualSurface({
  seed,
  variant = 'thumb',
  title,
  subtitle,
  icon: Icon,
  showWordmark = true,
  className,
  style,
  ...props
}: VisualSurfaceProps) {
  const visual = buildVisualGradient(seed)
  const mergedStyle: CSSProperties = {
    backgroundImage: visual.backgroundImage,
    ...style,
  }
  const showMeta = Boolean(title || subtitle)

  return (
    <div className={cn('relative isolate overflow-hidden', VARIANT_CLASS[variant], className)} style={mergedStyle} {...props}>
      <span aria-hidden className="media-scrim-top" />

      {showWordmark && (
        <div className="media-scrim-content absolute left-3 top-3 rounded-full px-1.5 py-1 media-copy-solid-scrim-soft">
          <PreLogotype
            size="micro"
            clearspace={false}
            wordmarkClassName="!w-[clamp(1.7rem,8vw,2.1rem)] text-content-primary/95"
          />
        </div>
      )}

      {Icon && (
        <span className="media-scrim-content absolute right-3 top-3 inline-flex h-6 w-6 items-center justify-center rounded-full border border-content-primary/20 bg-surface-primary/58 text-content-primary/88">
          <Icon className="h-[13px] w-[13px]" strokeWidth={1.75} />
        </span>
      )}

      {showMeta && <span aria-hidden className="media-scrim-gradient" />}

      {showMeta && (
        <div className="media-scrim-content absolute inset-x-3 bottom-3 rounded-xl px-2.5 py-2 media-copy-solid-scrim">
          {subtitle && (
            <p className="text-[10px] uppercase tracking-[0.14em] text-content-secondary">
              {subtitle}
            </p>
          )}
          {title && (
            <p className="mt-1 text-[clamp(1rem,3.8vw,1.2rem)] leading-[1.2] text-content-primary">
              {title}
            </p>
          )}
        </div>
      )}
    </div>
  )
}
