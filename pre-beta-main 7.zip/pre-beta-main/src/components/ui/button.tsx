import * as React from 'react'
import { cn } from '@/lib/utils'
import { LoadingDots } from '@/components/ui/loading-dots'

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'outline' | 'danger'
  size?: 'sm' | 'md' | 'lg' | 'icon'
  loading?: boolean
  fullWidth?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size = 'md', loading, fullWidth, disabled, children, ...props }, ref) => {
    const baseStyles = 'inline-flex items-center justify-center font-medium transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-30 rounded-pill enabled:hover:-translate-y-[1px]'
    
    const variants = {
      primary: 'bg-[color:var(--accent-primary)] text-[color:var(--accent-on-primary)] hover:opacity-92 active:brightness-95',
      secondary: 'bg-surface-secondary/35 border border-border-secondary text-content-primary active:bg-surface-tertiary',
      ghost: 'text-content-primary hover:bg-accent-muted/80 active:bg-accent-muted',
      outline: 'border border-border-secondary text-content-primary hover:bg-accent-muted/70',
      danger: 'bg-error text-white hover:opacity-92',
    }
    
    const sizes = {
      sm: 'h-[clamp(2.125rem,8.5vw,2.25rem)] px-[clamp(0.875rem,3.8vw,1rem)] text-[clamp(0.8125rem,3.5vw,0.875rem)] gap-1.5',
      md: 'h-[clamp(2.875rem,12vw,3.25rem)] px-[clamp(1rem,5vw,1.5rem)] text-[clamp(0.875rem,3.8vw,0.9375rem)] gap-2',
      lg: 'h-[clamp(3.125rem,13vw,3.5rem)] px-[clamp(1.25rem,5.5vw,2rem)] text-[clamp(0.9375rem,4vw,1rem)] gap-2',
      icon: 'h-[clamp(2.375rem,9.5vw,2.5rem)] w-[clamp(2.375rem,9.5vw,2.5rem)]',
    }

    return (
      <button
        className={cn(
          baseStyles,
          variants[variant],
          sizes[size],
          fullWidth && 'w-full',
          className
        )}
        disabled={disabled || loading}
        ref={ref}
        {...props}
      >
        {loading ? <LoadingDots size="md" /> : children}
      </button>
    )
  }
)
Button.displayName = 'Button'

export { Button }
