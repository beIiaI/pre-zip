'use client'

import * as React from 'react'
import { cn } from '@/lib/utils'
import { User } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
export interface AvatarProps {
  src?: string | null
  alt?: string
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl'
  className?: string
}

export function Avatar({ src, alt = 'Avatar', size = 'md', className }: AvatarProps) {
  const supabase = React.useMemo(() => createClient(), [])
  const [resolvedSrc, setResolvedSrc] = React.useState<string | null>(null)
  const sizes = {
    xs: 'h-6 w-6',
    sm: 'h-8 w-8',
    md: 'h-12 w-12',
    lg: 'h-16 w-16',
    xl: 'h-24 w-24',
  }

  const iconSizes = {
    xs: 'h-3 w-3',
    sm: 'h-4 w-4',
    md: 'h-6 w-6',
    lg: 'h-8 w-8',
    xl: 'h-12 w-12',
  }

  React.useEffect(() => {
    if (!src) {
      setResolvedSrc(null)
      return
    }

    const normalized = src.trim()
    if (/^(https?:|data:|blob:)/i.test(normalized)) {
      setResolvedSrc(normalized)
      return
    }

    const path = normalized.startsWith('avatars/') ? normalized.replace(/^avatars\//, '') : normalized
    const { data } = supabase.storage.from('avatars').getPublicUrl(path)
    setResolvedSrc(data?.publicUrl ?? null)
  }, [src, supabase])

  return (
    <div
      className={cn(
        'relative rounded-full bg-surface-tertiary flex items-center justify-center overflow-hidden border border-border-secondary',
        sizes[size],
        className
      )}
    >
      {resolvedSrc ? (
        <img
          src={resolvedSrc}
          alt={alt}
          className="h-full w-full object-cover"
        />
      ) : (
        <User className={cn('text-content-tertiary', iconSizes[size])} />
      )}
    </div>
  )
}
