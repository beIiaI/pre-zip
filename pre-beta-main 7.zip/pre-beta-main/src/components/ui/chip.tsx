'use client'

import * as React from 'react'
import { cn } from '@/lib/utils'
import { Check } from 'lucide-react'

export interface ChipProps {
  label: string
  selected?: boolean
  onSelect?: () => void
  disabled?: boolean
  size?: 'sm' | 'md'
}

export function Chip({ label, selected, onSelect, disabled, size = 'md' }: ChipProps) {
  return (
    <button
      type="button"
      onClick={onSelect}
      disabled={disabled}
      className={cn(
        'inline-flex items-center gap-1.5 rounded-pill border transition-all duration-200 enabled:hover:-translate-y-[1px]',
        size === 'sm' ? 'px-3 py-1.5 text-caption' : 'px-4 py-2 text-callout',
        selected
          ? 'bg-content-primary text-content-inverse border-content-primary'
          : 'bg-surface-secondary text-content-primary border-border-primary hover:border-content-primary',
        disabled && 'opacity-50 cursor-not-allowed'
      )}
    >
      {selected && <Check className="h-3.5 w-3.5" />}
      {label}
    </button>
  )
}

export interface ChipGroupProps {
  options: string[]
  selected: string[]
  onChange: (selected: string[]) => void
  max?: number
  disabled?: boolean
  size?: 'sm' | 'md'
}

export function ChipGroup({ options, selected, onChange, max, disabled, size }: ChipGroupProps) {
  const handleSelect = (option: string) => {
    if (selected.includes(option)) {
      onChange(selected.filter(s => s !== option))
    } else {
      if (!max || selected.length < max) {
        onChange([...selected, option])
      }
    }
  }

  return (
    <div className="flex flex-wrap gap-2">
      {options.map(option => (
        <Chip
          key={option}
          label={option}
          selected={selected.includes(option)}
          onSelect={() => handleSelect(option)}
          disabled={disabled}
          size={size}
        />
      ))}
    </div>
  )
}
