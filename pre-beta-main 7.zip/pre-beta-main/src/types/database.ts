export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string
          full_name: string | null
          username: string | null
          bio: string | null
          avatar_url: string | null
          date_of_birth: string | null
          location: string | null
          location_lat: number | null
          location_lng: number | null
          interests: string[]
          user_intent: string[]
          theme_mode: 'light' | 'dark' | 'system'
          amoled_enabled: boolean
          onboarding_completed: boolean
          onboarding_step: number
          early_supporter_number: number | null
          founder_number: number | null
          invite_refresh_count: number
          is_founder: boolean
          is_internal: boolean
          total_points: number
          is_verified: boolean
          verification_type: string | null
          university_verified: boolean
          university_email: string | null
          university_domain: string | null
          university_name: string | null
          university_verified_at: string | null
          university_graduation_year: number | null
          university_grad_year_confirmed_at: string | null
          university_graduated_at: string | null
          profile_visibility: 'public' | 'friends' | 'private'
          message_requests: 'everyone' | 'friends' | 'off'
          show_activity_status: boolean
          show_read_receipts: boolean
          show_location: boolean
          show_university: boolean
          show_college: boolean
          discoverable: boolean
          last_active_at: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          full_name?: string | null
          username?: string | null
          bio?: string | null
          avatar_url?: string | null
          date_of_birth?: string | null
          location?: string | null
          location_lat?: number | null
          location_lng?: number | null
          interests?: string[]
          user_intent?: string[]
          theme_mode?: 'light' | 'dark' | 'system'
          amoled_enabled?: boolean
          onboarding_completed?: boolean
          onboarding_step?: number
          early_supporter_number?: number | null
          founder_number?: number | null
          invite_refresh_count?: number
          is_founder?: boolean
          is_internal?: boolean
          total_points?: number
          is_verified?: boolean
          verification_type?: string | null
          university_verified?: boolean
          university_email?: string | null
          university_domain?: string | null
          university_name?: string | null
          university_verified_at?: string | null
          university_graduation_year?: number | null
          university_grad_year_confirmed_at?: string | null
          university_graduated_at?: string | null
          profile_visibility?: 'public' | 'friends' | 'private'
          message_requests?: 'everyone' | 'friends' | 'off'
          show_activity_status?: boolean
          show_read_receipts?: boolean
          show_location?: boolean
          show_university?: boolean
          show_college?: boolean
          discoverable?: boolean
          last_active_at?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          full_name?: string | null
          username?: string | null
          bio?: string | null
          avatar_url?: string | null
          date_of_birth?: string | null
          location?: string | null
          location_lat?: number | null
          location_lng?: number | null
          interests?: string[]
          user_intent?: string[]
          theme_mode?: 'light' | 'dark' | 'system'
          amoled_enabled?: boolean
          onboarding_completed?: boolean
          onboarding_step?: number
          early_supporter_number?: number | null
          founder_number?: number | null
          invite_refresh_count?: number
          is_founder?: boolean
          is_internal?: boolean
          total_points?: number
          is_verified?: boolean
          verification_type?: string | null
          university_verified?: boolean
          university_email?: string | null
          university_domain?: string | null
          university_name?: string | null
          university_verified_at?: string | null
          university_graduation_year?: number | null
          university_grad_year_confirmed_at?: string | null
          university_graduated_at?: string | null
          profile_visibility?: 'public' | 'friends' | 'private'
          message_requests?: 'everyone' | 'friends' | 'off'
          show_activity_status?: boolean
          show_read_receipts?: boolean
          show_location?: boolean
          show_university?: boolean
          show_college?: boolean
          discoverable?: boolean
          last_active_at?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      profile_college: {
        Row: {
          user_id: string
          college_name: string | null
          college_self_reported: boolean
          college_updated_at: string | null
          college_change_count: number
          created_at: string
          updated_at: string
        }
        Insert: {
          user_id: string
          college_name?: string | null
          college_self_reported?: boolean
          college_updated_at?: string | null
          college_change_count?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          user_id?: string
          college_name?: string | null
          college_self_reported?: boolean
          college_updated_at?: string | null
          college_change_count?: number
          created_at?: string
          updated_at?: string
        }
      }
      circles: {
        Row: {
          id: string
          name: string
          description: string | null
          cover_image_url: string | null
          creator_id: string
          is_public: boolean
          member_count: number
          category: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          description?: string | null
          cover_image_url?: string | null
          creator_id: string
          is_public?: boolean
          member_count?: number
          category?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          description?: string | null
          cover_image_url?: string | null
          creator_id?: string
          is_public?: boolean
          member_count?: number
          category?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      circle_members: {
        Row: {
          id: string
          circle_id: string
          user_id: string
          role: 'admin' | 'moderator' | 'member'
          joined_at: string
        }
        Insert: {
          id?: string
          circle_id: string
          user_id: string
          role?: 'admin' | 'moderator' | 'member'
          joined_at?: string
        }
        Update: {
          id?: string
          circle_id?: string
          user_id?: string
          role?: 'admin' | 'moderator' | 'member'
          joined_at?: string
        }
      }
      events: {
        Row: {
          id: string
          host_id: string | null
          title: string
          description: string | null
          hero_image_url: string | null
          creator_id: string
          circle_id: string | null
          location: string
          location_lat: number | null
          location_lng: number | null
          location_text: string | null
          starts_at: string
          ends_at: string | null
          max_attendees: number | null
          attendee_count: number
          is_public: boolean
          is_campus_only: boolean
          category: string | null
          image_url: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          host_id?: string | null
          title: string
          description?: string | null
          hero_image_url?: string | null
          creator_id: string
          circle_id?: string | null
          location: string
          location_lat?: number | null
          location_lng?: number | null
          location_text?: string | null
          starts_at: string
          ends_at?: string | null
          max_attendees?: number | null
          attendee_count?: number
          is_public?: boolean
          is_campus_only?: boolean
          category?: string | null
          image_url?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          host_id?: string | null
          title?: string
          description?: string | null
          hero_image_url?: string | null
          creator_id?: string
          circle_id?: string | null
          location?: string
          location_lat?: number | null
          location_lng?: number | null
          location_text?: string | null
          starts_at?: string
          ends_at?: string | null
          max_attendees?: number | null
          attendee_count?: number
          is_public?: boolean
          is_campus_only?: boolean
          category?: string | null
          image_url?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      event_rsvps: {
        Row: {
          event_id: string
          user_id: string
          status: 'going' | 'interested' | 'cant_go'
          created_at: string
        }
        Insert: {
          event_id: string
          user_id: string
          status: 'going' | 'interested' | 'cant_go'
          created_at?: string
        }
        Update: {
          event_id?: string
          user_id?: string
          status?: 'going' | 'interested' | 'cant_go'
          created_at?: string
        }
      }
      event_attendees: {
        Row: {
          id: string
          event_id: string
          user_id: string
          status: 'going' | 'maybe' | 'not_going'
          rsvp_at: string
        }
        Insert: {
          id?: string
          event_id: string
          user_id: string
          status?: 'going' | 'maybe' | 'not_going'
          rsvp_at?: string
        }
        Update: {
          id?: string
          event_id?: string
          user_id?: string
          status?: 'going' | 'maybe' | 'not_going'
          rsvp_at?: string
        }
      }
      dm_threads: {
        Row: {
          id: string
          created_at: string
          user_a: string | null
          user_b: string | null
        }
        Insert: {
          id?: string
          created_at?: string
          user_a?: string | null
          user_b?: string | null
        }
        Update: {
          id?: string
          created_at?: string
          user_a?: string | null
          user_b?: string | null
        }
      }
      dm_participants: {
        Row: {
          thread_id: string
          user_id: string
          last_read_at: string | null
          created_at: string
        }
        Insert: {
          thread_id: string
          user_id: string
          last_read_at?: string | null
          created_at?: string
        }
        Update: {
          thread_id?: string
          user_id?: string
          last_read_at?: string | null
          created_at?: string
        }
      }
      dm_messages: {
        Row: {
          id: string
          thread_id: string
          sender_id: string
          body: string
          created_at: string
          edited_at: string | null
          deleted_at: string | null
        }
        Insert: {
          id?: string
          thread_id: string
          sender_id: string
          body: string
          created_at?: string
          edited_at?: string | null
          deleted_at?: string | null
        }
        Update: {
          id?: string
          thread_id?: string
          sender_id?: string
          body?: string
          created_at?: string
          edited_at?: string | null
          deleted_at?: string | null
        }
      }
      messages: {
        Row: {
          id: string
          circle_id: string
          sender_id: string
          content: string
          created_at: string
        }
        Insert: {
          id?: string
          circle_id: string
          sender_id: string
          content: string
          created_at?: string
        }
        Update: {
          id?: string
          circle_id?: string
          sender_id?: string
          content?: string
          created_at?: string
        }
      }
      badges: {
        Row: {
          id: string
          name: string
          description: string
          icon: string
          category: string
          points_required: number | null
          criteria: Json | null
          is_earnable: boolean
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          description: string
          icon: string
          category: string
          points_required?: number | null
          criteria?: Json | null
          is_earnable?: boolean
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          description?: string
          icon?: string
          category?: string
          points_required?: number | null
          criteria?: Json | null
          is_earnable?: boolean
          created_at?: string
        }
      }
      user_badges: {
        Row: {
          id: string
          user_id: string
          badge_id: string
          earned_at: string
          progress: number
        }
        Insert: {
          id?: string
          user_id: string
          badge_id: string
          earned_at?: string
          progress?: number
        }
        Update: {
          id?: string
          user_id?: string
          badge_id?: string
          earned_at?: string
          progress?: number
        }
      }
      university_verifications: {
        Row: {
          id: string
          user_id: string
          email: string
          token_hash: string
          expires_at: string
          used_at: string | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          email: string
          token_hash: string
          expires_at: string
          used_at?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          email?: string
          token_hash?: string
          expires_at?: string
          used_at?: string | null
          created_at?: string
        }
      }
      emergency_contacts: {
        Row: {
          id: string
          owner_id: string
          contact_user_id: string | null
          external_name: string | null
          external_phone: string | null
          created_at: string
        }
        Insert: {
          id?: string
          owner_id: string
          contact_user_id?: string | null
          external_name?: string | null
          external_phone?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          owner_id?: string
          contact_user_id?: string | null
          external_name?: string | null
          external_phone?: string | null
          created_at?: string
        }
      }
      panic_events: {
        Row: {
          id: string
          owner_id: string
          lat: number | null
          lng: number | null
          status: string
          created_at: string
        }
        Insert: {
          id?: string
          owner_id: string
          lat?: number | null
          lng?: number | null
          status?: string
          created_at?: string
        }
        Update: {
          id?: string
          owner_id?: string
          lat?: number | null
          lng?: number | null
          status?: string
          created_at?: string
        }
      }
      notifications: {
        Row: {
          id: string
          user_id: string
          type: string
          title: string
          body: string | null
          data: Json | null
          read: boolean
          read_at: string | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          type: string
          title: string
          body?: string | null
          data?: Json | null
          read?: boolean
          read_at?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          type?: string
          title?: string
          body?: string | null
          data?: Json | null
          read?: boolean
          read_at?: string | null
          created_at?: string
        }
      }
      reports: {
        Row: {
          id: string
          reporter_id: string
          reported_user_id: string | null
          reported_content_id: string | null
          content_type: string | null
          reason: string
          description: string | null
          status: 'pending' | 'reviewed' | 'resolved' | 'dismissed'
          created_at: string
        }
        Insert: {
          id?: string
          reporter_id: string
          reported_user_id?: string | null
          reported_content_id?: string | null
          content_type?: string | null
          reason: string
          description?: string | null
          status?: 'pending' | 'reviewed' | 'resolved' | 'dismissed'
          created_at?: string
        }
        Update: {
          id?: string
          reporter_id?: string
          reported_user_id?: string | null
          reported_content_id?: string | null
          content_type?: string | null
          reason?: string
          description?: string | null
          status?: 'pending' | 'reviewed' | 'resolved' | 'dismissed'
          created_at?: string
        }
      }
      blocks: {
        Row: {
          id: string
          blocker_id: string
          blocked_id: string
          created_at: string
        }
        Insert: {
          id?: string
          blocker_id: string
          blocked_id: string
          created_at?: string
        }
        Update: {
          id?: string
          blocker_id?: string
          blocked_id?: string
          created_at?: string
        }
      }
      referrals: {
        Row: {
          id: string
          referrer_id: string
          referred_id: string
          code: string
          status: 'pending' | 'completed'
          completed_at: string | null
          created_at: string
        }
        Insert: {
          id?: string
          referrer_id: string
          referred_id: string
          code: string
          status?: 'pending' | 'completed'
          completed_at?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          referrer_id?: string
          referred_id?: string
          code?: string
          status?: 'pending' | 'completed'
          completed_at?: string | null
          created_at?: string
        }
      }
      access_invites: {
        Row: {
          id: string
          inviter_id: string
          invitee_email: string | null
          invitee_name: string | null
          invite_code: string
          status: 'pending' | 'accepted' | 'revoked' | 'expired'
          accepted_user_id: string | null
          accepted_at: string | null
          expires_at: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          inviter_id: string
          invitee_email?: string | null
          invitee_name?: string | null
          invite_code: string
          status?: 'pending' | 'accepted' | 'revoked' | 'expired'
          accepted_user_id?: string | null
          accepted_at?: string | null
          expires_at?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          inviter_id?: string
          invitee_email?: string | null
          invitee_name?: string | null
          invite_code?: string
          status?: 'pending' | 'accepted' | 'revoked' | 'expired'
          accepted_user_id?: string | null
          accepted_at?: string | null
          expires_at?: string
          created_at?: string
          updated_at?: string
        }
      }
      access_applications: {
        Row: {
          id: string
          email: string
          full_name: string | null
          note: string | null
          status: 'pending' | 'approved' | 'rejected'
          reviewed_by: string | null
          reviewed_at: string | null
          created_at: string
        }
        Insert: {
          id?: string
          email: string
          full_name?: string | null
          note?: string | null
          status?: 'pending' | 'approved' | 'rejected'
          reviewed_by?: string | null
          reviewed_at?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          email?: string
          full_name?: string | null
          note?: string | null
          status?: 'pending' | 'approved' | 'rejected'
          reviewed_by?: string | null
          reviewed_at?: string | null
          created_at?: string
        }
      }
      points_ledger: {
        Row: {
          id: string
          user_id: string
          amount: number
          reason: string
          reference_type: string | null
          reference_id: string | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          amount: number
          reason: string
          reference_type?: string | null
          reference_id?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          amount?: number
          reason?: string
          reference_type?: string | null
          reference_id?: string | null
          created_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}

// Helper types
export type Tables<T extends keyof Database['public']['Tables']> = Database['public']['Tables'][T]['Row']
export type InsertTables<T extends keyof Database['public']['Tables']> = Database['public']['Tables'][T]['Insert']
export type UpdateTables<T extends keyof Database['public']['Tables']> = Database['public']['Tables'][T]['Update']

export type Profile = Tables<'profiles'>
export type Circle = Tables<'circles'>
export type CircleMember = Tables<'circle_members'>
export type Event = Tables<'events'>
export type EventAttendee = Tables<'event_attendees'>
export type Message = Tables<'messages'>
export type Badge = Tables<'badges'>
export type UserBadge = Tables<'user_badges'>
export type Notification = Tables<'notifications'>
export type Report = Tables<'reports'>
export type Block = Tables<'blocks'>
export type Referral = Tables<'referrals'>
export type AccessInvite = Tables<'access_invites'>
export type AccessApplication = Tables<'access_applications'>
export type PointsLedger = Tables<'points_ledger'>
