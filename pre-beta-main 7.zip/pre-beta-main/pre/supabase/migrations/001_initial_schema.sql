-- PRE App Database Schema
-- Supabase SQL Migrations
-- Run these in the Supabase SQL Editor in order

-- ============================================
-- 1. PROFILES TABLE
-- ============================================

create table if not exists public.profiles (
  id uuid references auth.users on delete cascade primary key,
  email text not null,
  full_name text,
  username text unique,
  bio text,
  avatar_url text,
  date_of_birth date,
  location text,
  location_lat double precision,
  location_lng double precision,
  interests text[] default '{}',
  user_intent text[] default '{}',
  theme_mode text default 'system' check (theme_mode in ('light', 'dark', 'system')),
  amoled_enabled boolean default false,
  onboarding_completed boolean default false,
  onboarding_step integer default 1,
  early_supporter_number integer unique,
  total_points integer default 0,
  is_verified boolean default false,
  verification_type text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Index for username lookups
create index if not exists profiles_username_idx on public.profiles (username);

-- RLS for profiles
alter table public.profiles enable row level security;

create policy "Users can view all profiles" on public.profiles
  for select using (true);

create policy "Users can insert their own profile" on public.profiles
  for insert with check (auth.uid() = id);

create policy "Users can update their own profile" on public.profiles
  for update using (auth.uid() = id);

-- Function to handle new user signup
create or replace function public.handle_new_user()
returns trigger as $$
declare
  supporter_count integer;
  new_supporter_number integer;
begin
  -- Get current count of early supporters
  select count(*) into supporter_count from public.profiles where early_supporter_number is not null;
  
  -- Assign early supporter number if under 250
  if supporter_count < 250 then
    new_supporter_number := supporter_count + 1;
  else
    new_supporter_number := null;
  end if;
  
  insert into public.profiles (id, email, early_supporter_number)
  values (new.id, new.email, new_supporter_number);
  
  return new;
end;
$$ language plpgsql security definer;

-- Trigger for new user signup
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ============================================
-- 2. CIRCLES TABLE
-- ============================================

create table if not exists public.circles (
  id uuid default gen_random_uuid() primary key,
  name text not null,
  description text,
  cover_image_url text,
  creator_id uuid references public.profiles(id) on delete set null,
  is_public boolean default true,
  member_count integer default 0,
  category text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.circles enable row level security;

create policy "Anyone can view public circles" on public.circles
  for select using (is_public = true or auth.uid() = creator_id);

create policy "Authenticated users can create circles" on public.circles
  for insert with check (auth.uid() = creator_id);

create policy "Circle creators can update their circles" on public.circles
  for update using (auth.uid() = creator_id);

-- ============================================
-- 3. CIRCLE MEMBERS TABLE
-- ============================================

create table if not exists public.circle_members (
  id uuid default gen_random_uuid() primary key,
  circle_id uuid references public.circles(id) on delete cascade not null,
  user_id uuid references public.profiles(id) on delete cascade not null,
  role text default 'member' check (role in ('admin', 'moderator', 'member')),
  joined_at timestamp with time zone default timezone('utc'::text, now()) not null,
  unique(circle_id, user_id)
);

alter table public.circle_members enable row level security;

create policy "Anyone can view circle members" on public.circle_members
  for select using (true);

create policy "Authenticated users can join circles" on public.circle_members
  for insert with check (auth.uid() = user_id);

create policy "Users can leave circles" on public.circle_members
  for delete using (auth.uid() = user_id);

-- ============================================
-- 4. EVENTS TABLE
-- ============================================

create table if not exists public.events (
  id uuid default gen_random_uuid() primary key,
  title text not null,
  description text,
  hero_image_url text,
  creator_id uuid references public.profiles(id) on delete set null,
  circle_id uuid references public.circles(id) on delete set null,
  location text not null,
  location_lat double precision,
  location_lng double precision,
  starts_at timestamp with time zone not null,
  ends_at timestamp with time zone,
  max_attendees integer,
  attendee_count integer default 0,
  is_public boolean default true,
  category text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.events enable row level security;

create policy "Anyone can view public events" on public.events
  for select using (is_public = true or auth.uid() = creator_id);

create policy "Authenticated users can create events" on public.events
  for insert with check (auth.uid() = creator_id);

create policy "Event creators can update their events" on public.events
  for update using (auth.uid() = creator_id);

-- ============================================
-- 5. EVENT ATTENDEES TABLE
-- ============================================

create table if not exists public.event_attendees (
  id uuid default gen_random_uuid() primary key,
  event_id uuid references public.events(id) on delete cascade not null,
  user_id uuid references public.profiles(id) on delete cascade not null,
  status text default 'going' check (status in ('going', 'maybe', 'not_going')),
  rsvp_at timestamp with time zone default timezone('utc'::text, now()) not null,
  unique(event_id, user_id)
);

alter table public.event_attendees enable row level security;

create policy "Anyone can view event attendees" on public.event_attendees
  for select using (true);

create policy "Authenticated users can RSVP" on public.event_attendees
  for insert with check (auth.uid() = user_id);

create policy "Users can update their RSVP" on public.event_attendees
  for update using (auth.uid() = user_id);

create policy "Users can cancel their RSVP" on public.event_attendees
  for delete using (auth.uid() = user_id);

-- ============================================
-- 6. MESSAGES TABLE (Circle Chat)
-- ============================================

create table if not exists public.messages (
  id uuid default gen_random_uuid() primary key,
  circle_id uuid references public.circles(id) on delete cascade not null,
  sender_id uuid references public.profiles(id) on delete set null,
  content text not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.messages enable row level security;

create policy "Circle members can view messages" on public.messages
  for select using (
    exists (
      select 1 from public.circle_members
      where circle_id = messages.circle_id and user_id = auth.uid()
    )
  );

create policy "Circle members can send messages" on public.messages
  for insert with check (
    auth.uid() = sender_id and
    exists (
      select 1 from public.circle_members
      where circle_id = messages.circle_id and user_id = auth.uid()
    )
  );

-- ============================================
-- 7. BADGES TABLE
-- ============================================

create table if not exists public.badges (
  id uuid default gen_random_uuid() primary key,
  name text not null unique,
  description text not null,
  icon text not null,
  category text not null,
  points_required integer,
  criteria jsonb,
  is_earnable boolean default true,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.badges enable row level security;

create policy "Anyone can view badges" on public.badges
  for select using (true);

-- Seed badges
insert into public.badges (name, description, icon, category, is_earnable) values
  ('Early Supporter', 'One of the first 250 members to join pre', '⭐', 'special', false),
  ('Initiator', 'Hosted your first public event', '🎯', 'events', true),
  ('Social Butterfly', 'Attended 5 events in one month', '🦋', 'events', true),
  ('Community Pillar', 'Hosted 10+ successful events with high attendance', '🏛️', 'events', true),
  ('Ambassador', 'Referred 5 friends who completed onboarding', '🌟', 'referrals', true),
  ('Connector', 'Referred 10 friends who completed onboarding', '🔗', 'referrals', true),
  ('Founders'' pre', 'Exclusive badge for early ambassadors', '👑', 'special', false)
on conflict (name) do nothing;

-- ============================================
-- 8. USER BADGES TABLE
-- ============================================

create table if not exists public.user_badges (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  badge_id uuid references public.badges(id) on delete cascade not null,
  earned_at timestamp with time zone default timezone('utc'::text, now()) not null,
  progress integer default 0,
  unique(user_id, badge_id)
);

alter table public.user_badges enable row level security;

create policy "Users can view their badges" on public.user_badges
  for select using (auth.uid() = user_id);

create policy "System can award badges" on public.user_badges
  for insert with check (auth.uid() = user_id);

-- ============================================
-- 9. NOTIFICATIONS TABLE
-- ============================================

create table if not exists public.notifications (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  type text not null,
  title text not null,
  body text,
  data jsonb,
  read boolean default false,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.notifications enable row level security;

create policy "Users can view their notifications" on public.notifications
  for select using (auth.uid() = user_id);

create policy "Users can update their notifications" on public.notifications
  for update using (auth.uid() = user_id);

-- ============================================
-- 10. REPORTS TABLE
-- ============================================

create table if not exists public.reports (
  id uuid default gen_random_uuid() primary key,
  reporter_id uuid references public.profiles(id) on delete set null not null,
  reported_user_id uuid references public.profiles(id) on delete set null,
  reported_content_id uuid,
  content_type text,
  reason text not null,
  description text,
  status text default 'pending' check (status in ('pending', 'reviewed', 'resolved', 'dismissed')),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.reports enable row level security;

create policy "Users can create reports" on public.reports
  for insert with check (auth.uid() = reporter_id);

-- ============================================
-- 11. BLOCKS TABLE
-- ============================================

create table if not exists public.blocks (
  id uuid default gen_random_uuid() primary key,
  blocker_id uuid references public.profiles(id) on delete cascade not null,
  blocked_id uuid references public.profiles(id) on delete cascade not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  unique(blocker_id, blocked_id)
);

alter table public.blocks enable row level security;

create policy "Users can view their blocks" on public.blocks
  for select using (auth.uid() = blocker_id);

create policy "Users can create blocks" on public.blocks
  for insert with check (auth.uid() = blocker_id);

create policy "Users can remove blocks" on public.blocks
  for delete using (auth.uid() = blocker_id);

-- ============================================
-- 12. REFERRALS TABLE
-- ============================================

create table if not exists public.referrals (
  id uuid default gen_random_uuid() primary key,
  referrer_id uuid references public.profiles(id) on delete set null not null,
  referred_id uuid references public.profiles(id) on delete cascade not null,
  code text not null,
  status text default 'pending' check (status in ('pending', 'completed')),
  completed_at timestamp with time zone,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.referrals enable row level security;

create policy "Users can view their referrals" on public.referrals
  for select using (auth.uid() = referrer_id or auth.uid() = referred_id);

create policy "Users can create referrals" on public.referrals
  for insert with check (auth.uid() = referred_id);

-- ============================================
-- 13. POINTS LEDGER TABLE (Append-only)
-- ============================================

create table if not exists public.points_ledger (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  amount integer not null,
  reason text not null,
  reference_type text,
  reference_id uuid,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.points_ledger enable row level security;

create policy "Users can view their points" on public.points_ledger
  for select using (auth.uid() = user_id);

-- Function to update total points when ledger entry is added
create or replace function public.update_user_points()
returns trigger as $$
begin
  update public.profiles
  set total_points = total_points + new.amount
  where id = new.user_id;
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_points_added on public.points_ledger;
create trigger on_points_added
  after insert on public.points_ledger
  for each row execute procedure public.update_user_points();

-- ============================================
-- 14. STORAGE BUCKETS
-- ============================================

-- Run these in the Supabase Dashboard > Storage
-- Or use the following SQL:

insert into storage.buckets (id, name, public)
values ('avatars', 'avatars', true)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('circles', 'circles', true)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('events', 'events', true)
on conflict (id) do nothing;

-- Storage policies
create policy "Anyone can view avatars" on storage.objects
  for select using (bucket_id = 'avatars');

create policy "Authenticated users can upload avatars" on storage.objects
  for insert with check (
    bucket_id = 'avatars' and
    auth.uid()::text = (storage.foldername(name))[1]
  );

create policy "Users can update their own avatars" on storage.objects
  for update using (
    bucket_id = 'avatars' and
    auth.uid()::text = (storage.foldername(name))[1]
  );

create policy "Anyone can view circle images" on storage.objects
  for select using (bucket_id = 'circles');

create policy "Anyone can view event images" on storage.objects
  for select using (bucket_id = 'events');