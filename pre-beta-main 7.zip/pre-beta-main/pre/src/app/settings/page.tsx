'use client'

import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { useTheme } from '@/components/providers/theme-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Button } from '@/components/ui/button'
import { SegmentedControl } from '@/components/ui/segmented-control'
import { Toggle } from '@/components/ui/toggle'
import { ArrowLeft, ChevronRight, Shield, Bell, HelpCircle, LogOut, Palette, User, Lock } from 'lucide-react'
import Link from 'next/link'

export default function SettingsPage() {
  const { user, loading, initialized, signOut, updateProfile } = useAuth()
  const { mode, amoledEnabled, setMode, setAmoledEnabled, resolvedTheme } = useTheme()
  const router = useRouter()

  if (!initialized || loading) {
    return <LoadingScreen />
  }

  if (!user) {
    router.replace('/auth')
    return <LoadingScreen />
  }

  const handleSignOut = async () => {
    await signOut()
    router.replace('/auth')
  }

  const handleThemeChange = async (newMode: 'light' | 'dark' | 'system') => {
    setMode(newMode)
    await updateProfile({ theme_mode: newMode })
  }

  const handleAmoledChange = async (enabled: boolean) => {
    setAmoledEnabled(enabled)
    await updateProfile({ amoled_enabled: enabled })
  }

  const showAmoledToggle = mode === 'dark' || (mode === 'system' && resolvedTheme === 'dark')

  return (
    <div className="min-h-screen bg-surface-primary safe-top safe-bottom">
      {/* Header */}
      <header className="px-4 py-4 flex items-center justify-between border-b border-border-secondary">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
          data-testid="settings-back-button"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">Settings</h1>
        <div className="w-9" />
      </header>

      {/* Settings Content */}
      <main className="px-4 py-6">
        <div className="max-w-md mx-auto space-y-8">
          {/* Appearance Section */}
          <section className="space-y-4">
            <h2 className="text-callout font-medium text-content-secondary uppercase tracking-wider px-2">
              Appearance
            </h2>
            <div className="bg-surface-secondary rounded-card border border-border-secondary divide-y divide-border-secondary">
              <div className="p-4 space-y-3">
                <div className="flex items-center gap-3">
                  <Palette className="h-5 w-5 text-content-tertiary" />
                  <span className="text-body text-content-primary">Theme</span>
                </div>
                <SegmentedControl
                  options={[
                    { value: 'light', label: 'Light' },
                    { value: 'dark', label: 'Dark' },
                    { value: 'system', label: 'System' },
                  ]}
                  value={mode}
                  onChange={(v) => handleThemeChange(v as 'light' | 'dark' | 'system')}
                />
              </div>
              {showAmoledToggle && (
                <div className="p-4">
                  <Toggle
                    enabled={amoledEnabled}
                    onChange={handleAmoledChange}
                    label="AMOLED Mode"
                    description="Pure black backgrounds"
                  />
                </div>
              )}
            </div>
          </section>

          {/* Account Section */}
          <section className="space-y-4">
            <h2 className="text-callout font-medium text-content-secondary uppercase tracking-wider px-2">
              Account
            </h2>
            <div className="bg-surface-secondary rounded-card border border-border-secondary divide-y divide-border-secondary">
              <Link
                href="/profile/edit"
                className="flex items-center justify-between p-4 hover:bg-accent-muted transition-colors"
                data-testid="settings-edit-profile"
              >
                <div className="flex items-center gap-3">
                  <User className="h-5 w-5 text-content-tertiary" />
                  <span className="text-body text-content-primary">Edit Profile</span>
                </div>
                <ChevronRight className="h-5 w-5 text-content-tertiary" />
              </Link>
              <Link
                href="/settings/notifications"
                className="flex items-center justify-between p-4 hover:bg-accent-muted transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Bell className="h-5 w-5 text-content-tertiary" />
                  <span className="text-body text-content-primary">Notifications</span>
                </div>
                <ChevronRight className="h-5 w-5 text-content-tertiary" />
              </Link>
              <Link
                href="/settings/privacy"
                className="flex items-center justify-between p-4 hover:bg-accent-muted transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Lock className="h-5 w-5 text-content-tertiary" />
                  <span className="text-body text-content-primary">Privacy</span>
                </div>
                <ChevronRight className="h-5 w-5 text-content-tertiary" />
              </Link>
            </div>
          </section>

          {/* Safety Section */}
          <section className="space-y-4">
            <h2 className="text-callout font-medium text-content-secondary uppercase tracking-wider px-2">
              Safety
            </h2>
            <div className="bg-surface-secondary rounded-card border border-border-secondary divide-y divide-border-secondary">
              <Link
                href="/safety"
                className="flex items-center justify-between p-4 hover:bg-accent-muted transition-colors"
                data-testid="settings-safety"
              >
                <div className="flex items-center gap-3">
                  <Shield className="h-5 w-5 text-content-tertiary" />
                  <span className="text-body text-content-primary">Safety & Verification</span>
                </div>
                <ChevronRight className="h-5 w-5 text-content-tertiary" />
              </Link>
            </div>
          </section>

          {/* Support Section */}
          <section className="space-y-4">
            <h2 className="text-callout font-medium text-content-secondary uppercase tracking-wider px-2">
              Support
            </h2>
            <div className="bg-surface-secondary rounded-card border border-border-secondary divide-y divide-border-secondary">
              <Link
                href="/help"
                className="flex items-center justify-between p-4 hover:bg-accent-muted transition-colors"
              >
                <div className="flex items-center gap-3">
                  <HelpCircle className="h-5 w-5 text-content-tertiary" />
                  <span className="text-body text-content-primary">Help & Support</span>
                </div>
                <ChevronRight className="h-5 w-5 text-content-tertiary" />
              </Link>
            </div>
          </section>

          {/* Sign Out */}
          <Button
            variant="outline"
            className="w-full"
            onClick={handleSignOut}
            data-testid="settings-sign-out"
          >
            <LogOut className="h-4 w-4" />
            Sign Out
          </Button>

          {/* Version */}
          <p className="text-center text-caption text-content-tertiary">
            pre v1.0.0
          </p>
        </div>
      </main>
    </div>
  )
}