'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'

export default function HomePage() {
  const { user, profile, loading, initialized } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!initialized) return

    if (!user) {
      router.replace('/auth')
    } else if (!profile?.onboarding_completed) {
      router.replace('/onboarding')
    } else {
      router.replace('/home')
    }
  }, [user, profile, initialized, router])

  if (!initialized || loading) {
    return <LoadingScreen message="Loading..." />
  }

  return <LoadingScreen />
}