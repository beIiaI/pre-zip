'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar } from '@/components/ui/avatar'
import { Alert } from '@/components/ui/alert'
import { ArrowLeft, Camera, Loader2 } from 'lucide-react'
import { validateUsername } from '@/lib/utils'
import { createClient } from '@/lib/supabase/client'

export default function EditProfilePage() {
  const { user, profile, loading, initialized, updateProfile, refreshProfile } = useAuth()
  const router = useRouter()
  const supabase = createClient()

  const [fullName, setFullName] = useState('')
  const [username, setUsername] = useState('')
  const [bio, setBio] = useState('')
  const [location, setLocation] = useState('')
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null)
  
  const [saving, setSaving] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [usernameError, setUsernameError] = useState<string | null>(null)

  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name || '')
      setUsername(profile.username || '')
      setBio(profile.bio || '')
      setLocation(profile.location || '')
      setAvatarUrl(profile.avatar_url)
    }
  }, [profile])

  if (!initialized || loading) {
    return <LoadingScreen />
  }

  if (!user) {
    router.replace('/auth')
    return <LoadingScreen />
  }

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (!file.type.startsWith('image/')) {
      setError('Please select an image file')
      return
    }
    if (file.size > 5 * 1024 * 1024) {
      setError('Image must be less than 5MB')
      return
    }

    setUploading(true)
    setError(null)

    try {
      // Upload to Supabase Storage (when connected)
      const fileExt = file.name.split('.').pop()
      const fileName = `${user.id}-${Date.now()}.${fileExt}`
      const filePath = `avatars/${fileName}`

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file, { upsert: true })

      if (uploadError) {
        // Fallback to local preview for now
        setAvatarUrl(URL.createObjectURL(file))
      } else {
        const { data: { publicUrl } } = supabase.storage
          .from('avatars')
          .getPublicUrl(filePath)
        setAvatarUrl(publicUrl)
      }
    } catch (err) {
      // Fallback to local preview
      setAvatarUrl(URL.createObjectURL(file))
    } finally {
      setUploading(false)
    }
  }

  const handleUsernameChange = async (value: string) => {
    const cleaned = value.toLowerCase().replace(/[^a-z0-9_]/g, '')
    setUsername(cleaned)
    setUsernameError(null)

    if (!cleaned) return

    const validation = validateUsername(cleaned)
    if (!validation.valid) {
      setUsernameError(validation.error || null)
      return
    }

    // Check availability if different from current
    if (cleaned !== profile?.username) {
      try {
        const { data } = await supabase
          .from('profiles')
          .select('username')
          .eq('username', cleaned)
          .single()

        if (data) {
          setUsernameError('This username is already taken')
        }
      } catch {
        // No match found - available
      }
    }
  }

  const handleSave = async () => {
    setError(null)
    setSuccess(false)

    if (!fullName.trim()) {
      setError('Name is required')
      return
    }

    if (username && usernameError) {
      setError(usernameError)
      return
    }

    setSaving(true)

    try {
      const { error: updateError } = await updateProfile({
        full_name: fullName.trim() || null,
        username: username.trim() || null,
        bio: bio.trim() || null,
        location: location.trim() || null,
        avatar_url: avatarUrl,
      })

      if (updateError) {
        setError(updateError.message)
      } else {
        setSuccess(true)
        await refreshProfile()
        setTimeout(() => router.back(), 1000)
      }
    } catch (err) {
      setError('Failed to save changes')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="min-h-screen bg-surface-primary safe-top safe-bottom">
      {/* Header */}
      <header className="px-4 py-4 flex items-center justify-between border-b border-border-secondary">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
          data-testid="edit-profile-back"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">Edit Profile</h1>
        <Button
          size="sm"
          onClick={handleSave}
          loading={saving}
          disabled={!!usernameError}
          data-testid="edit-profile-save"
        >
          Save
        </Button>
      </header>

      <main className="px-6 py-8">
        <div className="max-w-md mx-auto space-y-8">
          {/* Alerts */}
          {error && (
            <Alert variant="error" dismissible onDismiss={() => setError(null)}>
              {error}
            </Alert>
          )}
          {success && (
            <Alert variant="success">
              Profile updated successfully!
            </Alert>
          )}

          {/* Avatar */}
          <div className="flex flex-col items-center space-y-4">
            <div className="relative">
              <Avatar src={avatarUrl} size="xl" />
              <label className="absolute bottom-0 right-0 h-8 w-8 rounded-full bg-content-primary flex items-center justify-center cursor-pointer border-2 border-surface-primary">
                {uploading ? (
                  <Loader2 className="h-4 w-4 animate-spin text-content-inverse" />
                ) : (
                  <Camera className="h-4 w-4 text-content-inverse" />
                )}
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleAvatarChange}
                  className="hidden"
                  data-testid="edit-profile-avatar-input"
                />
              </label>
            </div>
            <p className="text-caption text-content-secondary">Tap to change photo</p>
          </div>

          {/* Form */}
          <div className="space-y-4">
            <Input
              label="Full Name"
              placeholder="Your name"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              data-testid="edit-profile-name"
            />

            <Input
              label="Username"
              placeholder="your_username"
              value={username}
              onChange={(e) => handleUsernameChange(e.target.value)}
              error={usernameError || undefined}
              hint="Letters, numbers, and underscores only"
              data-testid="edit-profile-username"
            />

            <div className="space-y-2">
              <label className="text-callout font-medium text-content-primary">Bio</label>
              <textarea
                placeholder="Tell us about yourself..."
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                maxLength={200}
                rows={4}
                className="flex w-full rounded-input border bg-surface-secondary px-4 py-3 text-body text-content-primary placeholder:text-content-tertiary border-border-primary focus:border-border-focus focus:outline-none focus:ring-1 focus:ring-border-focus resize-none"
                data-testid="edit-profile-bio"
              />
              <p className="text-caption text-content-tertiary text-right">
                {bio.length}/200
              </p>
            </div>

            <Input
              label="Location"
              placeholder="City, Country"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              data-testid="edit-profile-location"
            />
          </div>
        </div>
      </main>
    </div>
  )
}