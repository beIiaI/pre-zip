'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { Avatar } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ArrowLeft, Edit2, Award, MapPin, Calendar } from 'lucide-react'
import { formatEarlySupporterNumber, formatDate } from '@/lib/utils'
import Link from 'next/link'

export default function ProfilePage() {
  const { user, profile, loading, initialized } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!initialized) return
    if (!user) {
      router.replace('/auth')
    }
  }, [user, initialized, router])

  if (!initialized || loading || !profile) {
    return <LoadingScreen />
  }

  return (
    <div className="min-h-screen bg-surface-primary safe-top safe-bottom">
      {/* Header */}
      <header className="px-4 py-4 flex items-center justify-between border-b border-border-secondary">
        <button
          onClick={() => router.back()}
          className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
          data-testid="profile-back-button"
        >
          <ArrowLeft className="h-5 w-5 text-content-primary" />
        </button>
        <h1 className="text-headline">Profile</h1>
        <Link
          href="/profile/edit"
          className="p-2 -mr-2 rounded-full hover:bg-accent-muted transition-colors"
          data-testid="profile-edit-link"
        >
          <Edit2 className="h-5 w-5 text-content-primary" />
        </Link>
      </header>

      {/* Profile Content */}
      <main className="px-6 py-8">
        <div className="max-w-md mx-auto space-y-8">
          {/* Avatar & Name */}
          <div className="flex flex-col items-center text-center space-y-4">
            <Avatar src={profile.avatar_url} size="xl" />
            <div className="space-y-1">
              <h2 className="text-title text-content-primary">{profile.full_name || 'Anonymous'}</h2>
              {profile.username && (
                <p className="text-body text-content-secondary">@{profile.username}</p>
              )}
              {profile.early_supporter_number && (
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-pill bg-surface-secondary border border-border-secondary">
                  <Award className="h-4 w-4 text-content-primary" />
                  <span className="text-caption font-medium text-content-primary">
                    Early Supporter {formatEarlySupporterNumber(profile.early_supporter_number)}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Bio */}
          {profile.bio && (
            <p className="text-body text-content-secondary text-center">{profile.bio}</p>
          )}

          {/* Info Cards */}
          <div className="grid grid-cols-2 gap-4">
            {profile.location && (
              <Card>
                <CardContent className="pt-4 flex items-center gap-3">
                  <MapPin className="h-5 w-5 text-content-tertiary" />
                  <span className="text-callout text-content-primary">{profile.location}</span>
                </CardContent>
              </Card>
            )}
            <Card>
              <CardContent className="pt-4 flex items-center gap-3">
                <Calendar className="h-5 w-5 text-content-tertiary" />
                <span className="text-callout text-content-primary">
                  Joined {formatDate(profile.created_at)}
                </span>
              </CardContent>
            </Card>
          </div>

          {/* Stats */}
          <Card>
            <CardContent className="pt-4">
              <div className="flex justify-around text-center">
                <div>
                  <p className="text-title text-content-primary">{profile.total_points}</p>
                  <p className="text-caption text-content-secondary">Points</p>
                </div>
                <div className="w-px bg-border-secondary" />
                <div>
                  <p className="text-title text-content-primary">0</p>
                  <p className="text-caption text-content-secondary">Circles</p>
                </div>
                <div className="w-px bg-border-secondary" />
                <div>
                  <p className="text-title text-content-primary">0</p>
                  <p className="text-caption text-content-secondary">Events</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Interests */}
          {profile.interests && profile.interests.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-headline text-content-primary">Interests</h3>
              <div className="flex flex-wrap gap-2">
                {profile.interests.map((interest) => (
                  <span
                    key={interest}
                    className="px-3 py-1.5 rounded-pill bg-surface-secondary border border-border-secondary text-caption text-content-primary"
                  >
                    {interest}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Badges Link */}
          <Link href="/badges" className="block">
            <Button variant="secondary" className="w-full" data-testid="profile-badges-link">
              <Award className="h-4 w-4" />
              View Badges
            </Button>
          </Link>
        </div>
      </main>
    </div>
  )
}