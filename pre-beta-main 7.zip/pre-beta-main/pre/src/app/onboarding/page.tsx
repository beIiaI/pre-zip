'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/providers/auth-provider'
import { LoadingScreen } from '@/components/ui/spinner'
import { OnboardingIntro } from '@/components/onboarding/intro'
import { OnboardingName } from '@/components/onboarding/name'
import { OnboardingUsername } from '@/components/onboarding/username'
import { OnboardingIntent } from '@/components/onboarding/intent'
import { OnboardingInterests } from '@/components/onboarding/interests'
import { OnboardingDOB } from '@/components/onboarding/dob'
import { OnboardingLocation } from '@/components/onboarding/location'
import { OnboardingTheme } from '@/components/onboarding/theme'
import { OnboardingProfile } from '@/components/onboarding/profile'

export interface OnboardingData {
  fullName: string
  username: string
  userIntent: string[]
  interests: string[]
  dateOfBirth: string
  location: string
  locationLat?: number
  locationLng?: number
  themeMode: 'light' | 'dark' | 'system'
  amoledEnabled: boolean
  avatarUrl?: string
  bio: string
}

const TOTAL_STEPS = 9

export default function OnboardingPage() {
  const { user, profile, loading, initialized, updateProfile } = useAuth()
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [data, setData] = useState<OnboardingData>({
    fullName: '',
    username: '',
    userIntent: [],
    interests: [],
    dateOfBirth: '',
    location: '',
    themeMode: 'system',
    amoledEnabled: false,
    bio: '',
  })

  // Redirect if not authenticated or already completed
  useEffect(() => {
    if (!initialized) return

    if (!user) {
      router.replace('/auth')
    } else if (profile?.onboarding_completed) {
      router.replace('/home')
    } else if (profile?.onboarding_step && profile.onboarding_step > 1) {
      // Resume from saved step
      setStep(profile.onboarding_step)
      // Restore saved data
      setData(prev => ({
        ...prev,
        fullName: profile.full_name || '',
        username: profile.username || '',
        userIntent: profile.user_intent || [],
        interests: profile.interests || [],
        dateOfBirth: profile.date_of_birth || '',
        location: profile.location || '',
        locationLat: profile.location_lat || undefined,
        locationLng: profile.location_lng || undefined,
        themeMode: profile.theme_mode || 'system',
        amoledEnabled: profile.amoled_enabled || false,
        bio: profile.bio || '',
        avatarUrl: profile.avatar_url || undefined,
      }))
    }
  }, [user, profile, initialized, router])

  const updateData = (updates: Partial<OnboardingData>) => {
    setData(prev => ({ ...prev, ...updates }))
  }

  const nextStep = async () => {
    // Save progress to profile
    const nextStepNum = step + 1
    await updateProfile({
      onboarding_step: nextStepNum,
      full_name: data.fullName || null,
      username: data.username || null,
      user_intent: data.userIntent,
      interests: data.interests,
      date_of_birth: data.dateOfBirth || null,
      location: data.location || null,
      location_lat: data.locationLat || null,
      location_lng: data.locationLng || null,
      theme_mode: data.themeMode,
      amoled_enabled: data.amoledEnabled,
      bio: data.bio || null,
      avatar_url: data.avatarUrl || null,
    })
    setStep(nextStepNum)
  }

  const prevStep = () => {
    if (step > 1) {
      setStep(step - 1)
    }
  }

  const completeOnboarding = async () => {
    await updateProfile({
      onboarding_completed: true,
      onboarding_step: TOTAL_STEPS,
      full_name: data.fullName || null,
      username: data.username || null,
      user_intent: data.userIntent,
      interests: data.interests,
      date_of_birth: data.dateOfBirth || null,
      location: data.location || null,
      location_lat: data.locationLat || null,
      location_lng: data.locationLng || null,
      theme_mode: data.themeMode,
      amoled_enabled: data.amoledEnabled,
      bio: data.bio || null,
      avatar_url: data.avatarUrl || null,
    })
    router.push('/home')
  }

  if (!initialized || loading) {
    return <LoadingScreen message="Loading..." />
  }

  if (!user) {
    return <LoadingScreen />
  }

  const renderStep = () => {
    switch (step) {
      case 1:
        return <OnboardingIntro onNext={nextStep} />
      case 2:
        return (
          <OnboardingName
            value={data.fullName}
            onChange={(fullName) => updateData({ fullName })}
            onNext={nextStep}
            onBack={prevStep}
          />
        )
      case 3:
        return (
          <OnboardingUsername
            value={data.username}
            onChange={(username) => updateData({ username })}
            onNext={nextStep}
            onBack={prevStep}
          />
        )
      case 4:
        return (
          <OnboardingIntent
            value={data.userIntent}
            onChange={(userIntent) => updateData({ userIntent })}
            onNext={nextStep}
            onBack={prevStep}
          />
        )
      case 5:
        return (
          <OnboardingInterests
            value={data.interests}
            onChange={(interests) => updateData({ interests })}
            onNext={nextStep}
            onBack={prevStep}
          />
        )
      case 6:
        return (
          <OnboardingDOB
            value={data.dateOfBirth}
            onChange={(dateOfBirth) => updateData({ dateOfBirth })}
            onNext={nextStep}
            onBack={prevStep}
          />
        )
      case 7:
        return (
          <OnboardingLocation
            value={data.location}
            onChange={(location, lat, lng) => updateData({ location, locationLat: lat, locationLng: lng })}
            onNext={nextStep}
            onBack={prevStep}
          />
        )
      case 8:
        return (
          <OnboardingTheme
            mode={data.themeMode}
            amoled={data.amoledEnabled}
            onChangeMode={(themeMode) => updateData({ themeMode })}
            onChangeAmoled={(amoledEnabled) => updateData({ amoledEnabled })}
            onNext={nextStep}
            onBack={prevStep}
          />
        )
      case 9:
        return (
          <OnboardingProfile
            bio={data.bio}
            avatarUrl={data.avatarUrl}
            onChangeBio={(bio) => updateData({ bio })}
            onChangeAvatar={(avatarUrl) => updateData({ avatarUrl })}
            onComplete={completeOnboarding}
            onBack={prevStep}
          />
        )
      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-surface-primary safe-top safe-bottom">
      {renderStep()}
    </div>
  )
}