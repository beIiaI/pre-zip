'use client'

import { ArrowLeft } from 'lucide-react'
import { cn } from '@/lib/utils'

interface Props {
  step: number
  totalSteps: number
  title: string
  subtitle?: string
  onBack?: () => void
  children: React.ReactNode
}

export function OnboardingLayout({ step, totalSteps, title, subtitle, onBack, children }: Props) {
  const progress = (step / totalSteps) * 100

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="px-4 py-4 space-y-4">
        <div className="flex items-center justify-between">
          {onBack ? (
            <button
              onClick={onBack}
              className="p-2 -ml-2 rounded-full hover:bg-accent-muted transition-colors"
              aria-label="Go back"
              data-testid="onboarding-back-button"
            >
              <ArrowLeft className="h-5 w-5 text-content-primary" />
            </button>
          ) : (
            <div className="w-9" />
          )}
          <span className="text-callout text-content-secondary">
            {step} of {totalSteps}
          </span>
          <div className="w-9" />
        </div>

        {/* Progress Bar */}
        <div className="h-1 bg-surface-tertiary rounded-pill overflow-hidden">
          <div
            className="h-full bg-content-primary transition-all duration-300 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
      </header>

      {/* Content */}
      <main className="flex-1 px-6 py-6">
        <div className="max-w-md mx-auto space-y-8">
          {/* Title */}
          <div className="space-y-2">
            <h1 className="text-display text-content-primary">{title}</h1>
            {subtitle && (
              <p className="text-body text-content-secondary">{subtitle}</p>
            )}
          </div>

          {/* Step Content */}
          {children}
        </div>
      </main>
    </div>
  )
}