'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { ChipGroup } from '@/components/ui/chip'
import { OnboardingLayout } from './layout'

const INTEREST_OPTIONS = [
  'Sports & Fitness',
  'Music',
  'Art & Design',
  'Technology',
  'Food & Dining',
  'Travel',
  'Gaming',
  'Photography',
  'Books & Reading',
  'Movies & TV',
  'Outdoor Activities',
  'Yoga & Wellness',
  'Dancing',
  'Cooking',
  'Fashion',
  'Business & Startups',
  'Volunteering',
  'Languages',
  'Pets & Animals',
  'Board Games',
]

interface Props {
  value: string[]
  onChange: (value: string[]) => void
  onNext: () => void
  onBack: () => void
}

export function OnboardingInterests({ value, onChange, onNext, onBack }: Props) {
  const [error, setError] = useState<string | null>(null)

  const handleNext = () => {
    if (value.length < 3) {
      setError('Please select at least 3 interests')
      return
    }
    onNext()
  }

  return (
    <OnboardingLayout
      step={5}
      totalSteps={9}
      title="What are you into?"
      subtitle="Select at least 3 interests to help us find your people."
      onBack={onBack}
    >
      <div className="space-y-6">
        <ChipGroup
          options={INTEREST_OPTIONS}
          selected={value}
          onChange={(selected) => {
            onChange(selected)
            setError(null)
          }}
          min={3}
          size="sm"
        />
        
        {error && (
          <p className="text-caption text-error">{error}</p>
        )}

        <div className="flex items-center justify-between">
          <span className="text-callout text-content-secondary">
            {value.length} selected
          </span>
          <Button
            size="lg"
            onClick={handleNext}
            disabled={value.length < 3}
            data-testid="onboarding-interests-next"
          >
            Continue
          </Button>
        </div>
      </div>
    </OnboardingLayout>
  )
}