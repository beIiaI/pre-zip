'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { OnboardingLayout } from './layout'
import { isOver18 } from '@/lib/utils'

interface Props {
  value: string
  onChange: (value: string) => void
  onNext: () => void
  onBack: () => void
}

export function OnboardingDOB({ value, onChange, onNext, onBack }: Props) {
  const [error, setError] = useState<string | null>(null)

  const handleNext = () => {
    if (!value) {
      setError('Please enter your date of birth')
      return
    }

    if (!isOver18(value)) {
      setError('You must be 18 or older to use pre')
      return
    }

    onNext()
  }

  // Calculate max date (18 years ago)
  const maxDate = new Date()
  maxDate.setFullYear(maxDate.getFullYear() - 18)
  const maxDateStr = maxDate.toISOString().split('T')[0]

  return (
    <OnboardingLayout
      step={6}
      totalSteps={9}
      title="When's your birthday?"
      subtitle="You must be 18+ to use pre. Your age won't be shown publicly."
      onBack={onBack}
    >
      <div className="space-y-6">
        <Input
          type="date"
          label="Date of Birth"
          value={value}
          onChange={(e) => {
            onChange(e.target.value)
            setError(null)
          }}
          max={maxDateStr}
          error={error || undefined}
          data-testid="onboarding-dob-input"
        />

        <Button
          className="w-full"
          size="lg"
          onClick={handleNext}
          data-testid="onboarding-dob-next"
        >
          Continue
        </Button>
      </div>
    </OnboardingLayout>
  )
}