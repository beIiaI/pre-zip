'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { OnboardingLayout } from './layout'
import { validateUsername } from '@/lib/utils'
import { createClient } from '@/lib/supabase/client'
import { Check, X, Loader2 } from 'lucide-react'

interface Props {
  value: string
  onChange: (value: string) => void
  onNext: () => void
  onBack: () => void
}

export function OnboardingUsername({ value, onChange, onNext, onBack }: Props) {
  const [error, setError] = useState<string | null>(null)
  const [checking, setChecking] = useState(false)
  const [available, setAvailable] = useState<boolean | null>(null)
  const supabase = createClient()

  // Check username availability
  useEffect(() => {
    if (!value.trim()) {
      setAvailable(null)
      return
    }

    const validation = validateUsername(value)
    if (!validation.valid) {
      setError(validation.error || null)
      setAvailable(null)
      return
    }

    setError(null)
    setChecking(true)

    const timer = setTimeout(async () => {
      try {
        const { data, error: queryError } = await supabase
          .from('profiles')
          .select('username')
          .eq('username', value.toLowerCase())
          .single()

        if (queryError && queryError.code === 'PGRST116') {
          // No match found - username is available
          setAvailable(true)
        } else if (data) {
          setAvailable(false)
          setError('This username is already taken')
        }
      } catch (err) {
        // Assume available if check fails
        setAvailable(true)
      } finally {
        setChecking(false)
      }
    }, 500)

    return () => clearTimeout(timer)
  }, [value, supabase])

  const handleNext = () => {
    // Username is optional
    if (!value.trim()) {
      onNext()
      return
    }

    const validation = validateUsername(value)
    if (!validation.valid) {
      setError(validation.error || 'Invalid username')
      return
    }

    if (available === false) {
      setError('This username is already taken')
      return
    }

    onNext()
  }

  return (
    <OnboardingLayout
      step={3}
      totalSteps={9}
      title="Choose a username"
      subtitle="This is optional, but makes it easier for friends to find you."
      onBack={onBack}
    >
      <div className="space-y-6">
        <div className="relative">
          <Input
            label="Username"
            placeholder="your_username"
            value={value}
            onChange={(e) => onChange(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
            error={error || undefined}
            hint="Letters, numbers, and underscores only"
            autoFocus
            data-testid="onboarding-username-input"
          />
          {value && (
            <div className="absolute right-3 top-[38px]">
              {checking ? (
                <Loader2 className="h-5 w-5 animate-spin text-content-tertiary" />
              ) : available === true ? (
                <Check className="h-5 w-5 text-success" />
              ) : available === false ? (
                <X className="h-5 w-5 text-error" />
              ) : null}
            </div>
          )}
        </div>

        <div className="flex gap-3">
          <Button
            variant="secondary"
            className="flex-1"
            size="lg"
            onClick={onNext}
            data-testid="onboarding-username-skip"
          >
            Skip
          </Button>
          <Button
            className="flex-1"
            size="lg"
            onClick={handleNext}
            disabled={checking || (!!value && available === false)}
            data-testid="onboarding-username-next"
          >
            Continue
          </Button>
        </div>
      </div>
    </OnboardingLayout>
  )
}