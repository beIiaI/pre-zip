'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { OnboardingLayout } from './layout'
import { MapPin, Navigation } from 'lucide-react'

interface Props {
  value: string
  onChange: (value: string, lat?: number, lng?: number) => void
  onNext: () => void
  onBack: () => void
}

export function OnboardingLocation({ value, onChange, onNext, onBack }: Props) {
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  const handleGetLocation = async () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser')
      return
    }

    setLoading(true)
    setError(null)

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords
        
        // Try to get city name from coordinates (simplified - in production use a geocoding API)
        try {
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json`
          )
          const data = await response.json()
          const city = data.address?.city || data.address?.town || data.address?.village || 'Unknown location'
          const country = data.address?.country || ''
          const locationStr = country ? `${city}, ${country}` : city
          onChange(locationStr, latitude, longitude)
        } catch {
          onChange(`${latitude.toFixed(4)}, ${longitude.toFixed(4)}`, latitude, longitude)
        }
        setLoading(false)
      },
      (err) => {
        setError('Unable to get your location. Please enter it manually.')
        setLoading(false)
      }
    )
  }

  const handleNext = () => {
    if (!value.trim()) {
      setError('Please enter your location')
      return
    }
    onNext()
  }

  return (
    <OnboardingLayout
      step={7}
      totalSteps={9}
      title="Where are you based?"
      subtitle="This helps us show you local circles and events."
      onBack={onBack}
    >
      <div className="space-y-6">
        <div className="space-y-3">
          <Input
            label="Location"
            placeholder="City, Country"
            value={value}
            onChange={(e) => {
              onChange(e.target.value)
              setError(null)
            }}
            error={error || undefined}
            data-testid="onboarding-location-input"
          />

          <Button
            variant="secondary"
            className="w-full"
            onClick={handleGetLocation}
            loading={loading}
            data-testid="onboarding-location-gps"
          >
            <Navigation className="h-4 w-4" />
            Use my current location
          </Button>
        </div>

        <Button
          className="w-full"
          size="lg"
          onClick={handleNext}
          data-testid="onboarding-location-next"
        >
          Continue
        </Button>
      </div>
    </OnboardingLayout>
  )
}