'use client'

import { useState } from 'react'
import { SegmentedControl } from '@/components/ui/segmented-control'
import { CirclesTab } from './circles-tab'
import { PeopleTab } from './people-tab'
import { EventsTab } from './events-tab'

type Tab = 'circles' | 'people' | 'events'

export function HomeTabs() {
  const [activeTab, setActiveTab] = useState<Tab>('circles')

  return (
    <div className="space-y-6">
      {/* Tab Switcher */}
      <div className="flex justify-center">
        <SegmentedControl
          options={[
            { value: 'circles', label: 'Circles' },
            { value: 'people', label: 'People' },
            { value: 'events', label: 'Events' },
          ]}
          value={activeTab}
          onChange={(v) => setActiveTab(v as Tab)}
        />
      </div>

      {/* Tab Content */}
      <div className="animate-fade-in">
        {activeTab === 'circles' && <CirclesTab />}
        {activeTab === 'people' && <PeopleTab />}
        {activeTab === 'events' && <EventsTab />}
      </div>
    </div>
  )
}