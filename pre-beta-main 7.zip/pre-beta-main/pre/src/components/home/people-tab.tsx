'use client'

import { Avatar } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { UserPlus } from 'lucide-react'

export function PeopleTab() {
  // TODO: Fetch suggested people from Supabase
  const people: any[] = []

  if (people.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <div className="h-16 w-16 rounded-full bg-surface-secondary flex items-center justify-center mb-4">
          <UserPlus className="h-8 w-8 text-content-tertiary" />
        </div>
        <h3 className="text-headline text-content-primary mb-2">Find your people</h3>
        <p className="text-body text-content-secondary mb-6 max-w-xs">
          We're looking for people who match your interests. Check back soon!
        </p>
        <Button variant="secondary" disabled>
          Coming soon
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {people.map((person) => (
        <div
          key={person.id}
          className="flex items-center gap-4 p-4 rounded-card bg-surface-secondary border border-border-secondary"
        >
          <Avatar src={person.avatar_url} size="lg" />
          <div className="flex-1 min-w-0">
            <p className="text-body font-medium text-content-primary truncate">
              {person.full_name}
            </p>
            {person.username && (
              <p className="text-callout text-content-secondary">@{person.username}</p>
            )}
          </div>
        </div>
      ))}
    </div>
  )
}