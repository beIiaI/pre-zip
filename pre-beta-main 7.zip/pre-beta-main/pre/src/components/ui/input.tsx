import * as React from 'react'
import { cn } from '@/lib/utils'

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string
  error?: string
  hint?: string
  prefix?: string
}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, type, label, error, hint, prefix, id, ...props }, ref) => {
    const inputId = id || React.useId()
    
    return (
      <div className="w-full space-y-2">
        {label && (
          <label
            htmlFor={inputId}
            className="block text-sm font-medium text-content-primary"
          >
            {label}
          </label>
        )}
        <div className="relative">
          {prefix && (
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-content-tertiary">
              {prefix}
            </span>
          )}
          <input
            type={type}
            id={inputId}
            className={cn(
              'flex h-[52px] w-full rounded-xl border bg-[var(--input-background)] text-[var(--input-text)] placeholder:text-[var(--input-placeholder)] transition-colors',
              'border-[var(--input-border)] focus:border-content-primary/30 focus:outline-none',
              'disabled:cursor-not-allowed disabled:opacity-50',
              error && 'border-error focus:border-error',
              prefix ? 'pl-9 pr-4 py-4' : 'px-4 py-4',
              className
            )}
            ref={ref}
            {...props}
          />
        </div>
        {error && (
          <p className="text-sm text-error">{error}</p>
        )}
        {hint && !error && (
          <p className="text-sm text-content-tertiary">{hint}</p>
        )}
      </div>
    )
  }
)
Input.displayName = 'Input'

export { Input }