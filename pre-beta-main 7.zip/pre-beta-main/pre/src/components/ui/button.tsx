import * as React from 'react'
import { cn } from '@/lib/utils'

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'outline' | 'danger'
  size?: 'sm' | 'md' | 'lg' | 'icon'
  loading?: boolean
  fullWidth?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size = 'md', loading, fullWidth, disabled, children, ...props }, ref) => {
    const baseStyles = 'inline-flex items-center justify-center font-medium transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-30 rounded-full'
    
    const variants = {
      primary: 'bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] hover:opacity-90 active:bg-[#333333] dark:active:bg-[#E5E5E5]',
      secondary: 'bg-transparent border border-border-primary text-content-primary active:bg-surface-tertiary dark:active:bg-surface-tertiary',
      ghost: 'text-content-primary hover:bg-accent-muted active:bg-accent-muted',
      outline: 'border border-border-primary text-content-primary hover:bg-accent-muted',
      danger: 'bg-error text-white hover:opacity-90',
    }
    
    const sizes = {
      sm: 'h-9 px-4 text-sm gap-1.5',
      md: 'h-[52px] px-6 text-[15px] gap-2',
      lg: 'h-14 px-8 text-base gap-2',
      icon: 'h-10 w-10',
    }

    return (
      <button
        className={cn(
          baseStyles,
          variants[variant],
          sizes[size],
          fullWidth && 'w-full',
          className
        )}
        disabled={disabled || loading}
        ref={ref}
        {...props}
      >
        {loading ? (
          <span className="inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
        ) : (
          children
        )}
      </button>
    )
  }
)
Button.displayName = 'Button'

export { Button }