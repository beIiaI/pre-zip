'use client'

import * as React from 'react'
import { cn } from '@/lib/utils'
import { AlertCircle, CheckCircle, Info, X, AlertTriangle } from 'lucide-react'

export interface AlertProps {
  variant?: 'info' | 'success' | 'warning' | 'error'
  title?: string
  children: React.ReactNode
  dismissible?: boolean
  onDismiss?: () => void
  className?: string
}

export function Alert({ variant = 'info', title, children, dismissible, onDismiss, className }: AlertProps) {
  const variants = {
    info: 'bg-surface-secondary border-border-primary',
    success: 'bg-success/10 border-success/20',
    warning: 'bg-warning/10 border-warning/20',
    error: 'bg-error/10 border-error/20',
  }

  const icons = {
    info: <Info className="h-5 w-5 text-content-secondary" />,
    success: <CheckCircle className="h-5 w-5 text-success" />,
    warning: <AlertTriangle className="h-5 w-5 text-warning" />,
    error: <AlertCircle className="h-5 w-5 text-error" />,
  }

  return (
    <div
      role="alert"
      className={cn(
        'relative flex gap-3 p-4 rounded-card border',
        variants[variant],
        className
      )}
    >
      <div className="shrink-0">{icons[variant]}</div>
      <div className="flex-1 min-w-0">
        {title && <p className="text-body font-medium text-content-primary mb-1">{title}</p>}
        <div className="text-callout text-content-secondary">{children}</div>
      </div>
      {dismissible && (
        <button
          onClick={onDismiss}
          className="shrink-0 p-1 rounded-full hover:bg-accent-muted transition-colors"
        >
          <X className="h-4 w-4 text-content-tertiary" />
        </button>
      )}
    </div>
  )
}