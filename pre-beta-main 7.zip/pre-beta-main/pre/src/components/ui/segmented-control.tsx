'use client'

import * as React from 'react'
import { cn } from '@/lib/utils'

export interface SegmentedControlProps {
  options: { value: string; label: string }[]
  value: string
  onChange: (value: string) => void
  disabled?: boolean
}

export function SegmentedControl({ options, value, onChange, disabled }: SegmentedControlProps) {
  return (
    <div className="inline-flex p-1 bg-surface-secondary rounded-button border border-border-secondary">
      {options.map((option) => (
        <button
          key={option.value}
          type="button"
          onClick={() => onChange(option.value)}
          disabled={disabled}
          className={cn(
            'px-4 py-2 text-callout font-medium rounded-chip transition-all duration-200',
            value === option.value
              ? 'bg-surface-primary text-content-primary shadow-subtle'
              : 'text-content-secondary hover:text-content-primary',
            disabled && 'opacity-50 cursor-not-allowed'
          )}
        >
          {option.label}
        </button>
      ))}
    </div>
  )
}