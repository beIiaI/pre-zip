'use client'

import { createContext, useContext, useEffect, useState, useCallback, ReactNode } from 'react'
import type { ThemeMode } from '@/types'

interface ThemeContextType {
  mode: ThemeMode
  amoledEnabled: boolean
  resolvedTheme: 'light' | 'dark'
  setMode: (mode: ThemeMode) => void
  setAmoledEnabled: (enabled: boolean) => void
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [mode, setModeState] = useState<ThemeMode>('system')
  const [amoledEnabled, setAmoledState] = useState(false)
  const [resolvedTheme, setResolvedTheme] = useState<'light' | 'dark'>('light')
  const [mounted, setMounted] = useState(false)

  // Resolve theme based on mode and system preference
  const resolveTheme = useCallback((currentMode: ThemeMode): 'light' | 'dark' => {
    if (currentMode === 'system') {
      if (typeof window !== 'undefined') {
        return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
      }
      return 'light'
    }
    return currentMode
  }, [])

  // Apply theme to document
  const applyTheme = useCallback((theme: 'light' | 'dark', amoled: boolean) => {
    const root = document.documentElement
    root.classList.remove('light', 'dark', 'amoled')
    
    if (theme === 'dark') {
      root.classList.add('dark')
      if (amoled) {
        root.classList.add('amoled')
      }
    } else {
      root.classList.add('light')
    }
  }, [])

  // Initialize from localStorage
  useEffect(() => {
    const savedMode = localStorage.getItem('pre-theme-mode') as ThemeMode | null
    const savedAmoled = localStorage.getItem('pre-amoled') === 'true'
    
    const initialMode = savedMode || 'system'
    const resolved = resolveTheme(initialMode)
    
    setModeState(initialMode)
    setAmoledState(savedAmoled)
    setResolvedTheme(resolved)
    applyTheme(resolved, savedAmoled && resolved === 'dark')
    setMounted(true)
  }, [resolveTheme, applyTheme])

  // Listen for system theme changes
  useEffect(() => {
    if (!mounted) return

    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)')
    const handleChange = () => {
      if (mode === 'system') {
        const resolved = resolveTheme('system')
        setResolvedTheme(resolved)
        applyTheme(resolved, amoledEnabled && resolved === 'dark')
      }
    }

    mediaQuery.addEventListener('change', handleChange)
    return () => mediaQuery.removeEventListener('change', handleChange)
  }, [mounted, mode, amoledEnabled, resolveTheme, applyTheme])

  const setMode = useCallback((newMode: ThemeMode) => {
    setModeState(newMode)
    localStorage.setItem('pre-theme-mode', newMode)
    const resolved = resolveTheme(newMode)
    setResolvedTheme(resolved)
    applyTheme(resolved, amoledEnabled && resolved === 'dark')
  }, [amoledEnabled, resolveTheme, applyTheme])

  const setAmoledEnabled = useCallback((enabled: boolean) => {
    setAmoledState(enabled)
    localStorage.setItem('pre-amoled', String(enabled))
    applyTheme(resolvedTheme, enabled && resolvedTheme === 'dark')
  }, [resolvedTheme, applyTheme])

  // Prevent flash of unstyled content
  if (!mounted) {
    return (
      <div style={{ visibility: 'hidden' }}>
        {children}
      </div>
    )
  }

  return (
    <ThemeContext.Provider value={{ mode, amoledEnabled, resolvedTheme, setMode, setAmoledEnabled }}>
      {children}
    </ThemeContext.Provider>
  )
}

const defaultThemeContext: ThemeContextType = {
  mode: 'system',
  amoledEnabled: false,
  resolvedTheme: 'light',
  setMode: () => {},
  setAmoledEnabled: () => {},
}

export function useTheme(): ThemeContextType {
  const context = useContext(ThemeContext)
  // Return defaults if context is not yet available (hydration)
  if (context === undefined) {
    return defaultThemeContext
  }
  return context
}