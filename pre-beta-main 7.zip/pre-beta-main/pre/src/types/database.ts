export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string
          full_name: string | null
          username: string | null
          bio: string | null
          avatar_url: string | null
          date_of_birth: string | null
          location: string | null
          location_lat: number | null
          location_lng: number | null
          interests: string[]
          user_intent: string[]
          theme_mode: 'light' | 'dark' | 'system'
          amoled_enabled: boolean
          onboarding_completed: boolean
          onboarding_step: number
          early_supporter_number: number | null
          total_points: number
          is_verified: boolean
          verification_type: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          full_name?: string | null
          username?: string | null
          bio?: string | null
          avatar_url?: string | null
          date_of_birth?: string | null
          location?: string | null
          location_lat?: number | null
          location_lng?: number | null
          interests?: string[]
          user_intent?: string[]
          theme_mode?: 'light' | 'dark' | 'system'
          amoled_enabled?: boolean
          onboarding_completed?: boolean
          onboarding_step?: number
          early_supporter_number?: number | null
          total_points?: number
          is_verified?: boolean
          verification_type?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          full_name?: string | null
          username?: string | null
          bio?: string | null
          avatar_url?: string | null
          date_of_birth?: string | null
          location?: string | null
          location_lat?: number | null
          location_lng?: number | null
          interests?: string[]
          user_intent?: string[]
          theme_mode?: 'light' | 'dark' | 'system'
          amoled_enabled?: boolean
          onboarding_completed?: boolean
          onboarding_step?: number
          early_supporter_number?: number | null
          total_points?: number
          is_verified?: boolean
          verification_type?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      circles: {
        Row: {
          id: string
          name: string
          description: string | null
          cover_image_url: string | null
          creator_id: string
          is_public: boolean
          member_count: number
          category: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          description?: string | null
          cover_image_url?: string | null
          creator_id: string
          is_public?: boolean
          member_count?: number
          category?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          description?: string | null
          cover_image_url?: string | null
          creator_id?: string
          is_public?: boolean
          member_count?: number
          category?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      circle_members: {
        Row: {
          id: string
          circle_id: string
          user_id: string
          role: 'admin' | 'moderator' | 'member'
          joined_at: string
        }
        Insert: {
          id?: string
          circle_id: string
          user_id: string
          role?: 'admin' | 'moderator' | 'member'
          joined_at?: string
        }
        Update: {
          id?: string
          circle_id?: string
          user_id?: string
          role?: 'admin' | 'moderator' | 'member'
          joined_at?: string
        }
      }
      events: {
        Row: {
          id: string
          title: string
          description: string | null
          hero_image_url: string | null
          creator_id: string
          circle_id: string | null
          location: string
          location_lat: number | null
          location_lng: number | null
          starts_at: string
          ends_at: string | null
          max_attendees: number | null
          attendee_count: number
          is_public: boolean
          category: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          title: string
          description?: string | null
          hero_image_url?: string | null
          creator_id: string
          circle_id?: string | null
          location: string
          location_lat?: number | null
          location_lng?: number | null
          starts_at: string
          ends_at?: string | null
          max_attendees?: number | null
          attendee_count?: number
          is_public?: boolean
          category?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          title?: string
          description?: string | null
          hero_image_url?: string | null
          creator_id?: string
          circle_id?: string | null
          location?: string
          location_lat?: number | null
          location_lng?: number | null
          starts_at?: string
          ends_at?: string | null
          max_attendees?: number | null
          attendee_count?: number
          is_public?: boolean
          category?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      event_attendees: {
        Row: {
          id: string
          event_id: string
          user_id: string
          status: 'going' | 'maybe' | 'not_going'
          rsvp_at: string
        }
        Insert: {
          id?: string
          event_id: string
          user_id: string
          status?: 'going' | 'maybe' | 'not_going'
          rsvp_at?: string
        }
        Update: {
          id?: string
          event_id?: string
          user_id?: string
          status?: 'going' | 'maybe' | 'not_going'
          rsvp_at?: string
        }
      }
      messages: {
        Row: {
          id: string
          circle_id: string
          sender_id: string
          content: string
          created_at: string
        }
        Insert: {
          id?: string
          circle_id: string
          sender_id: string
          content: string
          created_at?: string
        }
        Update: {
          id?: string
          circle_id?: string
          sender_id?: string
          content?: string
          created_at?: string
        }
      }
      badges: {
        Row: {
          id: string
          name: string
          description: string
          icon: string
          category: string
          points_required: number | null
          criteria: Json | null
          is_earnable: boolean
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          description: string
          icon: string
          category: string
          points_required?: number | null
          criteria?: Json | null
          is_earnable?: boolean
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          description?: string
          icon?: string
          category?: string
          points_required?: number | null
          criteria?: Json | null
          is_earnable?: boolean
          created_at?: string
        }
      }
      user_badges: {
        Row: {
          id: string
          user_id: string
          badge_id: string
          earned_at: string
          progress: number
        }
        Insert: {
          id?: string
          user_id: string
          badge_id: string
          earned_at?: string
          progress?: number
        }
        Update: {
          id?: string
          user_id?: string
          badge_id?: string
          earned_at?: string
          progress?: number
        }
      }
      notifications: {
        Row: {
          id: string
          user_id: string
          type: string
          title: string
          body: string | null
          data: Json | null
          read: boolean
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          type: string
          title: string
          body?: string | null
          data?: Json | null
          read?: boolean
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          type?: string
          title?: string
          body?: string | null
          data?: Json | null
          read?: boolean
          created_at?: string
        }
      }
      reports: {
        Row: {
          id: string
          reporter_id: string
          reported_user_id: string | null
          reported_content_id: string | null
          content_type: string | null
          reason: string
          description: string | null
          status: 'pending' | 'reviewed' | 'resolved' | 'dismissed'
          created_at: string
        }
        Insert: {
          id?: string
          reporter_id: string
          reported_user_id?: string | null
          reported_content_id?: string | null
          content_type?: string | null
          reason: string
          description?: string | null
          status?: 'pending' | 'reviewed' | 'resolved' | 'dismissed'
          created_at?: string
        }
        Update: {
          id?: string
          reporter_id?: string
          reported_user_id?: string | null
          reported_content_id?: string | null
          content_type?: string | null
          reason?: string
          description?: string | null
          status?: 'pending' | 'reviewed' | 'resolved' | 'dismissed'
          created_at?: string
        }
      }
      blocks: {
        Row: {
          id: string
          blocker_id: string
          blocked_id: string
          created_at: string
        }
        Insert: {
          id?: string
          blocker_id: string
          blocked_id: string
          created_at?: string
        }
        Update: {
          id?: string
          blocker_id?: string
          blocked_id?: string
          created_at?: string
        }
      }
      referrals: {
        Row: {
          id: string
          referrer_id: string
          referred_id: string
          code: string
          status: 'pending' | 'completed'
          completed_at: string | null
          created_at: string
        }
        Insert: {
          id?: string
          referrer_id: string
          referred_id: string
          code: string
          status?: 'pending' | 'completed'
          completed_at?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          referrer_id?: string
          referred_id?: string
          code?: string
          status?: 'pending' | 'completed'
          completed_at?: string | null
          created_at?: string
        }
      }
      points_ledger: {
        Row: {
          id: string
          user_id: string
          amount: number
          reason: string
          reference_type: string | null
          reference_id: string | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          amount: number
          reason: string
          reference_type?: string | null
          reference_id?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          amount?: number
          reason?: string
          reference_type?: string | null
          reference_id?: string | null
          created_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}

// Helper types
export type Tables<T extends keyof Database['public']['Tables']> = Database['public']['Tables'][T]['Row']
export type InsertTables<T extends keyof Database['public']['Tables']> = Database['public']['Tables'][T]['Insert']
export type UpdateTables<T extends keyof Database['public']['Tables']> = Database['public']['Tables'][T]['Update']

export type Profile = Tables<'profiles'>
export type Circle = Tables<'circles'>
export type CircleMember = Tables<'circle_members'>
export type Event = Tables<'events'>
export type EventAttendee = Tables<'event_attendees'>
export type Message = Tables<'messages'>
export type Badge = Tables<'badges'>
export type UserBadge = Tables<'user_badges'>
export type Notification = Tables<'notifications'>
export type Report = Tables<'reports'>
export type Block = Tables<'blocks'>
export type Referral = Tables<'referrals'>
export type PointsLedger = Tables<'points_ledger'>