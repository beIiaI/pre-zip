export type ThemeMode = 'light' | 'dark' | 'system'

export interface ThemeState {
  mode: ThemeMode
  amoledEnabled: boolean
  resolvedTheme: 'light' | 'dark'
}

export interface OnboardingState {
  step: number
  totalSteps: number
  completed: boolean
  data: {
    fullName?: string
    username?: string
    userIntent?: string[]
    interests?: string[]
    dateOfBirth?: string
    location?: string
    locationLat?: number
    locationLng?: number
    themeMode?: ThemeMode
    amoledEnabled?: boolean
    avatarUrl?: string
    bio?: string
  }
}

export interface User {
  id: string
  email: string
  profile?: import('./database').Profile
}

export interface AuthState {
  user: User | null
  profile: import('./database').Profile | null
  loading: boolean
  initialized: boolean
}