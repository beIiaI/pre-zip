import React from 'react'
import {
  Pressable,
  Text,
  StyleSheet,
  ActivityIndicator,
  ViewStyle,
  TextStyle,
} from 'react-native'
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
} from 'react-native-reanimated'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

interface ButtonProps {
  onPress: () => void
  children: React.ReactNode
  variant?: 'primary' | 'secondary' | 'ghost'
  size?: 'small' | 'medium' | 'large'
  loading?: boolean
  disabled?: boolean
  fullWidth?: boolean
  style?: ViewStyle
  textStyle?: TextStyle
  testID?: string
}

const SPRING = { damping: 18, stiffness: 350, mass: 0.8 }

export function Button({
  onPress,
  children,
  variant = 'primary',
  size = 'large',
  loading = false,
  disabled = false,
  fullWidth = false,
  style,
  textStyle,
  testID,
}: ButtonProps) {
  const { colors } = useTheme()
  const scale = useSharedValue(1)
  const isDisabled = disabled || loading

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }))

  const handlePressIn = () => {
    scale.value = withSpring(0.96, SPRING)
  }

  const handlePressOut = () => {
    scale.value = withSpring(1, SPRING)
  }

  const handlePress = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)
    onPress()
  }

  const pressableStyles: ViewStyle[] = [
    styles.base,
    {
      backgroundColor:
        variant === 'primary'
          ? colors.contentPrimary
          : variant === 'secondary'
            ? colors.surfaceElevated
            : 'transparent',
      borderColor:
        variant === 'secondary' ? colors.borderSecondary : 'transparent',
      borderWidth: variant === 'secondary' ? 1 : 0,
      paddingVertical:
        size === 'large' ? Spacing.base : size === 'medium' ? 12 : Spacing.sm,
      paddingHorizontal: Spacing.lg,
      opacity: isDisabled ? 0.5 : 1,
    },
  ]

  const textStyles: TextStyle[] = [
    styles.text,
    {
      color:
        variant === 'primary' ? colors.contentInverse : colors.contentPrimary,
      fontSize: size === 'small' ? Typography.callout : Typography.body,
    },
    textStyle,
  ]

  return (
    <Animated.View
      style={[animatedStyle, fullWidth && styles.fullWidth, style]}
    >
      <Pressable
        onPress={handlePress}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        disabled={isDisabled}
        style={pressableStyles}
        testID={testID}
      >
        {loading ? (
          <ActivityIndicator
            size="small"
            color={
              variant === 'primary'
                ? colors.contentInverse
                : colors.contentPrimary
            }
          />
        ) : (
          <Text style={textStyles}>{children}</Text>
        )}
      </Pressable>
    </Animated.View>
  )
}

const styles = StyleSheet.create({
  base: {
    borderRadius: BorderRadius.lg,
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: 52,
  },
  fullWidth: {
    width: '100%',
  },
  text: {
    fontWeight: Typography.medium,
    textAlign: 'center',
  },
})
