# Supabase Configuration for Pre Mobile App

This document lists all required Supabase Auth settings for the Pre mobile app to work correctly with the pre-beta backend.

## Required Supabase Auth Settings

### 1. Email Authentication

**Location**: Supabase Dashboard → Authentication → Providers → Email

- ✅ **Enable Email provider**
- ✅ **Confirm email**: Enabled
- ✅ **Email OTP**: Enabled for signup
- ✅ **OTP length**: 8 digits
- ✅ **OTP expiry**: 900 seconds (15 minutes)

### 2. Redirect URLs

**Location**: Supabase Dashboard → Authentication → URL Configuration

#### Development
Add these URLs for local development:

```
http://localhost:3000/auth/callback
http://localhost:3000/auth/reset
http://127.0.0.1:3000/auth/callback
http://127.0.0.1:3000/auth/reset
pre://auth/callback
pre://auth/reset
```

#### Production
Add these URLs for production deployment:

```
https://app.presocial.app/auth/callback
https://app.presocial.app/auth/reset
pre://auth/callback
pre://auth/reset
```

**Note**: 
- The `pre://` URLs are for mobile deep linking
- The `https://app.presocial.app` URLs are for web password reset emails
- `app.presocial.app` is the deployed Next.js app (pre-beta)
- `presocial.app` (without "app." prefix) is the marketing site (not relevant for app)

### 3. Site URL

**Location**: Supabase Dashboard → Authentication → URL Configuration → Site URL

#### Development
```
http://localhost:3000
```

#### Production
```
https://app.presocial.app
```

**Note**: This is the base URL for email templates and OAuth redirects. `app.presocial.app` is where the Next.js backend is deployed.

### 4. Email Templates

**Location**: Supabase Dashboard → Authentication → Email Templates

#### Confirm Signup Template
- Subject: `Verify your email for pre`
- Body must include: `{{ .Token }}` (8-digit OTP)
- **Do not modify** the template unless coordinating with pre-beta team

#### Reset Password Template
- Subject: `Reset your password for pre`
- Body must include: `{{ .ConfirmationURL }}`
- The confirmation URL will redirect to `/auth/callback?type=recovery` which then routes to `/auth/reset`

### 5. OAuth Providers (Optional)

**Location**: Supabase Dashboard → Authentication → Providers

#### Google OAuth (if enabled)
- ✅ Enable Google provider
- Client ID: `your-google-client-id`
- Client Secret: `your-google-client-secret`
- Redirect URL: `https://<your-supabase-project>.supabase.co/auth/v1/callback`
- Authorized domains: Add your production domain

#### Apple OAuth (if enabled)
- ✅ Enable Apple provider
- Services ID: `com.pre.app`
- Team ID: Your Apple Team ID
- Key ID: Your Apple Key ID
- Private Key: Your Apple private key
- Redirect URL: `https://<your-supabase-project>.supabase.co/auth/v1/callback`

**Note**: Mobile OAuth requires native flows (not web-based). Current mobile app does not implement OAuth.

### 6. Security Settings

**Location**: Supabase Dashboard → Authentication → Settings

#### JWT Expiry
- **JWT expiry**: 3600 seconds (1 hour) - default
- **Refresh token rotation**: Enabled (recommended)

#### Rate Limiting
**Location**: Supabase Dashboard → Authentication → Rate Limits

- **OTP requests**: 5 per 15 minutes per email
- **Password reset**: 5 per 15 minutes per email
- **Sign up**: 5 per 15 minutes per IP

**Note**: Additional rate limiting is enforced by Next.js API routes.

## Mobile-Specific Configuration

### Deep Link Setup

#### iOS (app.json)
```json
{
  "expo": {
    "scheme": "pre",
    "ios": {
      "bundleIdentifier": "com.pre.app",
      "associatedDomains": [
        "applinks:*.presocial.app",
        "applinks:your-domain.com"
      ]
    }
  }
}
```

#### Universal Links (iOS)
For production, configure Apple App Site Association (AASA) file at:
```
https://app.presocial.app/.well-known/apple-app-site-association
```

Example AASA file:
```json
{
  "applinks": {
    "apps": [],
    "details": [
      {
        "appID": "TEAM_ID.com.pre.app",
        "paths": ["/auth/*"]
      }
    ]
  }
}
```

**Domain Notes**:
- `app.presocial.app` = Deployed Next.js app (pre-beta backend)
- `presocial.app` = Marketing site (GitHub Pages, not used for app functionality)

## Environment Variables

### Mobile App (.env)
```env
# Same as pre-beta web
EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key

# Next.js API base URL (cloud-first)
EXPO_PUBLIC_API_URL=https://app.presocial.app

# For local testing, uncomment and set to your LAN IP:
# EXPO_PUBLIC_API_URL=http://192.168.1.100:3000

# App configuration
EXPO_PUBLIC_APP_ENV=production
EXPO_PUBLIC_APP_SCHEME=pre
EXPO_PUBLIC_UNIVERSAL_LINK_DOMAIN=app.presocial.app
```

### Pre-Beta Web (.env.local)
```env
# Required
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
NEXT_PUBLIC_SITE_URL=http://localhost:3000
NEXT_PUBLIC_APP_URL=http://localhost:3000

# For university verification emails
RESEND_API_KEY=your-resend-key
EMAIL_FROM="pre <no-reply@presocial.app>"
```

**Production Pre-Beta Web (.env.local)**:
```env
NEXT_PUBLIC_SITE_URL=https://app.presocial.app
NEXT_PUBLIC_APP_URL=https://app.presocial.app
```

## Verification Checklist

Before deploying, verify:

- [ ] Email OTP is 8 digits
- [ ] OTP expiry is 900 seconds
- [ ] All redirect URLs include both web and mobile schemes
- [ ] Site URL matches your deployment domain
- [ ] Password reset emails link to correct domain
- [ ] Deep link scheme matches app.json
- [ ] RLS policies are applied (migrations 001-032)
- [ ] Rate limits are configured
- [ ] Email templates are not modified from defaults

## Testing Deep Links

### iOS Simulator
```bash
# Test password reset deep link
xcrun simctl openurl booted "pre://auth/callback?type=recovery&token_hash=test"

# Test auth callback
xcrun simctl openurl booted "pre://auth/callback?next=/home"
```

### Physical Device
Send test password reset email and click the link. It should:
1. Open the mobile app
2. Route to `/auth/callback`
3. Detect `type=recovery`
4. Redirect to `/auth/reset`
5. Allow password change

## Troubleshooting

### Password Reset Email Not Working

**Symptom**: Email links go to web app instead of mobile app

**Fix**:
1. Verify `pre://` scheme is in Supabase redirect URLs
2. Check mobile app's `scheme` in app.json
3. Ensure iOS Associated Domains are configured
4. Test with `xcrun simctl openurl` first

### OTP Not Received

**Symptom**: No verification code email

**Fix**:
1. Check Supabase email provider is enabled
2. Verify email templates are not broken
3. Check spam folder
4. Review Supabase logs for email send errors
5. Ensure rate limits not exceeded

### "Invalid or Expired Token" on Reset

**Symptom**: Password reset link shows error

**Fix**:
1. Check token hasn't expired (15 min default)
2. Verify redirect URL is in Supabase allowlist
3. Ensure token is only used once
4. Check Supabase session is created after callback

### Mobile App Won't Open from Email

**Symptom**: Email link opens Safari instead of app

**Fix**:
1. Verify Universal Links are configured
2. Check AASA file is accessible
3. Ensure associated domains are correct
4. Test with `pre://` scheme directly first
5. Re-install app to refresh OS deep link cache

## Rate Limiting Strategy

### Client-Side Throttling (Mobile)
```typescript
// Example: Throttle OTP resend button
const [lastResend, setLastResend] = useState(0)
const canResend = Date.now() - lastResend > 60000 // 1 minute
```

### Server-Side Rate Limiting (Next.js API)
Already implemented in pre-beta:
- `/api/auth/sign-up`: 5 requests per 15 min per email
- `/api/auth/password/forgot`: 5 requests per 15 min per email
- `/api/invites/validate`: 10 requests per 5 min per IP

### Supabase Rate Limiting
Configured in Supabase Dashboard:
- Auth operations: 5 per 15 min per identifier
- Enforced at database level

## Production Deployment

### Before Going Live

1. **Update Supabase URLs**
   - Change Site URL to production domain
   - Add production redirect URLs
   - Remove localhost URLs

2. **Configure DNS**
   - Set up domain for pre-beta web
   - Configure Universal Links domain
   - Verify SSL certificates

3. **Test Email Flows**
   - Send test signup OTP
   - Send test password reset
   - Verify deep links work on physical device

4. **App Store Submission**
   - Update associated domains in App Store Connect
   - Match bundle identifier with Supabase config
   - Test with TestFlight before public release

## Support

If you encounter issues:
1. Check Supabase logs: Dashboard → Logs → Auth
2. Check Next.js API logs: Server console
3. Check mobile app logs: Expo DevTools
4. Review this configuration guide
5. Contact pre-beta support: support@presocial.app
