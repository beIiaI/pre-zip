# Pre Mobile ↔ Pre-Beta Parity Checklist

## Auth Flows

| Feature | Pre-Beta (Web) | Mobile (Expo) | Status | Notes |
|---------|----------------|---------------|--------|-------|
| **Sign Up** | `/auth?mode=signup` | `/auth/signup` | ✅ Parity | 8-digit OTP via Supabase, invite code required |
| Email OTP length | 8 digits | 8 digits | ✅ Parity | Configured in Supabase Auth settings |
| OTP expiry | 900s (15 min) | 900s (15 min) | ✅ Parity | Supabase default |
| Invite validation | `/api/invites/validate` | `/api/invites/validate` | ✅ Parity | Calls Next.js API |
| Invite claim | `/api/invites/claim` | `/api/invites/claim` | ✅ Parity | Calls Next.js API after OTP |
| **Sign In** | `/auth?mode=signin` | `/auth/signin` | ✅ Parity | Email/password |
| OAuth (Google/Apple) | Supported (web only) | ❌ Not implemented | 🔄 Future | Native OAuth requires different flow |
| **Forgot Password** | `/auth` forgot flow | `/auth/signin` forgot button | ✅ Parity | Calls `/api/auth/password/forgot` |
| Password reset | `/auth/reset` | `/auth/reset` | ✅ Parity | Deep link from email |
| Password reset callback | `/auth/callback?type=recovery` | `/auth/callback?type=recovery` | ✅ Parity | Handles token, redirects to reset |
| **Sign Out** | Sign out button | Settings tab sign out | ✅ Parity | Clears Supabase session |
| **Session Persistence** | Cookie-based | AsyncStorage-based | ✅ Parity | Both use Supabase Auth |
| **Access Request** | `/api/access/apply` | Signup screen | ✅ Parity | Vetted access flow |

## Onboarding

| Feature | Pre-Beta (Web) | Mobile (Expo) | Status | Notes |
|---------|----------------|---------------|--------|-------|
| **Onboarding Flow** | `/onboarding` (9 steps) | `/auth/onboarding` | ⚠️ Placeholder | Full implementation needed |
| Step 1: Intro | Welcome screen | ❌ Not implemented | 🔄 Next phase | |
| Step 2: Full name | Input | ❌ Not implemented | 🔄 Next phase | |
| Step 3: Username | Optional, availability check | ❌ Not implemented | 🔄 Next phase | |
| Step 4: Intent | Multi-select | ❌ Not implemented | 🔄 Next phase | |
| Step 5: Interests | Multi-select, min 3 | ❌ Not implemented | 🔄 Next phase | |
| Step 6: DOB | 18+ validation | ❌ Not implemented | 🔄 Next phase | |
| Step 7: Location | Manual + GPS | ❌ Not implemented | 🔄 Next phase | |
| Step 8: Theme | Light/Dark/AMOLED | ❌ Not implemented | 🔄 Next phase | |
| Step 9: Photo + Bio | Avatar upload | ❌ Not implemented | 🔄 Next phase | |
| Completion API | `/api/onboarding/complete` | ❌ Not implemented | 🔄 Next phase | |

## Navigation

| Feature | Pre-Beta (Web) | Mobile (Expo) | Status | Notes |
|---------|----------------|---------------|--------|-------|
| **Home Hub** | `/home` | `/(tabs)/home` | ✅ MVP | Placeholder tabs |
| Circles tab | Home circles section | ❌ Not implemented | 🔄 Phase 4 | |
| People tab | Home people section | ❌ Not implemented | 🔄 Phase 2 | |
| Events tab | Home events section | ❌ Not implemented | 🔄 Phase 4 | |
| **Messages** | `/messages` | `/(tabs)/messages` | ⚠️ Placeholder | List view needed |
| DM thread | `/messages/[id]` | `/messages/[id]` | ❌ Not implemented | 🔄 Phase 5 | |
| **Profile** | `/profile` | `/(tabs)/profile` | ✅ MVP | Own profile view |
| Profile edit | `/profile/edit` | `/profile/edit` | ❌ Not implemented | 🔄 Phase 2 | |
| Public profile | `/profile/[username]` | `/profile/[username]` | ❌ Not implemented | 🔄 Phase 2 | |
| Followers | `/profile/[username]/followers` | ❌ Not implemented | 🔄 Phase 2 | |
| Following | `/profile/[username]/following` | ❌ Not implemented | 🔄 Phase 2 | |
| **Settings** | `/settings` | `/(tabs)/settings` | ✅ MVP | Section list |

## Safety & Verification

| Feature | Pre-Beta (Web) | Mobile (Expo) | Status | Notes |
|---------|----------------|---------------|--------|-------|
| **University Verification** | `/settings/safety-verification` | `/settings/verification` | ❌ Not implemented | 🔄 Phase 3 |
| Request verification | `/api/verification/university/request` | Calls same API | ❌ Not implemented | 🔄 Phase 3 |
| Confirm verification | `/api/verification/university/confirm` | Email link → callback | ❌ Not implemented | 🔄 Phase 3 |
| Verification display | Shows verified badge | ❌ Not implemented | 🔄 Phase 3 | |
| **College (Self-Reported)** | `/api/verification/college` | ❌ Not implemented | 🔄 Phase 3 | Private table |
| College display | "College (self-reported)" | ❌ Not implemented | 🔄 Phase 3 | Never shows "verified" |
| Show university toggle | `profiles.show_university` | ❌ Not implemented | 🔄 Phase 3 | |
| Show college toggle | `profiles.show_college` | ❌ Not implemented | 🔄 Phase 3 | |
| **Privacy Settings** | `/settings/privacy` | `/settings/privacy` | ❌ Not implemented | 🔄 Phase 3 |
| **Password Change** | `/settings/password` | `/settings/password` | ❌ Not implemented | 🔄 Phase 7 |
| **Emergency Contacts** | `/api/emergency-contacts` | ❌ Not implemented | 🔄 Future | |
| **Panic Alerts** | `/api/panic` | ❌ Not implemented | 🔄 Future | |
| **Blocks** | `/api/blocks` | ❌ Not implemented | 🔄 Future | |

## Social Graph

| Feature | Pre-Beta (Web) | Mobile (Expo) | Status | Notes |
|---------|----------------|---------------|--------|-------|
| **User Search** | `/api/users/search` | ❌ Not implemented | 🔄 Phase 2 | |
| **Follow/Unfollow** | `/api/follow`, `/api/unfollow` | ❌ Not implemented | 🔄 Phase 2 | |
| **Followers List** | `/api/followers` | ❌ Not implemented | 🔄 Phase 2 | |
| **Following List** | `/api/following` | ❌ Not implemented | 🔄 Phase 2 | |

## Circles

| Feature | Pre-Beta (Web) | Mobile (Expo) | Status | Notes |
|---------|----------------|---------------|--------|-------|
| **Circles List** | `/api/circles` | ❌ Not implemented | 🔄 Phase 4 | |
| **Create Circle** | `/circles/new` | ❌ Not implemented | 🔄 Phase 4 | |
| **Circle Detail** | Circle page | ❌ Not implemented | 🔄 Phase 4 | |
| **Join/Leave** | `/api/circles/members` | ❌ Not implemented | 🔄 Phase 4 | |
| **Circle Chat** | Messages in circle | ❌ Not implemented | 🔄 Future | |

## Events

| Feature | Pre-Beta (Web) | Mobile (Expo) | Status | Notes |
|---------|----------------|---------------|--------|-------|
| **Events List** | `/events` | ❌ Not implemented | 🔄 Phase 4 | |
| **Create Event** | `/events/new` | ❌ Not implemented | 🔄 Phase 4 | |
| **Event Detail** | `/events/[id]` | ❌ Not implemented | 🔄 Phase 4 | |
| **RSVP** | `/api/events/rsvp` | ❌ Not implemented | 🔄 Phase 4 | |
| **Event Chat** | `/events/[id]/chat` | ❌ Not implemented | 🔄 Future | |
| **Campus-Only Gating** | `is_campus_only` check | ❌ Not implemented | 🔄 Phase 4 | Requires `university_verified` |

## Direct Messages

| Feature | Pre-Beta (Web) | Mobile (Expo) | Status | Notes |
|---------|----------------|---------------|--------|-------|
| **DM Thread List** | `/messages` | ❌ Not implemented | 🔄 Phase 5 | |
| **Conversation View** | `/messages/[id]` | ❌ Not implemented | 🔄 Phase 5 | |
| **Send Message** | `/api/dms/[id]/messages` | ❌ Not implemented | 🔄 Phase 5 | |
| **New DM Thread** | `/api/dms` | ❌ Not implemented | 🔄 Phase 5 | |
| **Participant RLS** | Enforced by Supabase | ✅ Parity | Same RLS policies |
| **Realtime Updates** | Supabase Realtime | ❌ Not implemented | 🔄 Phase 5 | |
| **Read Receipts** | `last_read_at` | ❌ Not implemented | 🔄 Phase 5 | |

## Settings Screens

| Feature | Pre-Beta (Web) | Mobile (Expo) | Status | Notes |
|---------|----------------|---------------|--------|-------|
| **Help & Support** | `/settings/help` | `/settings/help` | ❌ Not implemented | 🔄 Phase 7 |
| **Invites Management** | `/settings/invites` | `/settings/invites` | ❌ Not implemented | 🔄 Phase 7 |
| **Access Review** | `/settings/access-review` | ❌ Not implemented | 🔄 Future | Admin only |
| **Notifications** | `/notifications` | ❌ Not implemented | 🔄 Phase 7 | |

## Badges & Points

| Feature | Pre-Beta (Web) | Mobile (Expo) | Status | Notes |
|---------|----------------|---------------|--------|-------|
| **Badges Screen** | `/badges` | ❌ Not implemented | 🔄 Phase 7 | |
| **Early Supporter Badge** | `/badges/early-supporter` | ❌ Not implemented | 🔄 Phase 7 | First 250 users |
| **Founder Badge** | Admin override | ❌ Not implemented | 🔄 Future | |
| **Points Ledger** | `/api/points` (implicit) | ❌ Not implemented | 🔄 Future | |

## Design System

| Feature | Pre-Beta (Web) | Mobile (Expo) | Status | Notes |
|---------|----------------|---------------|--------|-------|
| **Theme Modes** | Light/Dark/AMOLED | Light/Dark/AMOLED | ✅ Parity | System detection + manual |
| **PreWordmark SVG** | `PreWordmark` component | `PreWordmark` RN component | ✅ Parity | Converted to react-native-svg |
| **Color Tokens** | CSS variables | TypeScript constants | ✅ Parity | Ceramic/obsidian palette |
| **Typography Scale** | 32/22/18/16/14/12 | Same scale | ✅ Parity | |
| **Spacing Grid** | 4/8/12/16/24/32/48 | Same grid | ✅ Parity | |
| **Border Radius** | 8/12/16/20/9999 | Same values | ✅ Parity | |
| **Bento System** | Web-specific classes | ❌ Not applicable | N/A | Native cards instead |

## Security

| Feature | Pre-Beta (Web) | Mobile (Expo) | Status | Notes |
|---------|----------------|---------------|--------|-------|
| **No Service Role Key** | Server-side only | ✅ Not in mobile | ✅ Secure | |
| **No Resend Key** | Server-side only | ✅ Not in mobile | ✅ Secure | |
| **RLS Enforcement** | Supabase policies | Same policies | ✅ Parity | |
| **Anon Key Only** | Client-side | Client-side | ✅ Parity | |
| **API Proxy** | Direct endpoints | Calls Next.js API | ✅ Secure | All privileged ops server-side |
| **Rate Limiting** | Server-side | Server-side | ✅ Parity | Enforced by Next.js API |

## Legend
- ✅ **Parity**: Fully matches pre-beta behavior
- ✅ **MVP**: Basic implementation complete
- ⚠️ **Placeholder**: Exists but needs full implementation
- ❌ **Not implemented**: Feature not yet built
- 🔄 **Phase X**: Planned for specific phase
- N/A **Not applicable**: Feature doesn't apply to mobile

## Summary

### Complete (✅)
- Auth: Sign up, sign in, sign out, forgot password, session persistence
- Theme system with light/dark/AMOLED
- Tab navigation structure
- Own profile view
- Settings screen structure
- Design tokens and components
- Security architecture (no privileged keys in mobile)

### In Progress (⚠️)
- Onboarding (placeholder)
- Messages tab (placeholder)

### Next Priority (Phase 2)
- Profile editing
- Public profiles
- User search
- Follow/unfollow
- Followers/following lists

### Future Phases
- Phase 3: Safety & Verification
- Phase 4: Circles & Events
- Phase 5: Direct Messages
- Phase 6: Full Onboarding
- Phase 7: Settings & Polish
