# Universal Links Setup for Pre iOS App

## Overview

Universal Links allow password reset emails to open the mobile app directly instead of Safari. This requires proper configuration on **both** the backend (AASA file) and mobile app (entitlements).

## ⚠️ Important: Universal Links Won't Work Until...

Universal Links require **all** of the following:

1. ✅ AASA file hosted at `app.presocial.app/.well-known/apple-app-site-association`
2. ✅ AASA file served with correct `content-type: application/json`
3. ✅ Mobile app built with **real bundle ID** (not Expo Go)
4. ✅ Mobile app includes Apple **Associated Domains entitlement**
5. ✅ Mobile app installed via **EAS Build** (not Expo Go)
6. ✅ Device has **cached** the AASA file (takes up to 24 hours)

**Until these are met**: Use custom scheme (`pre://`) as fallback. Password reset will work via custom scheme even without Universal Links.

---

## Backend Setup (app.presocial.app)

### 1. Create AASA File

Create file at `/public/.well-known/apple-app-site-association` (or configure server to serve at this path):

```json
{
  "applinks": {
    "apps": [],
    "details": [
      {
        "appID": "TEAM_ID.com.pre.app",
        "paths": ["/auth/callback", "/auth/reset"]
      }
    ]
  }
}
```

**Replace `TEAM_ID`** with your Apple Developer Team ID (found in Apple Developer Portal).

### 2. Serve with Correct Content-Type

**Critical**: AASA file **must** be served with:
```
Content-Type: application/json
```

**Not**: `text/plain`, `application/octet-stream`, or any other type.

#### Next.js Configuration

Add to `next.config.js`:

```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  async headers() {
    return [
      {
        source: '/.well-known/apple-app-site-association',
        headers: [
          {
            key: 'Content-Type',
            value: 'application/json',
          },
        ],
      },
    ]
  },
}

module.exports = nextConfig
```

#### Vercel Configuration

Add to `vercel.json`:

```json
{
  "headers": [
    {
      "source": "/.well-known/apple-app-site-association",
      "headers": [
        {
          "key": "Content-Type",
          "value": "application/json"
        }
      ]
    }
  ]
}
```

### 3. Verify AASA File

```bash
# Check AASA is accessible
curl -I https://app.presocial.app/.well-known/apple-app-site-association

# Should return:
# HTTP/2 200
# content-type: application/json

# Check content
curl https://app.presocial.app/.well-known/apple-app-site-association

# Should return valid JSON
```

**Apple's Validator**:
```
https://search.developer.apple.com/appsearch-validation-tool/
```

Enter: `https://app.presocial.app`

Should show: ✅ Valid AASA file found

---

## Mobile App Setup (Expo/React Native)

### 1. Bundle Identifier

In `app.json`:
```json
{
  "ios": {
    "bundleIdentifier": "com.pre.app"
  }
}
```

**Must match** the `appID` in AASA file (minus the Team ID prefix).

### 2. Associated Domains

In `app.json`:
```json
{
  "ios": {
    "associatedDomains": ["applinks:app.presocial.app"]
  }
}
```

**Note**: 
- Use `applinks:` prefix (not `https://`)
- Domain only (no path)
- Must match AASA file domain exactly

### 3. Build with EAS

**Universal Links DO NOT work in**:
- ❌ Expo Go app
- ❌ Development builds without proper entitlements
- ❌ Web previews

**Universal Links ONLY work in**:
- ✅ EAS production builds
- ✅ EAS preview builds (with correct entitlements)
- ✅ TestFlight builds
- ✅ App Store builds

#### Build for TestFlight

```bash
# Install EAS CLI
npm install -g eas-cli

# Login to Expo
eas login

# Configure project
eas build:configure

# Build for iOS
eas build --platform ios --profile production

# Submit to TestFlight
eas submit --platform ios
```

### 4. Apple Developer Portal

1. Go to [Apple Developer Portal](https://developer.apple.com/)
2. Select your app identifier (`com.pre.app`)
3. Enable **Associated Domains** capability
4. Save changes
5. Regenerate provisioning profiles if needed

---

## Testing Universal Links

### Before AASA is Live

**Use custom scheme** for testing:

```
pre://auth/callback?type=recovery&...
```

This works immediately without AASA file or entitlements.

### After AASA is Live

1. **Install app** via TestFlight or EAS build
2. **Wait 24 hours** (iOS caches AASA files slowly)
3. **Force refresh** (optional):
   - Delete app
   - Restart device
   - Re-install app

4. **Test password reset**:
   - Request password reset from mobile app
   - Check email on device
   - Tap link in email
   - Should open app (not Safari)

### Debug Universal Links

**Check if iOS fetched AASA**:
- No direct way to see this
- If link opens Safari instead of app, AASA not cached yet

**Verify domain**:
```bash
# On Mac, check AASA validator
xcrun simctl openurl booted "https://app.presocial.app/auth/callback?type=recovery"

# Should open Simulator app (if Universal Links work)
```

**Check entitlements**:
```bash
# In EAS build
eas build:inspect --platform ios --profile production

# Look for:
# <key>com.apple.developer.associated-domains</key>
# <array>
#   <string>applinks:app.presocial.app</string>
# </array>
```

---

## Fallback Strategy

### Custom Scheme Always Works

Even without Universal Links, custom scheme (`pre://`) works immediately:

```
pre://auth/callback?type=recovery&token_hash=...
```

### Supabase Configuration

Add **both** to redirect URLs:

```
# Universal Link (preferred, requires AASA)
https://app.presocial.app/auth/callback

# Custom Scheme (fallback, always works)
pre://auth/callback
```

### Email Template Strategy

Pre-beta's `/api/auth/password/forgot` should generate recovery links that try **both**:

1. First attempt: Universal Link (`https://app.presocial.app/auth/callback?type=recovery&...`)
2. Fallback: Custom scheme (`pre://auth/callback?type=recovery&...`)

iOS will use Universal Link if available, otherwise custom scheme.

---

## Production Checklist

Before going live with Universal Links:

### Backend (app.presocial.app)
- [ ] AASA file at `/.well-known/apple-app-site-association`
- [ ] AASA file has correct Team ID in `appID`
- [ ] AASA file served with `Content-Type: application/json`
- [ ] AASA validates at Apple's validation tool
- [ ] Next.js headers configured (if using Next.js)

### Mobile App
- [ ] Bundle ID matches AASA file (`com.pre.app`)
- [ ] Associated Domains includes `applinks:app.presocial.app`
- [ ] Built with EAS (not Expo Go)
- [ ] Apple Developer Portal has Associated Domains enabled
- [ ] Submitted to TestFlight or App Store

### Supabase
- [ ] Redirect URLs include both Universal Link and custom scheme
- [ ] Site URL is `https://app.presocial.app`
- [ ] Email templates use correct confirmation URL

### Testing
- [ ] Password reset email received on device
- [ ] Link opens app (not Safari)
- [ ] App routes to `/auth/reset`
- [ ] Password can be updated successfully
- [ ] Tested on physical device (not simulator)

---

## Troubleshooting

### Link Opens Safari Instead of App

**Problem**: Universal Link treated as web link

**Causes**:
1. AASA file not cached by iOS (wait 24 hours or force refresh)
2. AASA file wrong `Content-Type` (must be `application/json`)
3. Bundle ID mismatch (app vs AASA file)
4. App not installed via EAS build (Expo Go doesn't work)
5. Associated Domains not enabled in Apple Developer Portal

**Fix**:
1. Verify AASA at Apple's validation tool
2. Check `Content-Type` header with `curl -I`
3. Delete app, restart device, re-install
4. Use custom scheme as temporary workaround

### AASA Validation Fails

**Problem**: Apple validator shows "No apps associated"

**Causes**:
1. AASA file not at `/.well-known/apple-app-site-association`
2. Wrong `Content-Type` (not `application/json`)
3. Invalid JSON syntax
4. Wrong Team ID in `appID`

**Fix**:
1. Check file is accessible: `curl https://app.presocial.app/.well-known/apple-app-site-association`
2. Check `Content-Type`: `curl -I https://app.presocial.app/.well-known/apple-app-site-association`
3. Validate JSON: `jq . < apple-app-site-association`
4. Verify Team ID in Apple Developer Portal

### Custom Scheme Works, Universal Links Don't

**Problem**: `pre://` opens app, `https://` opens Safari

**This is expected** if:
- AASA not yet cached (wait up to 24 hours)
- First install (iOS fetches AASA in background)

**This is normal** in early testing. Custom scheme is the fallback.

### Links Work in Safari, Not in Email

**Problem**: Tapping link in Mail app opens Safari

**Cause**: iOS Mail app sometimes doesn't respect Universal Links

**Fix**:
- Long-press link in Mail
- Choose "Open in Pre"
- Or copy link and paste in Safari (then it should work)

---

## Summary

**Universal Links are preferred** but optional for MVP:
- Better UX (no browser intermediary)
- More secure (app-to-app, not web redirect)
- Professional appearance

**Custom Scheme is sufficient** for launch:
- Works immediately without AASA setup
- No backend configuration needed
- Reliable fallback

**Recommendation**: 
1. Launch with custom scheme (`pre://`) for MVP
2. Add Universal Links later for polish
3. Keep both in Supabase redirect URLs (belt and suspenders)

---

For questions, see:
- `SUPABASE_SETUP.md` - Supabase configuration
- `CLOUD_DEPLOYMENT.md` - Cloud deployment guide
- `README.md` - Full project documentation
