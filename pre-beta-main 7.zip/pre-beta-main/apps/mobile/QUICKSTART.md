# Quick Start Guide - Pre Mobile App

## 🚀 Get Running in 5 Minutes

### Prerequisites
- macOS with Xcode (for iOS Simulator)
- Node.js 20+
- Pre-beta web app running (Next.js on `localhost:3000` or deployed)

### Step 1: Install Dependencies
```bash
cd apps/mobile
npm install
```

### Step 2: Configure Environment
```bash
# Copy example env file
cp .env.example .env

# Edit .env with your values
```

**Required Values**:
```env
EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=eyJhbGc...
EXPO_PUBLIC_API_URL=https://app.presocial.app
```

**Cloud-First**: The app connects to `app.presocial.app` by default. No LAN setup needed.

**For Local Backend Testing Only**:
If you're developing the backend locally, override the API URL:
```env
EXPO_PUBLIC_API_URL=http://192.168.1.100:3000  # Your computer's LAN IP
```

**Find your LAN IP** (only if testing locally):
- macOS: `ifconfig | grep "inet " | grep -v 127.0.0.1`
- Windows: `ipconfig | findstr IPv4`
- Look for something like `192.168.1.100` or `10.0.0.50`

### Step 3: Start Expo
```bash
npm start
```

### Step 4: Open iOS Simulator
Press `i` in the terminal, or run:
```bash
npm run ios
```

## ✅ Verify It Works

### Test Sign Up Flow
1. Open app \u2192 "Sign Up" button
2. Enter email, password, invite code (get from pre-beta web)
3. Check email for 8-digit OTP
4. Enter OTP in app
5. Should redirect to onboarding screen

### Test Sign In Flow
1. Open app \u2192 "Sign In" button
2. Enter email, password
3. Should redirect to home tab

### Test Forgot Password
1. Sign In screen \u2192 "Forgot password?"
2. Enter email
3. Check email for reset link
4. Click link (should open app)
5. Enter new password
6. Should redirect to home

## 🔧 Troubleshooting

### "Network request failed"
**Problem**: Mobile can't reach Next.js API  
**Fix**: 
1. Check your internet connection
2. Verify `EXPO_PUBLIC_API_URL=https://app.presocial.app` in `.env`
3. Tap "API Health Check" on sign-in screen to test connectivity
4. If testing locally, use LAN IP (not `localhost`)

### "Cannot reach API server"
**Problem**: Detailed error shows API URL is unreachable  
**Fix**:
1. Verify the backend is deployed and running at `app.presocial.app`
2. Check if you can access `https://app.presocial.app` in a browser
3. For local testing: Ensure backend is running on the IP specified in `EXPO_PUBLIC_API_URL`
4. Check firewall settings (for local testing only)

### "Invalid Supabase URL"
**Problem**: Supabase credentials wrong  
**Fix**: Copy exact values from pre-beta `.env.local`

### "Invite code is invalid"
**Problem**: No valid invite code  
**Fix**: Create invite in pre-beta web at `/settings/invites`

### "Email not received"
**Problem**: OTP or reset email not arriving  
**Fix**: 
1. Check spam folder
2. Verify Supabase email provider is enabled
3. Check Supabase logs for send errors

### Deep links not working
**Problem**: Password reset link opens Safari instead of app  
**Fix**: 
1. Test in iOS Simulator first (not Expo Go)
2. Verify `scheme: "pre"` in `app.json`
3. Add `pre://auth/callback` to Supabase redirect URLs

## 📱 Running on Physical Device

### Option 1: Expo Go App (Development)
1. Install Expo Go from App Store
2. Run `npm start` on computer
3. Scan QR code with Camera app
4. App opens in Expo Go

**Limitations**: Deep links won't work in Expo Go. Use for testing UI only.

### Option 2: Development Build (Full Features)
```bash
# Install EAS CLI
npm install -g eas-cli

# Login to Expo
eas login

# Create development build
eas build --profile development --platform ios

# Install on device
eas build:run -p ios
```

**Benefits**: Deep links work, native modules work, full feature set.

## 🎯 Next Steps

After verifying auth works:

1. **Complete Onboarding Flow** (Phase 6)
   - Implement 9-step onboarding matching pre-beta
   - Call `/api/onboarding/complete` when done

2. **Profile Editing** (Phase 2)
   - Create `/profile/edit` screen
   - Implement avatar upload to Supabase Storage
   - Call `/api/profile/update`

3. **User Search & Follow** (Phase 2)
   - Create search screen
   - Call `/api/users/search`
   - Implement follow/unfollow buttons
   - Call `/api/follow` and `/api/unfollow`

See `PARITY_CHECKLIST.md` for complete feature roadmap.

## 📚 Documentation

- `README.md` - Full project documentation
- `PARITY_CHECKLIST.md` - Feature parity with pre-beta
- `SUPABASE_SETUP.md` - Complete Supabase configuration
- `SECURITY_AUDIT.md` - Security review and best practices

## 🆘 Getting Help

1. Check troubleshooting section above
2. Review Supabase logs: Dashboard → Logs → Auth
3. Check Next.js API logs: Terminal running `npm run dev`
4. Review Expo logs: Press `j` in Expo terminal to open DevTools
5. Check mobile app logs: Expo DevTools → Logs tab

## 🎉 You're Ready!

The mobile app is now running with full auth parity to pre-beta. Start building out the remaining features following the roadmap.

**Happy coding!** 🚀
