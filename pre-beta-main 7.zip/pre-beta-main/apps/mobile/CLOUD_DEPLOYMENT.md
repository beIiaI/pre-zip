# Cloud-First Deployment Guide

## Overview

The Pre mobile app is configured for **cloud-first operation**, meaning it works with the deployed backend at `app.presocial.app` by default. No local network setup is required unless you're actively developing the backend.

## Architecture

```
┌─────────────────┐
│  iOS Mobile App │
│   (Expo/RN)     │
└────────┬────────┘
         │ HTTPS
         ├─────────────────────────────────┐
         │                                 │
         ▼                                 ▼
┌────────────────────┐         ┌──────────────────┐
│ app.presocial.app  │         │ Supabase Project │
│  (Next.js Backend) │◄────────┤  (Database/Auth) │
└────────────────────┘         └──────────────────┘
```

**Key Domains**:
- `app.presocial.app` - Deployed Next.js backend (pre-beta)
- `presocial.app` - Marketing site (GitHub Pages, not used by app)

## Default Configuration

### Mobile App (`.env`)
```env
# Production configuration (default)
EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=<your-anon-key>
EXPO_PUBLIC_API_URL=https://app.presocial.app
EXPO_PUBLIC_APP_ENV=production
EXPO_PUBLIC_APP_SCHEME=pre
EXPO_PUBLIC_UNIVERSAL_LINK_DOMAIN=app.presocial.app
```

### What Happens
1. Mobile app loads with `EXPO_PUBLIC_API_URL=https://app.presocial.app`
2. All API calls (invite validation, password reset, etc.) go to production backend
3. Supabase auth and database queries use production project
4. Deep links use `app.presocial.app` for Universal Links

**Result**: App works immediately with no network configuration.

## Network Requirements

### Minimum Requirements
- ✅ Internet connection (WiFi or cellular)
- ✅ Access to `app.presocial.app` (HTTPS)
- ✅ Access to Supabase project (HTTPS)

### No Requirements For
- ❌ LAN setup
- ❌ Local backend server
- ❌ Port forwarding
- ❌ Firewall configuration
- ❌ VPN or proxy (unless restricted network)

## API Health Check

The mobile app includes a built-in health check:

1. Open sign-in screen
2. Tap "API Health Check" button (below logo)
3. See result:
   - ✅ "API is reachable" - All good
   - ❌ "Cannot reach..." - Check internet or backend

**URL Displayed**: Shows current `EXPO_PUBLIC_API_URL` for debugging

## Error Handling

### Clear On-Screen Errors

All API failures show detailed, actionable errors:

```
Cannot reach API server at https://app.presocial.app.

Check:
1. Internet connection
2. API URL is correct
3. Server is running
```

### Network Error Types

| Error Code | Meaning | Solution |
|------------|---------|----------|
| `NETWORK_ERROR` | DNS failure, no internet | Check connection, verify URL |
| `TIMEOUT` | Request took >30s | Check backend is responding |
| `SERVER_ERROR` | Backend returned 500+ | Backend issue, contact support |
| `INVALID_RESPONSE` | Backend returned 400-499 | Check request format |

## Local Development Override

### When to Use Local Backend

Only override API URL if you're:
- Developing new backend API endpoints
- Testing backend changes before deployment
- Debugging backend-specific issues

### How to Override

1. Find your computer's LAN IP:
   ```bash
   # macOS
   ipconfig getifaddr en0
   
   # Linux
   hostname -I | awk '{print $1}'
   
   # Windows
   ipconfig | findstr IPv4
   ```

2. Update `.env`:
   ```env
   # Override for local testing
   EXPO_PUBLIC_API_URL=http://192.168.1.100:3000
   EXPO_PUBLIC_APP_ENV=development
   ```

3. Start local backend:
   ```bash
   cd /path/to/pre-beta
   npm run dev
   ```

4. Restart Expo:
   ```bash
   npm start -- --clear
   ```

### Verify Local Connection

1. Tap "API Health Check" on sign-in screen
2. Should show: "API is reachable" with your local IP
3. If not, check:
   - Backend is running (`http://YOUR_IP:3000` accessible in browser)
   - Mobile and computer on same WiFi network
   - Firewall allows port 3000

### Return to Cloud

1. Update `.env`:
   ```env
   EXPO_PUBLIC_API_URL=https://app.presocial.app
   EXPO_PUBLIC_APP_ENV=production
   ```

2. Restart Expo:
   ```bash
   npm start -- --clear
   ```

## HTTPS Enforcement

### Production Security

The mobile app enforces HTTPS in production:

```typescript
// lib/api.ts
if (process.env.EXPO_PUBLIC_APP_ENV === 'production' && 
    !API_BASE_URL.startsWith('https://')) {
  throw new Error('API_BASE_URL must use HTTPS in production')
}
```

**Result**: App crashes on startup if `EXPO_PUBLIC_API_URL` is HTTP in production mode.

### Why HTTPS?

- ✅ Encrypts all data in transit
- ✅ Prevents man-in-the-middle attacks
- ✅ Required for App Store submission
- ✅ Trusted by iOS (no certificate warnings)

### Development Exception

HTTP allowed only when `EXPO_PUBLIC_APP_ENV=development`:
```env
EXPO_PUBLIC_APP_ENV=development
EXPO_PUBLIC_API_URL=http://192.168.1.100:3000  # OK for dev
```

## Deep Link Configuration

### Production Deep Links

Universal Links use `app.presocial.app`:

```json
// app.json
{
  "ios": {
    "associatedDomains": ["applinks:app.presocial.app"]
  }
}
```

**Password Reset Flow**:
1. User requests password reset
2. Email contains: `https://app.presocial.app/auth/callback?type=recovery&...`
3. iOS detects universal link, opens mobile app
4. App routes to `/auth/reset`
5. User sets new password

### Custom Scheme Fallback

If universal link fails, custom scheme works:
```
pre://auth/callback?type=recovery&...
```

Both redirect URLs must be in Supabase config.

**Note**: Universal Links require AASA file hosted at `app.presocial.app/.well-known/apple-app-site-association` with correct content-type and EAS build with proper entitlements. See `UNIVERSAL_LINKS.md` for complete setup guide. Custom scheme (`pre://`) works immediately without AASA setup and is sufficient for MVP.

## Supabase Configuration

### Required Settings

**Redirect URLs** (in Supabase Dashboard → Auth → URL Configuration):
```
https://app.presocial.app/auth/callback
https://app.presocial.app/auth/reset
pre://auth/callback
pre://auth/reset
```

**Site URL**:
```
https://app.presocial.app
```

**Email Templates**:
- Do not modify default Supabase templates
- Confirmation URL will use Site URL + `/auth/callback`
- Works automatically with universal links

### Verification

1. Send password reset email from mobile app
2. Check email - link should be `https://app.presocial.app/auth/callback?type=recovery&...`
3. Tap link on iPhone
4. Should open mobile app (not Safari)
5. Should route to password reset screen

## Troubleshooting

### "Cannot reach API server"

**Symptoms**: All API calls fail with network error

**Debug Steps**:
1. Tap "API Health Check" on sign-in screen
2. Note the URL shown (should be `https://app.presocial.app`)
3. Open Safari on iPhone, visit `https://app.presocial.app`
4. Should load pre-beta web app

**If pre-beta doesn't load**:
- Backend is down (contact devops)
- DNS issue (try again later)
- Network blocks HTTPS (try different WiFi)

**If pre-beta loads but mobile fails**:
- Check `.env` has correct URL
- Restart Expo with `npm start -- --clear`
- Re-install app on device

### "Request timed out"

**Symptoms**: API calls take >30s and fail

**Fix**:
- Backend is slow or overloaded
- Check backend logs for errors
- Increase timeout (advanced):
  ```typescript
  await apiRequest('/api/endpoint', { timeout: 60000 }) // 60s
  ```

### Deep links open Safari instead of app

**Symptoms**: Password reset link opens web app, not mobile

**Note**: Universal Links won't work until AASA file is hosted at `app.presocial.app/.well-known/apple-app-site-association` with correct content-type AND app is built with EAS (not Expo Go). See `UNIVERSAL_LINKS.md` for complete setup.

**For MVP**: Use custom scheme which works immediately:

**Fix**:
1. Verify custom scheme `pre://` in Supabase redirect URLs
2. Test with: `pre://auth/callback?type=recovery`
3. This works without AASA file or entitlements
4. For Universal Links: Follow complete setup in `UNIVERSAL_LINKS.md`

### "Invalid API URL" error on startup

**Symptoms**: App crashes immediately on launch

**Fix**:
```env
# Check .env has valid HTTPS URL
EXPO_PUBLIC_API_URL=https://app.presocial.app  # ✅ Correct
# EXPO_PUBLIC_API_URL=http://app.presocial.app  # ❌ Wrong (HTTP)
# EXPO_PUBLIC_API_URL=app.presocial.app         # ❌ Wrong (no protocol)
```

## Production Checklist

Before deploying mobile app to TestFlight/App Store:

- [ ] `.env` has `EXPO_PUBLIC_API_URL=https://app.presocial.app`
- [ ] `.env` has `EXPO_PUBLIC_APP_ENV=production`
- [ ] Backend is deployed and reachable at `app.presocial.app`
- [ ] Supabase redirect URLs include `https://app.presocial.app/*`
- [ ] AASA file configured at `app.presocial.app/.well-known/apple-app-site-association`
- [ ] Universal links tested on physical device
- [ ] API health check returns "reachable"
- [ ] Password reset flow tested end-to-end
- [ ] Sign up with OTP tested end-to-end

## Monitoring

### Mobile-Side Monitoring

Built into app:
- API health check (manual)
- Detailed error messages with URL
- Network error codes (NETWORK_ERROR, TIMEOUT, etc.)

### Backend-Side Monitoring

Check these in `app.presocial.app`:
- Next.js API logs for failed requests
- Supabase logs for auth failures
- Uptime monitoring for availability

### User Reports

If users report "cannot reach server":
1. Verify `app.presocial.app` is up
2. Check Supabase project status
3. Review backend logs for errors
4. Test password reset flow yourself

## Summary

**Default**: Mobile app works with cloud backend (`app.presocial.app`) immediately.

**No LAN required**: Users and developers can use the app without local network setup.

**Local override available**: Developers can test against local backend by setting `EXPO_PUBLIC_API_URL` to LAN IP.

**HTTPS enforced**: Production mode requires HTTPS for security.

**Clear errors**: All failures show actionable on-screen messages with API URL.

**Health check**: Built-in tool to verify API connectivity.

---

**For questions**: See `README.md`, `SUPABASE_SETUP.md`, or contact support.
