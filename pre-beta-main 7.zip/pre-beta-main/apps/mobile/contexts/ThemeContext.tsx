import React, { createContext, useContext, useEffect, useState } from 'react'
import { Appearance, ColorSchemeName } from 'react-native'
import AsyncStorage from '@react-native-async-storage/async-storage'
import { Colors } from '@/constants/theme'

type ThemeMode = 'light' | 'dark' | 'amoled' | 'system'

interface ThemeContextType {
  theme: ThemeMode
  colors: typeof Colors.light
  setTheme: (theme: ThemeMode) => Promise<void>
  isDark: boolean
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

const THEME_STORAGE_KEY = '@pre:theme'

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setThemeState] = useState<ThemeMode>('system')
  const [systemColorScheme, setSystemColorScheme] = useState<ColorSchemeName>(
    Appearance.getColorScheme()
  )

  useEffect(() => {
    // Load saved theme
    AsyncStorage.getItem(THEME_STORAGE_KEY).then((saved) => {
      if (saved && ['light', 'dark', 'amoled', 'system'].includes(saved)) {
        setThemeState(saved as ThemeMode)
      }
    })

    // Listen to system theme changes
    const subscription = Appearance.addChangeListener(({ colorScheme }) => {
      setSystemColorScheme(colorScheme)
    })

    return () => subscription.remove()
  }, [])

  const setTheme = async (newTheme: ThemeMode) => {
    setThemeState(newTheme)
    await AsyncStorage.setItem(THEME_STORAGE_KEY, newTheme)
  }

  // Resolve effective theme
  const effectiveTheme =
    theme === 'system' ? systemColorScheme || 'light' : theme

  // Select color palette
  const colors =
    effectiveTheme === 'amoled'
      ? Colors.amoled
      : effectiveTheme === 'dark'
        ? Colors.dark
        : Colors.light

  const isDark = effectiveTheme === 'dark' || effectiveTheme === 'amoled'

  return (
    <ThemeContext.Provider value={{ theme, colors, setTheme, isDark }}>
      {children}
    </ThemeContext.Provider>
  )
}

export function useTheme() {
  const context = useContext(ThemeContext)
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider')
  }
  return context
}
