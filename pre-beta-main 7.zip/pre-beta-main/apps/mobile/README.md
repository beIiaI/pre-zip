# pre - iOS Mobile App (Expo)

This is the native iOS app for **pre**, built with Expo and React Native. It connects to the same Supabase backend as the pre-beta web app.

## Tech Stack

- **Framework**: Expo (latest stable)
- **Navigation**: expo-router (file-based routing)
- **Language**: TypeScript
- **Backend**: Supabase (Auth + Postgres + RLS)
- **State Management**: @tanstack/react-query
- **Graphics**: react-native-svg
- **Storage**: @react-native-async-storage/async-storage

## Architecture

- **Thin Client**: Mobile app only uses Supabase anon key. All privileged operations (emails, admin actions) go through Next.js API routes.
- **Shared Database**: Uses the same Supabase project and RLS policies as pre-beta web.
- **API Integration**: Calls existing Next.js API routes at `/api/*` for server-side operations.

## Prerequisites

- Node.js 20+
- npm or yarn
- Expo CLI (`npm install -g expo-cli`)
- iOS Simulator (Xcode on macOS) or Expo Go app on physical device

## Setup

### 1. Install Dependencies

```bash
cd apps/mobile
npm install
```

### 2. Configure Environment Variables

Create `.env` file from the example:

```bash
cp .env.example .env
```

Update with your values:

```env
EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=<your-anon-key>
EXPO_PUBLIC_API_URL=https://app.presocial.app
EXPO_PUBLIC_APP_ENV=production
```

**Important**: 
- Use the SAME Supabase project as pre-beta web
- `EXPO_PUBLIC_API_URL` defaults to `https://app.presocial.app` (production)
- For local testing, override with your LAN IP: `http://192.168.1.100:3000`
- Never include service role keys in mobile app

**Cloud-First Operation**:
The mobile app is configured to work with the deployed backend at `app.presocial.app` by default. No LAN setup required unless you're developing the backend locally.

### 3. Configure Supabase

See `SUPABASE_SETUP.md` for complete configuration, including:
- Redirect URLs (web + mobile deep links)
- Email templates (8-digit OTP)
- Rate limiting
- Deep link setup

**Required Redirect URLs**:
```
# Development
http://localhost:3000/auth/callback
http://localhost:3000/auth/reset
pre://auth/callback
pre://auth/reset

# Production
https://app.presocial.app/auth/callback
https://app.presocial.app/auth/reset
pre://auth/callback
pre://auth/reset
```

**Universal Link Domain**: `app.presocial.app` (deployed Next.js backend)

**Note**: `presocial.app` (without "app." prefix) is the marketing site only (GitHub Pages). It is not used for app functionality.

### 4. Run Development Server

```bash
npm start
```

This will open Expo DevTools. You can then:
- Press `i` to open iOS Simulator
- Scan QR code with Expo Go app on physical iPhone
- Press `w` to open in web browser (for testing)

### 5. Run on iOS Simulator

```bash
npm run ios
```

Requires macOS with Xcode installed.

## Project Structure

```
/mobile/
├── app/                      # expo-router screens
│   ├── _layout.tsx           # Root layout
│   ├── index.tsx             # Auth gate / splash
│   ├── auth/                 # Auth flows
│   │   ├── splash.tsx        # Unauthenticated splash
│   │   ├── signin.tsx        # Sign in
│   │   ├── signup.tsx        # Sign up with OTP
│   │   └── onboarding.tsx    # Onboarding flow
│   ├── (tabs)/               # Main tab navigation
│   │   ├── home.tsx          # Home feed
│   │   ├── messages.tsx      # DMs
│   │   ├── profile.tsx       # User profile
│   │   └── settings.tsx      # Settings
│   ├── circles/              # Circles feature
│   ├── events/               # Events feature
│   ├── messages/             # DM threads
│   ├── profile/              # Public profiles
│   └── settings/             # Settings screens
├── components/
│   ├── ui/                   # Reusable UI components
│   │   ├── Button.tsx
│   │   ├── Input.tsx
│   │   └── PreWordmark.tsx   # Brand SVG
│   └── screens/              # Complex screen components
├── contexts/                 # React contexts
│   ├── AuthContext.tsx       # Auth state management
│   └── ThemeContext.tsx      # Theme state management
├── lib/
│   ├── supabase.ts           # Supabase client (anon key only)
│   └── api.ts                # API helper for Next.js routes
├── constants/
│   └── theme.ts              # Design tokens (ported from pre-beta)
├── types/
│   └── database.ts           # Supabase types (shared with pre-beta)
├── utils/
│   └── validation.ts         # Validation helpers
└── app.json                  # Expo configuration
```

## Features Status

### ✅ Implemented (Auth Complete - Parity with Pre-Beta)
- [x] Auth: Sign up with 8-digit OTP (Supabase native)
- [x] Auth: Sign in with email/password
- [x] Auth: Sign out with session clear
- [x] Auth: Invite code validation (via Next.js API)
- [x] Auth: Password reset request (via Next.js API)
- [x] Auth: Password reset deep link handling
- [x] Auth: Session persistence via AsyncStorage
- [x] Theme: Light/Dark/AMOLED modes with system detection
- [x] Navigation: Tab structure (Home, Messages, Profile, Settings)
- [x] Profile: View own profile
- [x] Brand: PreWordmark SVG component (react-native-svg)
- [x] UI: Button, Input components
- [x] Security: No service role keys, all privileged ops server-side

### 🚧 In Progress
- [ ] Onboarding: 9-step flow (name, username, interests, DOB, location, theme, photo, bio)
- [ ] Profile: Edit profile

### 📋 Planned
- [ ] Circles: Browse, create, join/leave
- [ ] Events: Browse, create, RSVP
- [ ] Messages: Thread list, conversation view, send message
- [ ] Settings: Privacy, Password change, Invites management, Help
- [ ] Profile: Public profiles, followers/following, search
- [ ] Notifications: In-app notifications

## Key Differences from Web App

1. **No Service Role Key**: Mobile app uses anon key only. All privileged operations happen server-side.
2. **API Proxy**: Email sending (OTP, verification, password reset) goes through Next.js API routes, not directly from mobile.
3. **Native UI**: React Native components instead of Tailwind CSS. Design tokens match pre-beta aesthetic.
4. **Simplified Navigation**: Native tab bar instead of custom web navigation.
5. **Deep Linking**: Password reset emails deep link into app via `pre://` scheme.
6. **LAN Development**: Use computer's LAN IP (not localhost) for mobile to reach local Next.js server.

## Auth Flow Parity with Pre-Beta

### Sign Up (100% Parity)
1. User enters email, password, invite code
2. Mobile validates invite via `/api/invites/validate`
3. Mobile calls Supabase `signUp()` which triggers 8-digit OTP email
4. User enters OTP in mobile app
5. Mobile calls Supabase `verifyOtp()` with `type: 'signup'`
6. Mobile claims invite via `/api/invites/claim`
7. Redirect to onboarding

**Matches pre-beta**: Same OTP length (8 digits), same API calls, same invite flow

### Sign In (100% Parity)
1. User enters email, password
2. Mobile calls Supabase `signInWithPassword()`
3. Session stored in AsyncStorage
4. Redirect to home or onboarding based on `onboarding_completed`

**Matches pre-beta**: Same auth method, same session handling

### Forgot Password (100% Parity)
1. User enters email, clicks "Forgot password?"
2. Mobile calls `/api/auth/password/forgot` (Next.js)
3. Server generates recovery link with multiple redirect URL attempts
4. Email contains link to `pre://auth/callback?type=recovery&...` or `https://...`
5. Link opens mobile app at `/auth/callback`
6. Callback detects `type=recovery`, redirects to `/auth/reset`
7. User enters new password
8. Mobile calls Supabase `updateUser({ password })`
9. Redirect to home

**Matches pre-beta**: Same API endpoint, same recovery flow, deep link support added

## Security

- ✅ No service role keys in mobile app
- ✅ All email operations server-side
- ✅ RLS policies enforced by Supabase
- ✅ Session management via Supabase Auth
- ✅ API calls to Next.js routes for privileged operations

## Database

Mobile app uses the **same Supabase database** as pre-beta web. All migrations are in `/supabase/migrations/` in the root repo.

Required migrations (run in order):
- 001 through 032 (see pre-beta README for full list)

## Development Workflow

1. **Local Development**: Point `EXPO_PUBLIC_API_URL` to `http://localhost:3000` and run pre-beta web app alongside mobile
2. **Testing**: Use Expo Go app on physical device or iOS Simulator
3. **API Changes**: Update Next.js API routes in pre-beta web app; mobile app automatically uses new endpoints

## Troubleshooting

### Supabase connection fails
- Verify `EXPO_PUBLIC_SUPABASE_URL` and `EXPO_PUBLIC_SUPABASE_ANON_KEY`
- Check that Supabase project is same as pre-beta web
- Ensure RLS policies are applied (migrations 001-032)

### API calls fail
- Verify `EXPO_PUBLIC_API_URL` points to running Next.js server
- Check CORS settings in Next.js API routes
- For local dev: Use your computer's local IP, not `localhost`

### Auth session not persisting
- Check that `@react-native-async-storage/async-storage` is installed
- Clear app data and reinstall

### Brand wordmark not rendering
- Verify `react-native-svg` is installed
- Check that PreWordmark component is imported correctly

## Testing

Manual QA checklist:
1. Sign up with valid invite code → receives OTP → verifies → onboarding
2. Sign in with email/password → redirects to home
3. Forgot password → receives reset email
4. Theme switching (light/dark/AMOLED/system)
5. Tab navigation works
6. Sign out clears session

## Building for Production

### iOS App Store

```bash
# Build for iOS
eas build --platform ios

# Submit to App Store
eas submit --platform ios
```

Requires:
- Apple Developer Account
- Expo Application Services (EAS) account
- App Store Connect setup

## License

Private repository. All rights reserved.
