/**
 * Design tokens ported from pre-beta web app
 * Matches the ceramic/obsidian monochrome aesthetic
 */

export const Colors = {
  light: {
    // Surface tokens
    surfacePrimary: '#FFFFFF',
    surfaceSecondary: '#F8F8F8',
    surfaceElevated: '#FAFAFA',

    // Content tokens
    contentPrimary: '#0A0A0A',
    contentSecondary: '#666666',
    contentTertiary: '#999999',
    contentInverse: '#FFFFFF',

    // Border tokens
    borderPrimary: 'rgba(10, 10, 10, 0.1)',
    borderSecondary: 'rgba(10, 10, 10, 0.06)',

    // Accent tokens
    accent: '#0A0A0A',
    accentHover: '#1A1A1A',

    // Semantic colors
    success: '#0F9D58',
    error: '#DB4437',
    warning: '#F4B400',

    // Dividers
    dividerStrong: 'rgba(10, 10, 10, 0.12)',
    dividerSoft: 'rgba(10, 10, 10, 0.06)',
  },
  dark: {
    // Surface tokens
    surfacePrimary: '#0A0A0A',
    surfaceSecondary: '#1A1A1A',
    surfaceElevated: '#242424',

    // Content tokens
    contentPrimary: '#F5F5F5',
    contentSecondary: '#A0A0A0',
    contentTertiary: '#707070',
    contentInverse: '#0A0A0A',

    // Border tokens
    borderPrimary: 'rgba(245, 245, 245, 0.1)',
    borderSecondary: 'rgba(245, 245, 245, 0.06)',

    // Accent tokens
    accent: '#F5F5F5',
    accentHover: '#FFFFFF',

    // Semantic colors
    success: '#34C759',
    error: '#FF453A',
    warning: '#FFD60A',

    // Dividers
    dividerStrong: 'rgba(245, 245, 245, 0.12)',
    dividerSoft: 'rgba(245, 245, 245, 0.06)',
  },
  amoled: {
    // Pure black AMOLED mode
    surfacePrimary: '#000000',
    surfaceSecondary: '#0F0F0F',
    surfaceElevated: '#1A1A1A',

    // Content tokens
    contentPrimary: '#F5F5F5',
    contentSecondary: '#A0A0A0',
    contentTertiary: '#707070',
    contentInverse: '#000000',

    // Border tokens
    borderPrimary: 'rgba(245, 245, 245, 0.1)',
    borderSecondary: 'rgba(245, 245, 245, 0.06)',

    // Accent tokens
    accent: '#F5F5F5',
    accentHover: '#FFFFFF',

    // Semantic colors
    success: '#34C759',
    error: '#FF453A',
    warning: '#FFD60A',

    // Dividers
    dividerStrong: 'rgba(245, 245, 245, 0.12)',
    dividerSoft: 'rgba(245, 245, 245, 0.06)',
  },
}

export const Typography = {
  // Font sizes (matching pre-beta scale)
  display: 32,
  title: 22,
  headline: 18,
  body: 16,
  callout: 14,
  caption: 12,
  labelCaps: 10,

  // Line heights
  lineHeightTight: 1.35,
  lineHeightNormal: 1.45,
  lineHeightRelaxed: 1.5,

  // Font weights
  regular: '400' as const,
  medium: '600' as const,
  semibold: '600' as const,
}

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  base: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
}

export const BorderRadius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  full: 9999,
}
