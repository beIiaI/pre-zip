import React, { useState, useEffect, useCallback } from 'react'
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Switch,
  Alert,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useLocalSearchParams, useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import DateTimePicker from '@react-native-community/datetimepicker'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

const CATEGORIES = [
  'Social', 'Academic', 'Sports', 'Arts', 'Technology',
  'Gaming', 'Music', 'Food', 'Wellness', 'Career', 'Other',
]

function fmtDate(d: Date) {
  return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })
}
function fmtTime(d: Date) {
  return d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
}

export default function EditEventScreen() {
  const { id: eventId } = useLocalSearchParams<{ id: string }>()
  const router = useRouter()
  const { colors } = useTheme()
  const { user } = useAuth()

  const [loading, setLoading] = useState(true)
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [location, setLocation] = useState('')
  const [category, setCategory] = useState<string | null>(null)
  const [isPublic, setIsPublic] = useState(true)
  const [startDate, setStartDate] = useState(new Date())
  const [endDate, setEndDate] = useState(new Date())
  const [saving, setSaving] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [picker, setPicker] = useState<null | 'startDate' | 'startTime' | 'endDate' | 'endTime'>(null)

  const isIOS = Platform.OS === 'ios'
  const isAndroid = Platform.OS === 'android'

  const load = useCallback(async () => {
    if (!eventId) return
    const { data } = await supabase
      .from('events')
      .select('title, description, starts_at, ends_at, location, location_text, category, is_public, creator_id')
      .eq('id', eventId)
      .single()

    if (!data) { router.back(); return }
    if (data.creator_id !== user?.id) { router.back(); return }

    setTitle(data.title)
    setDescription(data.description ?? '')
    setLocation(data.location_text || data.location)
    setCategory(data.category)
    setIsPublic(data.is_public)
    setStartDate(new Date(data.starts_at))
    setEndDate(data.ends_at ? new Date(data.ends_at) : new Date(new Date(data.starts_at).getTime() + 2 * 3600_000))
    setLoading(false)
  }, [eventId, user])

  useEffect(() => { load() }, [load])

  const canSave = title.trim().length >= 2 && location.trim().length >= 2 && !saving && !deleting

  const handleStartChange = (_: any, selected?: Date) => {
    if (isAndroid) setPicker(null)
    if (!selected) return
    setStartDate(selected)
    if (endDate <= selected) setEndDate(new Date(selected.getTime() + 2 * 3600_000))
  }

  const handleEndChange = (_: any, selected?: Date) => {
    if (isAndroid) setPicker(null)
    if (selected) setEndDate(selected)
  }

  const handleSave = async () => {
    if (!canSave || !eventId) return
    if (endDate <= startDate) { Alert.alert('Invalid time', 'End time must be after start time.'); return }
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)
    setSaving(true)

    const { error } = await supabase
      .from('events')
      .update({
        title: title.trim(),
        description: description.trim() || null,
        location: location.trim(),
        location_text: location.trim(),
        starts_at: startDate.toISOString(),
        ends_at: endDate.toISOString(),
        category,
        is_public: isPublic,
      })
      .eq('id', eventId)

    setSaving(false)
    if (error) { Alert.alert('Error', 'Could not save changes. Please try again.'); return }
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success)
    router.back()
  }

  const handleDelete = () => {
    Alert.alert(
      'Delete event?',
      'This will permanently delete the event and all RSVPs. This cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy)
            setDeleting(true)
            await supabase.from('events').delete().eq('id', eventId)
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success)
            router.dismissAll()
          },
        },
      ],
    )
  }

  // ─── Inline date/time chips ───────────────────────────────────────────────

  const DateRow = ({
    label,
    value,
    onPressDate,
    onPressTime,
    pickerKeyDate,
    pickerKeyTime,
    onChange,
    minDate,
  }: {
    label: string; value: Date
    onPressDate: () => void; onPressTime: () => void
    pickerKeyDate: typeof picker; pickerKeyTime: typeof picker
    onChange: (...args: any[]) => void; minDate?: Date
  }) => (
    <View style={styles.fieldGroup}>
      <Text style={[styles.label, { color: colors.contentSecondary }]}>{label}</Text>
      <View style={styles.dateRow}>
        <Pressable
          onPress={onPressDate}
          style={[styles.dateChip, { backgroundColor: colors.surfaceSecondary, borderColor: picker === pickerKeyDate ? colors.contentPrimary : colors.borderSecondary }]}
        >
          <Ionicons name="calendar-outline" size={14} color={colors.contentSecondary} />
          <Text style={[styles.chipText, { color: colors.contentPrimary }]}>{fmtDate(value)}</Text>
        </Pressable>
        <Pressable
          onPress={onPressTime}
          style={[styles.timeChip, { backgroundColor: colors.surfaceSecondary, borderColor: picker === pickerKeyTime ? colors.contentPrimary : colors.borderSecondary }]}
        >
          <Ionicons name="time-outline" size={14} color={colors.contentSecondary} />
          <Text style={[styles.chipText, { color: colors.contentPrimary }]}>{fmtTime(value)}</Text>
        </Pressable>
      </View>
      {isIOS && (picker === pickerKeyDate || picker === pickerKeyTime) && (
        <View style={[styles.pickerBox, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
          <DateTimePicker
            value={value}
            mode={picker === pickerKeyDate ? 'date' : 'time'}
            display="spinner"
            onChange={onChange}
            minimumDate={minDate}
            textColor={colors.contentPrimary}
            themeVariant={colors.contentPrimary === '#FFFFFF' ? 'dark' : 'light'}
          />
          <Pressable onPress={() => setPicker(null)} style={[styles.pickerDone, { borderTopColor: colors.borderSecondary }]}>
            <Text style={[styles.pickerDoneText, { color: colors.contentPrimary }]}>Done</Text>
          </Pressable>
        </View>
      )}
      {isAndroid && (picker === pickerKeyDate || picker === pickerKeyTime) && (
        <DateTimePicker value={value} mode={picker === pickerKeyDate ? 'date' : 'time'} display="default" onChange={onChange} minimumDate={minDate} />
      )}
    </View>
  )

  if (loading) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
        <View style={styles.centered}><ActivityIndicator color={colors.contentTertiary} /></View>
      </SafeAreaView>
    )
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={isIOS ? 'padding' : undefined}>
        {/* Header */}
        <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
          <Pressable onPress={() => router.back()} style={styles.headerButton}>
            <Text style={[styles.headerCancel, { color: colors.contentSecondary }]}>Cancel</Text>
          </Pressable>
          <Text style={[styles.headerTitle, { color: colors.contentPrimary }]}>Edit Event</Text>
          <Pressable onPress={handleSave} style={styles.headerButton} disabled={!canSave}>
            {saving ? (
              <ActivityIndicator size="small" color={colors.contentPrimary} />
            ) : (
              <Text style={[styles.headerSave, { color: canSave ? colors.contentPrimary : colors.contentTertiary, fontWeight: '600' }]}>Save</Text>
            )}
          </Pressable>
        </View>

        <ScrollView contentContainerStyle={styles.body} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          {/* Title */}
          <View style={styles.fieldGroup}>
            <Text style={[styles.label, { color: colors.contentSecondary }]}>EVENT TITLE *</Text>
            <View style={[styles.inputWrap, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
              <TextInput value={title} onChangeText={setTitle} placeholder="Event title" placeholderTextColor={colors.contentTertiary} style={[styles.input, { color: colors.contentPrimary }]} maxLength={100} autoFocus />
            </View>
            <Text style={[styles.hint, { color: colors.contentTertiary }]}>{title.length}/100</Text>
          </View>

          {/* Description */}
          <View style={styles.fieldGroup}>
            <Text style={[styles.label, { color: colors.contentSecondary }]}>DESCRIPTION</Text>
            <View style={[styles.inputWrap, styles.textareaWrap, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
              <TextInput value={description} onChangeText={setDescription} placeholder="Tell people what to expect…" placeholderTextColor={colors.contentTertiary} style={[styles.input, styles.textarea, { color: colors.contentPrimary }]} multiline maxLength={500} textAlignVertical="top" />
            </View>
            <Text style={[styles.hint, { color: colors.contentTertiary }]}>{description.length}/500</Text>
          </View>

          {/* Start */}
          <DateRow
            label="STARTS *"
            value={startDate}
            onPressDate={() => setPicker(picker === 'startDate' ? null : 'startDate')}
            onPressTime={() => setPicker(picker === 'startTime' ? null : 'startTime')}
            pickerKeyDate="startDate"
            pickerKeyTime="startTime"
            onChange={handleStartChange}
            minDate={new Date()}
          />

          {/* End */}
          <DateRow
            label="ENDS"
            value={endDate}
            onPressDate={() => setPicker(picker === 'endDate' ? null : 'endDate')}
            onPressTime={() => setPicker(picker === 'endTime' ? null : 'endTime')}
            pickerKeyDate="endDate"
            pickerKeyTime="endTime"
            onChange={handleEndChange}
            minDate={startDate}
          />

          {/* Location */}
          <View style={styles.fieldGroup}>
            <Text style={[styles.label, { color: colors.contentSecondary }]}>LOCATION *</Text>
            <View style={[styles.inputWrap, styles.locationWrap, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
              <Ionicons name="location-outline" size={16} color={colors.contentTertiary} />
              <TextInput value={location} onChangeText={setLocation} placeholder="Venue name or address" placeholderTextColor={colors.contentTertiary} style={[styles.input, { color: colors.contentPrimary, flex: 1 }]} maxLength={200} />
            </View>
          </View>

          {/* Category */}
          <View style={styles.fieldGroup}>
            <Text style={[styles.label, { color: colors.contentSecondary }]}>CATEGORY</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.pillScroll}>
              {CATEGORIES.map(cat => {
                const selected = category === cat
                return (
                  <Pressable
                    key={cat}
                    onPress={() => { Haptics.selectionAsync(); setCategory(selected ? null : cat) }}
                    style={[styles.pill, { backgroundColor: selected ? colors.contentPrimary : colors.surfaceSecondary, borderColor: selected ? colors.contentPrimary : colors.borderSecondary }]}
                  >
                    <Text style={[styles.pillText, { color: selected ? colors.contentInverse : colors.contentSecondary }]}>{cat}</Text>
                  </Pressable>
                )
              })}
            </ScrollView>
          </View>

          {/* Public toggle */}
          <View style={[styles.toggleRow, { borderColor: colors.borderSecondary, backgroundColor: colors.surfaceSecondary }]}>
            <View style={styles.toggleInfo}>
              <Text style={[styles.toggleLabel, { color: colors.contentPrimary }]}>Public event</Text>
              <Text style={[styles.toggleSub, { color: colors.contentTertiary }]}>
                {isPublic ? 'Anyone can find and RSVP' : 'Only invited people can see this'}
              </Text>
            </View>
            <Switch
              value={isPublic}
              onValueChange={v => { Haptics.selectionAsync(); setIsPublic(v) }}
              trackColor={{ false: colors.borderSecondary, true: colors.contentPrimary }}
              thumbColor={colors.contentInverse}
            />
          </View>

          {/* Save */}
          <Pressable
            onPress={handleSave}
            disabled={!canSave}
            style={[styles.saveBtn, { backgroundColor: canSave ? colors.contentPrimary : colors.surfaceElevated }]}
          >
            {saving ? <ActivityIndicator color={colors.contentInverse} /> : (
              <Text style={[styles.saveBtnText, { color: canSave ? colors.contentInverse : colors.contentTertiary }]}>Save Changes</Text>
            )}
          </Pressable>

          {/* Delete */}
          <View style={[styles.dangerZone, { borderColor: colors.borderSecondary }]}>
            <Text style={[styles.dangerTitle, { color: colors.contentTertiary }]}>Danger zone</Text>
            <Pressable
              onPress={handleDelete}
              disabled={deleting}
              style={[styles.deleteBtn, { borderColor: colors.contentTertiary }]}
            >
              {deleting ? <ActivityIndicator color={colors.contentTertiary} /> : (
                <Text style={[styles.deleteBtnText, { color: colors.contentTertiary }]}>Delete Event</Text>
              )}
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },

  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.md, borderBottomWidth: 1,
  },
  headerButton: { minWidth: 60 },
  headerTitle: { fontSize: Typography.callout, fontWeight: '600' },
  headerCancel: { fontSize: Typography.callout },
  headerSave: { fontSize: Typography.callout, textAlign: 'right' },

  body: { padding: Spacing.base, gap: Spacing.lg, paddingBottom: 60 },

  fieldGroup: { gap: Spacing.xs },
  label: { fontSize: 11, fontWeight: '600', letterSpacing: 0.8, textTransform: 'uppercase' },
  inputWrap: { borderRadius: BorderRadius.md, borderWidth: 1, paddingHorizontal: Spacing.md, paddingVertical: 12 },
  textareaWrap: { paddingVertical: Spacing.md },
  locationWrap: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  input: { fontSize: Typography.callout, padding: 0 },
  textarea: { minHeight: 80 },
  hint: { fontSize: Typography.caption, textAlign: 'right' },

  dateRow: { flexDirection: 'row', gap: Spacing.sm },
  dateChip: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 6, borderRadius: BorderRadius.md, borderWidth: 1, paddingHorizontal: Spacing.md, paddingVertical: 10 },
  timeChip: { flexDirection: 'row', alignItems: 'center', gap: 6, borderRadius: BorderRadius.md, borderWidth: 1, paddingHorizontal: Spacing.md, paddingVertical: 10 },
  chipText: { fontSize: Typography.caption, fontWeight: '500' },

  pickerBox: { borderRadius: BorderRadius.md, borderWidth: 1, overflow: 'hidden', marginTop: 4 },
  pickerDone: { paddingVertical: Spacing.md, alignItems: 'center', borderTopWidth: 1 },
  pickerDoneText: { fontSize: Typography.callout, fontWeight: '600' },

  pillScroll: { gap: Spacing.sm, paddingVertical: 4 },
  pill: { paddingHorizontal: Spacing.md, paddingVertical: 7, borderRadius: BorderRadius.full, borderWidth: 1 },
  pillText: { fontSize: Typography.caption, fontWeight: '500' },

  toggleRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    borderRadius: BorderRadius.md, borderWidth: 1, padding: Spacing.md, gap: Spacing.base,
  },
  toggleInfo: { flex: 1, gap: 2 },
  toggleLabel: { fontSize: Typography.callout, fontWeight: '500' },
  toggleSub: { fontSize: Typography.caption },

  saveBtn: { borderRadius: BorderRadius.md, paddingVertical: 15, alignItems: 'center', marginTop: Spacing.md },
  saveBtnText: { fontSize: Typography.callout, fontWeight: '600' },

  dangerZone: { borderWidth: 1, borderRadius: BorderRadius.lg, padding: Spacing.base, gap: Spacing.md, marginTop: Spacing.base },
  dangerTitle: { fontSize: Typography.caption, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.8 },
  deleteBtn: { borderWidth: 1, borderRadius: BorderRadius.md, paddingVertical: 13, alignItems: 'center' },
  deleteBtnText: { fontSize: Typography.callout, fontWeight: '600' },
})
