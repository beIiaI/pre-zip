import React, { useState, useCallback, useEffect } from 'react'
import {
  View,
  Text,
  ScrollView,
  Pressable,
  StyleSheet,
  ActivityIndicator,
  Image,
  Alert,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useLocalSearchParams, useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

// ─── Types ────────────────────────────────────────────────────────────────────

interface UserProfile {
  id: string
  full_name: string | null
  username: string | null
  avatar_url: string | null
  bio: string | null
  location: string | null
  interests: string[]
  is_verified: boolean
  early_supporter_number: number | null
  is_founder: boolean
  university_name: string | null
  university_verified: boolean
  show_university: boolean
  total_points: number
  created_at: string
  profile_visibility: 'public' | 'friends' | 'private'
  message_requests: 'everyone' | 'friends' | 'off'
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getInitials(name: string | null, username: string | null): string {
  if (name) return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
  if (username) return username[0].toUpperCase()
  return '?'
}

function formatMemberSince(iso: string): string {
  return new Date(iso).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function UserProfileScreen() {
  const { id: userId } = useLocalSearchParams<{ id: string }>()
  const router = useRouter()
  const { colors } = useTheme()
  const { user } = useAuth()

  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)
  const [messagingLoading, setMessagingLoading] = useState(false)
  const [isBlocked, setIsBlocked] = useState(false)

  // Redirect to own profile if viewing self
  useEffect(() => {
    if (userId && user && userId === user.id) {
      router.replace('/(tabs)/profile')
    }
  }, [userId, user, router])

  const loadProfile = useCallback(async () => {
    if (!userId || !user) return
    setLoading(true)

    const [profileRes, blockRes] = await Promise.all([
      supabase
        .from('profiles')
        .select('id, full_name, username, avatar_url, bio, location, interests, is_verified, early_supporter_number, is_founder, university_name, university_verified, show_university, total_points, created_at, profile_visibility, message_requests')
        .eq('id', userId)
        .single(),
      supabase
        .from('blocks')
        .select('id')
        .eq('blocker_id', user.id)
        .eq('blocked_id', userId)
        .maybeSingle(),
    ])

    if (profileRes.data) setProfile(profileRes.data as UserProfile)
    setIsBlocked(!!blockRes.data)
    setLoading(false)
  }, [userId, user])

  useEffect(() => { loadProfile() }, [loadProfile])

  // ─── Message ────────────────────────────────────────────────────────────────

  const handleMessage = async () => {
    if (!user || !userId || messagingLoading) return
    setMessagingLoading(true)
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)

    // Check if thread already exists
    const { data: existing } = await supabase
      .from('dm_threads')
      .select('id')
      .or(`and(user_a.eq.${user.id},user_b.eq.${userId}),and(user_a.eq.${userId},user_b.eq.${user.id})`)
      .maybeSingle()

    if (existing) {
      setMessagingLoading(false)
      router.push(`/conversation/${existing.id}` as any)
      return
    }

    // Create new thread
    const { data: thread, error } = await supabase
      .from('dm_threads')
      .insert({ user_a: user.id, user_b: userId })
      .select('id')
      .single()

    if (error || !thread) {
      setMessagingLoading(false)
      Alert.alert('Error', 'Could not start a conversation. Please try again.')
      return
    }

    // Add both participants
    await supabase.from('dm_participants').insert([
      { thread_id: thread.id, user_id: user.id },
      { thread_id: thread.id, user_id: userId },
    ])

    setMessagingLoading(false)
    router.push(`/conversation/${thread.id}` as any)
  }

  // ─── Block / Unblock ────────────────────────────────────────────────────────

  const handleBlock = async () => {
    if (!user || !userId) return

    if (isBlocked) {
      Alert.alert('Unblock user?', `${profile?.full_name || profile?.username || 'This user'} will be able to see your profile again.`, [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Unblock', onPress: async () => {
            setIsBlocked(false)
            await supabase.from('blocks').delete().match({ blocker_id: user.id, blocked_id: userId })
          },
        },
      ])
    } else {
      Alert.alert('Block user?', `${profile?.full_name || profile?.username || 'This user'} won't be able to message you or see your profile.`, [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Block', style: 'destructive', onPress: async () => {
            setIsBlocked(true)
            await supabase.from('blocks').insert({ blocker_id: user.id, blocked_id: userId })
          },
        },
      ])
    }
  }

  // ─── Render ────────────────────────────────────────────────────────────────

  if (loading) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
        <Pressable onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
        </Pressable>
        <View style={styles.centered}><ActivityIndicator color={colors.contentTertiary} /></View>
      </SafeAreaView>
    )
  }

  if (!profile) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
        <Pressable onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
        </Pressable>
        <View style={styles.centered}>
          <Ionicons name="person-outline" size={40} color={colors.contentTertiary} />
          <Text style={[styles.errorText, { color: colors.contentPrimary }]}>User not found</Text>
        </View>
      </SafeAreaView>
    )
  }

  const canMessage = profile.message_requests !== 'off' && !isBlocked
  const initials = getInitials(profile.full_name, profile.username)

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
        <Pressable onPress={() => router.back()} style={styles.backButton2}>
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.contentPrimary }]} numberOfLines={1}>
          {profile.full_name || profile.username || 'Profile'}
        </Text>
        <Pressable onPress={handleBlock} style={styles.moreButton}>
          <Ionicons name="ellipsis-horizontal" size={20} color={colors.contentTertiary} />
        </Pressable>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Hero */}
        <View style={styles.heroSection}>
          {profile.avatar_url ? (
            <Image source={{ uri: profile.avatar_url }} style={styles.avatar} />
          ) : (
            <View style={[styles.avatar, styles.avatarFallback, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
              <Text style={[styles.avatarText, { color: colors.contentPrimary }]}>{initials}</Text>
            </View>
          )}
          <Text style={[styles.name, { color: colors.contentPrimary }]}>
            {profile.full_name || profile.username || '…'}
          </Text>
          {profile.username && (
            <View style={styles.usernameRow}>
              <Text style={[styles.username, { color: colors.contentSecondary }]}>@{profile.username}</Text>
              {profile.is_verified && (
                <Ionicons name="checkmark-circle" size={15} color={colors.contentPrimary} style={{ marginLeft: 4 }} />
              )}
            </View>
          )}
        </View>

        {/* Badges */}
        {(profile.early_supporter_number != null || profile.is_founder) && (
          <View style={styles.badgesRow}>
            {profile.early_supporter_number != null && (
              <View style={[styles.badge, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
                <Ionicons name="star-outline" size={12} color={colors.contentSecondary} />
                <Text style={[styles.badgeText, { color: colors.contentSecondary }]}>
                  Early Supporter #{profile.early_supporter_number}
                </Text>
              </View>
            )}
            {profile.is_founder && (
              <View style={[styles.badge, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
                <Ionicons name="ribbon-outline" size={12} color={colors.contentSecondary} />
                <Text style={[styles.badgeText, { color: colors.contentSecondary }]}>Founder</Text>
              </View>
            )}
          </View>
        )}

        {/* Stats */}
        <View style={[styles.statsRow, { borderColor: colors.borderSecondary }]}>
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: colors.contentPrimary }]}>
              {(profile.total_points ?? 0).toLocaleString()}
            </Text>
            <Text style={[styles.statLabel, { color: colors.contentTertiary }]}>Points</Text>
          </View>
          <View style={[styles.statDivider, { backgroundColor: colors.borderSecondary }]} />
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: colors.contentPrimary }]}>
              {formatMemberSince(profile.created_at)}
            </Text>
            <Text style={[styles.statLabel, { color: colors.contentTertiary }]}>Member since</Text>
          </View>
        </View>

        {/* Message button */}
        {canMessage && (
          <Pressable
            onPress={handleMessage}
            disabled={messagingLoading}
            style={[styles.messageButton, { backgroundColor: colors.contentPrimary }]}
          >
            {messagingLoading
              ? <ActivityIndicator size="small" color={colors.contentInverse} />
              : <>
                <Ionicons name="chatbubble" size={18} color={colors.contentInverse} />
                <Text style={[styles.messageButtonText, { color: colors.contentInverse }]}>Message</Text>
              </>
            }
          </Pressable>
        )}

        {/* Bio */}
        {profile.bio && (
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: colors.contentTertiary }]}>About</Text>
            <Text style={[styles.bioText, { color: colors.contentPrimary }]}>{profile.bio}</Text>
          </View>
        )}

        {/* Details */}
        <View style={[styles.detailsCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
          {profile.location && (
            <View style={styles.detailRow}>
              <Ionicons name="location-outline" size={16} color={colors.contentTertiary} />
              <Text style={[styles.detailText, { color: colors.contentSecondary }]}>{profile.location}</Text>
            </View>
          )}
          {profile.university_verified && profile.university_name && profile.show_university && (
            <View style={[styles.detailRow, profile.location ? { borderTopWidth: 1, borderTopColor: colors.borderSecondary } : null]}>
              <Ionicons name="school-outline" size={16} color={colors.contentTertiary} />
              <Text style={[styles.detailText, { color: colors.contentSecondary }]}>{profile.university_name}</Text>
              <Ionicons name="checkmark-circle" size={13} color={colors.success} style={{ marginLeft: 4 }} />
            </View>
          )}
        </View>

        {/* Interests */}
        {Array.isArray(profile.interests) && profile.interests.length > 0 && (
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: colors.contentTertiary }]}>Interests</Text>
            <View style={styles.tagsRow}>
              {profile.interests.map((tag: string) => (
                <View key={tag} style={[styles.tag, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
                  <Text style={[styles.tagText, { color: colors.contentPrimary }]}>{tag}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Blocked state */}
        {isBlocked && (
          <View style={[styles.blockedBanner, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
            <Ionicons name="ban-outline" size={16} color={colors.contentTertiary} />
            <Text style={[styles.blockedText, { color: colors.contentTertiary }]}>You have blocked this user</Text>
            <Pressable onPress={handleBlock}>
              <Text style={[styles.unblockLink, { color: colors.contentPrimary }]}>Unblock</Text>
            </Pressable>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  )
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: Spacing.md },
  errorText: { fontSize: Typography.headline, fontWeight: '600' },

  backButton: {
    position: 'absolute',
    top: 56,
    left: Spacing.sm,
    zIndex: 10,
    width: 36,
    height: 36,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButton2: { width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.sm,
    borderBottomWidth: 1,
    gap: Spacing.sm,
  },
  headerTitle: { flex: 1, fontSize: Typography.callout, fontWeight: '700' },
  moreButton: { width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },

  scrollContent: { padding: Spacing.base, gap: Spacing.md, paddingBottom: 100 },

  heroSection: { alignItems: 'center', paddingVertical: Spacing.lg, gap: Spacing.sm },
  avatar: { width: 88, height: 88, borderRadius: 44 },
  avatarFallback: { borderWidth: 1, justifyContent: 'center', alignItems: 'center' },
  avatarText: { fontSize: 34, fontWeight: '600' },
  name: { fontSize: Typography.title, fontWeight: '700', textAlign: 'center' },
  usernameRow: { flexDirection: 'row', alignItems: 'center' },
  username: { fontSize: Typography.body },

  badgesRow: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: Spacing.sm },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
  badgeText: { fontSize: Typography.caption },

  statsRow: {
    flexDirection: 'row',
    borderWidth: 1,
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
  },
  statItem: { flex: 1, alignItems: 'center', paddingVertical: Spacing.base },
  statValue: { fontSize: Typography.callout, fontWeight: '600' },
  statLabel: { fontSize: Typography.caption, marginTop: 2 },
  statDivider: { width: 1 },

  messageButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.lg,
  },
  messageButtonText: { fontSize: Typography.callout, fontWeight: '600' },

  section: { gap: Spacing.sm },
  sectionTitle: {
    fontSize: Typography.caption,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
  },
  bioText: { fontSize: Typography.body, lineHeight: Typography.body * 1.5 },

  detailsCard: {
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    overflow: 'hidden',
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
  },
  detailText: { fontSize: Typography.callout, flex: 1 },

  tagsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  tag: {
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
  tagText: { fontSize: Typography.caption },

  blockedBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    padding: Spacing.base,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
  },
  blockedText: { flex: 1, fontSize: Typography.caption },
  unblockLink: { fontSize: Typography.caption, fontWeight: '600' },
})
