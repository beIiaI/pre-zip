import React, { useState, useCallback, useEffect, useRef } from 'react'
import {
  View,
  Text,
  FlatList,
  Pressable,
  StyleSheet,
  ActivityIndicator,
  Image,
  ScrollView,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useLocalSearchParams, useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

// ─── Types ────────────────────────────────────────────────────────────────────

interface CircleDetail {
  id: string
  name: string
  description: string | null
  category: string | null
  is_public: boolean
  member_count: number
  creator_id: string
  created_at: string
}

interface Member {
  user_id: string
  role: 'admin' | 'moderator' | 'member'
  joined_at: string
  profiles: {
    id: string
    full_name: string | null
    username: string | null
    avatar_url: string | null
    is_verified: boolean
    early_supporter_number: number | null
  } | null
}

interface CircleMessage {
  id: string
  content: string
  sender_id: string
  created_at: string
  profiles: {
    full_name: string | null
    username: string | null
    avatar_url: string | null
  } | null
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getInitials(name: string | null, username: string | null): string {
  if (name) return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
  if (username) return username[0].toUpperCase()
  return '?'
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
}

function formatMessageTime(iso: string): string {
  const d = new Date(iso)
  const now = new Date()
  const isToday = d.toDateString() === now.toDateString()
  if (isToday) return d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) +
    ' · ' + d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
}

// ─── Avatar ───────────────────────────────────────────────────────────────────

function Avatar({
  uri, name, username, size = 36, colors,
}: { uri: string | null; name: string | null; username: string | null; size?: number; colors: any }) {
  if (uri) return <Image source={{ uri }} style={{ width: size, height: size, borderRadius: size / 2 }} />
  return (
    <View style={{
      width: size, height: size, borderRadius: size / 2,
      backgroundColor: colors.surfaceElevated,
      borderWidth: 1, borderColor: colors.borderPrimary,
      justifyContent: 'center', alignItems: 'center',
    }}>
      <Text style={{ fontSize: size * 0.35, color: colors.contentPrimary, fontWeight: '600' }}>
        {getInitials(name, username)}
      </Text>
    </View>
  )
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

type ActiveSection = 'about' | 'chat'

export default function CircleDetailScreen() {
  const { id: circleId } = useLocalSearchParams<{ id: string }>()
  const router = useRouter()
  const { colors } = useTheme()
  const { user } = useAuth()

  const [circle, setCircle] = useState<CircleDetail | null>(null)
  const [members, setMembers] = useState<Member[]>([])
  const [messages, setMessages] = useState<CircleMessage[]>([])
  const [loading, setLoading] = useState(true)
  const [isJoined, setIsJoined] = useState(false)
  const [joining, setJoining] = useState(false)
  const [activeSection, setActiveSection] = useState<ActiveSection>('about')

  // Chat
  const [draft, setDraft] = useState('')
  const [sending, setSending] = useState(false)
  const flatListRef = useRef<FlatList>(null)

  // ─── Load ──────────────────────────────────────────────────────────────────

  const loadCircle = useCallback(async () => {
    if (!circleId || !user) return
    setLoading(true)

    const [circleRes, membersRes, membershipRes] = await Promise.all([
      supabase
        .from('circles')
        .select('id, name, description, category, is_public, member_count, creator_id, created_at')
        .eq('id', circleId)
        .single(),
      supabase
        .from('circle_members')
        .select('user_id, role, joined_at, profiles(id, full_name, username, avatar_url, is_verified, early_supporter_number)')
        .eq('circle_id', circleId)
        .order('joined_at', { ascending: true })
        .limit(50),
      supabase
        .from('circle_members')
        .select('user_id')
        .eq('circle_id', circleId)
        .eq('user_id', user.id)
        .maybeSingle(),
    ])

    if (circleRes.data) setCircle(circleRes.data)
    if (membersRes.data) setMembers(membersRes.data as Member[])
    setIsJoined(!!membershipRes.data)
    setLoading(false)
  }, [circleId, user])

  const loadMessages = useCallback(async () => {
    if (!circleId) return
    const { data } = await supabase
      .from('messages')
      .select('id, content, sender_id, created_at, profiles(full_name, username, avatar_url)')
      .eq('circle_id', circleId)
      .order('created_at', { ascending: false })
      .limit(100)
    if (data) setMessages(data as CircleMessage[])
  }, [circleId])

  useEffect(() => { loadCircle() }, [loadCircle])

  useEffect(() => {
    if (activeSection === 'chat') loadMessages()
  }, [activeSection, loadMessages])

  // ─── Realtime for chat ─────────────────────────────────────────────────────

  useEffect(() => {
    if (activeSection !== 'chat' || !circleId) return

    const channel = supabase
      .channel(`circle-chat:${circleId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'messages',
        filter: `circle_id=eq.${circleId}`,
      }, async (payload) => {
        const msg = payload.new as any
        // fetch sender profile
        const { data: profile } = await supabase
          .from('profiles')
          .select('full_name, username, avatar_url')
          .eq('id', msg.sender_id)
          .single()
        const fullMsg: CircleMessage = { ...msg, profiles: profile }
        setMessages(prev => {
          if (prev.some(m => m.id === fullMsg.id)) return prev
          return [fullMsg, ...prev]
        })
      })
      .subscribe()

    return () => { supabase.removeChannel(channel) }
  }, [activeSection, circleId])

  // ─── Join / Leave ──────────────────────────────────────────────────────────

  const handleJoin = async () => {
    if (!user || !circle || joining) return
    setJoining(true)
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)

    if (isJoined) {
      Alert.alert('Leave circle?', `You will leave "${circle.name}".`, [
        { text: 'Cancel', style: 'cancel', onPress: () => setJoining(false) },
        {
          text: 'Leave', style: 'destructive', onPress: async () => {
            setIsJoined(false)
            setCircle(prev => prev ? { ...prev, member_count: Math.max(0, prev.member_count - 1) } : prev)
            setMembers(prev => prev.filter(m => m.user_id !== user.id))
            await supabase.from('circle_members').delete().match({ circle_id: circleId, user_id: user.id })
            setJoining(false)
          },
        },
      ])
    } else {
      setIsJoined(true)
      setCircle(prev => prev ? { ...prev, member_count: prev.member_count + 1 } : prev)
      const { error } = await supabase.from('circle_members').insert({ circle_id: circleId, user_id: user.id })
      if (error) {
        setIsJoined(false)
        setCircle(prev => prev ? { ...prev, member_count: prev.member_count - 1 } : prev)
      }
      setJoining(false)
    }
  }

  // ─── Send message ──────────────────────────────────────────────────────────

  const handleSend = async () => {
    const content = draft.trim()
    if (!content || !user || !circleId || sending || !isJoined) return
    setSending(true)
    setDraft('')
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)

    const optimisticId = `opt-${Date.now()}`
    const optimistic: CircleMessage = {
      id: optimisticId,
      content,
      sender_id: user.id,
      created_at: new Date().toISOString(),
      profiles: null,
    }
    setMessages(prev => [optimistic, ...prev])

    const { data, error } = await supabase
      .from('messages')
      .insert({ circle_id: circleId, sender_id: user.id, content })
      .select('id, content, sender_id, created_at')
      .single()

    setSending(false)
    if (error) {
      setMessages(prev => prev.filter(m => m.id !== optimisticId))
      setDraft(content)
    } else if (data) {
      setMessages(prev => prev.map(m => m.id === optimisticId ? { ...data, profiles: null } : m))
    }
  }

  // ─── Render ────────────────────────────────────────────────────────────────

  if (loading) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
        <View style={styles.backRow}>
          <Pressable onPress={() => router.back()} style={styles.backButton}>
            <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
          </Pressable>
        </View>
        <View style={styles.centered}>
          <ActivityIndicator color={colors.contentTertiary} />
        </View>
      </SafeAreaView>
    )
  }

  if (!circle) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
        <View style={styles.backRow}>
          <Pressable onPress={() => router.back()} style={styles.backButton}>
            <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
          </Pressable>
        </View>
        <View style={styles.centered}>
          <Ionicons name="alert-circle-outline" size={40} color={colors.contentTertiary} />
          <Text style={[styles.emptyTitle, { color: colors.contentPrimary }]}>Circle not found</Text>
        </View>
      </SafeAreaView>
    )
  }

  const isAdmin = circle.creator_id === user?.id ||
    members.some(m => m.user_id === user?.id && (m.role === 'admin' || m.role === 'moderator'))

  const renderMessage = ({ item, index }: { item: CircleMessage; index: number }) => {
    const isMine = item.sender_id === user?.id
    const prevItem = messages[index + 1]
    const showTime = !prevItem ||
      new Date(prevItem.created_at).getTime() < new Date(item.created_at).getTime() - 5 * 60_000
    const profile = item.profiles

    return (
      <View style={isMine ? styles.msgOuterMine : styles.msgOuterTheirs}>
        {showTime && (
          <Text style={[styles.msgTime, { color: colors.contentTertiary }]}>
            {formatMessageTime(item.created_at)}
          </Text>
        )}
        {!isMine && (
          <View style={styles.msgRow}>
            <Avatar
              uri={profile?.avatar_url ?? null}
              name={profile?.full_name ?? null}
              username={profile?.username ?? null}
              size={26}
              colors={colors}
            />
            <View>
              <Text style={[styles.msgSender, { color: colors.contentTertiary }]}>
                {profile?.full_name || profile?.username || '…'}
              </Text>
              <View style={[styles.bubble, styles.bubbleTheirs, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
                <Text style={[styles.bubbleText, { color: colors.contentPrimary }]}>{item.content}</Text>
              </View>
            </View>
          </View>
        )}
        {isMine && (
          <View style={[styles.bubble, styles.bubbleMine, { backgroundColor: colors.contentPrimary }]}>
            <Text style={[styles.bubbleText, { color: colors.contentInverse }]}>{item.content}</Text>
          </View>
        )}
      </View>
    )
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
        <Pressable onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
        </Pressable>
        <View style={styles.headerCenter}>
          <Text style={[styles.headerTitle, { color: colors.contentPrimary }]} numberOfLines={1}>
            {circle.name}
          </Text>
          {circle.category && (
            <Text style={[styles.headerSub, { color: colors.contentTertiary }]}>{circle.category}</Text>
          )}
        </View>
        {isAdmin ? (
          <Pressable
            onPress={() => router.push(`/edit-circle/${circleId}` as any)}
            style={styles.moreButton}
          >
            <Ionicons name="ellipsis-horizontal" size={20} color={colors.contentPrimary} />
          </Pressable>
        ) : (
          <Pressable
            onPress={handleJoin}
            disabled={joining}
            style={[styles.joinBtn, {
              backgroundColor: isJoined ? colors.surfaceElevated : colors.contentPrimary,
              borderColor: isJoined ? colors.borderPrimary : colors.contentPrimary,
            }]}
          >
            {joining
              ? <ActivityIndicator size="small" color={isJoined ? colors.contentPrimary : colors.contentInverse} />
              : <Text style={[styles.joinBtnText, { color: isJoined ? colors.contentPrimary : colors.contentInverse }]}>
                {isJoined ? 'Joined' : 'Join'}
              </Text>
            }
          </Pressable>
        )}
      </View>

      {/* Section tabs */}
      <View style={[styles.sectionTabs, { borderBottomColor: colors.borderSecondary }]}>
        {(['about', 'chat'] as ActiveSection[]).map(s => (
          <Pressable key={s} style={styles.sectionTab} onPress={() => setActiveSection(s)}>
            <Text style={[styles.sectionTabLabel, {
              color: activeSection === s ? colors.contentPrimary : colors.contentTertiary,
              fontWeight: activeSection === s ? '600' : '400',
            }]}>
              {s === 'about' ? 'About' : 'Chat'}
            </Text>
            {activeSection === s && (
              <View style={[styles.sectionTabIndicator, { backgroundColor: colors.contentPrimary }]} />
            )}
          </Pressable>
        ))}
      </View>

      {/* About section */}
      {activeSection === 'about' && (
        <ScrollView contentContainerStyle={styles.aboutContent} showsVerticalScrollIndicator={false}>

          {/* Meta row */}
          <View style={styles.metaRow}>
            <View style={styles.metaItem}>
              <Text style={[styles.metaValue, { color: colors.contentPrimary }]}>
                {circle.member_count.toLocaleString()}
              </Text>
              <Text style={[styles.metaLabel, { color: colors.contentTertiary }]}>
                {circle.member_count === 1 ? 'member' : 'members'}
              </Text>
            </View>
            {circle.category && (
              <View style={styles.metaItem}>
                <Text style={[styles.metaValue, { color: colors.contentPrimary }]}>{circle.category}</Text>
                <Text style={[styles.metaLabel, { color: colors.contentTertiary }]}>category</Text>
              </View>
            )}
            <View style={styles.metaItem}>
              <Text style={[styles.metaValue, { color: colors.contentPrimary }]}>{formatDate(circle.created_at)}</Text>
              <Text style={[styles.metaLabel, { color: colors.contentTertiary }]}>created</Text>
            </View>
          </View>

          {/* Description */}
          {circle.description && (
            <View style={[styles.descCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
              <Text style={[styles.sectionLabel, { color: colors.contentTertiary }]}>About</Text>
              <Text style={[styles.descText, { color: colors.contentPrimary }]}>{circle.description}</Text>
            </View>
          )}

          {/* Members */}
          {members.length > 0 && (
            <View style={[styles.descCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
              <Text style={[styles.sectionLabel, { color: colors.contentTertiary }]}>
                Members · {members.length}{members.length === 50 ? '+' : ''}
              </Text>

              {/* Avatar row */}
              <View style={styles.avatarRow}>
                {members.slice(0, 12).map(m => (
                  <Pressable
                    key={m.user_id}
                    onPress={() => router.push(`/user/${m.user_id}` as any)}
                    style={styles.avatarWrap}
                  >
                    <Avatar
                      uri={m.profiles?.avatar_url ?? null}
                      name={m.profiles?.full_name ?? null}
                      username={m.profiles?.username ?? null}
                      size={44}
                      colors={colors}
                    />
                    {m.role !== 'member' && (
                      <View style={[styles.roleDot, { backgroundColor: colors.contentPrimary }]} />
                    )}
                  </Pressable>
                ))}
                {members.length > 12 && (
                  <View style={[styles.moreAvatars, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
                    <Text style={[styles.moreAvatarsText, { color: colors.contentSecondary }]}>
                      +{members.length - 12}
                    </Text>
                  </View>
                )}
              </View>

              {/* Member list rows */}
              {members.slice(0, 6).map((m, i) => (
                <Pressable
                  key={m.user_id}
                  onPress={() => router.push(`/user/${m.user_id}` as any)}
                  style={[
                    styles.memberRow,
                    i > 0 && { borderTopWidth: 1, borderTopColor: colors.borderSecondary },
                  ]}
                >
                  <Avatar
                    uri={m.profiles?.avatar_url ?? null}
                    name={m.profiles?.full_name ?? null}
                    username={m.profiles?.username ?? null}
                    size={34}
                    colors={colors}
                  />
                  <View style={styles.memberInfo}>
                    <Text style={[styles.memberName, { color: colors.contentPrimary }]} numberOfLines={1}>
                      {m.profiles?.full_name || m.profiles?.username || '…'}
                    </Text>
                    {m.profiles?.username && (
                      <Text style={[styles.memberUsername, { color: colors.contentTertiary }]}>
                        @{m.profiles.username}
                      </Text>
                    )}
                  </View>
                  {m.role !== 'member' && (
                    <View style={[styles.roleTag, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
                      <Text style={[styles.roleTagText, { color: colors.contentSecondary }]}>
                        {m.role}
                      </Text>
                    </View>
                  )}
                  <Ionicons name="chevron-forward" size={14} color={colors.contentTertiary} />
                </Pressable>
              ))}
            </View>
          )}
        </ScrollView>
      )}

      {/* Chat section */}
      {activeSection === 'chat' && (
        <KeyboardAvoidingView
          style={styles.flex}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          keyboardVerticalOffset={0}
        >
          <FlatList
            ref={flatListRef}
            data={messages}
            keyExtractor={item => item.id}
            renderItem={renderMessage}
            inverted
            contentContainerStyle={styles.chatList}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
              <View style={styles.chatEmpty}>
                <Ionicons name="chatbubbles-outline" size={36} color={colors.contentTertiary} />
                <Text style={[styles.chatEmptyText, { color: colors.contentTertiary }]}>
                  {isJoined ? 'Be the first to say something!' : 'Join the circle to chat'}
                </Text>
              </View>
            }
          />
          {isJoined && (
            <View style={[styles.inputBar, { borderTopColor: colors.borderSecondary, backgroundColor: colors.surfacePrimary }]}>
              <TextInput
                value={draft}
                onChangeText={setDraft}
                placeholder="Message the circle…"
                placeholderTextColor={colors.contentTertiary}
                style={[styles.inputField, { color: colors.contentPrimary, backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}
                multiline
                maxLength={2000}
              />
              <Pressable
                onPress={handleSend}
                disabled={!draft.trim() || sending}
                style={[styles.sendButton, { backgroundColor: draft.trim() ? colors.contentPrimary : colors.surfaceElevated }]}
              >
                {sending
                  ? <ActivityIndicator size="small" color={colors.contentInverse} />
                  : <Ionicons name="arrow-up" size={18} color={draft.trim() ? colors.contentInverse : colors.contentTertiary} />
                }
              </Pressable>
            </View>
          )}
          {!isJoined && (
            <View style={[styles.joinPrompt, { borderTopColor: colors.borderSecondary, backgroundColor: colors.surfacePrimary }]}>
              <Text style={[styles.joinPromptText, { color: colors.contentSecondary }]}>
                Join this circle to participate in chat
              </Text>
              <Pressable onPress={handleJoin} style={[styles.joinPromptBtn, { backgroundColor: colors.contentPrimary }]}>
                <Text style={[styles.joinPromptBtnText, { color: colors.contentInverse }]}>Join Circle</Text>
              </Pressable>
            </View>
          )}
        </KeyboardAvoidingView>
      )}
    </SafeAreaView>
  )
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1 },
  flex: { flex: 1 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: Spacing.md },

  backRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.sm, paddingVertical: Spacing.sm },
  backButton: { width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.sm,
    borderBottomWidth: 1,
    gap: Spacing.sm,
  },
  headerCenter: { flex: 1 },
  headerTitle: { fontSize: Typography.callout, fontWeight: '700' },
  headerSub: { fontSize: Typography.caption, marginTop: 1 },

  moreButton: { width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },

  joinBtn: {
    paddingHorizontal: Spacing.md,
    paddingVertical: 7,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
    minWidth: 64,
    alignItems: 'center',
  },
  joinBtnText: { fontSize: Typography.caption, fontWeight: '600' },

  sectionTabs: {
    flexDirection: 'row',
    borderBottomWidth: 1,
  },
  sectionTab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: Spacing.md,
    position: 'relative',
  },
  sectionTabLabel: { fontSize: Typography.callout },
  sectionTabIndicator: {
    position: 'absolute',
    bottom: 0,
    left: '25%',
    right: '25%',
    height: 2,
    borderRadius: BorderRadius.full,
  },

  aboutContent: {
    padding: Spacing.base,
    gap: Spacing.md,
    paddingBottom: 100,
  },

  metaRow: {
    flexDirection: 'row',
    gap: Spacing.base,
    flexWrap: 'wrap',
  },
  metaItem: { gap: 2 },
  metaValue: { fontSize: Typography.callout, fontWeight: '600' },
  metaLabel: { fontSize: Typography.caption },

  descCard: {
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    padding: Spacing.base,
    gap: Spacing.md,
  },
  sectionLabel: {
    fontSize: Typography.caption,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
  },
  descText: { fontSize: Typography.body, lineHeight: Typography.body * 1.5 },

  emptyTitle: { fontSize: Typography.headline, fontWeight: '600' },

  avatarRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.sm,
  },
  avatarWrap: { position: 'relative' },
  roleDot: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  moreAvatars: {
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  moreAvatarsText: { fontSize: Typography.caption, fontWeight: '600' },

  memberRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    paddingTop: Spacing.sm,
    marginTop: Spacing.sm,
  },
  memberInfo: { flex: 1 },
  memberName: { fontSize: Typography.callout, fontWeight: '500' },
  memberUsername: { fontSize: Typography.caption, marginTop: 1 },
  roleTag: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 3,
    borderRadius: BorderRadius.sm,
    borderWidth: 1,
  },
  roleTagText: { fontSize: 10, fontWeight: '600', textTransform: 'capitalize' },

  chatList: { paddingHorizontal: Spacing.base, paddingVertical: Spacing.md, gap: 4 },
  chatEmpty: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: Spacing.xl, gap: Spacing.md },
  chatEmptyText: { fontSize: Typography.callout, textAlign: 'center' },

  msgOuterMine: { alignItems: 'flex-end', marginVertical: 2 },
  msgOuterTheirs: { alignItems: 'flex-start', marginVertical: 2 },
  msgRow: { flexDirection: 'row', alignItems: 'flex-end', gap: Spacing.sm },
  msgTime: { fontSize: 11, textAlign: 'center', marginVertical: Spacing.sm, width: '100%' },
  msgSender: { fontSize: 10, marginBottom: 2, marginLeft: 2 },
  bubble: { maxWidth: 260, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 18 },
  bubbleMine: { borderBottomRightRadius: 4 },
  bubbleTheirs: { borderWidth: 1, borderBottomLeftRadius: 4 },
  bubbleText: { fontSize: Typography.callout, lineHeight: Typography.callout * 1.45 },

  inputBar: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: Spacing.sm,
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.sm,
    borderTopWidth: 1,
  },
  inputField: {
    flex: 1,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    paddingHorizontal: Spacing.md,
    paddingVertical: 10,
    fontSize: Typography.callout,
    maxHeight: 120,
  },
  sendButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 2,
  },

  joinPrompt: {
    alignItems: 'center',
    gap: Spacing.sm,
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.base,
    borderTopWidth: 1,
  },
  joinPromptText: { fontSize: Typography.callout, textAlign: 'center' },
  joinPromptBtn: {
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.full,
  },
  joinPromptBtnText: { fontSize: Typography.callout, fontWeight: '600' },
})
