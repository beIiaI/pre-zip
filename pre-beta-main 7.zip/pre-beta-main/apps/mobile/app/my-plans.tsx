import React, { useState, useCallback, useEffect } from 'react'
import {
  View,
  Text,
  FlatList,
  Pressable,
  StyleSheet,
  RefreshControl,
  ActivityIndicator,
  Image,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

// ─── Shared palette utils ─────────────────────────────────────────────────────

const CARD_PALETTES = [
  { bg: '#3D1F0F', text: '#F5E6D8', accent: '#D4845A', sub: '#9A6644' },
  { bg: '#0F1E3D', text: '#D8E6F5', accent: '#5A84D4', sub: '#4464A0' },
  { bg: '#0F3D1F', text: '#D8F5E6', accent: '#5AD484', sub: '#44A064' },
  { bg: '#2A0F3D', text: '#EDD8F5', accent: '#A45AD4', sub: '#7A44A0' },
  { bg: '#0F3A3A', text: '#D8F5F5', accent: '#5AD4C4', sub: '#44A0A0' },
  { bg: '#3D300F', text: '#F5EED8', accent: '#D4B45A', sub: '#A08844' },
]

const AVATAR_COLORS = ['#C45A7A', '#5A7AC4', '#5AC47A', '#C4A45A', '#7A5AC4', '#C45AC4']

function getPaletteIndex(id: string): number {
  let h = 0
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0
  return Math.abs(h) % CARD_PALETTES.length
}

function getAvatarColor(id: string): string {
  let h = 0
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0
  return AVATAR_COLORS[Math.abs(h) % AVATAR_COLORS.length]
}

function getInitials(name: string | null, username: string | null): string {
  if (name) return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
  if (username) return username[0].toUpperCase()
  return '?'
}

function formatEventDate(starts_at: string): string {
  const d = new Date(starts_at)
  return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })
}

function formatEventTime(starts_at: string): string {
  return new Date(starts_at)
    .toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
    .replace(':00', '')
    .toLowerCase()
}

// ─── Types ────────────────────────────────────────────────────────────────────

type Tab = 'upcoming' | 'hosting' | 'past'

interface PlanEvent {
  id: string
  title: string
  starts_at: string
  ends_at: string | null
  location: string
  location_text: string | null
  attendee_count: number
  creator_id: string
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function MyPlansScreen() {
  const router = useRouter()
  const { colors } = useTheme()
  const { user } = useAuth()

  const [activeTab, setActiveTab] = useState<Tab>('upcoming')
  const [events, setEvents] = useState<PlanEvent[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  const fetchPlans = useCallback(async (refresh = false) => {
    if (!user) return
    if (refresh) setRefreshing(true)
    else setLoading(true)

    const now = new Date().toISOString()

    if (activeTab === 'hosting') {
      const { data } = await supabase
        .from('events')
        .select('id, title, starts_at, ends_at, location, location_text, attendee_count, creator_id')
        .eq('creator_id', user.id)
        .order('starts_at', { ascending: true })
        .limit(50)
      setEvents((data ?? []) as PlanEvent[])
    } else if (activeTab === 'past') {
      const { data } = await supabase
        .from('event_attendees')
        .select('events(id, title, starts_at, ends_at, location, location_text, attendee_count, creator_id)')
        .eq('user_id', user.id)
        .eq('status', 'going')

      const pastEvents = (data ?? [])
        .map(r => (r as any).events)
        .filter(e => e && new Date(e.starts_at) < new Date())
        .sort((a: any, b: any) => new Date(b.starts_at).getTime() - new Date(a.starts_at).getTime())
      setEvents(pastEvents as PlanEvent[])
    } else {
      const { data } = await supabase
        .from('event_attendees')
        .select('events(id, title, starts_at, ends_at, location, location_text, attendee_count, creator_id)')
        .eq('user_id', user.id)
        .eq('status', 'going')

      const upcoming = (data ?? [])
        .map(r => (r as any).events)
        .filter(e => e && new Date(e.starts_at) >= new Date())
        .sort((a: any, b: any) => new Date(a.starts_at).getTime() - new Date(b.starts_at).getTime())
      setEvents(upcoming as PlanEvent[])
    }

    setLoading(false)
    setRefreshing(false)
  }, [user, activeTab])

  useEffect(() => { fetchPlans() }, [fetchPlans])

  const renderEvent = ({ item }: { item: PlanEvent }) => {
    const pal = CARD_PALETTES[getPaletteIndex(item.id)]
    const isPast = new Date(item.starts_at) < new Date()
    const isCreator = item.creator_id === user?.id

    return (
      <Pressable
        onPress={() => { Haptics.selectionAsync(); router.push(`/event/${item.id}` as any) }}
        style={[styles.eventCard, { backgroundColor: pal.bg, opacity: isPast ? 0.7 : 1 }]}
      >
        <View style={styles.cardContent}>
          <View style={[styles.dateBadge, { backgroundColor: pal.accent + '28' }]}>
            <Text style={[styles.dateBadgeText, { color: pal.accent }]}>
              {formatEventDate(item.starts_at)}
            </Text>
          </View>
          <Text style={[styles.eventTitle, { color: pal.text }]} numberOfLines={1}>
            {item.title}
          </Text>
          <View style={styles.eventMeta}>
            <Ionicons name="time-outline" size={11} color={pal.sub} />
            <Text style={[styles.eventMetaText, { color: pal.sub }]}>{formatEventTime(item.starts_at)}</Text>
            <Ionicons name="location-outline" size={11} color={pal.sub} style={{ marginLeft: Spacing.sm }} />
            <Text style={[styles.eventMetaText, { color: pal.sub }]} numberOfLines={1}>
              {item.location_text || item.location}
            </Text>
          </View>
          <View style={styles.eventBottom}>
            <Text style={[styles.goingCount, { color: pal.sub }]}>
              {item.attendee_count} going
            </Text>
            {isCreator && (
              <Pressable
                onPress={(e) => {
                  e.stopPropagation()
                  Haptics.selectionAsync()
                  router.push(`/event-attendees/${item.id}` as any)
                }}
                style={[styles.managePill, { backgroundColor: pal.accent + '28' }]}
              >
                <Ionicons name="people-outline" size={11} color={pal.accent} />
                <Text style={[styles.managePillText, { color: pal.accent }]}>Manage</Text>
              </Pressable>
            )}
          </View>
        </View>
        <Ionicons name="chevron-forward" size={16} color={pal.sub} />
      </Pressable>
    )
  }

  const TABS: { key: Tab; label: string }[] = [
    { key: 'upcoming', label: 'Upcoming' },
    { key: 'hosting', label: 'Hosting' },
    { key: 'past', label: 'Past' },
  ]

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
        <Pressable onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.contentPrimary }]}>My Plans</Text>
        <Pressable
          onPress={() => { Haptics.selectionAsync(); router.push('/create-event' as any) }}
          style={styles.headerAction}
        >
          <Ionicons name="add" size={22} color={colors.contentPrimary} />
        </Pressable>
      </View>

      {/* Tabs */}
      <View style={[styles.tabBar, { borderBottomColor: colors.borderSecondary }]}>
        {TABS.map(tab => (
          <Pressable
            key={tab.key}
            onPress={() => { Haptics.selectionAsync(); setActiveTab(tab.key) }}
            style={[
              styles.tab,
              activeTab === tab.key && { borderBottomColor: colors.contentPrimary, borderBottomWidth: 2 },
            ]}
          >
            <Text style={[
              styles.tabText,
              { color: activeTab === tab.key ? colors.contentPrimary : colors.contentTertiary },
              activeTab === tab.key && { fontWeight: '600' },
            ]}>
              {tab.label}
            </Text>
          </Pressable>
        ))}
      </View>

      {loading ? (
        <View style={styles.centered}>
          <ActivityIndicator color={colors.contentTertiary} />
        </View>
      ) : (
        <FlatList
          data={events}
          keyExtractor={item => item.id}
          renderItem={renderEvent}
          contentContainerStyle={styles.list}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => fetchPlans(true)}
              tintColor={colors.contentTertiary}
            />
          }
          ListEmptyComponent={
            <View style={styles.empty}>
              <Ionicons
                name={activeTab === 'hosting' ? 'megaphone-outline' : activeTab === 'past' ? 'time-outline' : 'calendar-outline'}
                size={48}
                color={colors.contentTertiary}
              />
              <Text style={[styles.emptyTitle, { color: colors.contentPrimary }]}>
                {activeTab === 'upcoming' ? 'No upcoming plans' : activeTab === 'hosting' ? "You haven't hosted any events" : 'No past events'}
              </Text>
              <Text style={[styles.emptySub, { color: colors.contentSecondary }]}>
                {activeTab === 'upcoming'
                  ? 'Browse events on the home screen or create your own.'
                  : activeTab === 'hosting'
                  ? 'Create an event and invite people to join.'
                  : 'Events you attend will show up here.'}
              </Text>
              {activeTab !== 'past' && (
                <Pressable
                  onPress={() => { Haptics.selectionAsync(); router.push('/create-event' as any) }}
                  style={[styles.emptyBtn, { backgroundColor: colors.contentPrimary }]}
                >
                  <Text style={[styles.emptyBtnText, { color: colors.contentInverse }]}>+ Create a plan</Text>
                </Pressable>
              )}
            </View>
          }
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  )
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backButton: { width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },
  headerTitle: { flex: 1, fontSize: Typography.headline, fontWeight: '700', marginLeft: Spacing.sm },
  headerAction: { width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },

  tabBar: {
    flexDirection: 'row',
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  tab: {
    flex: 1,
    paddingVertical: Spacing.md,
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  tabText: { fontSize: Typography.callout },

  list: {
    padding: Spacing.base,
    gap: Spacing.sm,
    paddingBottom: 100,
  },

  eventCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: BorderRadius.xl,
    padding: Spacing.base,
    gap: Spacing.md,
  },
  cardContent: { flex: 1, gap: Spacing.xs },
  dateBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: Spacing.sm,
    paddingVertical: 3,
    borderRadius: BorderRadius.sm,
  },
  dateBadgeText: { fontSize: Typography.caption, fontWeight: '700' },
  eventTitle: { fontSize: Typography.body, fontWeight: '700' },
  eventMeta: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  eventMetaText: { fontSize: Typography.caption },
  eventBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: Spacing.xs,
  },
  goingCount: { fontSize: Typography.caption },
  managePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 3,
    borderRadius: BorderRadius.full,
  },
  managePillText: { fontSize: Typography.caption, fontWeight: '600' },

  empty: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: Spacing.md,
    paddingVertical: Spacing.xxl * 2,
    paddingHorizontal: Spacing.xl,
  },
  emptyTitle: { fontSize: Typography.headline, fontWeight: '600' },
  emptySub: { fontSize: Typography.callout, textAlign: 'center', lineHeight: Typography.callout * 1.5 },
  emptyBtn: {
    marginTop: Spacing.sm,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.full,
  },
  emptyBtnText: { fontSize: Typography.callout, fontWeight: '600' },
})
