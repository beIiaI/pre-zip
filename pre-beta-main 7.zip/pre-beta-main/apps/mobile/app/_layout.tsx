import { Slot, SplashScreen, useRouter } from 'expo-router'
import { StatusBar } from 'expo-status-bar'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { AuthProvider } from '@/contexts/AuthContext'
import { ThemeProvider, useTheme } from '@/contexts/ThemeContext'
import { useEffect, useRef } from 'react'
import { View } from 'react-native'
import { GestureHandlerRootView } from 'react-native-gesture-handler'
import * as SystemUI from 'expo-system-ui'
import * as Notifications from 'expo-notifications'
import { validateApiConfig, getApiBaseUrl } from '@/lib/api'
import { ConfigErrorScreen } from '@/components/ui/ConfigErrorScreen'

// ─── Foreground notification behaviour ──────────────────────────────────────
// Show banner + badge + sound even when the app is in the foreground.
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
})

// Prevent splash screen from auto-hiding
SplashScreen.preventAutoHideAsync()

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 5 * 60 * 1000, // 5 minutes
    },
  },
})

function RootLayoutContent() {
  const { colors, isDark } = useTheme()
  const router = useRouter()
  const responseListener = useRef<Notifications.Subscription>()

  // Check for configuration errors
  const configValidation = validateApiConfig()

  useEffect(() => {
    // Set system UI colors
    SystemUI.setBackgroundColorAsync(colors.surfacePrimary)
  }, [colors.surfacePrimary])

  useEffect(() => {
    // Hide splash screen once layout is ready
    const timer = setTimeout(() => {
      SplashScreen.hideAsync()
    }, 100)
    return () => clearTimeout(timer)
  }, [])

  // ─── Tap-to-navigate: when the user taps a push notification ──────────────
  useEffect(() => {
    // Handle notification that was tapped while app was killed / backgrounded
    Notifications.getLastNotificationResponseAsync().then((response) => {
      if (response) {
        navigateFromNotification(response.notification.request.content.data)
      }
    })

    // Handle notification taps while app is running
    responseListener.current = Notifications.addNotificationResponseReceivedListener(
      (response) => {
        navigateFromNotification(response.notification.request.content.data)
      },
    )

    return () => {
      if (responseListener.current) {
        Notifications.removeNotificationSubscription(responseListener.current)
      }
    }
  }, [])

  const navigateFromNotification = (data: Record<string, any> | undefined) => {
    if (!data) return
    if (data.thread_id) router.push(`/conversation/${data.thread_id}` as any)
    else if (data.circle_id) router.push(`/circle/${data.circle_id}` as any)
    else if (data.event_id) router.push(`/event/${data.event_id}` as any)
    else if (data.user_id) router.push(`/user/${data.user_id}` as any)
    else router.push('/notifications' as any)
  }

  // Show config error screen if validation fails
  if (!configValidation.valid) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.surfacePrimary }}>
        <StatusBar style={isDark ? 'light' : 'dark'} />
        <ConfigErrorScreen error={configValidation.error!} apiUrl={getApiBaseUrl()} />
      </View>
    )
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.surfacePrimary }}>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <Slot />
    </View>
  )
}

export default function RootLayout() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <QueryClientProvider client={queryClient}>
        <ThemeProvider>
          <AuthProvider>
            <RootLayoutContent />
          </AuthProvider>
        </ThemeProvider>
      </QueryClientProvider>
    </GestureHandlerRootView>
  )
}
