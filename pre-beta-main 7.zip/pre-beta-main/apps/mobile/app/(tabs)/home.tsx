import React, { useState, useCallback, useEffect } from 'react'
import {
  View,
  Text,
  ScrollView,
  Pressable,
  StyleSheet,
  RefreshControl,
  ActivityIndicator,
  Image,
  FlatList,
  Dimensions,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { PreWordmark } from '@/components/ui/PreWordmark'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

// ─── Card palettes ────────────────────────────────────────────────────────────

const CARD_PALETTES = [
  { bg: '#3D1F0F', text: '#F5E6D8', accent: '#D4845A', sub: '#9A6644' },
  { bg: '#0F1E3D', text: '#D8E6F5', accent: '#5A84D4', sub: '#4464A0' },
  { bg: '#0F3D1F', text: '#D8F5E6', accent: '#5AD484', sub: '#44A064' },
  { bg: '#2A0F3D', text: '#EDD8F5', accent: '#A45AD4', sub: '#7A44A0' },
  { bg: '#0F3A3A', text: '#D8F5F5', accent: '#5AD4C4', sub: '#44A0A0' },
  { bg: '#3D300F', text: '#F5EED8', accent: '#D4B45A', sub: '#A08844' },
]

const AVATAR_COLORS = ['#C45A7A', '#5A7AC4', '#5AC47A', '#C4A45A', '#7A5AC4', '#C45AC4']

function getPaletteIndex(id: string): number {
  let h = 0
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0
  return Math.abs(h) % CARD_PALETTES.length
}

function getAvatarColor(id: string): string {
  let h = 0
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0
  return AVATAR_COLORS[Math.abs(h) % AVATAR_COLORS.length]
}

function getInitials(name: string | null, username: string | null): string {
  if (name) return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
  if (username) return username[0].toUpperCase()
  return '?'
}

function formatEventTime(starts_at: string): string {
  const d = new Date(starts_at)
  const day = d.toLocaleDateString('en-US', { weekday: 'short' })
  const time = d
    .toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
    .replace(':00', '')
    .toLowerCase()
  return `${day} · ${time}`
}

function formatDayShort(starts_at: string): string {
  const d = new Date(starts_at)
  const now = new Date()
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  const eventDay = new Date(d.getFullYear(), d.getMonth(), d.getDate())
  const diffDays = Math.round((eventDay.getTime() - todayStart.getTime()) / 86_400_000)
  if (diffDays <= 0) return 'Today'
  if (diffDays === 1) return 'Tomorrow'
  return d.toLocaleDateString('en-US', { weekday: 'short' })
}

function formatTimeShort(starts_at: string): string {
  return new Date(starts_at)
    .toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
    .replace(':00', '')
    .toLowerCase()
}

function getGreeting(): string {
  const h = new Date().getHours()
  if (h < 12) return 'Good morning'
  if (h < 17) return 'Good afternoon'
  return 'Good evening'
}

// ─── Types ────────────────────────────────────────────────────────────────────

interface AttendeePreview {
  user_id: string
  initials: string
  avatar_url: string | null
}

interface HomeEvent {
  id: string
  title: string
  description: string | null
  starts_at: string
  ends_at: string | null
  location: string
  location_text: string | null
  attendee_count: number
  is_public: boolean
  host_id: string | null
  creator_id: string
  attendeePreviews: AttendeePreview[]
}

// ─── Notification badge hook ──────────────────────────────────────────────────

function useUnreadNotifCount(userId: string | undefined) {
  const [count, setCount] = useState(0)
  const fetch = useCallback(async () => {
    if (!userId) return
    const { count: c } = await supabase
      .from('notifications')
      .select('id', { count: 'exact', head: true })
      .eq('user_id', userId)
      .eq('read', false)
    setCount(Math.min(c ?? 0, 99))
  }, [userId])
  useEffect(() => { fetch() }, [fetch])
  useEffect(() => {
    if (!userId) return
    const ch = supabase
      .channel(`notif-badge-home:${userId}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${userId}` }, fetch)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'notifications', filter: `user_id=eq.${userId}` }, fetch)
      .subscribe()
    return () => { supabase.removeChannel(ch) }
  }, [userId, fetch])
  return count
}

const { width: SCREEN_WIDTH } = Dimensions.get('window')
const YOUR_PLAN_CARD_WIDTH = SCREEN_WIDTH * 0.72

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function HomeScreen() {
  const router = useRouter()
  const { colors } = useTheme()
  const { user, profile } = useAuth()
  const unreadNotifs = useUnreadNotifCount(user?.id)

  const [discoverEvents, setDiscoverEvents] = useState<HomeEvent[]>([])
  const [myPlans, setMyPlans] = useState<HomeEvent[]>([])
  const [goingIds, setGoingIds] = useState<Set<string>>(new Set())
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  const fetchData = useCallback(async (refresh = false) => {
    if (refresh) setRefreshing(true)
    else setLoading(true)

    const now = new Date()
    const weekEnd = new Date(now)
    weekEnd.setDate(now.getDate() + 7)

    // Fetch all public events this week
    const { data: eventsData } = await supabase
      .from('events')
      .select('id, title, description, starts_at, ends_at, location, location_text, attendee_count, is_public, host_id, creator_id')
      .eq('is_public', true)
      .gte('starts_at', now.toISOString())
      .lte('starts_at', weekEnd.toISOString())
      .order('starts_at', { ascending: true })
      .limit(20)

    const eventIds = (eventsData ?? []).map(e => e.id)

    // Fetch attendee previews and user's RSVPs
    const [attendeesRes, goingRes] = await Promise.all([
      eventIds.length > 0
        ? supabase
            .from('event_attendees')
            .select('event_id, user_id, profiles(full_name, username, avatar_url)')
            .in('event_id', eventIds)
            .eq('status', 'going')
            .limit(100)
        : Promise.resolve({ data: [] }),
      user && eventIds.length > 0
        ? supabase
            .from('event_attendees')
            .select('event_id')
            .eq('user_id', user.id)
            .in('event_id', eventIds)
            .eq('status', 'going')
        : Promise.resolve({ data: [] }),
    ])

    // Also fetch user's upcoming plans (may include events outside this week's public list)
    let myPlanEvents: any[] = []
    if (user) {
      const { data: myRsvps } = await supabase
        .from('event_attendees')
        .select('event_id, events(id, title, description, starts_at, ends_at, location, location_text, attendee_count, is_public, host_id, creator_id)')
        .eq('user_id', user.id)
        .eq('status', 'going')

      if (myRsvps) {
        myPlanEvents = myRsvps
          .map(r => (r as any).events)
          .filter(e => e && new Date(e.starts_at) >= now)
          .sort((a: any, b: any) => new Date(a.starts_at).getTime() - new Date(b.starts_at).getTime())
      }
    }

    const byEvent: Record<string, AttendeePreview[]> = {}
    for (const row of (attendeesRes.data as any[]) ?? []) {
      if (!byEvent[row.event_id]) byEvent[row.event_id] = []
      if (byEvent[row.event_id].length < 5) {
        byEvent[row.event_id].push({
          user_id: row.user_id,
          initials: getInitials(row.profiles?.full_name ?? null, row.profiles?.username ?? null),
          avatar_url: row.profiles?.avatar_url ?? null,
        })
      }
    }

    const currentGoingIds = new Set<string>()
    if (goingRes.data && user) {
      for (const r of goingRes.data as any[]) currentGoingIds.add(r.event_id)
    }
    for (const e of myPlanEvents) {
      if (e?.id) currentGoingIds.add(e.id)
    }
    setGoingIds(currentGoingIds)

    if (eventsData) {
      setDiscoverEvents(eventsData.map(e => ({
        ...(e as any),
        ends_at: (e as any).ends_at ?? null,
        attendeePreviews: byEvent[e.id] ?? [],
      })))
    }

    // Build my plans with attendee previews
    if (myPlanEvents.length > 0) {
      const myPlanIds = myPlanEvents.map((e: any) => e.id)
      const { data: myPlanAttendees } = await supabase
        .from('event_attendees')
        .select('event_id, user_id, profiles(full_name, username, avatar_url)')
        .in('event_id', myPlanIds)
        .eq('status', 'going')
        .limit(50)

      const myPlanByEvent: Record<string, AttendeePreview[]> = {}
      for (const row of (myPlanAttendees as any[]) ?? []) {
        if (!myPlanByEvent[row.event_id]) myPlanByEvent[row.event_id] = []
        if (myPlanByEvent[row.event_id].length < 5) {
          myPlanByEvent[row.event_id].push({
            user_id: row.user_id,
            initials: getInitials(row.profiles?.full_name ?? null, row.profiles?.username ?? null),
            avatar_url: row.profiles?.avatar_url ?? null,
          })
        }
      }

      setMyPlans(myPlanEvents.map((e: any) => ({
        ...e,
        ends_at: e.ends_at ?? null,
        attendeePreviews: myPlanByEvent[e.id] ?? byEvent[e.id] ?? [],
      })))
    } else {
      setMyPlans([])
    }

    setLoading(false)
    setRefreshing(false)
  }, [user])

  useEffect(() => { fetchData() }, [fetchData])

  const handleRsvp = useCallback(async (eventId: string) => {
    if (!user) return
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)
    const isGoing = goingIds.has(eventId)
    const userInitials = getInitials(profile?.full_name ?? null, profile?.username ?? null)

    if (isGoing) {
      setGoingIds(prev => { const n = new Set(prev); n.delete(eventId); return n })
      setDiscoverEvents(prev => prev.map(e =>
        e.id === eventId
          ? { ...e, attendee_count: Math.max(0, e.attendee_count - 1), attendeePreviews: e.attendeePreviews.filter(a => a.user_id !== user.id) }
          : e
      ))
      setMyPlans(prev => prev.filter(e => e.id !== eventId))
      await supabase.from('event_attendees').delete().match({ event_id: eventId, user_id: user.id })
    } else {
      setGoingIds(prev => new Set([...prev, eventId]))
      setDiscoverEvents(prev => prev.map(e => {
        if (e.id !== eventId) return e
        const alreadyIn = e.attendeePreviews.some(a => a.user_id === user.id)
        return {
          ...e,
          attendee_count: e.attendee_count + 1,
          attendeePreviews: alreadyIn
            ? e.attendeePreviews
            : [{ user_id: user.id, initials: userInitials, avatar_url: profile?.avatar_url ?? null }, ...e.attendeePreviews].slice(0, 5),
        }
      }))
      const joinedEvent = discoverEvents.find(e => e.id === eventId)
      if (joinedEvent) {
        setMyPlans(prev => {
          const updated = [...prev, { ...joinedEvent, attendee_count: joinedEvent.attendee_count + 1 }]
          return updated.sort((a, b) => new Date(a.starts_at).getTime() - new Date(b.starts_at).getTime())
        })
      }
      await supabase.from('event_attendees').upsert(
        { event_id: eventId, user_id: user.id, status: 'going' },
        { onConflict: 'event_id,user_id' }
      )
    }
  }, [user, goingIds, profile, discoverEvents])

  const firstName = profile?.full_name?.split(' ')[0] ?? ''
  const userInitialsDisplay = getInitials(profile?.full_name ?? null, profile?.username ?? null)
  const userAvatarColor = user ? getAvatarColor(user.id) : '#888'
  const greeting = getGreeting()
  const discoverEventsFiltered = discoverEvents.filter(e => !goingIds.has(e.id))

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>

      {/* Header */}
      <View style={styles.header}>
        <PreWordmark size="small" color={colors.contentPrimary} />
        <View style={styles.headerRight}>
          <Pressable
            onPress={() => { Haptics.selectionAsync(); router.push('/(tabs)/search' as any) }}
            style={[styles.headerCircleBtn, { backgroundColor: colors.surfaceSecondary }]}
          >
            <Ionicons name="search-outline" size={17} color={colors.contentPrimary} />
          </Pressable>
          <Pressable
            onPress={() => { Haptics.selectionAsync(); router.push('/(tabs)/messages' as any) }}
            style={[styles.headerCircleBtn, { backgroundColor: colors.surfaceSecondary }]}
          >
            <Ionicons name="chatbubble-outline" size={16} color={colors.contentPrimary} />
          </Pressable>
          <Pressable
            onPress={() => router.push('/notifications' as any)}
            style={[styles.headerCircleBtn, { backgroundColor: colors.surfaceSecondary }]}
          >
            <Ionicons name="notifications-outline" size={17} color={colors.contentPrimary} />
            {unreadNotifs > 0 && (
              <View style={[styles.notifPip, { backgroundColor: colors.contentPrimary }]} />
            )}
          </Pressable>
        </View>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => fetchData(true)}
            tintColor={colors.contentTertiary}
          />
        }
      >
        {/* Greeting */}
        <View style={styles.greetingSection}>
          <Pressable
            onPress={() => router.push('/(tabs)/profile' as any)}
            style={[styles.greetingAvatar, { backgroundColor: userAvatarColor }]}
          >
            {profile?.avatar_url ? (
              <Image source={{ uri: profile.avatar_url }} style={StyleSheet.absoluteFillObject} />
            ) : (
              <Text style={styles.greetingAvatarText}>{userInitialsDisplay}</Text>
            )}
          </Pressable>
          <View style={styles.greetingTextWrap}>
            <Text style={[styles.greetingLine, { color: colors.contentTertiary }]}>{greeting}</Text>
            <Text style={[styles.greetingName, { color: colors.contentPrimary }]}>
              {firstName || 'there'}
            </Text>
          </View>
        </View>

        {loading ? (
          <View style={styles.centered}>
            <ActivityIndicator color={colors.contentTertiary} />
          </View>
        ) : (
          <>
            {/* ─── YOUR PLANS ──────────────────────────────────────────── */}
            <View style={styles.sectionRow}>
              <Text style={[styles.sectionLabel, { color: colors.contentTertiary }]}>YOUR PLANS</Text>
              {myPlans.length > 0 && (
                <Pressable
                  onPress={() => { Haptics.selectionAsync(); router.push('/my-plans' as any) }}
                  style={styles.seeAllBtn}
                >
                  <Text style={[styles.seeAllText, { color: colors.contentTertiary }]}>See all</Text>
                  <Ionicons name="chevron-forward" size={12} color={colors.contentTertiary} />
                </Pressable>
              )}
            </View>

            {myPlans.length === 0 ? (
              <View style={[styles.emptyPlans, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
                <Ionicons name="calendar-outline" size={28} color={colors.contentTertiary} />
                <Text style={[styles.emptyPlansTitle, { color: colors.contentPrimary }]}>No upcoming plans</Text>
                <Text style={[styles.emptyPlansBody, { color: colors.contentSecondary }]}>
                  Join an event below or create your own
                </Text>
              </View>
            ) : (
              <FlatList
                data={myPlans.slice(0, 6)}
                keyExtractor={item => `plan-${item.id}`}
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.plansList}
                snapToInterval={YOUR_PLAN_CARD_WIDTH + Spacing.sm}
                decelerationRate="fast"
                renderItem={({ item }) => {
                  const pal = CARD_PALETTES[getPaletteIndex(item.id)]
                  return (
                    <Pressable
                      onPress={() => { Haptics.selectionAsync(); router.push(`/event/${item.id}` as any) }}
                      style={[styles.planCard, { backgroundColor: pal.bg, width: YOUR_PLAN_CARD_WIDTH }]}
                    >
                      <View style={styles.planCardHeader}>
                        <View style={[styles.planDayBadge, { backgroundColor: pal.accent + '28' }]}>
                          <Text style={[styles.planDayText, { color: pal.accent }]}>
                            {formatDayShort(item.starts_at)}
                          </Text>
                        </View>
                        <Text style={[styles.planTimeText, { color: pal.sub }]}>
                          {formatTimeShort(item.starts_at)}
                        </Text>
                      </View>
                      <Text style={[styles.planTitle, { color: pal.text }]} numberOfLines={2}>
                        {item.title}
                      </Text>
                      <View style={styles.planLocationRow}>
                        <Ionicons name="location-outline" size={11} color={pal.sub} />
                        <Text style={[styles.planLocationText, { color: pal.sub }]} numberOfLines={1}>
                          {item.location_text || item.location}
                        </Text>
                      </View>
                      <View style={styles.planBottom}>
                        <View style={styles.planAvatars}>
                          {item.attendeePreviews.slice(0, 4).map((a, idx) => (
                            <View
                              key={a.user_id}
                              style={[
                                styles.planAvatarDot,
                                { backgroundColor: getAvatarColor(a.user_id), marginLeft: idx > 0 ? -6 : 0 },
                              ]}
                            >
                              {a.avatar_url ? (
                                <Image source={{ uri: a.avatar_url }} style={{ width: 22, height: 22, borderRadius: 11 }} />
                              ) : (
                                <Text style={styles.planAvatarInitial}>{a.initials[0]}</Text>
                              )}
                            </View>
                          ))}
                        </View>
                        <Text style={[styles.planGoingCount, { color: pal.sub }]}>
                          {item.attendee_count} going
                        </Text>
                      </View>
                    </Pressable>
                  )
                }}
              />
            )}

            {/* ─── THIS WEEK ──────────────────────────────────────────── */}
            <View style={styles.sectionRow}>
              <Text style={[styles.sectionLabel, { color: colors.contentTertiary }]}>THIS WEEK</Text>
              <Pressable
                onPress={() => { Haptics.selectionAsync(); router.push('/create-event' as any) }}
                style={styles.planBtn}
              >
                <Ionicons name="add" size={12} color={colors.contentTertiary} />
                <Text style={[styles.planBtnText, { color: colors.contentTertiary }]}>Plan</Text>
              </Pressable>
            </View>

            {discoverEventsFiltered.length === 0 && discoverEvents.length === 0 ? (
              <View style={styles.emptyState}>
                <Text style={[styles.emptyTitle, { color: colors.contentPrimary }]}>Nothing this week</Text>
                <Text style={[styles.emptyBody, { color: colors.contentSecondary }]}>
                  Plans will show up here. Create one to get started.
                </Text>
                <Pressable
                  onPress={() => { Haptics.selectionAsync(); router.push('/create-event' as any) }}
                  style={[styles.emptyAction, { backgroundColor: colors.contentPrimary }]}
                >
                  <Text style={[styles.emptyActionText, { color: colors.contentInverse }]}>+ Create a plan</Text>
                </Pressable>
              </View>
            ) : discoverEventsFiltered.length === 0 ? (
              <View style={[styles.emptyPlans, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
                <Ionicons name="checkmark-circle-outline" size={28} color={colors.success} />
                <Text style={[styles.emptyPlansTitle, { color: colors.contentPrimary }]}>You've seen everything</Text>
                <Text style={[styles.emptyPlansBody, { color: colors.contentSecondary }]}>
                  You've joined all this week's events. Nice!
                </Text>
              </View>
            ) : (
              <View style={styles.cardList}>
                {discoverEventsFiltered.map(event => {
                  const pal = CARD_PALETTES[getPaletteIndex(event.id)]
                  return (
                    <Pressable
                      key={event.id}
                      onPress={() => { Haptics.selectionAsync(); router.push(`/event/${event.id}` as any) }}
                      style={[styles.eventCard, { backgroundColor: pal.bg }]}
                    >
                      <View style={styles.cardTop}>
                        <View style={[styles.iconBox, { backgroundColor: pal.accent + '28' }]}>
                          <View style={[styles.iconDot, { backgroundColor: pal.accent }]} />
                        </View>
                        <View style={styles.cardInfo}>
                          <Text style={[styles.cardTitle, { color: pal.text }]} numberOfLines={1}>
                            {event.title}
                          </Text>
                          <View style={styles.cardMetaRow}>
                            <Ionicons name="location-outline" size={11} color={pal.sub} />
                            <Text style={[styles.cardMetaText, { color: pal.sub }]} numberOfLines={1}>
                              {(event.location_text || event.location)} · {formatEventTime(event.starts_at)}
                            </Text>
                          </View>
                        </View>
                        <Pressable
                          onPress={e => { e.stopPropagation(); handleRsvp(event.id) }}
                          style={[styles.joinPill, { borderColor: 'rgba(255,255,255,0.28)' }]}
                        >
                          <Text style={[styles.joinPillText, { color: pal.text }]}>Join</Text>
                        </Pressable>
                      </View>

                      <View style={styles.attendeeRow}>
                        {event.attendeePreviews.slice(0, 4).map((a, idx) => (
                          <View
                            key={a.user_id}
                            style={[
                              styles.attendeeDot,
                              { backgroundColor: getAvatarColor(a.user_id), marginLeft: idx > 0 ? -5 : 0 },
                            ]}
                          >
                            {a.avatar_url ? (
                              <Image source={{ uri: a.avatar_url }} style={{ width: 20, height: 20, borderRadius: 10 }} />
                            ) : (
                              <Text style={styles.attendeeInitial}>{a.initials[0]}</Text>
                            )}
                          </View>
                        ))}
                        <Text style={[styles.goingText, { color: pal.sub }]}>
                          {event.attendeePreviews.length > 0 ? '  ' : ''}{event.attendee_count} going
                        </Text>
                      </View>
                    </Pressable>
                  )
                })}
              </View>
            )}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  )
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1 },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
  },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  headerCircleBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  notifPip: {
    position: 'absolute',
    top: 9,
    right: 9,
    width: 6,
    height: 6,
    borderRadius: 3,
  },

  scrollContent: {
    paddingBottom: 110,
    gap: Spacing.base,
  },

  greetingSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    paddingHorizontal: Spacing.base,
    paddingTop: Spacing.xs,
  },
  greetingAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  greetingAvatarText: { fontSize: 16, fontWeight: '700', color: '#FFFFFF' },
  greetingTextWrap: { gap: 1 },
  greetingLine: { fontSize: Typography.caption },
  greetingName: { fontSize: Typography.headline, fontWeight: '700' },

  sectionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.base,
    paddingTop: Spacing.sm,
  },
  sectionLabel: {
    fontSize: Typography.labelCaps,
    fontWeight: '700',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  seeAllBtn: { flexDirection: 'row', alignItems: 'center', gap: 2 },
  seeAllText: { fontSize: Typography.caption },
  planBtn: { flexDirection: 'row', alignItems: 'center', gap: 2 },
  planBtnText: { fontSize: Typography.caption },

  centered: { paddingVertical: Spacing.xxl, alignItems: 'center' },

  emptyPlans: {
    marginHorizontal: Spacing.base,
    borderRadius: BorderRadius.lg,
    borderWidth: StyleSheet.hairlineWidth,
    padding: Spacing.lg,
    alignItems: 'center',
    gap: Spacing.sm,
  },
  emptyPlansTitle: { fontSize: Typography.callout, fontWeight: '600' },
  emptyPlansBody: { fontSize: Typography.caption, textAlign: 'center' },

  emptyState: {
    alignItems: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.xxl,
    paddingHorizontal: Spacing.xl,
  },
  emptyTitle: { fontSize: Typography.headline, fontWeight: '600' },
  emptyBody: { fontSize: Typography.callout, textAlign: 'center', lineHeight: Typography.callout * 1.5 },
  emptyAction: {
    marginTop: Spacing.sm,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.full,
  },
  emptyActionText: { fontSize: Typography.callout, fontWeight: '600' },

  plansList: {
    paddingHorizontal: Spacing.base,
    gap: Spacing.sm,
  },
  planCard: {
    borderRadius: BorderRadius.xl,
    padding: Spacing.base,
    gap: Spacing.sm,
  },
  planCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  planDayBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 3,
    borderRadius: BorderRadius.sm,
  },
  planDayText: { fontSize: Typography.caption, fontWeight: '700' },
  planTimeText: { fontSize: Typography.caption, fontWeight: '500' },
  planTitle: { fontSize: Typography.body, fontWeight: '700', lineHeight: Typography.body * 1.3 },
  planLocationRow: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  planLocationText: { fontSize: Typography.caption, flex: 1 },
  planBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: Spacing.xs,
  },
  planAvatars: { flexDirection: 'row', alignItems: 'center' },
  planAvatarDot: {
    width: 22,
    height: 22,
    borderRadius: 11,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(0,0,0,0.2)',
  },
  planAvatarInitial: { fontSize: 8, fontWeight: '700', color: '#FFFFFF' },
  planGoingCount: { fontSize: Typography.caption },

  cardList: { gap: Spacing.sm, paddingHorizontal: Spacing.base },

  eventCard: {
    borderRadius: BorderRadius.xl,
    padding: Spacing.base,
    gap: 10,
  },
  cardTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
  },
  iconBox: {
    width: 38,
    height: 38,
    borderRadius: BorderRadius.md,
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  cardInfo: { flex: 1, gap: 3 },
  cardTitle: { fontSize: Typography.callout, fontWeight: '600' },
  cardMetaRow: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  cardMetaText: { fontSize: Typography.caption, flex: 1 },

  joinPill: {
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
  joinPillText: { fontSize: Typography.caption, fontWeight: '600' },

  attendeeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: 38 + Spacing.md,
  },
  attendeeDot: {
    width: 20,
    height: 20,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  attendeeInitial: { fontSize: 8, fontWeight: '700', color: '#FFFFFF' },
  goingText: { fontSize: Typography.caption, marginLeft: Spacing.sm },
})
