import React from 'react'
import { View, Text, Pressable, StyleSheet } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

const OPTIONS = [
  {
    key: 'event',
    icon: 'calendar-outline' as const,
    title: 'New Plan',
    subtitle: 'Create an event for your circles',
    route: '/create-event',
  },
  {
    key: 'circle',
    icon: 'people-outline' as const,
    title: 'New Circle',
    subtitle: 'Start a group for your community',
    route: '/create-circle',
  },
]

export default function AddScreen() {
  const router = useRouter()
  const { colors } = useTheme()

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.contentPrimary }]}>Create</Text>
        <Text style={[styles.subtitle, { color: colors.contentSecondary }]}>
          What would you like to add?
        </Text>
      </View>

      <View style={styles.options}>
        {OPTIONS.map(opt => (
          <Pressable
            key={opt.key}
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)
              router.push(opt.route as any)
            }}
            style={[styles.optionCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}
          >
            <View style={[styles.optionIconBox, { backgroundColor: colors.surfaceElevated }]}>
              <Ionicons name={opt.icon} size={24} color={colors.contentPrimary} />
            </View>
            <View style={styles.optionText}>
              <Text style={[styles.optionTitle, { color: colors.contentPrimary }]}>{opt.title}</Text>
              <Text style={[styles.optionSub, { color: colors.contentSecondary }]}>{opt.subtitle}</Text>
            </View>
            <Ionicons name="chevron-forward" size={16} color={colors.contentTertiary} />
          </Pressable>
        ))}
      </View>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1 },

  header: {
    paddingHorizontal: Spacing.base,
    paddingTop: Spacing.lg,
    paddingBottom: Spacing.xl,
    gap: Spacing.xs,
  },
  title: { fontSize: Typography.title, fontWeight: '700' },
  subtitle: { fontSize: Typography.callout },

  options: {
    paddingHorizontal: Spacing.base,
    gap: Spacing.sm,
  },
  optionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.base,
    padding: Spacing.base,
    borderRadius: BorderRadius.lg,
    borderWidth: StyleSheet.hairlineWidth,
  },
  optionIconBox: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    justifyContent: 'center',
    alignItems: 'center',
  },
  optionText: { flex: 1, gap: 3 },
  optionTitle: { fontSize: Typography.callout, fontWeight: '600' },
  optionSub: { fontSize: Typography.caption, lineHeight: Typography.caption * 1.5 },
})
