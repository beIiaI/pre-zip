import { Tabs } from 'expo-router'
import { Platform, StyleSheet, View } from 'react-native'
import { BlurView } from 'expo-blur'
import { Ionicons } from '@expo/vector-icons'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { useEffect, useState, useCallback } from 'react'
import { supabase } from '@/lib/supabase'

type IoniconName = React.ComponentProps<typeof Ionicons>['name']

function TabIcon({
  name,
  focusedName,
  color,
  focused,
}: {
  name: IoniconName
  focusedName: IoniconName
  color: string
  focused: boolean
}) {
  return <Ionicons name={focused ? focusedName : name} size={22} color={color} />
}

function AddIcon({ color }: { color: string }) {
  return (
    <View style={{
      width: 30,
      height: 30,
      borderRadius: 8,
      borderWidth: 1.5,
      borderColor: color,
      justifyContent: 'center',
      alignItems: 'center',
    }}>
      <Ionicons name="add" size={18} color={color} />
    </View>
  )
}

// ─── Realtime unread counts ───────────────────────────────────────────────────

function useUnreadCounts(userId: string | undefined) {
  const [unreadMessages, setUnreadMessages] = useState(0)

  const fetchCounts = useCallback(async () => {
    if (!userId) return

    const [threadsRes, participationsRes] = await Promise.all([
      supabase
        .from('dm_threads')
        .select('id')
        .or(`user_a.eq.${userId},user_b.eq.${userId}`),
      supabase
        .from('dm_participants')
        .select('thread_id, last_read_at')
        .eq('user_id', userId),
    ])

    const threadIds = (threadsRes.data ?? []).map(t => t.id)
    if (threadIds.length === 0) { setUnreadMessages(0); return }

    const lastReadMap = new Map(
      (participationsRes.data ?? []).map(p => [p.thread_id, p.last_read_at])
    )

    const { data: unreadMsgs } = await supabase
      .from('dm_messages')
      .select('id, thread_id, sender_id, created_at')
      .in('thread_id', threadIds)
      .neq('sender_id', userId)

    let count = 0
    for (const msg of unreadMsgs ?? []) {
      const lastRead = lastReadMap.get(msg.thread_id)
      if (!lastRead || new Date(msg.created_at) > new Date(lastRead)) count++
    }
    setUnreadMessages(Math.min(count, 99))
  }, [userId])

  useEffect(() => { fetchCounts() }, [fetchCounts])

  useEffect(() => {
    if (!userId) return
    const channel = supabase
      .channel(`unread-badge:${userId}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'dm_messages' }, fetchCounts)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'dm_participants', filter: `user_id=eq.${userId}` }, fetchCounts)
      .subscribe()
    return () => { supabase.removeChannel(channel) }
  }, [userId, fetchCounts])

  return unreadMessages
}

// ─── Layout ───────────────────────────────────────────────────────────────────

export default function TabsLayout() {
  const { colors, isDark } = useTheme()
  const { user } = useAuth()
  const unreadMessages = useUnreadCounts(user?.id)
  const isIOS = Platform.OS === 'ios'

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.contentPrimary,
        tabBarInactiveTintColor: colors.contentTertiary,
        tabBarStyle: isIOS
          ? {
              position: 'absolute',
              backgroundColor: 'transparent',
              borderTopWidth: 0,
              elevation: 0,
            }
          : {
              backgroundColor: colors.surfacePrimary,
              borderTopColor: colors.borderSecondary,
              borderTopWidth: StyleSheet.hairlineWidth,
            },
        tabBarBackground: isIOS
          ? () => (
              <BlurView
                intensity={80}
                tint={isDark ? 'dark' : 'light'}
                style={StyleSheet.absoluteFill}
              />
            )
          : undefined,
        tabBarLabelStyle: { fontSize: 10, marginBottom: 2 },
        tabBarBadgeStyle: {
          backgroundColor: colors.contentPrimary,
          color: colors.contentInverse,
          fontSize: 10,
          minWidth: 16,
          height: 16,
          lineHeight: 16,
        },
      }}
    >
      {/* ── Visible tabs ── */}
      <Tabs.Screen
        name="home"
        options={{
          title: 'Home',
          tabBarIcon: ({ color, focused }) => (
            <TabIcon name="home-outline" focusedName="home" color={color} focused={focused} />
          ),
        }}
      />
      <Tabs.Screen
        name="circles"
        options={{
          title: 'Circles',
          tabBarIcon: ({ color, focused }) => (
            <TabIcon name="people-outline" focusedName="people" color={color} focused={focused} />
          ),
        }}
      />
      <Tabs.Screen
        name="add"
        options={{
          title: 'Add',
          tabBarIcon: ({ color }) => <AddIcon color={color} />,
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: 'Profile',
          tabBarIcon: ({ color, focused }) => (
            <TabIcon name="person-outline" focusedName="person" color={color} focused={focused} />
          ),
        }}
      />

      {/* ── Hidden from tab bar, still navigable ── */}
      <Tabs.Screen
        name="search"
        options={{ href: null }}
      />
      <Tabs.Screen
        name="messages"
        options={{
          href: null,
          tabBarBadge: unreadMessages > 0 ? unreadMessages : undefined,
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{ href: null }}
      />
    </Tabs>
  )
}
