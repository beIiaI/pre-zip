import { useEffect } from 'react'
import { Redirect, useRouter } from 'expo-router'
import { View, Text, ActivityIndicator, StyleSheet } from 'react-native'
import { useAuth } from '@/contexts/AuthContext'
import { useTheme } from '@/contexts/ThemeContext'

/**
 * Root index - auth gate and routing logic
 * Matches pre-beta behavior: splash → auth check → route to appropriate screen
 */
export default function Index() {
  const { user, profile, loading, initialized, profileLoaded } = useAuth()
  const { colors } = useTheme()
  const router = useRouter()

  // Wait for auth to initialize
  if (!initialized || loading || !profileLoaded) {
    return (
      <View style={[styles.container, { backgroundColor: colors.surfacePrimary }]}>
        <ActivityIndicator size="large" color={colors.contentPrimary} />
        <Text style={[styles.loadingText, { color: colors.contentSecondary }]}>
          Loading...
        </Text>
      </View>
    )
  }

  // Not authenticated → redirect to auth
  if (!user) {
    return <Redirect href="/auth/splash" />
  }

  // Authenticated but onboarding incomplete → redirect to onboarding
  if (!profile?.onboarding_completed) {
    return <Redirect href="/auth/onboarding" />
  }

  // Authenticated and onboarded → redirect to home
  return <Redirect href="/(tabs)/home" />
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    fontSize: 14,
    marginTop: 12,
  },
})
