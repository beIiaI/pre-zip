import { useEffect, useState } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native'
import { useRouter, useLocalSearchParams } from 'expo-router'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useTheme } from '@/contexts/ThemeContext'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { PreWordmark } from '@/components/ui/PreWordmark'
import { validatePassword } from '@/utils/validation'
import { supabase } from '@/lib/supabase'
import { Spacing, Typography } from '@/constants/theme'

/**
 * Password Reset screen
 * Handles deep link from password reset email
 * Matches pre-beta /auth/reset
 */
export default function ResetPasswordScreen() {
  const router = useRouter()
  const params = useLocalSearchParams()
  const { colors } = useTheme()

  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  // Check for recovery token in URL params
  useEffect(() => {
    const checkSession = async () => {
      const { data: { session } } = await supabase.auth.getSession()
      if (!session) {
        setError('Password reset link is invalid or expired. Please request a new one.')
      }
    }
    checkSession()
  }, [params])

  const handleResetPassword = async () => {
    setError(null)
    setSuccess(null)

    const passwordValidation = validatePassword(password)
    if (!passwordValidation.valid) {
      setError(passwordValidation.error || 'Invalid password')
      return
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match')
      return
    }

    setLoading(true)

    const { error: updateError } = await supabase.auth.updateUser({
      password: password,
    })

    if (updateError) {
      setError(updateError.message || 'Failed to update password')
      setLoading(false)
    } else {
      setSuccess('Password updated successfully!')
      setTimeout(() => {
        router.replace('/(tabs)/home')
      }, 2000)
      setLoading(false)
    }
  }

  const passwordChecks = {
    length: password.length >= 8,
    lower: /[a-z]/.test(password),
    upper: /[A-Z]/.test(password),
    number: /[0-9]/.test(password),
    symbol: /[^A-Za-z0-9]/.test(password),
  }

  return (
    <SafeAreaView
      style={[styles.container, { backgroundColor: colors.surfacePrimary }]}
      edges={['top', 'bottom']}
    >
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.header}>
            <PreWordmark size="medium" color={colors.contentPrimary} />
          </View>

          <View style={styles.content}>
            <View style={styles.titleSection}>
              <Text style={[styles.title, { color: colors.contentPrimary }]}>
                Reset Password
              </Text>
              <Text style={[styles.subtitle, { color: colors.contentSecondary }]}>
                Enter your new password
              </Text>
            </View>

            {error && (
              <View style={[styles.alert, { backgroundColor: colors.error + '15', borderColor: colors.error }]}>
                <Text style={[styles.alertText, { color: colors.error }]}>
                  {error}
                </Text>
              </View>
            )}

            {success && (
              <View style={[styles.alert, { backgroundColor: colors.success + '15', borderColor: colors.success }]}>
                <Text style={[styles.alertText, { color: colors.success }]}>
                  {success}
                </Text>
              </View>
            )}

            <View style={styles.form}>
              <Input
                label="New Password"
                placeholder="••••••••"
                value={password}
                onChangeText={setPassword}
                secureTextEntry
                showPasswordToggle
                textContentType="newPassword"
              />

              <Input
                label="Confirm New Password"
                placeholder="••••••••"
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                secureTextEntry
                showPasswordToggle
                textContentType="newPassword"
              />

              <View style={[styles.passwordChecks, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
                <Text style={[styles.passwordChecksTitle, { color: colors.contentSecondary }]}>
                  Password must include:
                </Text>
                {[
                  { label: 'At least 8 characters', ok: passwordChecks.length },
                  { label: 'One lowercase letter', ok: passwordChecks.lower },
                  { label: 'One uppercase letter', ok: passwordChecks.upper },
                  { label: 'One number', ok: passwordChecks.number },
                  { label: 'One symbol', ok: passwordChecks.symbol },
                ].map((rule) => (
                  <View key={rule.label} style={styles.passwordCheck}>
                    <Text
                      style={[
                        styles.passwordCheckText,
                        { color: rule.ok ? colors.success : colors.contentTertiary },
                      ]}
                    >
                      {rule.ok ? '✓' : '○'} {rule.label}
                    </Text>
                  </View>
                ))}
              </View>

              <Button
                onPress={handleResetPassword}
                loading={loading}
                disabled={loading}
                fullWidth
              >
                Update Password
              </Button>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: Spacing.lg,
  },
  header: {
    paddingTop: Spacing.lg,
    paddingBottom: Spacing.xl,
    alignItems: 'center',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
  },
  titleSection: {
    marginBottom: Spacing.xl,
  },
  title: {
    fontSize: Typography.display,
    fontWeight: Typography.medium,
    marginBottom: Spacing.sm,
  },
  subtitle: {
    fontSize: Typography.body,
  },
  alert: {
    padding: Spacing.md,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: Spacing.md,
  },
  alertText: {
    fontSize: Typography.callout,
  },
  form: {
    gap: Spacing.md,
  },
  passwordChecks: {
    padding: Spacing.md,
    borderRadius: 12,
    borderWidth: 1,
    gap: Spacing.xs,
  },
  passwordChecksTitle: {
    fontSize: Typography.caption,
    marginBottom: Spacing.xs,
  },
  passwordCheck: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  passwordCheckText: {
    fontSize: Typography.caption,
  },
})
