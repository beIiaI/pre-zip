import { View, Text, StyleSheet } from 'react-native'
import { useRouter } from 'expo-router'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useTheme } from '@/contexts/ThemeContext'
import { Button } from '@/components/ui/Button'
import { PreWordmark } from '@/components/ui/PreWordmark'
import { Spacing, Typography } from '@/constants/theme'

/**
 * Splash screen for unauthenticated users
 * Matches pre-beta splash with sign up / sign in CTAs
 */
export default function SplashScreen() {
  const router = useRouter()
  const { colors } = useTheme()

  return (
    <SafeAreaView
      style={[styles.container, { backgroundColor: colors.surfacePrimary }]}
      edges={['top', 'bottom']}
    >
      <View style={styles.content}>
        <View style={styles.branding}>
          <PreWordmark size="hero" color={colors.contentPrimary} />
          <Text style={[styles.tagline, { color: colors.contentSecondary }]}>
            Connect with people who share your interests
          </Text>
        </View>

        <View style={styles.actions}>
          <Button
            onPress={() => router.push('/auth/signin')}
            variant="primary"
            fullWidth
            testID="splash-signin-button"
          >
            Sign In
          </Button>
          <Button
            onPress={() => router.push('/auth/signup')}
            variant="secondary"
            fullWidth
            testID="splash-signup-button"
          >
            Sign Up
          </Button>
          <Text style={[styles.disclaimer, { color: colors.contentTertiary }]}>
            By continuing, you agree to our Terms of Service and Privacy Policy
          </Text>
        </View>
      </View>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.xxl,
    paddingBottom: Spacing.xl,
  },
  branding: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: Spacing.lg,
  },
  tagline: {
    fontSize: Typography.body,
    textAlign: 'center',
    maxWidth: 280,
    marginTop: Spacing.md,
  },
  actions: {
    gap: Spacing.md,
  },
  disclaimer: {
    fontSize: Typography.caption,
    textAlign: 'center',
    marginTop: Spacing.sm,
  },
})
