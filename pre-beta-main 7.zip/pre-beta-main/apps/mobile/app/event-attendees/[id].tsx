import React, { useState, useCallback, useEffect } from 'react'
import {
  View,
  Text,
  FlatList,
  Pressable,
  StyleSheet,
  RefreshControl,
  ActivityIndicator,
  Image,
  Share,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useLocalSearchParams, useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

// ─── Utils ────────────────────────────────────────────────────────────────────

const AVATAR_COLORS = ['#C45A7A', '#5A7AC4', '#5AC47A', '#C4A45A', '#7A5AC4', '#C45AC4']

function getAvatarColor(id: string): string {
  let h = 0
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0
  return AVATAR_COLORS[Math.abs(h) % AVATAR_COLORS.length]
}

function getInitials(name: string | null, username: string | null): string {
  if (name) return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
  if (username) return username[0].toUpperCase()
  return '?'
}

function formatRsvpTime(iso: string): string {
  const d = new Date(iso)
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) +
    ' at ' +
    d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
}

// ─── Types ────────────────────────────────────────────────────────────────────

interface Attendee {
  user_id: string
  status: 'going' | 'maybe' | 'not_going'
  rsvp_at: string
  profiles: {
    full_name: string | null
    username: string | null
    avatar_url: string | null
    university_name: string | null
    university_verified: boolean
  } | null
}

interface EventInfo {
  id: string
  title: string
  attendee_count: number
  max_attendees: number | null
  creator_id: string
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function EventAttendeesScreen() {
  const { id: eventId } = useLocalSearchParams<{ id: string }>()
  const router = useRouter()
  const { colors } = useTheme()
  const { user } = useAuth()

  const [event, setEvent] = useState<EventInfo | null>(null)
  const [attendees, setAttendees] = useState<Attendee[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  const loadData = useCallback(async (refresh = false) => {
    if (!eventId) return
    if (refresh) setRefreshing(true)
    else setLoading(true)

    const [eventRes, attendeesRes] = await Promise.all([
      supabase
        .from('events')
        .select('id, title, attendee_count, max_attendees, creator_id')
        .eq('id', eventId)
        .single(),
      supabase
        .from('event_attendees')
        .select('user_id, status, rsvp_at, profiles(full_name, username, avatar_url, university_name, university_verified)')
        .eq('event_id', eventId)
        .order('rsvp_at', { ascending: true }),
    ])

    if (eventRes.data) setEvent(eventRes.data as EventInfo)
    if (attendeesRes.data) setAttendees(attendeesRes.data as Attendee[])

    setLoading(false)
    setRefreshing(false)
  }, [eventId])

  useEffect(() => { loadData() }, [loadData])

  const isCreator = event?.creator_id === user?.id

  const goingAttendees = attendees.filter(a => a.status === 'going')
  const otherAttendees = attendees.filter(a => a.status !== 'going')

  const handleShare = async () => {
    if (!event) return
    Haptics.selectionAsync()
    await Share.share({
      message: `Join "${event.title}" on pre!\n\nCurrently ${event.attendee_count} people going.`,
    })
  }

  const renderAttendee = ({ item, index }: { item: Attendee; index: number }) => {
    const name = item.profiles?.full_name ?? item.profiles?.username ?? 'Unknown'
    const initials = getInitials(item.profiles?.full_name ?? null, item.profiles?.username ?? null)
    const avatarColor = getAvatarColor(item.user_id)

    return (
      <Pressable
        onPress={() => { Haptics.selectionAsync(); router.push(`/user/${item.user_id}` as any) }}
        style={[styles.attendeeRow, { borderBottomColor: colors.borderSecondary }]}
      >
        <Text style={[styles.attendeeNumber, { color: colors.contentTertiary }]}>{index + 1}</Text>
        <View style={[styles.attendeeAvatar, { backgroundColor: avatarColor }]}>
          {item.profiles?.avatar_url ? (
            <Image source={{ uri: item.profiles.avatar_url }} style={{ width: 40, height: 40, borderRadius: 20 }} />
          ) : (
            <Text style={styles.attendeeAvatarText}>{initials}</Text>
          )}
        </View>
        <View style={styles.attendeeInfo}>
          <View style={styles.attendeeNameRow}>
            <Text style={[styles.attendeeName, { color: colors.contentPrimary }]} numberOfLines={1}>
              {name}
            </Text>
            {item.profiles?.university_verified && (
              <Ionicons name="checkmark-circle" size={13} color={colors.success} />
            )}
          </View>
          {item.profiles?.username && (
            <Text style={[styles.attendeeUsername, { color: colors.contentSecondary }]}>
              @{item.profiles.username}
            </Text>
          )}
          <Text style={[styles.rsvpTime, { color: colors.contentTertiary }]}>
            RSVP'd {formatRsvpTime(item.rsvp_at)}
          </Text>
        </View>
        <View style={[
          styles.statusBadge,
          {
            backgroundColor: item.status === 'going' ? colors.success + '18' : colors.contentTertiary + '18',
          },
        ]}>
          <View style={[
            styles.statusDot,
            { backgroundColor: item.status === 'going' ? colors.success : colors.contentTertiary },
          ]} />
          <Text style={[
            styles.statusText,
            { color: item.status === 'going' ? colors.success : colors.contentTertiary },
          ]}>
            {item.status === 'going' ? 'Going' : item.status === 'maybe' ? 'Maybe' : 'Declined'}
          </Text>
        </View>
      </Pressable>
    )
  }

  if (loading) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
        <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
          <Pressable onPress={() => router.back()} style={styles.backButton}>
            <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
          </Pressable>
          <Text style={[styles.headerTitle, { color: colors.contentPrimary }]}>Attendees</Text>
          <View style={styles.headerAction} />
        </View>
        <View style={styles.centered}>
          <ActivityIndicator color={colors.contentTertiary} />
        </View>
      </SafeAreaView>
    )
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.borderSecondary }]}>
        <Pressable onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="chevron-back" size={24} color={colors.contentPrimary} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.contentPrimary }]}>Attendees</Text>
        <Pressable onPress={handleShare} style={styles.headerAction}>
          <Ionicons name="share-outline" size={20} color={colors.contentPrimary} />
        </Pressable>
      </View>

      {/* Summary card */}
      {event && (
        <View style={[styles.summaryCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
          <Text style={[styles.summaryTitle, { color: colors.contentPrimary }]} numberOfLines={1}>
            {event.title}
          </Text>
          <View style={styles.summaryStats}>
            <View style={styles.summaryStatItem}>
              <Text style={[styles.summaryStatValue, { color: colors.contentPrimary }]}>
                {goingAttendees.length}
              </Text>
              <Text style={[styles.summaryStatLabel, { color: colors.contentTertiary }]}>Going</Text>
            </View>
            <View style={[styles.summaryDivider, { backgroundColor: colors.borderSecondary }]} />
            <View style={styles.summaryStatItem}>
              <Text style={[styles.summaryStatValue, { color: colors.contentPrimary }]}>
                {event.max_attendees ?? '--'}
              </Text>
              <Text style={[styles.summaryStatLabel, { color: colors.contentTertiary }]}>Capacity</Text>
            </View>
            <View style={[styles.summaryDivider, { backgroundColor: colors.borderSecondary }]} />
            <View style={styles.summaryStatItem}>
              <Text style={[styles.summaryStatValue, { color: colors.contentPrimary }]}>
                {attendees.length}
              </Text>
              <Text style={[styles.summaryStatLabel, { color: colors.contentTertiary }]}>Total RSVPs</Text>
            </View>
          </View>
          {event.max_attendees != null && (
            <View style={styles.capacityBarWrap}>
              <View style={[styles.capacityBarBg, { backgroundColor: colors.borderSecondary }]}>
                <View
                  style={[
                    styles.capacityBarFill,
                    {
                      backgroundColor: goingAttendees.length >= event.max_attendees ? colors.error : colors.success,
                      width: `${Math.min((goingAttendees.length / event.max_attendees) * 100, 100)}%`,
                    },
                  ]}
                />
              </View>
              <Text style={[styles.capacityText, { color: colors.contentTertiary }]}>
                {goingAttendees.length >= event.max_attendees
                  ? 'At capacity'
                  : `${event.max_attendees - goingAttendees.length} spots left`}
              </Text>
            </View>
          )}
        </View>
      )}

      {/* Attendee list */}
      <FlatList
        data={[...goingAttendees, ...otherAttendees]}
        keyExtractor={item => item.user_id}
        renderItem={renderAttendee}
        contentContainerStyle={styles.list}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => loadData(true)}
            tintColor={colors.contentTertiary}
          />
        }
        ListHeaderComponent={
          goingAttendees.length > 0 ? (
            <Text style={[styles.listSectionLabel, { color: colors.contentTertiary }]}>
              GOING ({goingAttendees.length})
            </Text>
          ) : null
        }
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="people-outline" size={48} color={colors.contentTertiary} />
            <Text style={[styles.emptyTitle, { color: colors.contentPrimary }]}>No RSVPs yet</Text>
            <Text style={[styles.emptySub, { color: colors.contentSecondary }]}>
              Share this event to invite people.
            </Text>
          </View>
        }
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  )
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backButton: { width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },
  headerTitle: { flex: 1, fontSize: Typography.headline, fontWeight: '700', marginLeft: Spacing.sm },
  headerAction: { width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },

  summaryCard: {
    margin: Spacing.base,
    borderRadius: BorderRadius.lg,
    borderWidth: StyleSheet.hairlineWidth,
    padding: Spacing.base,
    gap: Spacing.md,
  },
  summaryTitle: { fontSize: Typography.callout, fontWeight: '600' },
  summaryStats: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  summaryStatItem: { flex: 1, alignItems: 'center', gap: 2 },
  summaryStatValue: { fontSize: Typography.headline, fontWeight: '700' },
  summaryStatLabel: { fontSize: Typography.caption },
  summaryDivider: { width: 1, height: 32 },
  capacityBarWrap: { gap: Spacing.xs },
  capacityBarBg: { height: 6, borderRadius: 3, overflow: 'hidden' },
  capacityBarFill: { height: 6, borderRadius: 3 },
  capacityText: { fontSize: Typography.caption, textAlign: 'center' },

  list: {
    paddingBottom: 100,
  },
  listSectionLabel: {
    fontSize: Typography.labelCaps,
    fontWeight: '700',
    letterSpacing: 1,
    textTransform: 'uppercase',
    paddingHorizontal: Spacing.base,
    paddingTop: Spacing.md,
    paddingBottom: Spacing.sm,
  },

  attendeeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    gap: Spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  attendeeNumber: { fontSize: Typography.caption, fontWeight: '500', width: 20, textAlign: 'center' },
  attendeeAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  attendeeAvatarText: { fontSize: 14, fontWeight: '700', color: '#FFFFFF' },
  attendeeInfo: { flex: 1, gap: 1 },
  attendeeNameRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  attendeeName: { fontSize: Typography.callout, fontWeight: '600' },
  attendeeUsername: { fontSize: Typography.caption },
  rsvpTime: { fontSize: Typography.labelCaps },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.full,
  },
  statusDot: { width: 6, height: 6, borderRadius: 3 },
  statusText: { fontSize: Typography.caption, fontWeight: '600' },

  empty: {
    justifyContent: 'center',
    alignItems: 'center',
    gap: Spacing.md,
    paddingVertical: Spacing.xxl * 2,
    paddingHorizontal: Spacing.xl,
  },
  emptyTitle: { fontSize: Typography.headline, fontWeight: '600' },
  emptySub: { fontSize: Typography.callout, textAlign: 'center' },
})
