import React, { useState, useCallback, useEffect } from 'react'
import {
  View,
  Text,
  ScrollView,
  Pressable,
  StyleSheet,
  ActivityIndicator,
  Image,
  Alert,
  Linking,
  Platform,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useLocalSearchParams, useRouter } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import * as Haptics from 'expo-haptics'
import { useTheme } from '@/contexts/ThemeContext'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { BorderRadius, Spacing, Typography } from '@/constants/theme'

// ─── Card palettes (matches home.tsx) ────────────────────────────────────────

const CARD_PALETTES = [
  { bg: '#3D1F0F', text: '#F5E6D8', accent: '#D4845A', sub: '#9A6644' },
  { bg: '#0F1E3D', text: '#D8E6F5', accent: '#5A84D4', sub: '#4464A0' },
  { bg: '#0F3D1F', text: '#D8F5E6', accent: '#5AD484', sub: '#44A064' },
  { bg: '#2A0F3D', text: '#EDD8F5', accent: '#A45AD4', sub: '#7A44A0' },
  { bg: '#0F3A3A', text: '#D8F5F5', accent: '#5AD4C4', sub: '#44A0A0' },
  { bg: '#3D300F', text: '#F5EED8', accent: '#D4B45A', sub: '#A08844' },
]

const AVATAR_COLORS = ['#C45A7A', '#5A7AC4', '#5AC47A', '#C4A45A', '#7A5AC4', '#C45AC4']

function getPaletteIndex(id: string): number {
  let h = 0
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0
  return Math.abs(h) % CARD_PALETTES.length
}

function getAvatarColor(id: string): string {
  let h = 0
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0
  return AVATAR_COLORS[Math.abs(h) % AVATAR_COLORS.length]
}

function getInitials(name: string | null, username: string | null): string {
  if (name) return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
  if (username) return username[0].toUpperCase()
  return '?'
}

function formatDayTime(starts_at: string): string {
  const d = new Date(starts_at)
  const day = d.toLocaleDateString('en-US', { weekday: 'long' }).toUpperCase()
  const time = d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
  return `${day} · ${time}`
}

function getDuration(starts_at: string, ends_at: string): string {
  const mins = (new Date(ends_at).getTime() - new Date(starts_at).getTime()) / 60000
  if (mins < 60) return `${Math.round(mins)} min`
  const hrs = mins / 60
  if (hrs % 1 === 0) return `${Math.round(hrs)} hr`
  return `${Math.floor(hrs)}–${Math.ceil(hrs)} hours`
}

// ─── Types ────────────────────────────────────────────────────────────────────

interface EventDetail {
  id: string
  title: string
  description: string | null
  starts_at: string
  ends_at: string | null
  location: string
  location_text: string | null
  location_lat: number | null
  location_lng: number | null
  attendee_count: number
  max_attendees: number | null
  is_public: boolean
  is_campus_only: boolean
  category: string | null
  creator_id: string
  circle_id: string | null
}

interface Attendee {
  user_id: string
  status: 'going' | 'maybe' | 'not_going'
  profiles: {
    full_name: string | null
    username: string | null
    avatar_url: string | null
  } | null
}

type RsvpStatus = 'going' | 'maybe' | 'not_going' | null

// ─── Nav bar component ────────────────────────────────────────────────────────

function NavBar({
  onBack,
  onEdit,
  showEdit,
  colors,
}: {
  onBack: () => void
  onEdit: () => void
  showEdit: boolean
  colors: any
}) {
  return (
    <View style={[navStyles.bar, { borderBottomColor: colors.borderSecondary }]}>
      <Pressable onPress={onBack} style={navStyles.backBtn} hitSlop={8}>
        <Ionicons name="arrow-back" size={20} color={colors.contentPrimary} />
      </Pressable>
      <Text style={[navStyles.title, { color: colors.contentPrimary }]}>Plan details</Text>
      <View style={navStyles.right}>
        {showEdit && (
          <Pressable onPress={onEdit} style={navStyles.editBtn} hitSlop={8}>
            <Ionicons name="ellipsis-horizontal" size={18} color={colors.contentSecondary} />
          </Pressable>
        )}
      </View>
    </View>
  )
}

const navStyles = StyleSheet.create({
  bar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backBtn: { width: 36, height: 36, justifyContent: 'center', alignItems: 'flex-start' },
  title: { flex: 1, textAlign: 'center', fontSize: Typography.callout, fontWeight: '600' },
  right: { width: 36, height: 36, justifyContent: 'center', alignItems: 'flex-end' },
  editBtn: { padding: 4 },
})

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function EventDetailScreen() {
  const { id: eventId } = useLocalSearchParams<{ id: string }>()
  const router = useRouter()
  const { colors } = useTheme()
  const { user } = useAuth()

  const [event, setEvent] = useState<EventDetail | null>(null)
  const [attendees, setAttendees] = useState<Attendee[]>([])
  const [myRsvp, setMyRsvp] = useState<RsvpStatus>(null)
  const [loading, setLoading] = useState(true)
  const [rsvping, setRsvping] = useState(false)

  const loadEvent = useCallback(async () => {
    if (!eventId || !user) return
    setLoading(true)

    const [eventRes, attendeesRes, myRsvpRes] = await Promise.all([
      supabase
        .from('events')
        .select('id, title, description, starts_at, ends_at, location, location_text, location_lat, location_lng, attendee_count, max_attendees, is_public, is_campus_only, category, creator_id, circle_id')
        .eq('id', eventId)
        .single(),
      supabase
        .from('event_attendees')
        .select('user_id, status, profiles(full_name, username, avatar_url)')
        .eq('event_id', eventId)
        .eq('status', 'going')
        .limit(20),
      supabase
        .from('event_attendees')
        .select('status')
        .eq('event_id', eventId)
        .eq('user_id', user.id)
        .maybeSingle(),
    ])

    if (eventRes.data) setEvent(eventRes.data as EventDetail)
    if (attendeesRes.data) setAttendees(attendeesRes.data as Attendee[])
    if (myRsvpRes.data) setMyRsvp(myRsvpRes.data.status as RsvpStatus)
    setLoading(false)
  }, [eventId, user])

  useEffect(() => { loadEvent() }, [loadEvent])

  const handleRsvp = async (action: 'going' | 'not_going') => {
    if (!user || !eventId || rsvping) return
    setRsvping(true)
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)

    if (action === 'going' && myRsvp !== 'going') {
      const wasGoing = myRsvp === 'going'
      setMyRsvp('going')
      if (!wasGoing) setEvent(e => e ? { ...e, attendee_count: e.attendee_count + 1 } : e)
      const { error } = await supabase
        .from('event_attendees')
        .upsert({ event_id: eventId, user_id: user.id, status: 'going' }, { onConflict: 'event_id,user_id' })
      if (error) {
        setMyRsvp(null)
        setEvent(e => e ? { ...e, attendee_count: Math.max(0, e.attendee_count - 1) } : e)
        Alert.alert('Error', 'Could not update your RSVP.')
      }
    } else if (action === 'not_going' && myRsvp === 'going') {
      setMyRsvp(null)
      setEvent(e => e ? { ...e, attendee_count: Math.max(0, e.attendee_count - 1) } : e)
      await supabase.from('event_attendees').delete().match({ event_id: eventId, user_id: user.id })
    }

    setRsvping(false)
  }

  const openMaps = () => {
    if (!event) return
    const query = encodeURIComponent(event.location_text || event.location)
    const url = Platform.OS === 'ios' ? `maps://?q=${query}` : `geo:0,0?q=${query}`
    Linking.openURL(url).catch(() => Linking.openURL(`https://maps.google.com/?q=${query}`))
  }

  if (loading) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
        <NavBar
          onBack={() => router.back()}
          onEdit={() => {}}
          showEdit={false}
          colors={colors}
        />
        <View style={styles.centered}><ActivityIndicator color={colors.contentTertiary} /></View>
      </SafeAreaView>
    )
  }

  if (!event) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top']}>
        <NavBar
          onBack={() => router.back()}
          onEdit={() => {}}
          showEdit={false}
          colors={colors}
        />
        <View style={styles.centered}>
          <Text style={[styles.errorText, { color: colors.contentPrimary }]}>Plan not found</Text>
        </View>
      </SafeAreaView>
    )
  }

  const pal = CARD_PALETTES[getPaletteIndex(event.id)]
  const isPast = new Date(event.starts_at) < new Date()
  const isFull = event.max_attendees != null && event.attendee_count >= event.max_attendees && myRsvp !== 'going'
  const isGoing = myRsvp === 'going'
  const isCreator = event.creator_id === user?.id

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.surfacePrimary }]} edges={['top', 'bottom']}>
      <NavBar
        onBack={() => router.back()}
        onEdit={() => router.push(`/edit-event/${eventId}` as any)}
        showEdit={isCreator}
        colors={colors}
      />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[styles.scrollContent, { paddingBottom: isPast ? Spacing.xl : 120 }]}
      >
        {/* Hero card */}
        <View style={[styles.heroCard, { backgroundColor: pal.bg }]}>
          <Text style={[styles.heroDateTime, { color: pal.sub }]}>
            {formatDayTime(event.starts_at)}
          </Text>
          <Text style={[styles.heroTitle, { color: pal.text }]}>{event.title}</Text>
          <View style={styles.heroLocationRow}>
            <Ionicons name="location-sharp" size={12} color={pal.sub} />
            <Text style={[styles.heroLocationText, { color: pal.sub }]} numberOfLines={1}>
              {event.location_text || event.location}
            </Text>
          </View>
        </View>

        {/* Going section */}
        <View style={styles.goingSection}>
          <View style={styles.goingHeader}>
            <Text style={[styles.goingLabel, { color: colors.contentTertiary }]}>
              GOING ({event.attendee_count})
            </Text>
            {isCreator && (
              <Pressable
                onPress={() => { Haptics.selectionAsync(); router.push(`/event-attendees/${eventId}` as any) }}
                style={[styles.manageBtn, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}
              >
                <Ionicons name="people-outline" size={13} color={colors.contentSecondary} />
                <Text style={[styles.manageBtnText, { color: colors.contentSecondary }]}>Manage</Text>
              </Pressable>
            )}
          </View>
          <Pressable
            onPress={isCreator ? () => { Haptics.selectionAsync(); router.push(`/event-attendees/${eventId}` as any) } : undefined}
            disabled={!isCreator}
          >
            <View style={styles.goingAvatars}>
              {attendees.slice(0, 7).map(a => (
                <Pressable
                  key={a.user_id}
                  onPress={() => router.push(`/user/${a.user_id}` as any)}
                  style={[styles.goingAvatar, { backgroundColor: getAvatarColor(a.user_id) }]}
                >
                  {a.profiles?.avatar_url ? (
                    <Image
                      source={{ uri: a.profiles.avatar_url }}
                      style={{ width: 44, height: 44, borderRadius: 22 }}
                    />
                  ) : (
                    <Text style={styles.goingAvatarText}>
                      {getInitials(a.profiles?.full_name ?? null, a.profiles?.username ?? null)}
                    </Text>
                  )}
                </Pressable>
              ))}
              {event.attendee_count > 7 && (
                <View style={[styles.goingAvatar, styles.goingAvatarOverflow, { backgroundColor: colors.surfaceElevated, borderColor: colors.borderPrimary }]}>
                  <Text style={[styles.goingAvatarOverflowText, { color: colors.contentSecondary }]}>
                    +{event.attendee_count - 7}
                  </Text>
                </View>
              )}
            </View>
          </Pressable>
        </View>

        {/* Details card */}
        <View style={[styles.detailsCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
          {event.ends_at && (
            <>
              <View style={styles.detailRow}>
                <Ionicons name="time-outline" size={17} color={colors.contentTertiary} />
                <Text style={[styles.detailText, { color: colors.contentPrimary }]}>
                  {getDuration(event.starts_at, event.ends_at)}
                </Text>
              </View>
              <View style={[styles.detailDivider, { backgroundColor: colors.borderSecondary }]} />
            </>
          )}
          {event.max_attendees && (
            <>
              <View style={styles.detailRow}>
                <Ionicons name="people-outline" size={17} color={colors.contentTertiary} />
                <Text style={[styles.detailText, { color: colors.contentPrimary }]}>
                  Max {event.max_attendees} people
                </Text>
              </View>
              <View style={[styles.detailDivider, { backgroundColor: colors.borderSecondary }]} />
            </>
          )}
          <Pressable style={styles.detailRow} onPress={openMaps}>
            <Ionicons name="location-outline" size={17} color={colors.contentTertiary} />
            <Text style={[styles.detailText, { color: colors.contentPrimary }]} numberOfLines={1}>
              {event.location_text || event.location}
            </Text>
            <Ionicons name="open-outline" size={13} color={colors.contentTertiary} style={{ marginLeft: 'auto' }} />
          </Pressable>
        </View>

        {/* Description */}
        {event.description && (
          <View style={[styles.descCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
            <Text style={[styles.descText, { color: colors.contentSecondary }]}>
              {event.description}
            </Text>
          </View>
        )}

        {/* Past banner */}
        {isPast && (
          <View style={[styles.pastBanner, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderSecondary }]}>
            <Ionicons name="time-outline" size={15} color={colors.contentTertiary} />
            <Text style={[styles.pastText, { color: colors.contentTertiary }]}>This plan has already passed</Text>
          </View>
        )}
      </ScrollView>

      {/* Sticky CTA */}
      {!isPast && (
        <View style={[styles.ctaWrap, { backgroundColor: colors.surfacePrimary, borderTopColor: colors.borderSecondary }]}>
          {isGoing ? (
            <View style={styles.ctaRow}>
              <View style={[styles.goingBadge, { backgroundColor: colors.surfaceSecondary, borderColor: colors.borderPrimary }]}>
                <Ionicons name="checkmark" size={15} color={colors.success} />
                <Text style={[styles.goingBadgeText, { color: colors.contentPrimary }]}>You're going</Text>
              </View>
              <Pressable
                onPress={() => handleRsvp('not_going')}
                style={[styles.cantGoBtn, { borderColor: colors.borderPrimary }]}
                disabled={rsvping}
              >
                <Text style={[styles.cantGoBtnText, { color: colors.contentTertiary }]}>Can't go</Text>
              </Pressable>
            </View>
          ) : (
            <Pressable
              onPress={() => handleRsvp('going')}
              style={[styles.imGoingBtn, { backgroundColor: colors.contentPrimary, opacity: rsvping || isFull ? 0.5 : 1 }]}
              disabled={rsvping || isFull}
            >
              <Ionicons name="checkmark" size={17} color={colors.contentInverse} />
              <Text style={[styles.imGoingText, { color: colors.contentInverse }]}>
                {isFull ? 'Event is full' : "I'm going"}
              </Text>
            </Pressable>
          )}
        </View>
      )}
    </SafeAreaView>
  )
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  errorText: { fontSize: Typography.headline, fontWeight: '600' },

  scrollContent: {
    padding: Spacing.base,
    gap: Spacing.base,
  },

  heroCard: {
    borderRadius: BorderRadius.xl,
    padding: Spacing.lg,
    gap: Spacing.sm,
  },
  heroDateTime: {
    fontSize: Typography.caption,
    fontWeight: '600',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
  },
  heroTitle: {
    fontSize: Typography.title,
    fontWeight: '700',
    lineHeight: Typography.title * 1.2,
  },
  heroLocationRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  heroLocationText: { fontSize: Typography.caption, flex: 1 },

  goingSection: { gap: Spacing.sm },
  goingHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  manageBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.full,
    borderWidth: StyleSheet.hairlineWidth,
  },
  manageBtnText: { fontSize: Typography.caption, fontWeight: '500' },
  goingLabel: {
    fontSize: Typography.caption,
    fontWeight: '700',
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  goingAvatars: { flexDirection: 'row', gap: Spacing.sm, flexWrap: 'wrap' },
  goingAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  goingAvatarText: { fontSize: 14, fontWeight: '700', color: '#FFFFFF' },
  goingAvatarOverflow: { borderWidth: 1 },
  goingAvatarOverflowText: { fontSize: Typography.caption, fontWeight: '600' },

  detailsCard: {
    borderRadius: BorderRadius.lg,
    borderWidth: StyleSheet.hairlineWidth,
    overflow: 'hidden',
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    paddingHorizontal: Spacing.base,
    paddingVertical: 15,
  },
  detailText: { fontSize: Typography.callout, flex: 1 },
  detailDivider: { height: StyleSheet.hairlineWidth, marginHorizontal: Spacing.base },

  descCard: {
    borderRadius: BorderRadius.lg,
    borderWidth: StyleSheet.hairlineWidth,
    padding: Spacing.base,
  },
  descText: { fontSize: Typography.callout, lineHeight: Typography.callout * 1.6 },

  pastBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    padding: Spacing.base,
    borderRadius: BorderRadius.lg,
    borderWidth: StyleSheet.hairlineWidth,
  },
  pastText: { fontSize: Typography.callout },

  ctaWrap: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: Spacing.base,
    paddingBottom: Spacing.lg,
    borderTopWidth: StyleSheet.hairlineWidth,
  },
  ctaRow: { flexDirection: 'row', gap: Spacing.sm, alignItems: 'center' },
  goingBadge: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
  },
  goingBadgeText: { fontSize: Typography.callout, fontWeight: '600' },
  cantGoBtn: {
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
  },
  cantGoBtnText: { fontSize: Typography.callout, fontWeight: '500' },
  imGoingBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    paddingVertical: 16,
    borderRadius: BorderRadius.xl,
  },
  imGoingText: { fontSize: Typography.callout, fontWeight: '600' },
})
